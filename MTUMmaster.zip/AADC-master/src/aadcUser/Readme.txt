In diesem Ordner sind die Includes, Descriptions und die Sourcen der demo-Filter enthalten.

Folders:
* src:		Hier ist der Quellcode der Basisssystemfilter enthalten
* description:	Hier koennen Description-Dateien fuer ADTF abgelegt werden
* include:	Hier liegen Header-Dateien, die von allen Quellen geladen werden koennnen


Files:
* CMakeLists.txt:	Datei der CMake kette
* Readme.txt:		Diese Datei