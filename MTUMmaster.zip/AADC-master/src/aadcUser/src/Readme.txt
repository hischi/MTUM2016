In diesem Ordner sind die Sourcen enthalten.

Folders:
* AADC_PIDController:		Dieser Filter stellt einen einfachen P/PI/PID Regler dar. An den Eing�ngen Setpoint und measured variable wird ein Sollwert und die Messgr��e angenommen, am Ausgang liefert er dann die berechnete Stellgr��e, die auf den Aktuator gegeben werden muss. Je nach Anwendungsfall muss noch ein Kalibrationsfilter zwischengeschaltet werden.
* AADC_MarkerDetection:		Quellcode der Library zur Verkehrszeichenerkennung 	

Files:
* Readme.txt:		Diese Datei