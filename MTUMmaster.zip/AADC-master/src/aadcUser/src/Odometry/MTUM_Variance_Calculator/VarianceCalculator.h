/**
 *
 * ADTF Template Project Filter.
 *
 * @file
 * Copyright &copy; Audi Electronics Venture GmbH. All rights reserved
 *
 * $Author: belkera $
 * $Date: 2011-06-30 16:51:21 +0200 (Do, 30 Jun 2011) $
 * $Revision: 26514 $
 *
 * @remarks
 *
 */
#pragma once

#define OID_Variance_Filter "adtf.test.Variance_filter"
#include <deque>
#undef __USE_SVID
#undef __USE_MISC
#include <math.h>



//*************************************************************************************************
class cVariance : public adtf::cFilter
{
    ADTF_FILTER(OID_Variance_Filter, "Variance Filter", adtf::OBJCAT_DataFilter);

protected:
    cInputPin    m_oTemplateInput;
    cOutputPin    m_oTemplateOutput;
    tUInt32 lastTick;
    tFloat32 outputValue;
    struct signalValue{
       tUInt32 timestamp;
       tFloat32 value;
    };
    deque<tFloat32> data;
    tFloat32 sum;
    int numberSamples;
    int numberOutputs;
    int displayCounter;

    enum state{START,INCREASEVALUE,GO,STOP};
    state myState;
public:
    tFloat32 processData(tUInt32 ticks);
    cVariance(const tChar* __info);
    virtual ~cVariance();

protected:
    tResult Init(tInitStage eStage, __exception);
    tResult Shutdown(tInitStage eStage, __exception);

    // implements IPinEventSink
    tResult OnPinEvent(IPin* pSource,
                       tInt nEventCode,
                       tInt nParam1,
                       tInt nParam2,
                       IMediaSample* pMediaSample);
};

//*************************************************************************************************
 // _TEMPLATE_PROJECT_FILTER_H_
