#pragma once
#include <deque>
#include <algorithm>
#include "IParent.h"

using namespace cv;
using namespace std;
class OdometryKalman
{
public:
	struct wheelStruct{
		tUInt32 ticks;
		tUInt32 ticksLast;
		tUInt32 time;
		tUInt32 timeLast;
		uchar dir;
		tUInt32 zeroCounter;
		tUInt64 streamTime;
		bool updated;
		bool first =true;
	};


    OdometryKalman( IParent* parent);
	~OdometryKalman();
	virtual void predict();
	void updateImU(float accY, float accX, float accZ, float yaw);
	void updateAcc(float acc);
	void updateYaw(float yaw);
	void updateTicksLeft(tUInt32 ticksL, tUInt8 dirL, tUInt32 timeL);
	void updateTicksRight(tUInt32 ticksR, tUInt8 dirR, tUInt32 timeR);
    void resetState();
    void cycle();
	void updateTicks(tUInt32 ticks, tUInt8 dir, tUInt32 time, wheelStruct &wh);
	bool checkTicks(tFloat &velocity, wheelStruct &wh);

    bool isReady();

private:
	tBool gyro_check(const tOdometryData &odo);

	cMutex reset_mux;
	float accX, accY, accZ, yaw;
    tUInt64 lastStreamTime;
	Mat transitionMatrix;
	KalmanFilter KF;
	Mat measurement;
	Mat control;
    Mat processNoiseCov;
    tUInt odometryState;
    enum OdometryState { ODO_INITIAL, ODO_STARTUP, ODO_GO};
    tUInt64 startTime;
    tUInt prop_startup_interval;
    std::pair<float,float> computeMeanVar(deque<float> values);
	tFloat smoothSavitzkyGolay5(tFloat value, deque<tFloat> &values);
	void initSavitzkyGolay7(deque<tFloat>& deque1);
	tFloat smoothSavitzkyGolay7(tFloat value, deque<tFloat> &values);

	deque<tFloat> speedValues;

	// values for Acceleration in driving direction
	int startCounter;
	float accOffset = 0;
	const int startCounterMax;
	bool updatedAcc;
	const float accVAR;
	const float accVARnoSense;


	// values for Gyro Yaw
	int startCounterYaw;
	bool startingYaw = true;
    bool startingAcc = true;
	deque<float> startValuesYaw;
    deque<float> startValuesAcc;
	const int startCounterYawMax;
    const float prop_startValuesYawEpilon;
    const float prop_startValuesYawLength;
    const float prop_startValuesAccLength = 100;
    const float prop_startValuesAccVar = 1e-4;
	float yawStart;
	bool updatedYaw;

	float check_phi_old;
	wheelStruct wheelR, wheelL;
	tOdometryData state;
	IParent* const parent;



};

