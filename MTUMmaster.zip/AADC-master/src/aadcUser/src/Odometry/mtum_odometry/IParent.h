#pragma once

#include "stdafx.h"
#include "OdometryDataType.h"
#include "StatusMessage.h"
class IParent
{
public:

    virtual void writeOdometry(tOdometryData &o)=0;
    virtual bool accConnected()=0;
    virtual bool initializeYaw()=0;
    virtual tUInt64 getTime()=0;
    virtual tResult SendStatusMessage(mtum_filters destination, mtum_status_messages content)=0;
	IParent()
	{
	}

	~IParent()
	{
	}
	float ticksPerM;
	float axleWidth;
	float vehicleLength;
    uint prop_startup_time;
};

