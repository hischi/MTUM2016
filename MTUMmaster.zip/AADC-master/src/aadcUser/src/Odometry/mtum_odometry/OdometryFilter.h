/**
 *
 * Demo Real Time Filter
 *
 * @file
 * Copyright &copy; Audi Electronics Venture GmbH. All rights reserved
 *
 * $Author: A1RHEND $
 * $Date: 2013-04-11 17:25:32 +0200 (Thu, 11 Apr 2013) $
 * $Revision: 37969 $
 *
 * @remarks
 *
 */
#ifndef _MTUM_ODOMETRY_FILTER_HEADER_
#define _MTUM_ODOMETRY_FILTER_HEADER_

#define OID_ADTF_MTUM_ODOMETRY_FILTER "adtf.example.demo_realtime"

#include <string>
#include <sstream>
#include "IParent.h"
#include "OdometryKalman.h"
#include "WheelDataType.h"
#include "SignalValueType.h"
#include "OdometryDataType.h"
#include "StatusMessage.h"
class cOdometry : public cFilter, public IParent
{
    ADTF_FILTER(OID_ADTF_MTUM_ODOMETRY_FILTER, "Momentum Odometry Filter", OBJCAT_Tool)

    private:
        // this is the handle for our real-time timer
        tHandle m_hTimer;

        // this queue will pass samples between non-real-time threads and our real-time timer
        typedef cLockFreeQueue<IMediaSample*> tQueue;

        tQueue* m_pQueueWheelLeft;
        tQueue* m_pQueueWheelRight;
        tQueue* m_pQueueAccY;
        tQueue* m_pQueueYaw;

        // our pins
        cInputPin  m_oInputWhL;
        cInputPin  m_oInputWhR;
        cInputPin  m_oInputYaw;
        cInputPin  m_oInputAccY;
        cOutputPin m_oOutputOdometry;
        cOutputPin   m_oStatusOutput;   // output pin for mtum-status-feedback
        cInputPin   m_oStatusInput;



        OdometryKalman* odometry;



        tUInt32 TachL;
        tUInt32 TachR;
        tUInt8  DirL;
        tUInt8  DirR;

        tUInt64 timestamp;

        // this will tell the timer handling if the filter is activated or not
        volatile tBool m_bRunning;

        tResult DecodeStatusMessage(IMediaSample* pMediaSample);

    public: // construction
        cOdometry(const tChar* __info);

    public: // overrides cBaseFilter
        tResult Init(tInitStage eStage, __exception);
        tResult Start(__exception);
        tResult Stop(__exception);
        tResult Shutdown(tInitStage eStage, __exception);
        tResult CreatePins(__exception);
        tUInt64 getTime();
        tResult SendStatusMessage(mtum_filters destination, mtum_status_messages content);
        bool initializeYaw();
        bool accConnected(){return m_oInputAccY.IsConnected();}
    public: // overrides IRunnable implementation
        tResult Run(tInt nActivationType, const tVoid* pvUserData, tInt szUserDataSize, __exception);

    public: // overrides IPinEventSink
        tResult OnPinEvent(IPin* pSource,
                           tInt nEventCode,
                           tInt nParam1,
                           tInt nParam2,
                           IMediaSample* pMediaSample);
    public: // overrides IParent
        void writeOdometry(tOdometryData &odom)  override;

    int GetWheelDataFromQueue(tQueue* queue, tWheelData &wheelData, tUInt64 &timestamp);
    int GetSignalValueFromQueue(tQueue* queue, tSignalValue &signalValue);
};

//*************************************************************************************************
#endif
