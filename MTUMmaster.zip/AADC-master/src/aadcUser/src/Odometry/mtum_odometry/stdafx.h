/**
 *
 * ADTF Demo Source.
 *
 * @file
 * Copyright &copy; Audi Electronics Venture GmbH. All rights reserved
 *
 * $Author: belkera $
 * $Date: 2011-06-30 16:51:21 +0200 (Thu, 30 Jun 2011) $
 * $Revision: 26514 $
 *
 * @remarks
 *
 */
#ifndef __STD_INCLUDES_HEADER
#define __STD_INCLUDES_HEADER

#undef __USE_SVID
#undef __USE_MISC
#include "opencv2/video/tracking.hpp"
#include "opencv2/highgui/highgui.hpp"

#include <adtf_plugin_sdk.h>
using namespace adtf;

#endif // __STD_INCLUDES_HEADER
