/**
 *
 * Demo Real-Time Filter
 *
 * @file
 * Copyright &copy; Audi Electronics Venture GmbH. All rights reserved.
 *
 * @author               $Author: AHAUSMA $
 * @date                 $Date: 2012-11-21 11:20:50 +0100 (Wed, 21 Nov 2012) $
 * @version              $Revision: 35564 $
 *
 * @remarks
 *
 */

/**
 * \page page_demo_realtime Demo Real-Time Filter
 *
 * Implements a filter which handles incoming data in a real-time cyclic timer.
 * Please have a look at the @ref page_demo_realtime_bridge as well. Please note that real-time capabilities are supported on Linux only.
 *
 * \par Location
 * \code
 *    ./src/examples/src/filters/demo_realtime/
 * \endcode
 *
 * \par Build Environment
 * To see how to set up the build environment have a look at this page @ref page_cmake_overview
 *
 * \par This example shows:
 * \li how to implement a time triggered adtf filter for processing data
 * \li how to pass media samples from non-real-time threads to real-time timers
 *
 * \par Debugging
 *
 * Note that the source code of a all classes provided in the ADTF SDK is installed as well, so you can use it to debug your filter.
 *
 * \par The Header for the Demo Real-Time Filter
 * \include demo_realtime.h
 *
 * \par The Implementation for the Demo Real-Time Filter
 * \include demo_realtime.cpp
 *
 */