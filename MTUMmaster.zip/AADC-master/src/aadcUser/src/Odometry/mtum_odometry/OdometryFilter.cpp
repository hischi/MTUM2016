/**
 *
 * Demo Real Time Filter
 *
 * @file
 * Copyright &copy; Audi Electronics Venture GmbH. All rights reserved
 *
 * $Author: A1RHEND $
 * $Date: 2013-04-11 17:25:32 +0200 (Thu, 11 Apr 2013) $
 * $Revision: 37969 $
 *
 * @remarks
 *
 */
#include "stdafx.h"
#include "OdometryFilter.h"
#include "StatusMessage.h"
#include <iostream>

/// Create filter plugin
ADTF_FILTER_PLUGIN("MTUM Odometry Filter", OID_ADTF_MTUM_ODOMETRY_FILTER, cOdometry)

cOdometry::cOdometry(const tChar* __info) : adtf::cFilter(__info)
{
    m_hTimer = NULL;
    m_bRunning = tFalse;
    TachL =0;
    TachR =0;
    DirL =0;


    SetPropertyFloat("axle_distance", 0.36);
    SetPropertyStr("axle_distance" NSSUBPROP_DESCRIPTION, "The distance between rear axle and front axle");
    SetPropertyInt("axle_distance" NSSUBPROP_MIN, 0.3);

    SetPropertyFloat("wheel_distance", 0.26);
    SetPropertyStr("wheel_distance" NSSUBPROP_DESCRIPTION, "The distance between left and right wheel");
    SetPropertyInt("wheel_distance" NSSUBPROP_MIN, 0.3);

    SetPropertyFloat("ticks_per_m", 183);
    SetPropertyStr("ticks_per_m" NSSUBPROP_DESCRIPTION, "The number of wheel encoder ticks while driving one meter");
    SetPropertyInt("ticks_per_m" NSSUBPROP_MIN, 1);

    SetPropertyBool("initialize Yaw", tTrue);

    SetPropertyInt("queue_size", 50);
    SetPropertyStr("queue_size" NSSUBPROP_DESCRIPTION, "The maximum size of the intermediate queues.");
    SetPropertyInt("queue_size" NSSUBPROP_MIN, 1);

    SetPropertyInt("cycle_time", 25000);
    SetPropertyStr("cycle_time" NSSUBPROP_GLOBALCONFIGPROPERTYNAME, "Odometry cycle time");
    SetPropertyStr("cycle_time" NSSUBPROP_GLOBALCONFIGPROPERTYNAME NSSUBPROP_DESCRIPTION, "The odometry cycle time in microseconds");
    SetPropertyInt("cycle_time" NSSUBPROP_MIN, 1);

    SetPropertyInt("startup time", 7);
    SetPropertyStr("startup time" NSSUBPROP_DESCRIPTION, "startup time in s");
    SetPropertyInt("startup time" NSSUBPROP_MIN, 0);

    SetPropertyBool("use_real_time_prio", tFalse);
    SetPropertyStr("use_real_time_prio" NSSUBPROP_DESCRIPTION, "Whether or not to use real-time priority for the timer "
                   "(requires the appropriate permissions).");

}

tResult cOdometry::CreatePins(__exception)
{

    // creates the output pins
    RETURN_IF_FAILED(m_oOutputOdometry.Create("odometry", new cMediaType(0,0,0,ODOMETRYDATA), static_cast<IPinEventSink*> (this)));
    RETURN_IF_FAILED(RegisterPin(&m_oOutputOdometry));

    RETURN_IF_FAILED(m_oStatusOutput.Create("status_output", new cMediaType(0,0,0,STATUSMESSAGE), this));
    RETURN_IF_FAILED(RegisterPin(&m_oStatusOutput));

    RETURN_IF_FAILED(m_oStatusInput.Create("status_input", new cMediaType(0,0,0,STATUSMESSAGE), this));
    RETURN_IF_FAILED(RegisterPin(&m_oStatusInput));

    // create the input pins
    RETURN_IF_FAILED(m_oInputWhL.Create("wheelticks_left", new cMediaType(0, 0, 0, WHEELDATA), static_cast<IPinEventSink*> (this)));
    RETURN_IF_FAILED(RegisterPin(&m_oInputWhL));
    RETURN_IF_FAILED(m_oInputWhR.Create("wheelticks_right", new cMediaType(0, 0, 0, WHEELDATA), static_cast<IPinEventSink*> (this)));
    RETURN_IF_FAILED(RegisterPin(&m_oInputWhR));
    RETURN_IF_FAILED(m_oInputYaw.Create("yaw", new cMediaType(0, 0, 0, SIGNALVALUE), static_cast<IPinEventSink*> (this)));
    RETURN_IF_FAILED(RegisterPin(&m_oInputYaw));
    RETURN_IF_FAILED(m_oInputAccY.Create("accY",new cMediaType(0, 0, 0, SIGNALVALUE), static_cast<IPinEventSink*> (this)));
    RETURN_IF_FAILED(RegisterPin(&m_oInputAccY));



    LOG_INFO("ODOMETRY: CREATED PINS");
    RETURN_NOERROR;
}

tUInt64 cOdometry::getTime()
{
    return _clock->GetStreamTime();
}

tResult cOdometry::Init(tInitStage eStage, __exception)
{
    // call parent first
    RETURN_IF_FAILED(cFilter::Init(eStage, __exception_ptr));

    if (StageFirst == eStage)
    {
        CreatePins(__exception_ptr);
    }
    else if (StageGraphReady == eStage)
    {
        // initialize our intermediate sample queue.
        // note that the queue pre-allocates all elements and thus does not require
        // any dynamic memory allocation later on.
        //m_pQueue = new tQueue(GetPropertyInt("queue_size"), tFalse);
        m_pQueueWheelLeft = new tQueue(GetPropertyInt("queue_size"),tFalse);
        m_pQueueWheelRight = new tQueue(GetPropertyInt("queue_size"),tFalse);
        m_pQueueAccY = new tQueue(GetPropertyInt("queue_size"),tFalse);
        m_pQueueYaw = new tQueue(GetPropertyInt("queue_size"),tFalse);

        ticksPerM = GetPropertyFloat("ticks_per_m");
        axleWidth = GetPropertyFloat("wheel_distance");
        vehicleLength = GetPropertyFloat("axle_distance");
        prop_startup_time = GetPropertyFloat("startup time");

        tFloat32 cycle_time = GetPropertyInt("cycle_time"); //cycle time in us
        // convert to s:
        cycle_time /= 1000000;
        std::stringstream ss;
        ss << "cycle time: " << cycle_time << "s";
        LOG_INFO(ss.str().c_str());
        odometry = new  OdometryKalman(this);

        tUInt32 nFlags = 0;

        // Create our cyclic timer.
        // we do this here and not in Start() to prevent the impact of
        // the thread creation during RL_Running
        cString strTimerName = OIGetInstanceName();
        strTimerName += ".rttimer1";
        m_hTimer = _kernel->TimerCreate(GetPropertyInt("cycle_time"),
                                        0,
                                        static_cast<IRunnable*>(this),
                                        NULL,
                                        NULL,
                                        0,
                                        nFlags,
                                        strTimerName);
        if (!m_hTimer)
        {
            THROW_ERROR_DESC(ERR_UNEXPECTED, "Unable to create timer");
        }
    }

    RETURN_NOERROR;
}


tResult cOdometry::Start(__exception)
{
    RETURN_IF_FAILED(adtf::cFilter::Start(__exception_ptr));

    // reinitialize our statistics variables
    TachL =0;
    TachR =0;
    // tell the timer handler to start working
    m_bRunning = tTrue;
    odometry->resetState();
    RETURN_NOERROR;
}

tResult cOdometry::Stop(__exception)
{
    // tell the timer handler to stop working
    m_bRunning = tFalse;

    return cFilter::Stop(__exception_ptr);
}

tResult cOdometry::Shutdown(tInitStage eStage, __exception)
{
    if (StageGraphReady == eStage)
    {
        if (m_hTimer)
        {
            // Destroy the timer
            _kernel->TimerDestroy(m_hTimer);
            m_hTimer = NULL;
        }
        IMediaSample* pSample = NULL;
        while (IS_OK(m_pQueueAccY->Pop(&pSample)))
             pSample->Unref();
        while (IS_OK(m_pQueueYaw->Pop(&pSample)))
             pSample->Unref();
        while (IS_OK(m_pQueueWheelLeft->Pop(&pSample)))
             pSample->Unref();
        while (IS_OK(m_pQueueWheelRight->Pop(&pSample)))
             pSample->Unref();

        // release our queue
        delete m_pQueueYaw;
        delete m_pQueueAccY;
        delete m_pQueueWheelLeft;
        delete m_pQueueWheelRight;

        m_pQueueYaw = NULL;
        m_pQueueAccY = NULL;
        m_pQueueWheelRight = NULL;
        m_pQueueWheelLeft= NULL;

        delete odometry;
        odometry = NULL;
    }
    return cFilter::Shutdown(eStage, __exception_ptr);
}


tResult cOdometry::SendStatusMessage(mtum_filters destination, mtum_status_messages content)
{
    // now we need a new media sample to forward the data.
    cObjectPtr<IMediaSample> pNewSample;
    if (IS_OK(AllocMediaSample(&pNewSample)))
    {
        // now set its data
        // we reuse the timestamp from the incoming media sample. Please see the api documentation
        // (ADTF Extreme Programmers -> The ADTF Streamtime) for further reference on how sample times are handled in ADTF
        tStatusMessage data;
        data.destination = destination;
        data.source = ODOMETRY;
        data.content = content;
        pNewSample->Update(_clock->GetStreamTime(), &data, sizeof(tStatusMessage), 0);

        // and now we can transmit it
        m_oStatusOutput.Transmit(pNewSample);
    }

    RETURN_NOERROR;
}

tResult cOdometry::DecodeStatusMessage(IMediaSample* pMediaSample)
{
    // this will store the value for our new sample
    tStatusMessage status_message;

    // now lets access the data in the sample,
    // the Lock method gives you access to the buffer of the sample.
    // we use a scoped sample lock to ensure that the lock is released in all circumstances.

    {
        // this will aquire the read lock on the sample and declare and initialize a pointer to the data
        __sample_read_lock(pMediaSample, tStatusMessage, pData);
        // now we can access the sample data through the pointer
        status_message = *pData;
        // the read lock on the sample will be released when leaving this scope
    }

    if(status_message.destination == mtum_filters(ODOMETRY) || status_message.destination == mtum_filters(ALL))
    {
        switch(status_message.content)
        {
        case RESET:
            odometry->resetState();
            break;
        case IS_READY:
            if(odometry->isReady())
                SendStatusMessage(mtum_filters(CAR_CONTROL), READY);
            else
                SendStatusMessage(mtum_filters(CAR_CONTROL), NOT_READY);
            break;
        }
    }


    RETURN_NOERROR;
}

bool cOdometry::initializeYaw(){return m_oInputYaw.IsConnected() && GetPropertyBool("initialize Yaw");}
tResult cOdometry::OnPinEvent(IPin* pSource, tInt nEventCode, tInt nParam1, tInt nParam2, IMediaSample* pMediaSample)
{
    if (IPinEventSink::PE_MediaSampleReceived == nEventCode)
    {
        if(pSource == &m_oStatusInput){
            DecodeStatusMessage(pMediaSample);
        }
        if(pSource == &m_oInputWhL){
            // all we have to do is push the sample onto the queue

            if (IS_FAILED(m_pQueueWheelLeft->Push(pMediaSample)))
            {
                IMediaSample* so;
                RETURN_IF_FAILED(m_pQueueWheelLeft->Pop(&so));
                so->Unref();
                RETURN_IF_FAILED(m_pQueueWheelLeft->Push(pMediaSample));
                pMediaSample->Ref();
                //LOG_ERROR("Queue overflow");
                //RETURN_ERROR(ERR_MEMORY);
            }else
                pMediaSample->Ref();
        }
        if(pSource == &m_oInputWhR){
            // all we have to do is push the sample onto the queue

            if (IS_FAILED(m_pQueueWheelRight->Push(pMediaSample)))
            {
                IMediaSample* so;
                RETURN_IF_FAILED(m_pQueueWheelRight->Pop(&so));
                so->Unref();
                RETURN_IF_FAILED(m_pQueueWheelRight->Push(pMediaSample));
                pMediaSample->Ref();
            }else
                pMediaSample->Ref();
        }
        if(pSource == &m_oInputAccY){
            // all we have to do is push the sample onto the queue

            if (IS_FAILED(m_pQueueAccY->Push(pMediaSample)))
            {
                IMediaSample* so;
                RETURN_IF_FAILED(m_pQueueAccY->Pop(&so));
                so->Unref();
                RETURN_IF_FAILED(m_pQueueAccY->Push(pMediaSample));
                pMediaSample->Ref();
            }else
                pMediaSample->Ref();
        }
        if(pSource == &m_oInputYaw){
            // all we have to do is push the sample onto the queue

            if (IS_FAILED(m_pQueueYaw->Push(pMediaSample)))
            {
                IMediaSample* so;
                RETURN_IF_FAILED(m_pQueueYaw->Pop(&so));
                so->Unref();
                RETURN_IF_FAILED(m_pQueueYaw->Push(pMediaSample));
                pMediaSample->Ref();
            }else
                pMediaSample->Ref();
        }
    }

    RETURN_NOERROR;
}
int cOdometry::GetWheelDataFromQueue(tQueue* queue, tWheelData& wd,tUInt64& timestamp){
    IMediaSample* pSample = NULL;
    int num =0;
    // get only last sample
    while (IS_OK(queue->Pop(&pSample)))
    {
       //read lock
       {
            __sample_read_lock(pSample, tWheelData, pData);
            timestamp = pSample->GetTime();
            wd = *pData;
            // the read lock on the sample will be released when leaving this scope
        }

        pSample->Unref();
        num ++;

    }
    return num;
}
int cOdometry::GetSignalValueFromQueue(tQueue* queue, tSignalValue& sv){
    IMediaSample* pSample = NULL;
    int num =0;
    // get only last sample
    while (IS_OK(queue->Pop(&pSample)))
    {
        //read lock
        {
             __sample_read_lock(pSample, tSignalValue, pData);

             sv = *pData;
             // the read lock on the sample will be released when leaving this scope
         }

         pSample->Unref();
         num ++;
    }
   return num;
}


tResult cOdometry::Run(tInt nActivationType, const tVoid* pvUserData, tInt szUserDataSize, __exception)
{
    // if it's the timer, and we have been started
    if (nActivationType == IRunnable::RUN_TIMER && m_bRunning)
    {

        tWheelData wheelL, wheelR;
        tSignalValue yaw, accy;
        tUInt64 timeL, timeR;

        // get SignalValue Samples from their queue
        int numacc =  GetSignalValueFromQueue(m_pQueueAccY,accy);
        int numyaw = GetSignalValueFromQueue(m_pQueueYaw,yaw);

        // get WheelTick samples from their queue
        int numl = GetWheelDataFromQueue(m_pQueueWheelLeft, wheelL,timeL);
        int numr = GetWheelDataFromQueue(m_pQueueWheelRight, wheelR,timeR);


        if(numl >0)
            odometry->updateTicksLeft(wheelL.tach,wheelL.dir,timeL);
        if(numr >0)
            odometry->updateTicksRight(wheelR.tach,wheelR.dir,timeR);
        if(numacc>0)
            odometry->updateAcc(accy.value);
        if(numyaw>0){
            tFloat32 angle = yaw.value*3.141592654/180;
            odometry->updateYaw(angle);
        }
       // cout << "got new samples: Wheel left: " << numl <<" Wheel right: " << numr << " Acc: " << numacc << " Yaw: " << numyaw << " passed microsecs: " <<_clock->GetStreamTime()-timestamp << endl;
        timestamp = _clock->GetStreamTime();
        odometry->cycle();
        //std::stringstream ss;
        //ss << "dx:" << dx << " dy:" << dy << " phi: " <<phi<< " vel: "<< vel << " steering: "<< steering;
        //LOG_WARNING(ss.str().c_str());
        //create new media sample

    }

    RETURN_NOERROR;
}


void cOdometry::writeOdometry(tOdometryData &odom)
{

    cObjectPtr<IMediaSample> pNewSample;
    if (IS_OK(AllocMediaSample(&pNewSample)))
    {
        // now set its data
        // we reuse the timestamp from the incoming media sample. Please see the api documentation
        // (ADTF Extreme Programmers -> The ADTF Streamtime) for further reference on how sample times are handled in ADTF
        pNewSample->Update(_clock->GetStreamTime(), &odom, sizeof(tOdometryData), 0);

        // and now we can transmit it
        m_oOutputOdometry.Transmit(pNewSample);
    }


}
