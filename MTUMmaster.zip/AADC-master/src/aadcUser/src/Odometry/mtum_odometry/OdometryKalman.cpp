#include "stdafx.h"
#include "OdometryKalman.h"
#include <iostream>
//#define debugOutput

OdometryKalman::OdometryKalman(IParent* parent)
    :startCounterMax(10),
    accVAR(5.8e-4),
    accVARnoSense(1e-3),
    startCounterYawMax(100),
    prop_startValuesYawEpilon(0.5),
    prop_startValuesYawLength(100),
    parent(parent)
{
    resetState();
#ifdef debugOutput
	std::cout << "kalman filter: \nProcess noise Covariance:\n" << KF.processNoiseCov << "\nmeasurementNoiseCov:\n" << KF.measurementNoiseCov << std::endl;
#endif
	startCounter = 0;
	updatedAcc = false;
    updatedYaw = false;
    startValuesYaw = deque<float>();
    startValuesAcc = deque<float>();
	startingYaw = true;
    startingAcc = true;
    lastStreamTime = parent->getTime();
    wheelL.dir=0;
    wheelL.time =0;
    wheelL.timeLast=0;
    wheelL.ticks =0;
    wheelL.ticksLast=0;
    wheelL.zeroCounter =0;
    wheelR.dir=0;
    wheelR.time =0;
    wheelR.timeLast=0;
    wheelR.ticks =0;
    wheelR.ticksLast=0;
    wheelR.zeroCounter =0;

    speedValues.push_back(0);
    speedValues.push_back(0);
    speedValues.push_back(0);
    speedValues.push_back(0);
    speedValues.push_back(0);

   // initSavitzkyGolay7(speedValues);
}


OdometryKalman::~OdometryKalman()
{
}

void OdometryKalman::updateImU(float accX, float accY, float accZ, float yaw){
	this->accX = accX;
	this->accY = accY;
	this->accZ = accZ;
	this->yaw = yaw;
}
void OdometryKalman::updateAcc(float acc){
	
    if (odometryState != ODO_GO){
        startValuesAcc.push_back(acc);

        if(startValuesAcc.size() > prop_startValuesAccLength){
            startValuesAcc.pop_front();
        }
        pair<float,float> vals = computeMeanVar(startValuesAcc);

        if( vals.second < prop_startValuesAccVar){
            accOffset = vals.first;
            if(startingAcc)
                LOG_INFO(cString::Format("Odometry: acceleration initialized: mean:  %f, var: %f",vals.first,vals.second) );
            startingAcc = false;
        }

        updatedAcc = false;
#ifdef debugOutput
        cout << " Got ACC sample: "<< acc << " counter: "<< startCounter << "starting: " << starting << " accOffset:"<< accOffset  <<endl;
#endif
	}
	else{
		updatedAcc = true;
		this->accY = acc-accOffset;
#ifdef debugOutput
        cout << "updated acc: " << this->accY << endl;
#endif
	}
}
void OdometryKalman::updateTicksLeft(tUInt32 ticksL, tUInt8 dirL, tUInt32 timeL){
    updateTicks(ticksL,dirL,timeL,wheelL);

}
void OdometryKalman::updateTicksRight(tUInt32 ticksR, tUInt8 dirR, tUInt32 timeR){
    updateTicks(ticksR,dirR,timeR,wheelR);
}
void OdometryKalman::updateTicks(tUInt32 ticks, tUInt8 dir, tUInt32 time, OdometryKalman::wheelStruct &wh) {

    if(ticks >=  wh.ticks) {
        wh.ticks = ticks;
        wh.dir = dir;
        wh.time = time;
        wh.updated = true;
    }else{
        LOG_WARNING(cString::Format("Wheel Tick Sensor got too many ticks: %d ticks", ticks-wh.ticks));
        wh.ticks = ticks;
        wh.time = time;
    }
}
bool OdometryKalman::checkTicks(tFloat &velocity, wheelStruct &wh) {
    if( wh.first) {
        wh.ticksLast = wh.ticks;
        wh.timeLast = wh.time;
        wh.first = false;
        velocity = 0;
        wh.streamTime = parent->getTime();
        return false;
    }
    if(wh.updated){
        tUInt64 timediff = parent->getTime()-wh.streamTime;
        wh.streamTime = parent->getTime();
        tFloat dticks = wh.ticks-wh.ticksLast;
        if(dticks > 0){
            wh.ticksLast = wh.ticks;
            tUInt32 dtime = wh.time -wh.timeLast;
            if(dtime < 1000) dtime = 1000;
            wh.timeLast = wh.time;
            velocity =  dticks * ((wh.dir == 0) ? 1.0 : -1.0) / dtime * 1e6;

        }else{
            velocity =0;
            wh.timeLast += timediff;

        }
        wh.updated = false;
        return true;
    }
    return false;
}

void OdometryKalman::updateYaw(float yaw){
    if (odometryState != ODO_GO){

		startValuesYaw.push_back(yaw);
		float min = yaw, max = yaw;
		for (int i = 0; i < startValuesYaw.size() - 1; i++){
            min = std::min(min, yaw);
            max = std::max(max, yaw);
		}
        //cout << "odometry: gyro min: "<< min << " max: " << max << " length startvalues: " << startValuesYaw.size() <<  endl;
        if (startValuesYaw.size() > prop_startValuesYawLength){
			startValuesYaw.pop_front();

            if (max - min < prop_startValuesYawEpilon ){
                if(startingYaw)
                    LOG_INFO(cString::Format("Odometry: Gyro initialized: max: %f, min: %f", max, min));
                startingYaw = false;
				yawStart = yaw- 3.141592654/2;

			}
		}
#ifdef debugOutput
        cout << " Got yaw sample: "<< yaw << " counter: "<< startCounterYaw << "startingYaw: " << startingYaw  <<endl;
#endif
	}
	else{
		updatedYaw = true;
		this->yaw = yaw - yawStart ;
		if (this->yaw > 3.141592654){
			this->yaw -= 2 * 3.141592654;
		}
		else if (this->yaw < -3.141592654){
			this->yaw += 2 * 3.141592654;
		}
#ifdef debugOutput
        cout << "updated yaw: " << this->yaw << endl;
#endif
	}


}

void OdometryKalman::resetState()
{
    reset_mux.Enter();
    KF = KalmanFilter(6,4,0);
    KF.transitionMatrix = (Mat_<float>(6, 6) <<
        1, 0, 0, 0, 0, 0,
        0, 1, 0, 0, 0, 0,
        0, 0, 1, 0, 1, 0,
        0, 0, 0, 1, 0, 0.025,
        0, 0, 0, 0, 1, 0,
        0, 0, 0, 0 ,0, 1);
      //x, y, phi, vel dphi acc
    KF.measurementMatrix = (Mat_<float>(4, 6) <<
        0, 0, 0, parent->ticksPerM, parent->axleWidth / 2 * parent->ticksPerM,0,
        0, 0, 0, parent->ticksPerM, -parent->axleWidth / 2 * parent->ticksPerM,0,
        0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 1); // is acceleration measurement used?
    // x   y phi vel dphi acc
    processNoiseCov = (Mat_<float>(6, 6) <<
        1e-4, 0, 0, 0, 0, 0,
        0, 1e-4, 0, 0, 0, 0,
        0, 0, 1e-3, 0, 0, 0,
        0, 0, 0, 1e-3, 0, 0,
        0, 0, 0, 0, 1e-5, 0,
        0, 0, 0, 0, 0, 1e1);

    setIdentity(KF.measurementNoiseCov);
    KF.measurementNoiseCov.at<float>(0, 0) = 8.3e-2; // left wheel
    KF.measurementNoiseCov.at<float>(1, 1) = 8.3e-2; // right wheel
    KF.measurementNoiseCov.at<float>(2, 2) = 1e-5;   // yaw angle
    KF.measurementNoiseCov.at<float>(3, 3) = 1e-3; // acceleration

    setIdentity(KF.errorCovPost, Scalar::all(1e-1));
    measurement = (Mat_<float>(4, 1) << 0, 0, 0,0);
    KF.statePost = (Mat_<float>(6, 1) << 0, 0, 3.141592654/2, 0, 0,0);
    KF.statePre = (Mat_<float>(6,1) << 0, 0, 3.141592654/2, 0,0,0);

    odometryState = ODO_INITIAL;
    startTime = parent->getTime();
    reset_mux.Leave();
}

bool OdometryKalman::isReady()
{
    return (odometryState == ODO_GO);
}

void OdometryKalman::cycle()
{
    reset_mux.Enter();
    switch(odometryState){
    case ODO_INITIAL:
        tOdometryData odos;
        odos.x = 0;
        odos.y = 0;
        odos.phi = 0;
        odos.vel = 0;
        odos.dPhi = 0;
        odos.acc = 0;
            odos.valid = false;
        parent->writeOdometry(odos);
        startingYaw = true;
        startingAcc = true;
        startValuesAcc.clear();
        startValuesYaw.clear();
            check_phi_old = 0;

        odometryState = ODO_STARTUP;
        if(!parent->accConnected()){
            startingAcc = false;
        }
        if(!parent->initializeYaw()){
            startingYaw = false;
        }
        break;
    case ODO_STARTUP:
        odos.x = 0;
        odos.y = 0;
        odos.phi = 0;
        odos.vel = 0;
        odos.dPhi = 0;
        odos.acc = 0;
            odos.valid=false;
            check_phi_old = 0;

        parent->writeOdometry(odos);
        if(parent->getTime() > startTime + 1000000* parent->prop_startup_time  && !startingAcc && !startingYaw){
            odometryState = ODO_GO;
            updatedAcc = false;
            updatedYaw = false;
            wheelL.first = true;
            wheelR.first = true;
            parent->SendStatusMessage(mtum_filters(CAR_CONTROL), READY);
            LOG_INFO("ODOMETRY: Start");
        }
        break;
    case ODO_GO:
        predict();
        break;
    }
    reset_mux.Leave();

}

std::pair<float, float> OdometryKalman::computeMeanVar(deque<float> values)
{

   float sum =0;
   for(size_t i =0; i< values.size(); i++){
       sum += values[i];
   }
   float mean = sum / values.size();
   float meandiff =0;
   for(size_t i =0; i < values.size(); i++){
       meandiff += (values[i]- mean)*(values[i]-mean);
   }
   if(values.size() > 1){
      float var = meandiff/(values.size()-1);
      //cout << "mean: " << mean << " VAR: " << var << endl;
      return make_pair(mean,var);
   }else
       return make_pair(mean,10000);
}
void OdometryKalman::predict(){

    tFloat timeInterval = (parent->getTime()-lastStreamTime)*1e-6;
    lastStreamTime = parent->getTime();
    if(timeInterval > 1) return;

    KF.transitionMatrix.at<float>(0, 2) = timeInterval * -sin(KF.statePost.at<float>(2)) * KF.statePost.at<float>(3);
    KF.transitionMatrix.at<float>(1, 2) = timeInterval *  cos(KF.statePost.at<float>(2)) * KF.statePost.at<float>(3);
	KF.transitionMatrix.at<float>(0, 3) = timeInterval * cos(KF.statePost.at<float>(2));
	KF.transitionMatrix.at<float>(1, 3) = timeInterval * sin(KF.statePost.at<float>(2));
    KF.transitionMatrix.at<float>(2,4) = timeInterval;
    KF.transitionMatrix.at<float>(3,5) = timeInterval;
    KF.processNoiseCov = processNoiseCov * timeInterval;
    //cout << "processNoiseCov: " << KF.processNoiseCov;

    Mat temp = KF.statePost.clone();
    KF.predict();
    KF.statePre.at<float>(0) = temp.at<float>(0) + temp.at<float>(3) * cos(temp.at<float>(2)) * timeInterval;
    KF.statePre.at<float>(1) = temp.at<float>(1) + temp.at<float>(3) * sin(temp.at<float>(2)) * timeInterval;
    KF.statePre.at<float>(2) = temp.at<float>(2) + temp.at<float>(4) * timeInterval;
    KF.statePre.at<float>(3) = temp.at<float>(3) + temp.at<float>(5) * timeInterval;
    KF.statePre.at<float>(4) = temp.at<float>(4);
    KF.statePre.at<float>(5) = temp.at<float>(5);

	if (updatedAcc){
        measurement.at<float>(3) = accY;
        KF.measurementMatrix.at<float>(3,5) = 1;
	}
	else{
        KF.measurementMatrix.at<float>(3,5) = 0;

	}
#ifdef debugOutput
	std::cout << "Prediction: \n" << KF.statePre << std::endl;
	std::cout << "errorCovPre \n" << KF.errorCovPre << std::endl;
#endif

    KF.measurementMatrix.at<float>(0, 4) = -parent->axleWidth / 2 * parent->ticksPerM;
    KF.measurementMatrix.at<float>(1, 4) = parent->axleWidth / 2 * parent->ticksPerM;
    KF.measurementMatrix.at<float>(1, 3) = parent->ticksPerM;
    KF.measurementMatrix.at<float>(0, 3) = parent->ticksPerM;

    tFloat velR,velL;
    bool updateR = checkTicks(velR,wheelR);
    bool updateL = checkTicks(velL, wheelL);
	if (!updateR){

		KF.measurementMatrix.at<float>(1, 3) = 0;
        KF.measurementMatrix.at<float>(1, 4) = 0;
	}
	if (!updateL){
		KF.measurementMatrix.at<float>(0, 3) = 0;
        KF.measurementMatrix.at<float>(0, 4) = 0;
	}

	if (updatedYaw){
		KF.measurementMatrix.at<float>(2, 2) = 1;
		float measNearState = yaw - KF.statePre.at<float>(2);
		if (measNearState > 3.141592654){
			yaw -= 2 * 3.141592654;
		}
		if (measNearState < -3.141592654){
			yaw += 2 * 3.141592654;
		}
		measurement.at<float>(2) = yaw;
	}
	else{
		KF.measurementMatrix.at<float>(2, 2) = 0;
	}

    measurement.at<float>(0) =velL;
    measurement.at<float>(1) =velR;
#ifdef debugOutput
    if(measurement.at<float>(0) != 0 || measurement.at<float>(1) != 0){
        cout << "mesurement: L: val: " << measurement.at<float>(0) << " v_l: " << v_l << " timediff: " << timediffL <<
                "\tR: " << measurement.at<float>(1) <<  " v_r: " << v_r << " timediff: " << timediffR << endl;
    }


	std::cout << "measurement: \n" << measurement << std::endl;
	std::cout << "measurement Matrix:\n" << KF.measurementMatrix << std::endl;
	
	std::cout << "z - Hx: \n" << KF.temp5 << "\n gain:\n" << KF.gain << std::endl;
	std::cout << "corrected matrix:\n" << KF.statePost << std::endl;
	std::cout << "errorCovPost \n" << KF.errorCovPost << std::endl;
#endif
    Mat s = KF.correct(measurement);
	if (KF.statePost.at<float>(2) > 3.141592654){
		KF.statePost.at<float>(2) -= 2 * 3.141592654;
	}
	else if (KF.statePost.at<float>(2) < -3.141592654){
		KF.statePost.at<float>(2) += 2 * 3.141592654;
	}
    if(KF.statePost.at<float>(3) > 10){
        KF.statePost.at<float>(3) = 10;
    }
    else if(KF.statePost.at<float>(3) < -10){
        KF.statePost.at<float>(3) = -10;
    }

    tOdometryData odos;
    odos.x = KF.statePost.at<float>(0);
    odos.y = KF.statePost.at<float>(1);
    odos.phi = KF.statePost.at<float>(2);
    odos.vel = smoothSavitzkyGolay5( KF.statePost.at<float>(3),speedValues);
    odos.dPhi = KF.statePost.at<float>(4);
    odos.phi -= 3.141592654 / 2;
    if(odos.phi > 3.141592654){
        odos.phi -= 2* 3.141592654;
    }
    if(odos.phi < -3.141592654){
        odos.phi += 2* 3.141592654;
    }
    odos.acc = KF.statePost.at<float>(5);

    odos.valid = gyro_check(odos);
    parent->writeOdometry(odos);
    updatedAcc = false;
	updatedYaw = false;

}


tFloat OdometryKalman::smoothSavitzkyGolay5(tFloat value, deque<tFloat> &values) {
    values.pop_front();
    values.push_back(value);

    tFloat sum = 31* values[4] + 9* values[3] -3  * values[2] -5 * values[1] + 3* values[0];
    return sum/ 35.0;
}

void OdometryKalman::initSavitzkyGolay7(deque<tFloat> &deque1) {
    deque1.clear();
    for(int i=0; i< 7; i++){
        deque1.push_back(0);
    }
}

tFloat OdometryKalman::smoothSavitzkyGolay7(tFloat value, deque<tFloat> &values) {
    values.pop_front();
    values.push_back(value);

    tFloat sum = 32* values[6] + 15* values[5] +3  * values[4] -4 * values[3] - 6* values[2] -3* values[1] + 5*values[0];
    return sum/ 35.0;

}

tBool OdometryKalman::gyro_check(const tOdometryData &odo) {
    float check_dphi= check_phi_old- odo.phi;

    if(check_dphi > M_PI){
        check_dphi -= 2*M_PI;
    }
    if(check_dphi < -M_PI){
        check_dphi += 2*M_PI;
    }

    check_phi_old = odo.phi;

    return fabs(check_dphi) <= 0.2;

}
