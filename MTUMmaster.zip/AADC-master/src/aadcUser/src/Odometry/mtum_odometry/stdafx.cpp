// stdafx.cpp :sourcecode file, which just includes the Standard-Includes 
// DemoTest.pch is the precompiled Header
// stdafx.obj includes the precompiled Typinformation

#include "stdafx.h"

// TODO: refer to additional Header, which are required at STDAFX.H 
// and not required at this file.


