/**
 *
 * ADTF Template Project Filter.
 *
 * @file
 * Copyright &copy; Audi Electronics Venture GmbH. All rights reserved
 *
 * $Author: belkera $
 * $Date: 2011-06-30 16:51:21 +0200 (Do, 30 Jun 2011) $
 * $Revision: 26514 $
 *
 * @remarks
 *
 */
#ifndef _TEMPLATE_PROJECT_FILTER_H_
#define _TEMPLATE_PROJECT_FILTER_H_

#define OID_100_DRIVER "adtf.test.driver_filter"


//*************************************************************************************************
class cDriver : public adtf::cFilter
{
    ADTF_FILTER(OID_100_DRIVER, "100 Ticks Driver Filter", adtf::OBJCAT_DataFilter);

protected:
    cInputPin    m_oTemplateInput;
    cOutputPin    m_oTemplateOutput;
    tUInt32 lastTick;
    tFloat32 outputValue;
    struct signalValue{
       tUInt32 timestamp;
       tFloat32 value;
    };
    struct wheelTicks{
        tUInt32 timestamp;
        tUInt32 ticks;
        tUInt8  dir;
    };

    enum state{START,INCREASEVALUE,GO,STOP};
    state myState;
public:
    tFloat32 processData(tUInt32 ticks);
    cDriver(const tChar* __info);
    virtual ~cDriver();

protected:
    tResult Init(tInitStage eStage, __exception);
    tResult Shutdown(tInitStage eStage, __exception);

    // implements IPinEventSink
    tResult OnPinEvent(IPin* pSource,
                       tInt nEventCode,
                       tInt nParam1,
                       tInt nParam2,
                       IMediaSample* pMediaSample);
};

//*************************************************************************************************
#endif // _TEMPLATE_PROJECT_FILTER_H_
