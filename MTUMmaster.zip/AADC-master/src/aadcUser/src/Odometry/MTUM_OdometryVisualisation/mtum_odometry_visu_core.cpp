//
// Created by aadc on 2/28/16.
//

#include "mtum_odometry_visu_core.h"

ostream& operator<<(ostream& os, const tOdometryData& dat){
    os << "x: " << dat.x << " y: " << dat.y << " vel: " << dat.vel << "m/s acc: " << dat.acc << "m/ss phi:" << dat.phi*180/M_PI << "deg ";
}
ostream& operator<<(ostream& os, const tDynamicControlValue& dat){
    os << "Vel: " << dat.setPointSpeed << " Curv: " << dat.setPointCurvature << "1/m Acc: " << dat.setPointAcceleration << "m/ss Lights: " << dat.LightFlags;
}


mtum_odometry_visu_core::mtum_odometry_visu_core(IOdometryVisuFilter *filter) {
 this->filter = filter;
    colors.push_back(Vec3b(0,0,255));
    colors.push_back(Vec3b(255,0,0));
    colors.push_back(Vec3b(0,255,0));
    colors.push_back(Vec3b(0, 127, 255));
    colors.push_back(Vec3b(255,0,143));
    colors.push_back(Vec3b(0,255,255));
    colors.push_back(Vec3b(130, 0, 75));
    resetMinMax();
    colornum=0;

    firstOdo = Point2d(0,0);
    firstOdoSample = true;
}

void mtum_odometry_visu_core::resetMinMax() {
    minMaxMux.Enter();
    min_x = -1;
    max_x = 1;
    min_y = -1;
    max_y - 1;
    minMaxMux.Leave();

}

mtum_odometry_visu_core::~mtum_odometry_visu_core() {

}

void mtum_odometry_visu_core::draw() {
    const int font = CV_FONT_HERSHEY_SIMPLEX;
    const double fontsize = 0.5;
    Mat image(filter->height,filter->width,CV_8UC3,Scalar(200,200,200));
    if(image.cols < 10 || image.rows < 10)
        return;
    minMaxMux.Enter();

    double pixels_per_cm =min(1*filter->width/(max_x-min_x), filter->height*1.0/(max_y-min_y));

    Point2f cpos(pixels_per_cm * -min_x,pixels_per_cm * max_y);

    int xmax = cpos.x+ pixels_per_cm* max_x;
    int ymax = cpos.y+ pixels_per_cm*-min_y;
    minMaxMux.Leave();
    Vec3b gridC(0,0,0);
    // draw grid with 10cm per cell
    if(max_y-min_y < 1000 && max_x-min_x<1000){
        for(int i =0; i< max_y; i+=10){
            int x1 = 0;
            int x2 = xmax;
            int y1 = cpos.y -pixels_per_cm*i;
            //LOG_INFO(cString::Format("position of line: %d, %d to %d, %d",x1,y1,x2,y1));
            line(image,Point2f(x1,y1),Point2f(x2,y1),gridC);
        }
        for(int i =-10; i >= min_y; i-=10){
            line(image,Point2f(0,cpos.y -pixels_per_cm*i),Point2f(xmax,cpos.y - pixels_per_cm*i),gridC);
        }
        for(int i =10; i<=max_x; i+=10){
            line(image,Point2f(cpos.x+ i*pixels_per_cm,0),Point2f(cpos.x+ i*pixels_per_cm,ymax),gridC);
        }
        for(int i =-10; i>= min_x; i-=10){
            line(image, Point2f(cpos.x+ i*pixels_per_cm,0),Point2f(cpos.x+ i*pixels_per_cm,ymax),gridC);
        }
    }
    line(image,Point2f(cpos.x,0),Point2f(cpos.x,ymax),gridC,2);
    line(image,Point2f(0,cpos.y),Point2f(xmax,cpos.y),gridC,2);

    int textStart =0;


    for (map<string,odometrystruct>::iterator it = odometryMap.begin(); it != odometryMap.end();++it){
        stringstream ss;
        it->second.mux.Enter();
        tOdometryData &odo = it->second.odoNow;
        Vec3b col = it->second.color;
        deque <Point2f> &ps = it->second.prevPoints;
        ss << it->first << ": " << odo << setprecision(3);
        putText(image,ss.str(),Point2f(10,50+textStart),font,fontsize,col,1,CV_AA);
        int baseline =0;
        Size size = getTextSize(ss.str(),font,fontsize,1,&baseline);
        textStart += size.height;

        Point converted[ps.size()];
        Point *p = converted;
        for(int i= 0; i< ps.size();i++) {
            converted[i] = PosToImage(ps[i], cpos, pixels_per_cm);
        }
        int num = ps.size();
        polylines(image,&p,&num,1,false,col,1,LINE_AA,0);
        Point2f carNow(odo.x,odo.y);
        carNow=PosToImage(carNow,cpos,pixels_per_cm);
        if(odo.valid){

            float scale = pixels_per_cm*0.3;
            int imgnum = odo.phi/2/M_PI*car_images.size()-0.5;
            if(imgnum < 0) imgnum += car_images.size();
            //TODO
            RotatedRect rrect(carNow,Size(pixels_per_cm*0.3,pixels_per_cm*0.6), -odo.phi*180/M_PI);
            Point2f points[4];
            rrect.points(points);
            for(int i=0; i< 4;i++){
                line(image,points[i],points[(i+1)%4],col);
            }
            /*
            Point offset = offsets[imgnum];
            Mat car = car_images[imgnum];
            Mat mask = car_images[imgnum];
            Point2f point2f = carNow - Point2f(offset.x,offset.y);
            Rect r(point2f.x,point2f.y,car.cols,car.rows);
            if(r.x< 0 || r.y < 0 || r.x+r.width >image.cols || r.y+r.height > image.rows){
                cout << "rectangle did not fit: " << r << " size image: " << image.cols << " ; " << image.rows << endl;
            }else
            car.copyTo(image(r),mask);
             */

        }

        drawPointDir(image, carNow, odo.phi, col);
        it->second.mux.Leave();
    }

    for (map<string,refstruct>::iterator it = refMap.begin(); it != refMap.end();++it) {
        it->second.mux.Enter();
        stringstream ss;
        tReferencePoints &ref = it->second.referenceNow;
        Vec3b col = it->second.color;
        deque<Point2f> &ps = it->second.prevRefs;
        ss << it->first;
        if (ref.numPoints == 0) {
            ss << " no Points";
        } else
            ss << ": " << ref.points[0] << setprecision(3);
        putText(image, ss.str(), Point2f(10, 50 + textStart), font, fontsize, col,1, CV_AA);
        int baseline = 0;
        Size size = getTextSize(ss.str(), font, fontsize, 1, &baseline);
        textStart += size.height;
        Point converted[ps.size()];
        Point* p =converted;
        for (int i = 0; i < ps.size(); i++) {
            converted[i] = PosToImage(ps[i], cpos, pixels_per_cm);
        }
        int num = ps.size();
        polylines(image, &p, &num, 1, false, col, 1, LINE_AA, 0);


        for (int j = 0; j < ref.numPoints; j++) {
            Vec3b c1 = col * (j*1.0 / ref.numPoints);
            Point2f p = PosToImage(Point2f(ref.points[j].x, ref.points[j].y), cpos, pixels_per_cm);
            drawPointDir(image, p, ref.points[j].phi, c1);

        }
        it->second.mux.Leave();
    }

    for (map<string,dynvalstruct>::iterator it = dynvalMap.begin(); it != dynvalMap.end();++it) {
        stringstream ss;
        tDynamicControlValue &dyn = it->second.value;
        Vec3b col = it->second.color;
        ss << it->first << ": " << dyn;
        putText(image, ss.str(), Point2f(10, 10 + textStart), font, fontsize, col, 1, CV_AA);
        odometrystruct odo = odometryMap.begin()->second;
        odo.mux.Enter();
        Point2f center(odo.odoNow.x, odo.odoNow.y);
        Point2f n(cos(odo.odoNow.phi), sin(odo.odoNow.phi));
        center = center - n * 1 / dyn.setPointCurvature;
        Point2f cIm = PosToImage(center, cpos, pixels_per_cm);
        float s = pixels_per_cm / abs(dyn.setPointCurvature);
        if (fabs(dyn.setPointCurvature) > 0.0001) {
            circle(image, cIm, s, col);
        }
        odo.mux.Leave();
    }

    filter->writeImage(image);
}

void mtum_odometry_visu_core::insertOdometry(const string &id, tOdometryData const &odo) {
    if(firstOdoSample)
    {
        firstOdoSample = false;
        firstOdo = Point2d(odo.x, odo.y);
    }

    odometrystruct& o =odometryMap[id];
    o.mux.Enter();
    if(o.color== Vec3b(0,0,0)){ // new value
        o.color = nextColor();
    }
    o.odoNow = odo;
    o.odoNow.x -= firstOdo.x;
    o.odoNow.y -= firstOdo.y;
    Point2f p(o.odoNow.x, o.odoNow.y);
    if(o.prevPoints.empty() || norm(p-o.prevPoints.back())>0.01)
    {
        updateMinMax(p);
        o.prevPoints.push_back(p);
        if(o.prevPoints.size()> 5000){
            o.prevPoints.pop_front();
        }
    }
    o.mux.Leave();
    //cout << "inserted Odometry: id:" << id << " odo: " << odo << " again: "<< odo <<endl;
}

void mtum_odometry_visu_core::insertReference(const string &id, tReferencePoints const &ref) {
 refstruct &refs = refMap[id];
    refs.mux.Enter();
    if(refs.color == Vec3b(0,0,0)){
     refs.color = nextColor();
    }
    refs.referenceNow = ref;

    for(int i = 0 ; i < refs.referenceNow.numPoints; i++ ){
        refs.referenceNow.points[i].x -= firstOdo.x;
        refs.referenceNow.points[i].y -= firstOdo.y;


    }

    if(refs.referenceNow.numPoints > 0)
    {
        Point2f p(refs.referenceNow.points[0].x,refs.referenceNow.points[0].y);
        refs.prevRefs.push_back(p);
        updateMinMax(p);
        if(refs.prevRefs.size()> 5000){
            refs.prevRefs.pop_front();
        }
    }


    refs.mux.Leave();
   // cout << "inserted Reference: id:" << id << " #refps: " << ref.numPoints << " ref1: " << ref.points[0] <<endl;

}

void mtum_odometry_visu_core::insertDynVal(const string &id, tDynamicControlValue const &dyn) {
    dynvalstruct &dvs = dynvalMap[id];
    dvs.mux.Enter();
    if(dvs.color == Vec3b(0,0,0)){
        dvs.color = nextColor();
    }
    dvs.value = dyn;
    dvs.mux.Leave();
}

Vec3b mtum_odometry_visu_core::nextColor() {
    return colors[(colornum++%numColors)];
}

void mtum_odometry_visu_core::updateMinMax(Point2f const &pos) {
    minMaxMux.Enter();
    min_x = fmax(fmin(pos.x-0.4,min_x),-1000);
    max_x = fmin(fmax(pos.x+0.4,max_x), 1000);
    min_y = fmax(fmin(pos.y-0.4,min_y),-1000);
    max_y = fmin(fmax(pos.y+0.4,max_y), 1000);
    minMaxMux.Leave();
}

Point2f mtum_odometry_visu_core::PosToImage(const Point2f &p, const Point2f &center, double px_per_cm) {
    return Point2f(p.x,-p.y) * px_per_cm + center;

}

void mtum_odometry_visu_core::loadCar(const string &filename) {
    Mat img = imread(filename,-1);
    img.resize(img.cols/4,img.rows/4);
    int maxl = max(img.rows,img.cols);
    Mat car_image1 = Mat(maxl,maxl,CV_8UC3);
    Rect r((car_image1.cols-img.cols)/2,(car_image1.rows-img.rows)/2,img.cols,img.rows);
    Point2f diff((car_image1.cols-img.cols)/2,(car_image1.rows-img.rows)/2);
    Mat car_image =car_image1(r);
    Mat car_mask1 = Mat(maxl,maxl, CV_8UC1, Scalar(0));
    Mat car_mask = car_mask1(r);
    for(int row =0; row < img.rows;row++){
        Vec4b *ptr = img.ptr<Vec4b>(row);
        Vec3b *img_ptr = car_image.ptr<Vec3b>(row);
        uchar *mask_ptr = car_mask.ptr<uchar>(row);
    for(int col = 0; col < img.cols; col++){
        img_ptr[col][0] = ptr[col][0];
        img_ptr[col][1] = ptr[col][1];
        img_ptr[col][2] = ptr[col][2];
        mask_ptr[col] = ptr[col][3];
    }
    }
    const int numPictures = 10;
    for(int i = 0; i < numPictures; i++){
        Mat rot = getRotationMatrix2D(diff+Point2f(img.cols,img.rows)*0.5,360.0*i/numPictures,1);
        Mat tempimg, tempmask;
        warpAffine(car_image1,tempimg,rot,Size(maxl,maxl));
        warpAffine(car_mask1, tempmask,rot,Size(maxl,maxl));

        Mat Points;
        findNonZero(tempmask,Points);
        Rect Min_Rect=boundingRect(Points);
        car_images.push_back(tempimg(Min_Rect).clone());
        car_masks.push_back(tempmask(Min_Rect).clone());
        offsets.push_back(Point(Min_Rect.x,Min_Rect.y));
    }

}

void mtum_odometry_visu_core::drawPointDir(Mat &mat, Point2f const &point_, tFloat32 phi, const Scalar &color) {
    Point2f p2 = point_ + 20*Point2f(-sin(phi),-cos(phi));
    arrowedLine(mat,point_,p2,color,1,CV_AA, 0, 1);
}
