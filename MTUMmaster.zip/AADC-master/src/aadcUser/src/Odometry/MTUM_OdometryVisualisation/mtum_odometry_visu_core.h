//
// Created by aadc on 2/28/16.
//

#ifndef AADC_USER_MTUM_ODOMETRY_VISU_CORE_H
#define AADC_USER_MTUM_ODOMETRY_VISU_CORE_H

#include "stdafx.h"
#include <OdometryDataType.h>
#include <ReferencePointsType.h>
#include <DynamicControlValueType.h>
#include <iomanip>
#include "mtum_odometry_visu_interface.h"




class mtum_odometry_visu_core {
public:
    mtum_odometry_visu_core(IOdometryVisuFilter* filter);
    ~mtum_odometry_visu_core();
    void draw();
    void insertOdometry(const string &id, tOdometryData const &odo);
    void insertReference(const string &id, tReferencePoints const &ref);
    void insertDynVal(const string &id, tDynamicControlValue const &dyn);
    void loadCar(const string& filename);
private:
    IOdometryVisuFilter* filter;

    struct odometrystruct{
        odometrystruct(){
            color =Vec3b(0,0,0);
        }
        odometrystruct(odometrystruct const &s){
            color = s.color;
            odoNow = s.odoNow;
            prevPoints= s.prevPoints;
            //cout << "copy constructor" << endl;
        }
        tOdometryData odoNow;
        deque<Point2f> prevPoints;
        cMutex mux;
        Vec3b color;
    };
    struct refstruct{
        refstruct(){
            color = Vec3b(0,0,0);
        }
        refstruct(refstruct const & ref){
            referenceNow = ref.referenceNow;
            prevRefs = ref.prevRefs;
            color = ref.color;

        }
        tReferencePoints referenceNow;
        deque<Point2f> prevRefs;
        cMutex mux;
        Vec3b color;
    };
    struct dynvalstruct{
        dynvalstruct() {
            color = Vec3b(0, 0, 0);
        }
        dynvalstruct(dynvalstruct const &dvs){
            value = dvs.value;
            color = dvs.color;
        }
        tDynamicControlValue value;
        cMutex mux;
        Vec3b color;
    };
    cMutex minMaxMux;
    int colornum;
    const int numColors = 7;
    vector<Mat> car_images;
    vector<Mat> car_masks;
    vector<Point> offsets;
    Vec3b nextColor();
    vector<Vec3b> colors;
    tFloat min_x, max_x, min_y, max_y;
    map<string, odometrystruct> odometryMap;
    map<string, refstruct> refMap;
    map<string, dynvalstruct> dynvalMap;

    Point2d firstOdo;
    bool firstOdoSample;

    void resetMinMax();
    void updateMinMax(Point2f const &pos);
    Point2f PosToImage(const Point2f &p, const Point2f &center, double cm_per_px);

    void drawPointDir(Mat &mat, Point2f const &point_, tFloat32 phi, const Scalar &color);
};


#endif //AADC_USER_MTUM_ODOMETRY_VISU_CORE_H
