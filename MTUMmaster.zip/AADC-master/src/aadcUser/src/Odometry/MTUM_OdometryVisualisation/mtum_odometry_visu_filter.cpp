

#include "stdafx.h"
#include "mtum_odometry_visu_filter.h"

ADTF_FILTER_PLUGIN("MTUM_ODOMETRY_VISUALISATION", OID_ODO_VISU, cMotionVisualisation)



cMotionVisualisation::cMotionVisualisation(const tChar* __info):cFilter(__info),core(this)
{


    ConfigureConnectionPins(0);

    // configure the reader

    SetPropertyInt("Width",500);
    SetPropertyInt("Height",500);
    SetPropertyFloat("FPS",10);
    m_bRunning = false;


}

cMotionVisualisation::~cMotionVisualisation()
{
}

tResult cMotionVisualisation::Init(tInitStage eStage, __exception)
{
    RETURN_IF_FAILED(cFilter::Init(eStage, __exception_ptr));
    if (eStage == StageFirst)
    {
        cObjectPtr<IMediaDescriptionManager> pDescManager;
        RETURN_IF_FAILED(_runtime->GetObject(OID_ADTF_MEDIA_DESCRIPTION_MANAGER,IID_ADTF_MEDIA_DESCRIPTION_MANAGER,(tVoid**)&pDescManager,__exception_ptr));


        tChar const * strDescCarPos = pDescManager->GetMediaDescription(ODOMETRYDATA);
        RETURN_IF_POINTER_NULL(strDescCarPos);
        //m_pTypeCarPos = new cMediaType(0, 0, 0, "tOdometryData", strDescCarPos,IMediaDescription::MDF_DDL_DEFAULT_VERSION);
        m_pTypeCarPos = new cMediaType(0,0,0,ODOMETRYDATA, strDescCarPos,IMediaDescription::MDF_DDL_DEFAULT_VERSION);
        //RETURN_IF_FAILED(m_pTypeCarPos->GetInterface(IID_ADTF_MEDIA_TYPE_DESCRIPTION, (tVoid**)&m_pCoderDescCarPos));


        tChar const * strDescReference = pDescManager->GetMediaDescription(REFERENCEPOINTS);
        RETURN_IF_POINTER_NULL(strDescReference);
        m_pTypeReferencePoint = new cMediaType(0, 0, 0, REFERENCEPOINTS, strDescReference,IMediaDescription::MDF_DDL_DEFAULT_VERSION);

        tChar const * strDescDriveSignal = pDescManager->GetMediaDescription(DYNAMICCONTROLVALUE);
        RETURN_IF_POINTER_NULL(strDescDriveSignal);
        //LOG_INFO(strDescDriveSignal);
        m_pTypeLLControllerValue = new cMediaType(0, 0, 0, DYNAMICCONTROLVALUE, strDescDriveSignal,IMediaDescription::MDF_DDL_DEFAULT_VERSION);

        // get a media type for the video-output pin
        RETURN_IF_FAILED(m_oOutput.Create("Visualisation", IPin::PD_Output, static_cast<IPinEventSink*>(this)));
        RETURN_IF_FAILED(RegisterPin(&m_oOutput));

    }
    else if (eStage == StageNormal)
    {
        //carfilename ="../../../src/aadcUser/src/Odometry/MTUM_OdometryVisualisation/car1.png"; // GetPropertyStr("Car_picture");
        //create path from path
        //ADTF_GET_CONFIG_FILENAME(carfilename);
        ///carfilename = carfilename.CreateAbsolutePath(".");
        //core.loadCar(carfilename.GetPtr());
        width = GetPropertyInt("Width");
        height = GetPropertyInt("Height");
        //set the videoformat of the rgb video pin
        m_sOutputFormat.nWidth = width;
        m_sOutputFormat.nHeight = height;
        m_sOutputFormat.nBitsPerPixel = 24;
        m_sOutputFormat.nPixelFormat = cImage::PF_BGR_888;
        m_sOutputFormat.nBytesPerLine = m_sOutputFormat.nWidth * 3;
        m_sOutputFormat.nSize = m_sOutputFormat.nBytesPerLine * m_sOutputFormat.nHeight;
        m_sOutputFormat.nPaletteSize = 0;
        m_oOutput.SetFormat(&m_sOutputFormat, NULL);


    }
    else if (eStage == StageGraphReady)
    {
        tUInt32 nFlags = 0;

        // Create our cyclic timer.
        // we do this here and not in Start() to prevent the impact of
        // the thread creation during RL_Running
        cString strTimerName = OIGetInstanceName();
        strTimerName += ".rttimerOdoVisu";
        m_hTimer = _kernel->TimerCreate(1e6 / GetPropertyFloat("FPS"),
                                        0,
                                        static_cast<IRunnable*>(this),
                                        NULL,
                                        NULL,
                                        0,
                                        nFlags,
                                        strTimerName);
        if (!m_hTimer)
        {
            THROW_ERROR_DESC(ERR_UNEXPECTED, "Unable to create timer");
        }



    }
    RETURN_NOERROR;
}



tResult cMotionVisualisation::OnPinEvent(	IPin* pSource, tInt nEventCode, tInt nParam1, tInt nParam2, IMediaSample* pMediaSample)
{

    if (nEventCode == IPinEventSink::PE_MediaSampleReceived && pMediaSample != NULL)
    {


        for(uint i =0; i< m_pDynamicInputPinsDriveSignal.size(); i++){
            if(pSource == m_pDynamicInputPinsDriveSignal[i]){
                //LOG_INFO("Found Drive Signal pin");
                tDynamicControlValue llcv;
                ReceiveDriveSignalPin(pMediaSample, llcv);
                core.insertDynVal(pSource->GetName(),llcv);
                //LOG_INFO(cString::Format("got drive signal values: curvature: %f, acceleration %f",llcv.curvature,llcv.acceleration));
                //LOG_INFO("insert points");

            }
        }
        for(uint i =0; i< m_pDynamicInputPinsCar.size(); i++){
            if(pSource == m_pDynamicInputPinsCar[i]){
                //LOG_INFO("dynamic car pin");
                tOdometryData d;
                ReceiveCarPos(pMediaSample, d);
                core.insertOdometry(pSource->GetName(),d);


            }
        }
        for(uint i =0; i< m_pDynamicInputPinsReference.size(); i++){
            if(pSource == m_pDynamicInputPinsReference[i]){
                //LOG_INFO("Found reference pin");
                tReferencePoints ps;
                ReceiveReferencePin(pMediaSample, ps);
                core.insertReference(pSource->GetName(),ps);
                //LOG_INFO("insert points");

            }
        }



    }
    RETURN_NOERROR;
}



tResult cMotionVisualisation::Start(__exception)
{
    RETURN_IF_FAILED(cFilter::Start(__exception_ptr));
    m_bRunning = true;

    RETURN_NOERROR;
}

tResult cMotionVisualisation::Run(tInt nActivationCode, const tVoid* pvUserData, tInt szUserDataSize, ucom::IException** __exception_ptr/* =NULL */)
{
    if (nActivationCode == IRunnable::RUN_TIMER && m_bRunning) {

        core.draw();
    }
      RETURN_NOERROR;
}

tResult cMotionVisualisation::Stop(__exception)
{
    m_bRunning = false;
    RETURN_IF_FAILED(cFilter::Stop(__exception_ptr));

    RETURN_NOERROR;
}

tResult cMotionVisualisation::Shutdown(tInitStage eStage, __exception)
{
    if (m_hTimer && eStage == StageGraphReady)
    {
        // Destroy the timer
        _kernel->TimerDestroy(m_hTimer);
        m_hTimer = NULL;
    }
    return cFilter::Shutdown(eStage, __exception_ptr);
}

tResult cMotionVisualisation::Connect(IPin* pSource,
                                      const tChar* strDestName,
                                      __exception)
{

    THROW_IF_POINTER_NULL(pSource);
    cout << "Motion visualisation: connect pin: "<< pSource->GetName() << endl;
    cString strDestPinname("");
    if (strDestName != NULL)
    {
        strDestPinname = cString(strDestName);
    }
    else
    {
        strDestPinname = pSource->GetName();
    }

    cObjectPtr<IPin> pPinInput;

    if(IS_OK(FindPin(strDestName, IPin::PD_Input, &pPinInput)))
    {
       cerr << "error: MotionVisualisation:  while finding pin" << endl;
    }

    cObjectPtr<IMediaType> pMediaType;
    if (IS_FAILED((pSource->GetMediaType(&pMediaType))))
    {
        cerr << "error: MotionVisualistation:  found no media description" << endl;
    }
    cObjectPtr<cDynamicInputPin> dpin = new cDynamicInputPin();
    cout << "pMediaType is equal to referencePoint:" <<pMediaType->IsEqual(m_pTypeReferencePoint) << " LL controller Value: " << pMediaType->IsEqual(m_pTypeLLControllerValue) << " car pos: " <<pMediaType->IsEqual(m_pTypeCarPos) << endl;
    cout << "pin name: " << strDestPinname << endl;
    if(pMediaType->IsEqual(m_pTypeReferencePoint) || pMediaType->IsEqual(m_pTypeLLControllerValue)|| pMediaType->IsEqual(m_pTypeCarPos)){

        if(IS_OK(dpin->Create(strDestName,pMediaType, static_cast<IPinEventSink*> (this)))){
            cout << "created pin: "<< dpin << " name: " << strDestName << endl;
            RegisterPin(dpin);
            cout << "registered pin" << endl;
        }else
        {
            if (strDestName)
            {
                cerr << "error: Motion Visu: Can not create the new pin !" << endl;
            }
            else
            {
                cerr << "error: Can not create the new pin!"<< endl;
            }
        }
        if(pMediaType->IsEqual(m_pTypeReferencePoint)){
            LOG_INFO("create new reference Points input pin");
            m_pDynamicInputPinsReference.push_back(dpin);
        }else if(pMediaType->IsEqual(m_pTypeLLControllerValue))
        {
            LOG_INFO("create new drive Signal Points input pin");
            m_pDynamicInputPinsDriveSignal.push_back(dpin);
        }else if(pMediaType->IsEqual(m_pTypeCarPos)){
            LOG_INFO("create new CarPosition input pin");
            m_pDynamicInputPinsCar.push_back(dpin);
        }

        RETURN_IF_FAILED(cFilter::Connect(pSource, strDestPinname.GetPtr(), __exception_ptr));
    }


    RETURN_NOERROR;
}





tResult cMotionVisualisation::ReceiveReferencePin(IMediaSample* pMediaSample, tReferencePoints &ref)
{


    {
        // this will aquire the read lock on the sample and declare and initialize a pointer to the data
        __sample_read_lock(pMediaSample, tReferencePoints, pData);
        // now we can access the sample data through the pointer
        ref = *pData;
        // the read lock on the sample will be released when leaving this scope
    }


    RETURN_NOERROR;
}

tResult cMotionVisualisation::ReceiveDriveSignalPin(IMediaSample *pMediaSample, tDynamicControlValue &llcv)
{
    {
        // this will aquire the read lock on the sample and declare and initialize a pointer to the data
        __sample_read_lock(pMediaSample, tDynamicControlValue, pData);
        // now we can access the sample data through the pointer
        llcv = *pData;
        // the read lock on the sample will be released when leaving this scope
    }


    RETURN_NOERROR;

}
tResult cMotionVisualisation::ReceiveCarPos(IMediaSample* pMediaSample, tOdometryData &odometry)
{
    __sample_read_lock(pMediaSample, tOdometryData,pData);
    odometry = *pData;

    RETURN_NOERROR;
}


void cMotionVisualisation::writeImage(Mat image) {
    cObjectPtr<IMediaSample> pNewSample;
    if (IS_OK(AllocMediaSample(&pNewSample)))
    {
        pNewSample->Update(_clock->GetStreamTime(), image.data, m_sOutputFormat.nSize, 0);
        m_oOutput.Transmit(pNewSample);
    }

}
