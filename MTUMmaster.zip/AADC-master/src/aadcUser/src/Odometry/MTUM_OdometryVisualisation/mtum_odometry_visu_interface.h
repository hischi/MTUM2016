//
// Created by aadc on 2/28/16.
//

#ifndef AADC_USER_MTUM_ODOMETRY_VISU_INTERFACE_H
#define AADC_USER_MTUM_ODOMETRY_VISU_INTERFACE_H

#include "stdafx.h"

class IOdometryVisuFilter{
public:
    virtual void writeImage(Mat image)=0;
    int width,height;
};

#endif //AADC_USER_MTUM_ODOMETRY_VISU_INTERFACE_H
