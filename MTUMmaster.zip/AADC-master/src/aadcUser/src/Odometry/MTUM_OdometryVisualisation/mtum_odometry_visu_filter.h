
#ifndef _ODOMETRYVISU_HEADER
#define _ODOMETRYVISU_HEADER

#define OID_ODO_VISU "adtf.aadc.odovisualisation"

#include "stdafx.h"
#include "ReferencePointsType.h"
#include "DynamicControlValueType.h"
#include "OdometryDataType.h"
#include "mtum_odometry_visu_interface.h"
#include "mtum_odometry_visu_core.h"

class cMotionVisualisation : public cFilter, IOdometryVisuFilter
{

    ADTF_DECLARE_FILTER_VERSION(OID_ODO_VISU, "MTUM_Odometry_Visualisation", adtf::OBJCAT_GraphicsDisplay, "Odometry Visualisation", 1, 0, 0, "Beta Version");
    public:
        cMotionVisualisation(const tChar* __info);
        virtual ~cMotionVisualisation();

        //cInputPin m_MotionPinIn;
        //cInputPin m_PinIn2;
        cVideoPin   m_oOutput;
       tBitmapFormat m_sOutputFormat;



        vector<cObjectPtr<cDynamicInputPin> > m_pDynamicInputPinsCar;
        vector<cObjectPtr<cDynamicInputPin> > m_pDynamicInputPinsReference;
        vector<cObjectPtr<cDynamicInputPin> > m_pDynamicInputPinsDriveSignal;



        cObjectPtr<cMediaType>m_pTypeCarPos;
        cObjectPtr<cMediaType>m_pTypeReferencePoint;
        cObjectPtr<cMediaType>m_pTypeLLControllerValue;

    // override odo visu interface
    virtual void writeImage(Mat image);

        /*! overrides cFilter */
        virtual tResult Init(tInitStage eStage, __exception = NULL);

        /*! overrides cFilter */
        virtual tResult Start(__exception = NULL);

        /*! overrides cFilter */
        virtual tResult Stop(__exception = NULL);

        /*! overrides cFilter */
        virtual tResult Shutdown(tInitStage eStage, __exception = NULL);

        virtual tResult OnPinEvent(IPin *pSource, tInt nEventCode, tInt nParam1, tInt nParam2, IMediaSample *pMediaSample);

        tResult Run(tInt nActivationCode, const tVoid* pvUserData, tInt szUserDataSize, ucom::IException** __exception_ptr =NULL );

        /*! overrides cFilter */
        tResult Connect(IPin* pSource,
                        const tChar* strDestName,
                        __exception=NULL);

        tResult ReceiveCarPos(IMediaSample* pMediaSample, tOdometryData &odometry);
        tResult ReceiveReferencePin(IMediaSample* pMediaSample, tReferencePoints &pos);
        tResult ReceiveDriveSignalPin(IMediaSample* pMediaSample, tDynamicControlValue &llcv);




       /*! The displayed widget*/
       tHandle m_hTimer;
       cFilename carfilename;
       tBool m_bRunning;

        mtum_odometry_visu_core core;

        pthread_mutex_t input_mux;
};
#endif
