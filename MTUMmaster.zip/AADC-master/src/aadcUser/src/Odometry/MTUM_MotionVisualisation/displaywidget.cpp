#include "displaywidget.h"
#include <iostream>
#include <QDebug>
#include <cmath>

#define RAD_TO_DEG 180/M_PI

DisplayWidgetDriver::DisplayWidgetDriver(QWidget* obj,cString Filename) : QWidget(obj)
{ 
    LOG_INFO("DisplayWidget: Start to set up the window!");
    cout << "start to set up the window"<< endl;
    //m_values= vector<Point>();
    m_length = 1000;
    m_lastsignid=0;
    m_signcounter=0;
    cout << "check if filename is empty: "<< endl;
    if(Filename.IsEmpty()){
        cout << "MotionVisualisation: no filename!!"<< endl;
        LOG_WARNING("MotionVisualisation: no filname");
    }else{
        cout << "...OK, filename is not empty. now open image;"<< endl;
    m_carPixmap = QPixmap(Filename.GetPtr());
     cout << ".. Done: Filename: " << Filename.GetPtr() <<  endl;
    if (m_carPixmap.isNull()){
        QFileInfo fi(Filename.GetPtr());
             cout << "could not find image!"<< endl;
             LOG_WARNING(cString::Format("Could not find image: %s", fi.absolutePath().toAscii().data()));
    }
    }
    cout << "init mCars" << endl;
    m_Cars = vector<Car>();
    cout << " init Layout" << endl;
    m_pLayout = new QVBoxLayout (this);
    m_switchModeCB = new QCheckBox("Auto zoom");
    m_switchModeCB->setChecked(true);
    m_pLayout->addWidget(m_switchModeCB);
    m_pLayout->setAlignment(m_switchModeCB,Qt::AlignRight|Qt::AlignTop);
    autoZoom = true;

    setLayout(m_pLayout);

    cout << "connect signals and slots" << endl;
    connect(this,SIGNAL(doSignalRepaint()),this,SLOT(repaint()),Qt::QueuedConnection);
    connect(m_switchModeCB,SIGNAL(stateChanged(int)),this,SLOT(changeZoomMode(int)));
    m_lastDrawing = QTime::currentTime();
    cout << "done with Display widget initializer" << endl;
}

DisplayWidgetDriver::~DisplayWidgetDriver()
{

}

void DisplayWidgetDriver::wheelEvent(QWheelEvent *event){
    float rotations = -2* event->delta() / 8.0 /360.0;
    QPoint px = event->pos();
    //m_switchModeCB->setChecked(false);
    minmax_mux.Enter();
    m_pixels_per_cm =min(1.0*this->width()/(m_x_maxval-m_x_minval), 1.0*this->height()/(m_y_maxval-m_y_minval));
    float mouse_cm_x = px.x()/m_pixels_per_cm+m_x_minval;
    float mouse_cm_y =m_y_maxval - px.y()/m_pixels_per_cm;
    m_x_maxval= (m_x_maxval-mouse_cm_x)*(1.0+rotations)+mouse_cm_x;
    m_x_minval= (m_x_minval-mouse_cm_x)*(1.0+rotations)+mouse_cm_x;
    m_y_maxval= (m_y_maxval-mouse_cm_y)*(1.0+rotations)+mouse_cm_y;
    m_y_minval= (m_y_minval-mouse_cm_y)*(1.0+rotations)+mouse_cm_y;
    minmax_mux.Leave();
    event->accept();
    emit doRepaint();
}

void DisplayWidgetDriver::mouseMoveEvent(QMouseEvent *event)
{
    QPoint px = event->pos();
    //m_switchModeCB->setChecked(false);
    if(event->buttons()&Qt::LeftButton){
        if(prevPos.x()==-1 || prevPos.y() == -1){
            prevPos = px;
        }
    minmax_mux.Enter();
    QPoint d = px - prevPos;
    m_pixels_per_cm =min(1.0*this->width()/(m_x_maxval-m_x_minval), 1.0*this->height()/(m_y_maxval-m_y_minval));
    float mouse_cm_x = -d.x()/m_pixels_per_cm;
    float mouse_cm_y = d.y()/m_pixels_per_cm;
    m_x_maxval= (m_x_maxval+mouse_cm_x);
    m_x_minval= (m_x_minval+mouse_cm_x);
    m_y_maxval= (m_y_maxval+mouse_cm_y);
    m_y_minval= (m_y_minval+mouse_cm_y);
    minmax_mux.Leave();
    prevPos= px;
    event->accept();
    emit doRepaint();
    }
}



void DisplayWidgetDriver::resetMaxMin()
{
    m_x_minval=-10;
    m_x_maxval=10;
    m_y_minval = -10;
    m_y_maxval = 10;
    for(uint i = 0; i < m_values.size(); i++){
        m_values[i].clear();
    }
    m_showbox = false;
    //doRepaint();
}
QPointF DisplayWidgetDriver::getPointPos(Point p){


    qreal x = p.PosX * m_pixels_per_cm + m_zposx;
    qreal y = m_zposy - p.PosY * m_pixels_per_cm;
    return QPointF(x,y);
}
void DisplayWidgetDriver::drawPointDir(QPainter &painter, Point p){

    try{

        QPointF dp = getPointPos(p);

        float x, y;
        x = dp.x() +cos(p.rot)*20;
        y =  dp.y() -sin(p.rot)*20;
        QPointF dp2(x,y);
        float arrowAngleL = p.rot + 3.141592654 - 15*3.141592654/180;
        float arrowAngleR = p.rot + 3.141592654 + 15*3.141592654/180;

        x = dp2.x() + cos(arrowAngleL)*10;
        y = dp2.y()-sin(arrowAngleL)*10;
        QPointF apl(x,y);

        x = dp2.x() + cos(arrowAngleR)*10;
        y = dp2.y()-sin(arrowAngleR)*10;
        QPointF apr(x,y);
        painter.drawLine(dp,dp2);
        painter.drawLine(dp2, apl);
        painter.drawLine(dp2, apr);
    }catch(exception e)
    {
        qDebug() << "caugth exception: " << e.what();
    }

}

void DisplayWidgetDriver::doRepaint()
{
    if(m_lastDrawing > QTime::currentTime().addMSecs(-100)){
        return;
    }
    m_lastDrawing = QTime::currentTime();
    emit doSignalRepaint();

}

void DisplayWidgetDriver::paintEvent(QPaintEvent *){

    try{
        QPainter p(this);
        p.setPen(QPen(Qt::gray,1));
        cars_mutex.Enter();
        points_mutex.Enter();
        dir_mutex.Enter();
        minmax_mux.Enter();

        m_pixels_per_cm =min(1.0*this->width()/(m_x_maxval-m_x_minval), 1.0*this->height()/(m_y_maxval-m_y_minval));

        m_zposx = m_pixels_per_cm * -m_x_minval;
        m_zposy = m_pixels_per_cm * m_y_maxval;

        int xmax = m_zposx+ m_pixels_per_cm* m_x_maxval;
        int ymax = m_zposy+ m_pixels_per_cm*-m_y_minval;

        // draw grid with 10cm per cell
        if(m_y_maxval-m_y_minval < 1000 && m_x_maxval-m_x_minval<1000){
            for(int i =0; i< m_y_maxval; i+=10){
                int x1 = 0;
                int x2 = xmax;
                int y1 = m_zposy -m_pixels_per_cm*i;
                //LOG_INFO(cString::Format("position of line: %d, %d to %d, %d",x1,y1,x2,y1));
                p.drawLine(x1,y1,x2,y1);
            }


            for(int i =0; i >= m_y_minval; i-=10){
                p.drawLine(0,m_zposy -m_pixels_per_cm*i,xmax,m_zposy - m_pixels_per_cm*i);
            }
            for(int i =10; i<= m_x_maxval; i+=10){
                p.drawLine(m_zposx+ i*m_pixels_per_cm,0,m_zposx+ i*m_pixels_per_cm,ymax);
            }
            for(int i =-10; i>= m_x_minval; i-=10){
                p.drawLine(m_zposx+ i*m_pixels_per_cm,0,m_zposx+ i*m_pixels_per_cm,ymax);
            }
        }
        p.setPen(QPen(Qt::black,1));
        p.drawLine(m_zposx,0,m_zposx,ymax);
        p.drawLine(0,m_zposy,xmax,m_zposy);

        int add = 0;

        for (int i = 0; i < m_Cars.size(); i++){
            p.setPen(m_pens[(add+i)%7]);
            p.drawStaticText(3,12*(i+add),tr("Car id: %1 x: %2m y: %3m vel: %4m/s %5m/ss").arg(QString::number(i)).arg(QString::number(m_Cars[i].Pos.PosX/10,5,2)).arg(QString::number(m_Cars[i].Pos.PosY/10,5,2)).arg(QString::number(m_Cars[i].Pos.Vel,5,2)).arg(QString::number(m_Cars[i].Pos.acc,5,2)));
            QPointF car= getPointPos(m_Cars[i].Pos);
            //LOG_INFO(cString::Format("wrote car nr: %d to pos: %f, %f",i,m_Cars[i].PosX, m_Cars[i].PosY));
            if(m_Cars[i].path.size()>1){
                QPointF pLast = getPointPos(m_Cars[i].path[0]);
                for(size_t j = 1; j < m_Cars[i].path.size(); j++){
                    QPointF point = getPointPos(m_Cars[i].path[j]);
                    // qDebug() << "draw line: " << pLast<< "to " << point;
                    p.drawLine(pLast,point);
                    pLast= point;
                }
            }

            if(!m_carPixmap.isNull() && m_Cars[i].valid){
                QTransform trans = QTransform();
                trans.rotateRadians(-m_Cars[i].Pos.rot);
                QPixmap dp = m_carPixmap.scaledToWidth(m_pixels_per_cm*3).transformed(trans);
                int px= car.x()-dp.width()/2;
                int py = car.y() -dp.height()/2;
                p.drawPixmap(px,py,dp);
            }
            Point point = m_Cars[i].Pos;
            point.rot += M_PI/2;
            drawPointDir(p,point);
        }
        add += m_Cars.size();
        for(int i =0; i < m_Points.size(); i++){
            p.setPen(m_pens[(add+i)%7]);
            p.drawStaticText(3,12*(i+add),tr("Reference id: %1 p1: x: %2m y: %3m phi: %4deg vel: %5m/s curvature: %6 1/m").arg(QString::number(i)).arg(QString::number(m_Points[i].Pos[0].PosX/10,5,2)).arg(QString::number(m_Points[i].Pos[0].PosY/10,5,2)).arg(QString::number(m_Points[i].Pos[0].rot*180/3.14,5,2),QString::number(m_Points[i].Pos[0].Vel,5,2),QString::number(m_Points[i].Pos[0].curvature,5,2)));

            QPointF pLast = getPointPos(m_Points[i].hist[0]);
            for(size_t j = 1; j < m_Points[i].hist.size(); j++){
                QPointF point = getPointPos(m_Points[i].hist[j]);
                // qDebug() << "draw line: " << pLast<< "to " << point;
                p.drawLine(pLast,point);
                pLast= point;
            }
           // cout << "num valid:" << m_Points[i].numValid << endl;
            for(int j =0; j < m_Points[i].numValid; j++){
                p.setPen(p.pen().color().lighter(100+50/m_Points[i].numValid));
                drawPointDir(p,m_Points[i].Pos[j]);

            }

        }

        add += m_Points.size();
        for(int i =0; i < m_DriveDirs.size(); i++){
            p.setPen(m_pens[(add+i)%7]);
            p.drawStaticText(3,12*(i+add),tr("Drive dir id: %1 Curvature: %2 1/m vel: %3m/s acc: %4m/s2").arg(QString::number(i)).arg(QString::number(m_DriveDirs[i].curvature,5,2)).arg(QString::number(m_DriveDirs[i].vel,5,2),QString::number(m_DriveDirs[i].acc,5,2)));
            if(fabs(m_DriveDirs[i].start.rot) > 0.0001){

            p.drawEllipse(getPointPos(m_DriveDirs[i].center),m_pixels_per_cm*m_DriveDirs[i].radius,m_pixels_per_cm*m_DriveDirs[i].radius);
}
        }
    }
    catch(exception e){
        stringstream ss;
        ss << "problem while drawing:" << e.what();
        LOG_ERROR(ss.str().c_str());
    }


   minmax_mux.Leave();
   dir_mutex.Leave();
   points_mutex.Leave();
   cars_mutex.Leave();


}




void DisplayWidgetDriver::updateMinMax(float xPos, float yPos)
{
    minmax_mux.Enter();

    if(autoZoom){

    m_x_maxval = (xPos>m_x_maxval)?xPos:m_x_maxval;
    m_x_minval = (xPos<m_x_minval)?xPos:m_x_minval;

    m_y_maxval = (yPos>m_y_maxval)?yPos:m_y_maxval;
    m_y_minval = (yPos< m_y_minval)?yPos:m_y_minval;

    m_x_maxval = (m_x_maxval > 1000)? 1000: m_x_maxval;
    m_x_minval = (m_x_minval < -1000)? -1000: m_x_minval;

    m_y_maxval = (m_y_maxval > 1000)? 1000: m_y_maxval;
    m_y_minval = (m_y_minval < -1000)? -1000: m_y_minval;
    }
    minmax_mux.Leave();
}


void DisplayWidgetDriver::insertCar(int id, float xPos, float yPos, float rot, float vel,float acc,bool valid)
{
    Point p;
    p.PosX = xPos*10;
    p.PosY = yPos*10;
    p.rot = rot;
    p.Vel = vel;
    p.acc = acc;
    cars_mutex.Enter();
    {

    if(m_Cars.size() <= id){
        Car c;
        c.path =std::deque<Point>();
        c.path.push_back(p);
        c.Pos = p;
        c.valid = valid;
        m_Cars.push_back(c);
        LOG_INFO(cString::Format("insert Car: id: %d, pos: %f, %f, rot: %f",id,xPos,yPos,rot));
    }else{
        float dx = m_Cars[id].path.back().PosX -p.PosX;
        float dy = m_Cars[id].path.back() .PosY - p.PosY;
        float dist = dx*dx + dy*dy;

        if(dist > 0.01){

            if(m_Cars[id].path.size() > 5000){

                //LOG_INFO(cString::Format("deleted one value of posValues pos: %f, %f, rot: %f",m_Cars[id].path[0].PosX,m_Cars[id].path[0].PosY,m_Cars[id].path[0].rot));
                m_Cars[id].path.pop_front();
            }
            m_Cars[id].path.push_back(p);

        }
        m_Cars[id].Pos = p;
        m_Cars[id].valid = valid;
    }
    }
    cars_mutex.Enter();
    updateMinMax(p.PosX,p.PosY);
    doRepaint();
}

void DisplayWidgetDriver::insertPoints(int id, tReferencePoints points)
{
    points_mutex.Enter();
    {
    //LOG_INFO("insert Point");
    Reference r;
    while(m_Points.size() <= id){
        r.hist = std::deque<Point>();
        m_Points.push_back(r);
        r.numValid=0;
        LOG_INFO("insert Reference Points");
    }

    for(int i =0; i< points.numPoints; i++){
        Point p;
        p.PosX = points.points[i].x*10;
        p.PosY = points.points[i].y*10;
        p.rot = points.points[i].phi +3.141592654/2;
        p.Vel = points.points[i].vel;
        p.curvature = points.points[i].curvature;
        m_Points[id].Pos[i] = p;
        updateMinMax(p.PosX+1,p.PosY+1);
        updateMinMax(p.PosX-1,p.PosY-1);
    }
    m_Points[id].numValid = points.numPoints;
    if(m_Points[id].hist.size() == 0){
        Point p;
        p.PosX = points.points[0].x*10;
        p.PosY = points.points[0].y*10;
        m_Points[id].hist.push_back(p);
    }else{
    float dx = m_Points[id].hist.back().PosX -points.points[0].x;
    float dy = m_Points[id].hist.back().PosY -points.points[0].y;
    float dist = dx*dx + dy*dy;

    if(points.numPoints > 0 && (m_Points[id].hist.size()< 10 || dist > 0.001)){

        if(m_Points[id].hist.size() > 5000){

            //LOG_INFO(cString::Format("deleted one value of posValues pos: %f, %f, rot: %f",m_Cars[id].path[0].PosX,m_Cars[id].path[0].PosY,m_Cars[id].path[0].rot));
            m_Points[id].hist.pop_front();
        }
        Point p;
        p.PosX = points.points[0].x*10;
        p.PosY = points.points[0].y*10;
        m_Points[id].hist.push_back(p);

    }
    }
    points_mutex.Leave();
    }
    doRepaint();
}

void DisplayWidgetDriver::insertDriveDir(int id, tDynamicControlValue value)
{

    DriveDir d;
    while(m_DriveDirs.size() <= id){
        m_DriveDirs.push_back(d);
        LOG_INFO("insert Drive Dir");
    }

    if(m_Cars.size() < 1){
        Point p;
        p.PosX =0;
        p.PosY =0;
        Car c;
        c.path =std::deque<Point>();
        c.path.push_back(p);
        c.Pos = p;
        m_Cars.push_back(c);
    }
    cars_mutex.Enter();
    Point p = m_Cars[0].Pos;
    cars_mutex.Leave();
    float radius = (value.setPointCurvature==0)?1e5:10/value.setPointCurvature;
    Point center;
    center.PosX= p.PosX - cos(p.rot/*-3.141592654/2*/)*radius;
    center.PosY =p.PosY - sin(p.rot/*-3.141592654/2*/)*radius;
    d.center = center;
    d.radius = abs(radius);
    d.start = p;
    d.vel =value.setPointSpeed;
    d.curvature = value.setPointCurvature;
    d.acc = value.setPointAcceleration;
    dir_mutex.Enter();
    m_DriveDirs[id] = d;
    dir_mutex.Leave();
    doRepaint();
}

void DisplayWidgetDriver::clearAll()
{
    cars_mutex.Enter();
    points_mutex.Enter();
    dir_mutex.Enter();
    minmax_mux.Enter();
    resetMaxMin();
    m_Cars.clear();
    m_Points.clear();
    m_DriveDirs.clear();
    minmax_mux.Leave();
    dir_mutex.Leave();
    points_mutex.Leave();
    cars_mutex.Leave();

}

void DisplayWidgetDriver::changeZoomMode(int mode)
{
    minmax_mux.Enter();
    if(mode == 2)
        autoZoom = true;
    else if(mode == 0)
        autoZoom = false;
    minmax_mux.Leave();
    cout << "changed zoom mode to: "<< mode << endl;

}

void DisplayWidgetDriver::mousePressEvent(QMouseEvent *event)
{
    prevPos = event->pos();
}

void DisplayWidgetDriver::mouseReleaseEvent(QMouseEvent *event)
{
    prevPos = QPoint(-1,-1);
}


