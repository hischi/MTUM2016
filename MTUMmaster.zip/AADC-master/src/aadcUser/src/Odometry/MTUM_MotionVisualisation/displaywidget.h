#ifndef DISPWIDGET_DRIVER_FILTER
#define DISPWIDGET_DRIVER_FILTER


#include "stdafx.h"
#include <map>
#include <deque>
#include "ReferencePointsType.h"
#include "DynamicControlValueType.h"
#include <QTime>

class DisplayWidgetDriver: public QWidget
{
	Q_OBJECT

	public:
		/*! constructor for the widget
        @param parent the parent widget
		*/
        DisplayWidgetDriver(QWidget* obj, cString Filename);
        ~DisplayWidgetDriver();


        virtual void paintEvent(QPaintEvent *);
        void wheelEvent(QWheelEvent *event);
        void mouseMoveEvent(QMouseEvent *event);
        void mousePressEvent(QMouseEvent *event);
        void mouseReleaseEvent(QMouseEvent *event);

        void resetMaxMin();

        struct Point{
            float PosX;
            float PosY;
            float rot;
            float Vel;
            float acc;
            float curvature;

        };


        vector<vector<Point> > m_values;


        struct Car{
            Point Pos;
            bool valid;
            std::deque<Point> path;
        };

        vector<Car> m_Cars;
        struct Reference{
            Point Pos[REFERENCEPOINTSIZE];
            int numValid;
            std::deque<Point> hist;
        };
        cMutex cars_mutex;

        vector<Reference> m_Points;
        struct DriveDir{
            Point center;
            Point start;
            float vel;
            float acc;
            float radius;
            float curvature;
        };
        cMutex points_mutex;

        vector<DriveDir> m_DriveDirs;
        cMutex dir_mutex;
        const QPen m_pens[7] = {{Qt::red,1}, {Qt::blue,1}, {Qt::green,1},{Qt::black,1},{Qt::magenta,1},{Qt::cyan,1},{Qt::gray,1}};

    public slots:
        void insertCar(int id, float xPos, float yPos, float rot, float vel,float acc,bool valid);
        void insertPoints(int id, tReferencePoints points);
        void insertDriveDir(int id, tDynamicControlValue value);
        void clearAll();
	private slots:
        /*! slot for slider Changes*/
        //void SliderMoved(float val,int num);
        //void saveValues();
        void changeZoomMode(int mode);
    signals:
        /* signal for sending the state
        @param state state to be sent
        @param entryId current entry to be sent
        */
        //void sendState(tInt16 state, float entryId);
        void doSignalRepaint();
        void showError();
    public:
        //void onConfig(cFilename &file);

       void updateMinMax(float xPos, float yPos);
protected:
        QPointF getPointPos(Point p);
        void drawPointDir(QPainter &painter, Point p);
private:
        bool autoZoom;
        void doRepaint();
        QLayout* m_pLayout;
        QCheckBox* m_switchModeCB;
		/*! the main widget */
		QWidget* m_pWidget;		

        QPoint prevPos;

        unsigned int m_length;
        float m_x_maxval;

        float m_x_minval;

        float m_y_maxval;
        float m_y_minval;

        float m_zposx;
        float m_zposy;
        float m_pixels_per_cm;
        bool m_showbox;
        vector<QString> m_strs;


        int dispcounter;
        int m_lastsignid;
        int m_signcounter;

        struct Pos{
            float driven;
            float ddriven;
            float x;
            float y;
            float rot;
            pthread_mutex_t mux;
        };
        vector<Pos> m_pos;
        cMutex minmax_mux;


        QPixmap m_carPixmap;
        QTime m_lastDrawing;

};



#endif
