/**********************************************************************
* Copyright (c) 2014 BFFT Gesellschaft fuer Fahrzeugtechnik mbH.
* All rights reserved.
**********************************************************************
* $Author:: spiesra $  $Date:: 2014-07-07 13:58:29#$ $Rev:: 24058   $
**********************************************************************/
#ifndef __STD_INCLUDES_HEADER
#define __STD_INCLUDES_HEADER
#ifdef WIN32
	#include <atlimage.h>
#endif
#include <adtf_platform_inc.h>
#include <adtf_plugin_sdk.h>
using namespace adtf;

#include <adtf_graphics.h>
using namespace adtf_graphics;

// opencv header
#include <opencv/cv.h>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/video/tracking.hpp>
#include <opencv2/calib3d/calib3d.hpp>
using namespace cv;


#include <QtGui/QtGui>
#include <QtCore/QtCore>

#include <iostream>



#endif // __STD_INCLUDES_HEADER
