
/**********************************************************************
* Copyright (c) 2014 BFFT Gesellschaft fuer Fahrzeugtechnik mbH.
* All rights reserved.
**********************************************************************
* $Author:: spiesra $  $Date:: 2014-07-23 14:31:29#$ $Rev:: 24478   $
**********************************************************************/

#include "stdafx.h"
#include "cMotionVisualisation.h"

ADTF_FILTER_PLUGIN("MTUM_MOTION_VISU", OID_MOTION_VISU, cMotionVisualisation)



cMotionVisualisation::cMotionVisualisation(const tChar* __info):
    QObject(),
    cBaseQtFilter(__info)
{
    qRegisterMetaType<tReferencePoints>("tReferencePoints");
    qRegisterMetaType<tDynamicControlValue>("tLLControllerValue");


    ConfigureConnectionPins(0);

    // configure the reader
    m_pos_x =0;
    m_pos_y=0;
    m_rot =0;
    SetPropertyStr("Car_picture","../../../src/aadcUser/src/Odometry/MTUM_MotionVisualisation/car1.png");
    SetPropertyBool("Car_picture" NSSUBPROP_FILENAME, tTrue);
    SetPropertyStr("Car_picture" NSSUBPROP_FILENAME NSSUBSUBPROP_EXTENSIONFILTER, "png files (*.png)");
}

cMotionVisualisation::~cMotionVisualisation()
{
}

tResult cMotionVisualisation::Init(tInitStage eStage, __exception)
{
    cout << " motion visu: init stage: " << eStage << endl;
    RETURN_IF_FAILED(cBaseQtFilter::Init(eStage, __exception_ptr));
    if (eStage == StageFirst)
    {
        cObjectPtr<IMediaDescriptionManager> pDescManager;
        RETURN_IF_FAILED(_runtime->GetObject(OID_ADTF_MEDIA_DESCRIPTION_MANAGER,IID_ADTF_MEDIA_DESCRIPTION_MANAGER,(tVoid**)&pDescManager,__exception_ptr));


        tChar const * strDescCarPos = pDescManager->GetMediaDescription(ODOMETRYDATA);
        RETURN_IF_POINTER_NULL(strDescCarPos);
        //m_pTypeCarPos = new cMediaType(0, 0, 0, "tOdometryData", strDescCarPos,IMediaDescription::MDF_DDL_DEFAULT_VERSION);
        m_pTypeCarPos = new cMediaType(0,0,0,ODOMETRYDATA, strDescCarPos,IMediaDescription::MDF_DDL_DEFAULT_VERSION);
        //RETURN_IF_FAILED(m_pTypeCarPos->GetInterface(IID_ADTF_MEDIA_TYPE_DESCRIPTION, (tVoid**)&m_pCoderDescCarPos));


        tChar const * strDescReference = pDescManager->GetMediaDescription(REFERENCEPOINTS);
        RETURN_IF_POINTER_NULL(strDescReference);
        m_pTypeReferencePoint = new cMediaType(0, 0, 0, REFERENCEPOINTS, strDescReference,IMediaDescription::MDF_DDL_DEFAULT_VERSION);

        tChar const * strDescDriveSignal = pDescManager->GetMediaDescription(DYNAMICCONTROLVALUE);
        RETURN_IF_POINTER_NULL(strDescDriveSignal);
        //LOG_INFO(strDescDriveSignal);
        m_pTypeLLControllerValue = new cMediaType(0, 0, 0, DYNAMICCONTROLVALUE, strDescDriveSignal,IMediaDescription::MDF_DDL_DEFAULT_VERSION);



    }
    else if (eStage == StageNormal)
    {
        carfilename ="../../../src/aadcUser/src/Odometry/MTUM_MotionVisualisation/car1.png"; // GetPropertyStr("Car_picture");
        //create path from path
        ADTF_GET_CONFIG_FILENAME(carfilename);
        carfilename = carfilename.CreateAbsolutePath(".");


    }
    else if (eStage == StageGraphReady)
    {




    }
    RETURN_NOERROR;
}

tHandle cMotionVisualisation::CreateView()
{
    qRegisterMetaType<tReferencePoints>("tReferencePoints");
    qRegisterMetaType<tDynamicControlValue>("tLLControllerValue");

    cout << "motionVisu: create view " << endl;
    LOG_INFO("MotionVisu: createView has been called!!!");
    QWidget* pWidget = (QWidget*)m_pViewport->VP_GetWindow();

    m_pWidget = new DisplayWidgetDriver(pWidget,carfilename);
    cout <<"connect signals and slots: " << endl;

    //connect(this,SIGNAL(startStream(uint,QString)),m_pWidget, SLOT(insertStream(uint,QString)),Qt::QueuedConnection);
    //connect(this,SIGNAL(insertValue(float,float,uint)),m_pWidget, SLOT(insertValue(float,float,uint)),Qt::QueuedConnection);
    connect(this,SIGNAL(insertCar(int,float,float,float,float,float,bool)),m_pWidget, SLOT(insertCar(int,float,float,float,float,float,bool)),Qt::QueuedConnection);
    connect(this,SIGNAL(insertPoints(int,tReferencePoints)),m_pWidget, SLOT(insertPoints(int,tReferencePoints)),Qt::QueuedConnection);
    connect(this,SIGNAL(insertDriveSignal(int,tDynamicControlValue)),m_pWidget, SLOT(insertDriveDir(int,tDynamicControlValue)),Qt::QueuedConnection);
    cout << " call reset pos" << endl;
    ResetPos();

    /*LOG_INFO("Test: now insertStream is called");
    for(int i =0; i< m_pos.size(); i++){
        LOG_INFO(cString::Format("input pin: %s",m_pDynamicInputPins[i]->GetName()));
        emit startStream(i,tr(m_pDynamicInputPins[i]->GetName()));
    }

    for(int i =0; i< m_signposes.size(); i++){
        LOG_INFO(cString::Format("Motion visu: Sign input pin: %s",m_pDynamicInputPinsSign[i]->GetName()));
        emit startSignStream(i,tr(m_pDynamicInputPinsSign[i]->GetName()));
    }
    */
    //emit startStream(1);
    //m_pWidget->insertStream(0);

    // m_pWidget->insertStream(1);
    cout << "return m_pWidget" << endl;
    return (tHandle)m_pWidget;
}

void cMotionVisualisation::ResetPos()
{
    m_pos_x =0;
    m_pos_y = 0;
    m_rot =0;
    m_pWidget->resetMaxMin();
}

tResult cMotionVisualisation::OnPinEvent(	IPin* pSource, tInt nEventCode, tInt nParam1, tInt nParam2, IMediaSample* pMediaSample)
{

    if (nEventCode == IPinEventSink::PE_MediaSampleReceived && pMediaSample != NULL)
    {


        for(uint i =0; i< m_pDynamicInputPinsDriveSignal.size(); i++){
            if(pSource == m_pDynamicInputPinsDriveSignal[i]){
                //LOG_INFO("Found Drive Signal pin");
                tDynamicControlValue llcv;
                ReceiveDriveSignalPin(pMediaSample, llcv);
                //LOG_INFO(cString::Format("got drive signal values: curvature: %f, acceleration %f",llcv.curvature,llcv.acceleration));
                //LOG_INFO("insert points");
                emit insertDriveSignal(i,llcv);
            }
        }
        for(uint i =0; i< m_pDynamicInputPinsCar.size(); i++){
            if(pSource == m_pDynamicInputPinsCar[i]){
                //LOG_INFO("dynamic car pin");
                tOdometryData d;
                ReceiveCarPos(pMediaSample, d);
                emit insertCar(i,d.x, d.y, d.phi,d.vel,d.acc,d.valid);

            }
        }
        for(uint i =0; i< m_pDynamicInputPinsReference.size(); i++){
            if(pSource == m_pDynamicInputPinsReference[i]){
                //LOG_INFO("Found reference pin");
                tReferencePoints ps;
                ReceiveReferencePin(pMediaSample, ps);
                //LOG_INFO("insert points");
                emit insertPoints(i,ps);
            }
        }



    }
    RETURN_NOERROR;
}

tResult cMotionVisualisation::ReleaseView()
{
    cout << "Motion Visu: release view" << endl;
    if (m_pWidget != NULL)
    {

        disconnect(m_pWidget,SLOT(insertCar(int,float,float,float,float,float,bool)));
        disconnect(m_pWidget,SLOT(insertDriveDir(int,tDynamicControlValue)));
        disconnect(m_pWidget,SLOT(insertPoints(int,tReferencePoints)));
        m_pWidget->clearAll();
        delete m_pWidget;
        m_pWidget = NULL;
    }
    RETURN_NOERROR;
}

tResult cMotionVisualisation::Start(__exception)
{
    RETURN_IF_FAILED(cBaseQtFilter::Start(__exception_ptr));
    //LOG_INFO("cBaseQtFilter has been started");


    RETURN_NOERROR;
}

tResult cMotionVisualisation::Run(tInt nActivationCode, const tVoid* pvUserData, tInt szUserDataSize, ucom::IException** __exception_ptr/* =NULL */)
{
    LOG_INFO("cBaseQtFilter is running.");
    return cBaseQtFilter::Run(nActivationCode, pvUserData, szUserDataSize, __exception_ptr);
}

tResult cMotionVisualisation::Stop(__exception)
{
    RETURN_IF_FAILED(cBaseQtFilter::Stop(__exception_ptr));

    RETURN_NOERROR;
}

tResult cMotionVisualisation::Shutdown(tInitStage eStage, __exception)
{		
    return cBaseQtFilter::Shutdown(eStage, __exception_ptr);
}

tResult cMotionVisualisation::Connect(IPin* pSource,
                                      const tChar* strDestName,
                                      __exception)
{

    THROW_IF_POINTER_NULL(pSource);
    cout << "Motion visualisation: connect pin: "<< pSource->GetName() << endl;
    cString strDestPinname("");
    if (strDestName != NULL)
    {
        strDestPinname = cString(strDestName);
    }
    else
    {
        strDestPinname = pSource->GetName();
    }

    cObjectPtr<IPin> pPinInput;

    if(IS_OK(FindPin(strDestName, IPin::PD_Input, &pPinInput)))
    {
       cerr << "error: MotionVisualisation:  while finding pin" << endl;
    }

    cObjectPtr<IMediaType> pMediaType;
    if (IS_FAILED((pSource->GetMediaType(&pMediaType))))
    {
        cerr << "error: MotionVisualistation:  found no media description" << endl;
    }
    cObjectPtr<cDynamicInputPin> dpin = new cDynamicInputPin();
    cout << "pMediaType is equal to referencePoint:" <<pMediaType->IsEqual(m_pTypeReferencePoint) << " LL controller Value: " << pMediaType->IsEqual(m_pTypeLLControllerValue) << " car pos: " <<pMediaType->IsEqual(m_pTypeCarPos) << endl;
    cout << "pin name: " << strDestPinname << endl;
    if(pMediaType->IsEqual(m_pTypeReferencePoint) || pMediaType->IsEqual(m_pTypeLLControllerValue)|| pMediaType->IsEqual(m_pTypeCarPos)){

        if(IS_OK(dpin->Create(strDestName,pMediaType, static_cast<IPinEventSink*> (this)))){
            cout << "created pin: "<< dpin << " name: " << strDestName << endl;
            RegisterPin(dpin);
            cout << "registered pin" << endl;
        }else
        {
            if (strDestName)
            {
                cerr << "error: Motion Visu: Can not create the new pin !" << endl;
            }
            else
            {
                cerr << "error: Can not create the new pin!"<< endl;
            }
        }
        if(pMediaType->IsEqual(m_pTypeReferencePoint)){
            LOG_INFO("create new reference Points input pin");
            m_pDynamicInputPinsReference.push_back(dpin);
        }else if(pMediaType->IsEqual(m_pTypeLLControllerValue))
        {
            LOG_INFO("create new drive Signal Points input pin");
            m_pDynamicInputPinsDriveSignal.push_back(dpin);
        }else if(pMediaType->IsEqual(m_pTypeCarPos)){
            LOG_INFO("create new CarPosition input pin");
            m_pDynamicInputPinsCar.push_back(dpin);
        }

        RETURN_IF_FAILED(cFilter::Connect(pSource, strDestPinname.GetPtr(), __exception_ptr));
    }


    RETURN_NOERROR;
}





tResult cMotionVisualisation::ReceiveReferencePin(IMediaSample* pMediaSample, tReferencePoints &ref)
{


    {
        // this will aquire the read lock on the sample and declare and initialize a pointer to the data
        __sample_read_lock(pMediaSample, tReferencePoints, pData);
        // now we can access the sample data through the pointer
        ref = *pData;
        // the read lock on the sample will be released when leaving this scope
    }


    RETURN_NOERROR;
}

tResult cMotionVisualisation::ReceiveDriveSignalPin(IMediaSample *pMediaSample, tDynamicControlValue &llcv)
{
    {
        // this will aquire the read lock on the sample and declare and initialize a pointer to the data
        __sample_read_lock(pMediaSample, tDynamicControlValue, pData);
        // now we can access the sample data through the pointer
        llcv = *pData;
        // the read lock on the sample will be released when leaving this scope
    }


    RETURN_NOERROR;

}
tResult cMotionVisualisation::ReceiveCarPos(IMediaSample* pMediaSample, tOdometryData &odometry)
{
    __sample_read_lock(pMediaSample, tOdometryData,pData);
    odometry = *pData;

    RETURN_NOERROR;
}





