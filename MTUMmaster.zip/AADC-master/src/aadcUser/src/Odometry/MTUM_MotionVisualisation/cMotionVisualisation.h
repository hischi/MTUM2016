/**********************************************************************
* Copyright (c) 2013 BFFT Gesellschaft fuer Fahrzeugtechnik mbH.
* All rights reserved.
**********************************************************************
* $Author:: spiesra $  $Date:: 2014-07-23 14:31:29#$ $Rev:: 24478   $
**********************************************************************/

/*! \brief QRReader
 *         
 *  
 */
#ifndef _MOTIONVISU_HEADER
#define _MOTIONVISU_HEADER
#define OID_MOTION_VISU "adtf.aadc.motionvisalisation"

#include "stdafx.h"
#include "displaywidget.h"
#include "ReferencePointsType.h"
#include "DynamicControlValueType.h"
#include "OdometryDataType.h"
Q_DECLARE_METATYPE(tReferencePoints);
Q_DECLARE_METATYPE(tDynamicControlValue);
class cMotionVisualisation : public QObject, public cBaseQtFilter
{
    Q_OBJECT

    ADTF_DECLARE_FILTER_VERSION(OID_MOTION_VISU, "MTUM_Motion_Visualisation", adtf::OBJCAT_Tool, "Motion Visualisation", 1, 0, 0, "Beta Version");
    public:
        cMotionVisualisation(const tChar* __info);
        virtual ~cMotionVisualisation();

        //cInputPin m_MotionPinIn;
        //cInputPin m_PinIn2;




        vector<cObjectPtr<cDynamicInputPin> > m_pDynamicInputPinsCar;
        vector<cObjectPtr<cDynamicInputPin> > m_pDynamicInputPinsReference;
        vector<cObjectPtr<cDynamicInputPin> > m_pDynamicInputPinsDriveSignal;


        cObjectPtr<cMediaType>m_pTypeCarPos;
        cObjectPtr<cMediaType>m_pTypeReferencePoint;
        cObjectPtr<cMediaType>m_pTypeLLControllerValue;


        /*! overrides cFilter */
        virtual tResult Init(tInitStage eStage, __exception = NULL);

        /*! overrides cFilter */
        virtual tResult Start(__exception = NULL);

        /*! overrides cFilter */
        virtual tResult Stop(__exception = NULL);

        /*! overrides cFilter */
        virtual tResult Shutdown(tInitStage eStage, __exception = NULL);

        virtual tResult OnPinEvent(IPin *pSource, tInt nEventCode, tInt nParam1, tInt nParam2, IMediaSample *pMediaSample);

        tResult Run(tInt nActivationCode, const tVoid* pvUserData, tInt szUserDataSize, ucom::IException** __exception_ptr =NULL );

        /*! overrides cFilter */
        tResult Connect(IPin* pSource,
                        const tChar* strDestName,
                        __exception=NULL);

        tResult ReceiveCarPos(IMediaSample* pMediaSample, tOdometryData &odometry);
        tResult ReceiveReferencePin(IMediaSample* pMediaSample, tReferencePoints &pos);
        tResult ReceiveDriveSignalPin(IMediaSample* pMediaSample, tDynamicControlValue &llcv);
protected: // Implement cBaseQtFilter
        void sendData(uint number, float value);

        /*! Creates the widget instance*/
        tHandle CreateView();

        /*! Destroys the widget instance*/
        tResult ReleaseView();

    public slots:
        /*! function which transmits the state
        @param state state to be sent
        @param entryId current entry to be sent
        */
        //tResult OnSendState(tInt16 state, float entryId);
   signals:
        void insertCar(int,float,float,float,float,float,bool);
        void insertPoints(int, tReferencePoints);
        void insertDriveSignal(int,tDynamicControlValue);
	private:
       void ResetPos();


       /*! The displayed widget*/
       DisplayWidgetDriver *m_pWidget;
        cFilename carfilename;


             // cFilename m_fileConfig;


        struct Pos{
            float driven;
            float x;
            float y;
            float rot;
        };
        vector<Pos> m_pos;
        float m_pos_x;
        float m_pos_y;
        float m_rot;
        pthread_mutex_t input_mux;
};
#endif
