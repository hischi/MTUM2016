/**
 *
 * ADTF Template Project Filter.
 *
 * @file
 * Copyright &copy; Audi Electronics Venture GmbH. All rights reserved
 *
 * $Author: belkera $
 * $Date: 2011-06-30 16:51:21 +0200 (Do, 30 Jun 2011) $
 * $Revision: 26514 $
 *
 * @remarks
 *
 */
#pragma once

#define OID_ADTF_TEMPLATE_FILTER "adtf.mtum.point2pid"
#include "ReferencePointsType.h"
#include "SignalValueType.h"
#include "LaneStruct.h"
#include "PolyModel.h"
#define LANE_WIDTH 460.0
//*************************************************************************************************
class cTemplateProjectFilter : public adtf::cFilter
{
    ADTF_FILTER(OID_ADTF_TEMPLATE_FILTER, "Point2PID", adtf::OBJCAT_DataFilter);

protected:
    cInputPin    m_oLaneInput;
    cOutputPin   m_out;

    double kp = 2;
    double ki = 0.0003;
    double kd = 200000;

    bool first = false;
    tTimeStamp lastTime;
    double lastX;
    double lastSteering;
    double i;


public:
    cTemplateProjectFilter(const tChar* __info);
    virtual ~cTemplateProjectFilter();

protected:
    tResult SendSignalValue(tSignalValue &p);
    tResult Init(tInitStage eStage, __exception);
    tResult Shutdown(tInitStage eStage, __exception);

    // implements IPinEventSink
    tResult OnPinEvent(IPin* pSource,
                       tInt nEventCode,
                       tInt nParam1,
                       tInt nParam2,
                       IMediaSample* pMediaSample);
};

//*************************************************************************************************

