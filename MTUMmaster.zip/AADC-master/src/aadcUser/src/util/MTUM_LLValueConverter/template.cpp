/**
 *
 * ADTF Template Project
 *
 * @file
 * Copyright &copy; Audi Electronics Venture GmbH. All rights reserved
 *
 * $Author: belkera $
 * $Date: 2011-06-30 16:51:21 +0200 (Do, 30 Jun 2011) $
 * $Revision: 26514 $
 *
 * @remarks
 *
 */
#include "stdafx.h"
#include "template.h"
#undef __USE_SVID
#undef __USE_MISC
#include "math.h"
#include <iostream>

/// Create filter shell
ADTF_FILTER_PLUGIN("Low Level Value Converter", OID_ADTF_TEMPLATE_FILTER, cTemplateProjectFilter);


cTemplateProjectFilter::cTemplateProjectFilter(const tChar* __info):cFilter(__info)
{
    SetPropertyStr("CalibrationFile","");
    SetPropertyBool("CalibrationFile" NSSUBPROP_FILENAME, tTrue);
    SetPropertyStr("CalibrationFile" NSSUBPROP_FILENAME NSSUBSUBPROP_EXTENSIONFILTER, "csv Files (*.csv)");
    SetPropertyStr("CalibrationFile" NSSUBPROP_DESCRIPTION, "The Calibrationfile for the reference points");

 wheelLeft.tach =0;
 wheelRight.tach =0;
  m_steer_calib.push_back(make_pair(-1,60));
  m_steer_calib.push_back(make_pair(0,90));
  m_steer_calib.push_back(make_pair(1,120));

  m_acc_calib.push_back(make_pair(-7,0));
  m_acc_calib.push_back(make_pair(0,90));
  m_acc_calib.push_back(make_pair(7,180));

}
cTemplateProjectFilter::~cTemplateProjectFilter(){}


tFloat cTemplateProjectFilter::interpolateAcc(tFloat in)
{
    if(in < m_acc_calib.front().first){
        return m_acc_calib.front().second;
    }
    int i;
    for(i =0; i< m_acc_calib.size() && in > m_acc_calib[i].first; i++){
    }

    if(i == m_acc_calib.size()){
        return m_acc_calib.back().second;
    }
    tFloat tween = (in - m_acc_calib[i-1].first)/(m_acc_calib[i].first-m_acc_calib[i-1].first);
    return m_acc_calib[i-1].second + (m_acc_calib[i].second-m_acc_calib[i-1].second)*tween;
}

tFloat cTemplateProjectFilter::interpolateSteer(tFloat in)
{
    if(in < m_steer_calib.front().first){
        return m_steer_calib.front().second;
    }
    int i;
    for(i =0; i< m_steer_calib.size() && in > m_steer_calib[i].first; i++){
    }
    if(i == m_steer_calib.size()){
        return m_steer_calib.back().second;
    }
    tFloat tween = (in - m_steer_calib[i-1].first)/(m_steer_calib[i].first-m_steer_calib[i-1].first);
    return m_steer_calib[i-1].second + (m_steer_calib[i].second-m_steer_calib[i-1].second)*tween;


}

tResult cTemplateProjectFilter::Init(tInitStage eStage, __exception)
{
    // never miss calling the parent implementation!!
    RETURN_IF_FAILED(cFilter::Init(eStage, __exception_ptr))
    
    // in StageFirst you can create and register your static pins.
    if (eStage == StageFirst)
    {

        // create and register the input pin
        RETURN_IF_FAILED(m_oTemplateInput.Create("input_LLValue", new cMediaType(0,0,0,LLCONTROLLERVALUES), this));
        RETURN_IF_FAILED(RegisterPin(&m_oTemplateInput));


        
        // create and register the output pin
        RETURN_IF_FAILED(m_oSteeringOutput.Create("output_Steering", new cMediaType(0,0,0,SIGNALVALUE), this));
        RETURN_IF_FAILED(RegisterPin(&m_oSteeringOutput));

        RETURN_IF_FAILED(m_oAccelerationOutput.Create("output_Acceleration",new cMediaType(0,0,0,SIGNALVALUE), this));
        RETURN_IF_FAILED(RegisterPin(&m_oAccelerationOutput));

        RETURN_IF_FAILED(m_oWheelLeft.Create("Wheel_left",new cMediaType(0,0,0,WHEELDATA),this));
        RETURN_IF_FAILED(RegisterPin(&m_oWheelLeft));

        RETURN_IF_FAILED(m_oWheelRight.Create("Wheel_right",new cMediaType(0,0,0,WHEELDATA),this));
        RETURN_IF_FAILED(RegisterPin(&m_oWheelRight));
    }
    else if (eStage == StageNormal)
    {
        // In this stage you would do further initialisation and/or create your dynamic pins.
        // Please take a look at the demo_dynamicpin example for further reference.
    }
    else if (eStage == StageGraphReady)
    {
        // All pin connections have been established in this stage so you can query your pins
        // about their media types and additional meta data.
        // Please take a look at the demo_imageproc example for further reference.
        readCalibration(GetPropertyStr("CalibrationFile"));
    }

    RETURN_NOERROR;
}

tResult cTemplateProjectFilter::Shutdown(tInitStage eStage, __exception)
{
    // In each stage clean up everything that you initiaized in the corresponding stage during Init.
    // Pins are an exception: 
    // - The base class takes care of static pins that are members of this class.
    // - Dynamic pins have to be cleaned up in the ReleasePins method, please see the demo_dynamicpin
    //   example for further reference.
    
    if (eStage == StageGraphReady)
    {
    }
    else if (eStage == StageNormal)
    {
    }
    else if (eStage == StageFirst)
    {
    }

    // call the base class implementation
    return cFilter::Shutdown(eStage, __exception_ptr);
}

tResult cTemplateProjectFilter::OnPinEvent(IPin* pSource,
                                           tInt nEventCode,
                                           tInt nParam1,
                                           tInt nParam2,
                                           IMediaSample* pMediaSample)
{
    // first check what kind of event it is
    if (nEventCode == IPinEventSink::PE_MediaSampleReceived)
    {
        // so we received a media sample, so this pointer better be valid.
        RETURN_IF_POINTER_NULL(pMediaSample);

        // by comparing it to our member pin variable we can find out which pin received
        // the sample
        if (pSource == &m_oTemplateInput)
        {
            // this will store the value for our new sample

            tDynamicControlValue llval;
            // now lets access the data in the sample,
            // the Lock method gives you access to the buffer of the sample.
            // we use a scoped sample lock to ensure that the lock is released in all circumstances.

            {
                // this will aquire the read lock on the sample and declare and initialize a pointer to the data
                __sample_read_lock(pMediaSample, tDynamicControlValue, pData);
                // now we can access the sample data through the pointer
                llval = *pData;
                // the read lock on the sample will be released when leaving this scope
            }
            tFloat32 steering = atan( llval.curvature * CAR_AXIS2AXIS_M);
            tFloat32 acc;
           // cout << "got llvalues: curvature: " << llval.curvature << " acc: " << llval.acceleration << endl;
            if(llval.acceleration > 0) {
                acc = llval.acceleration * 13.25 + 90 - 0.5; // computed 16.25

            }else {
                acc = llval.acceleration * 13.25 + 90 + 0.5;

            }
            if(max(llval.acceleration,-llval.acceleration) < 0.1){
                acc =90;
            }
            tSignalValue st, ac;
            st.timestamp =0;
            st.value = -steering*180/3.141592654*1.5 + 90;
            if(st.value <= 60)
                st.value = 60;
            if(st.value > 120)
                st.value = 120;
            //cout << "Steering: old value: " << st.value;
            st.value = interpolateSteer(-llval.curvature);
            //cout << " new value: "<< st.value ;
            ac.timestamp =0;
            ac.value = acc;
            //cout << " Acceleration: old value: " << ac.value;
            ac.value = interpolateAcc(llval.acceleration);
            //cout << " new value: "<< ac.value << endl;




            tFloat32 d = llval.acceleration*0.025;

            tFloat32 deltal = (1/llval.curvature-CAR_WIDTH/200.0)*llval.curvature;
            tFloat32 deltar = (1/llval.curvature+CAR_WIDTH/200.0)*llval.curvature;

            if(llval.curvature == 0){
             deltal = 1;
             deltar = 1;
            }
            tFloat32 d_l = d * deltal;
            tFloat32 d_r = d* deltar;
            cout << "curvature" << llval.curvature<<  " d: " << d << " deltal: " << d_l << "  deltaR: " << d_r<< endl;
            wheelLeft.tach += max(d_l,-d_l)*100/0.57;
            wheelRight.tach+= max(d_r,-d_r)*100/0.57;
            cout << "tachL: " << wheelLeft.tach << " wheelR: " << wheelRight.tach << endl;
            wheelLeft.dir = (d < 0)?1:0;
            wheelRight.dir = wheelLeft.dir;
            // now we need a new media sample to forward the data.
            cObjectPtr<IMediaSample> pNewSample;
            if (IS_OK(AllocMediaSample(&pNewSample)))
            {
                // now set its data
                // we reuse the timestamp from the incoming media sample. Please see the api documentation
                // (ADTF Extreme Programmers -> The ADTF Streamtime) for further reference on how sample times are handled in ADTF
                pNewSample->Update(_clock->GetStreamTime(), &st, sizeof(tSignalValue), 0);

                // and now we can transmit it
                m_oSteeringOutput.Transmit(pNewSample);
            }
            cObjectPtr<IMediaSample>pSecondSample;
            if (IS_OK(AllocMediaSample(&pSecondSample)))
            {
                // now set its data
                // we reuse the timestamp from the incoming media sample. Please see the api documentation
                // (ADTF Extreme Programmers -> The ADTF Streamtime) for further reference on how sample times are handled in ADTF
                pSecondSample->Update(_clock->GetStreamTime(), &ac, sizeof(tSignalValue), 0);

                // and now we can transmit it
                m_oAccelerationOutput.Transmit(pSecondSample);
            }
            cObjectPtr<IMediaSample>pThirdSample;
            if(IS_OK(AllocMediaSample(&pThirdSample))){
                pThirdSample->Update(_clock->GetStreamTime(),&wheelLeft, sizeof(tWheelData),0);
                m_oWheelLeft.Transmit(pThirdSample);
            }
            cObjectPtr<IMediaSample>pLastSample;
            if(IS_OK(AllocMediaSample(&pLastSample))){
                pLastSample->Update(_clock->GetStreamTime(),&wheelRight, sizeof(tWheelData),0);
                m_oWheelRight.Transmit(pLastSample);
            }


        }
    }

    RETURN_NOERROR;
}

void cTemplateProjectFilter::readCalibration(cFilename filen) {
        vector<pair<tFloat,tFloat> > points;
           // check if given property is not empty
        if (filen.IsEmpty())
        {
            LOG_ERROR("LLValueConverter: calibration file not found");
            return;
        }
        //create path from path
        ADTF_GET_CONFIG_FILENAME(filen);
        filen = filen.CreateAbsolutePath(".");

        //Load file, parse configuration
        if (cFileSystem::Exists(filen))
        {
            LOG_INFO(cString::Format("LL Value Converter: found calibration file"));
            cFile file;
            if(file.Open(filen, cFile::OM_Read)<0){
                return;
            }

            cString line;
            tInt lineCount = 0;
            tInt mode =0;

            while(file.ReadLine(line)>0) {
                if (line.IsEmpty())
                    break;

                lineCount++;

                cStringList list;


                line.Split(list, ';');

                if (list.GetItemCount() != 3) {
                    LOG_ERROR("Drive by CSV: You have at least one syntax error in your CSV file!");
                    LOG_ERROR(cString::Format("Drive by CSV: The first error is at line %d", lineCount));
                    file.Close();
                    return;
                }
                if (lineCount == 1) {

                } else {
                    points.push_back(make_pair(list.Get(1).AsFloat64(),list.Get(0).AsFloat64()));
                                    }
            }

            LOG_INFO(cString::Format("...found %d lines. Check them:", lineCount));

            sort(points.begin(),points.end());
            if(points.size()< 3) return;
            if(points.front().second != 60)
                return;
            if(points.back().second != 120)
                return;
            tFloat y = points[0].second;
            for(int i=1; i< points.size(); i++){
                if(y >= points[i].second)
                    return;
                y = points[i].second;
            }
            LOG_INFO("..checked. take new steering points.");
            m_steer_calib = points;
            points.clear();
            //read emtpy lines
            while(file.ReadLine(line) ==0);
            //read acc values
            while(file.ReadLine(line)>0) {
                if (line.IsEmpty())
                    break;

                lineCount++;

                cStringList list;


                line.Split(list, ';');

                if (list.GetItemCount() != 5) {
                    LOG_ERROR("Drive by CSV: You have at least one syntax error in your CSV file!");
                    LOG_ERROR(cString::Format("Drive by CSV: The first error is at line %d", lineCount));
                    file.Close();
                    return;
                }
               else {
                    points.push_back(make_pair(list.Get(2).AsFloat64(),list.Get(0).AsFloat64()));
                }
            }
            LOG_INFO(cString::Format("...found %d lines. Check them:", points.size()));
            file.Close();
            sort(points.begin(),points.end());
            if(points.size()< 3) return;
            if(points.front().second > 60)
                return;
            if(points.back().second < 120)
                return;
            y = points[0].second;
            for(int i=1; i< points.size(); i++){
                if(y >= points[i].second)
                    return;
                y = points[i].second;
            }
            for(int i=0; i< points.size(); i++){
                LOG_INFO(cString::Format("velocity: %f <-> servo Value: %f",points[i].first, points[i].second));
            }
            LOG_INFO("...checked");
            m_acc_calib = points;



        }
}
