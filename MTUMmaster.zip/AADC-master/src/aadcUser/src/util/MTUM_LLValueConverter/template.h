/**
 *
 * ADTF Template Project Filter.
 *
 * @file
 * Copyright &copy; Audi Electronics Venture GmbH. All rights reserved
 *
 * $Author: belkera $
 * $Date: 2011-06-30 16:51:21 +0200 (Do, 30 Jun 2011) $
 * $Revision: 26514 $
 *
 * @remarks
 *
 */
#pragma once

#define OID_ADTF_TEMPLATE_FILTER "adtf.mtum.llconverter"
#include "LLControllerValueType.h"
#include "SignalValueType.h"
#include "car_geometry.h"
#include "WheelDataType.h"
//*************************************************************************************************
class cTemplateProjectFilter : public adtf::cFilter
{
    ADTF_FILTER(OID_ADTF_TEMPLATE_FILTER, "LL Value Converter Filter", adtf::OBJCAT_DataFilter);

protected:
    cInputPin    m_oTemplateInput;
    cOutputPin    m_oSteeringOutput;
    cOutputPin  m_oAccelerationOutput;
    cOutputPin  m_oWheelLeft;
    cOutputPin  m_oWheelRight;
    tWheelData wheelLeft, wheelRight;
    vector<pair<tFloat, tFloat> > m_steer_calib;
    vector<pair<tFloat, tFloat> > m_acc_calib;
public:
    cTemplateProjectFilter(const tChar* __info);
    virtual ~cTemplateProjectFilter();
    tFloat  interpolateSteer(tFloat in);
    tFloat  interpolateAcc(tFloat in);
    void readCalibration(cFilename filen);
protected:
    tResult Init(tInitStage eStage, __exception);
    tResult Shutdown(tInitStage eStage, __exception);

    // implements IPinEventSink
    tResult OnPinEvent(IPin* pSource,
                       tInt nEventCode,
                       tInt nParam1,
                       tInt nParam2,
                       IMediaSample* pMediaSample);
};

//*************************************************************************************************

