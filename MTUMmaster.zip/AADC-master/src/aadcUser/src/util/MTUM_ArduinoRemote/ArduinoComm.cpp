//
// Created by aadc on 29.10.15.
//


#include "ArduinoComm.h"
#include <termios.h>

ArduinoComm::ArduinoComm(IParent *parent) : cKernelThread() {
    this->parent = parent;
    USB = -1;
}

ArduinoComm::~ArduinoComm() {

}

tResult ArduinoComm::ThreadFunc() {
    if(USB < 0) {
        //cout << "Arduino Comm: USB not connected" << endl;
        cThread::YieldExecution();
        RETURN_NOERROR;
    }

    tUInt8 speed;
    tUInt8 steering;
    int nRead;
    tUInt8 result;
    // Wait for newline
    do {
        nRead = read(USB, &result, 1);

        if(nRead < 0) {
            RETURN_NOERROR;
        }
    } while(nRead == 0 || result != 0);

    do {
        nRead = read(USB, &steering, 1);
    }while (nRead == 0);

    do {
        nRead = read(USB, &speed, 1);
    }while (nRead == 0);

// -1 because we transmit the real data +1 to be able to use 0 as separator
    parent->writeData(speed-1, steering-1);


    RETURN_NOERROR;
}

tResult ArduinoComm::ThreadInitFunc() {
    return cKernelThread::ThreadInitFunc();
}

tResult ArduinoComm::ThreadExitFunc() {
    cout << "Arduino Comm: Closing Port!" << endl;
    if(USB >= 0) {
        close(USB);
        USB = -1;
    }

    return cKernelThread::ThreadExitFunc();
}

void ArduinoComm::setPort(const char* port) {
    if(USB >= 0) {
        cout << "Arduino Comm: Closing Port!" << endl;
        close(USB);
        USB = -1;
    }

    cout << "Arduino Remote: Starting connection" << endl;

    USB = open( port, O_RDWR| O_NOCTTY );

    struct termios tty;
    memset (&tty, 0, sizeof tty);

/* Error Handling */
    if ( tcgetattr ( USB, &tty ) != 0 ) {
        std::cout << "Error " << errno << " from tcgetattr: " << strerror(errno) << std::endl;
    }

/* Set Baud Rate */
    cfsetospeed (&tty, (speed_t)B115200);
    cfsetispeed (&tty, (speed_t)B115200);

/* Setting other Port Stuff */
    tty.c_cflag     &=  ~PARENB;            // Make 8n1
    tty.c_cflag     &=  ~CSTOPB;
    tty.c_cflag     &=  ~CSIZE;
    tty.c_cflag     |=  CS8;

    tty.c_cflag     &=  ~CRTSCTS;           // no flow control
    tty.c_cc[VMIN]   =  1;                  // read doesn't block
    tty.c_cc[VTIME]  =  0;                  // 0.5 seconds read timeout
    tty.c_cflag     |=  CREAD | CLOCAL;     // turn on READ & ignore ctrl lines

/* Make raw */
    cfmakeraw(&tty);

/* Flush Port, then applies attributes */
    tcflush( USB, TCIFLUSH );
    if ( tcsetattr ( USB, TCSANOW, &tty ) != 0) {
        std::cout << "Error " << errno << " from tcsetattr" << std::endl;
    }
    cout << "Arduino Remote: Connection Successful!" << endl;
}
