/**********************************************************************
* Copyright (c) 2013 BFFT Gesellschaft fuer Fahrzeugtechnik mbH.
* All rights reserved.
**********************************************************************
* $Author:: spiesra $  $Date:: 2015-05-13 08:29:07#$ $Rev:: 35003   $
**********************************************************************/



#ifndef _MTUM_ARDUINO_FILTER_H_
#define _MTUM_ARDUINO_FILTER_H_

#include "ArduinoComm.h"
#include "SignalValueType.h"
#include "IParent.h"

#define OID_MTUM_ARDUINO_REMOTE "adtf.mtum.arduinoRemote"

/*! \brief cMtumArduino
The filter generates the samples of type tBoolSignalValue which can be passed to the Arduino Actuators filter to keep the Speed Controller alive. The Transmit Rate can be altered in the properties but normally does not need any adjustments.
*/
class cMtumArduino : public adtf::cFilter, IParent
{
    ADTF_DECLARE_FILTER_VERSION(OID_MTUM_ARDUINO_REMOTE, "Mtum Arduino Remote", OBJCAT_Tool,  "Mtum Arduino Remote", 1, 0,0, "MTUM");

protected:
    cOutputPin steeringOut;
    cOutputPin accelerationOut;

public:
    cMtumArduino(const tChar* __info);
    virtual ~cMtumArduino();

protected: // overwrites cFilter
    tResult Init(tInitStage eStage, __exception = NULL);

private:

    virtual void writeData(tUInt8 speed, tUInt8 steering);

protected:
    virtual tResult Shutdown(cFilter::tInitStage eStage, IException **__exception_ptr);

    ArduinoComm comm;

    inline tResult CreateOutputPins(__exception=NULL);

    void transmitSteering(unsigned char value);

    void transmitAcceleration(unsigned char value);
};

//*************************************************************************************************

#endif // _MTUM_ARDUINO_FILTER_H_

