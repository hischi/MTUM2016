#pragma once

class IParent
{
public:

	virtual void writeData(tUInt8 speed, tUInt8 steering)=0;
	IParent()
	{
	}

	~IParent() {
	}
};

