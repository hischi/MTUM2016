// arduinofilter.cpp : Definiert die exportierten Funktionen f�r die DLL-Anwendung.
//
#include "cMtumArduino.h"
#include "stdafx.h"

ADTF_FILTER_PLUGIN("MTUM Arduino Remote", OID_MTUM_ARDUINO_REMOTE, cMtumArduino)

    cMtumArduino::cMtumArduino(const tChar* __info) : adtf::cFilter(__info), comm(this)
{
    SetPropertyStr("ArduinoFile", "/dev/ttyACM4");
}

cMtumArduino::~cMtumArduino()
{
}

tResult cMtumArduino::CreateOutputPins(__exception)
{    
    // create and register the output pin
    RETURN_IF_FAILED(steeringOut.Create("output_Steering", new cMediaType(0,0,0,SIGNALVALUE), this));
    RETURN_IF_FAILED(RegisterPin(&steeringOut));

    RETURN_IF_FAILED(accelerationOut.Create("output_Acceleration",new cMediaType(0,0,0,SIGNALVALUE), this));
    RETURN_IF_FAILED(RegisterPin(&accelerationOut));

    RETURN_NOERROR;
}

tResult cMtumArduino::Init(tInitStage eStage, __exception)
{
    RETURN_IF_FAILED(cFilter::Init(eStage, __exception_ptr))

        if (eStage == StageFirst)
        {
            tResult nResult = CreateOutputPins();
            if (IS_FAILED(nResult))
            {
                THROW_ERROR_DESC(nResult, "Failed to create Output Pins");
            }

        }
        else if (eStage == StageNormal)
        {
            comm.setPort(GetPropertyStr("ArduinoFile"));
        }
        else if (eStage == StageGraphReady)
        {
            comm.Create();
            comm.Run();
        }
        RETURN_NOERROR;
}




void cMtumArduino::transmitSteering(unsigned char value) {
    // now we need a new media sample to forward the data.
    cObjectPtr<IMediaSample> pNewSample;
    if (IS_OK(AllocMediaSample(&pNewSample)))
    {
        // now set its data
        // we reuse the timestamp from the incoming media sample. Please see the api documentation
        // (ADTF Extreme Programmers -> The ADTF Streamtime) for further reference on how sample times are handled in ADTF
        tSignalValue data;
        data.value = (tFloat32)value;
        pNewSample->Update(_clock->GetStreamTime(), &data, sizeof(tSignalValue), 0);

        // and now we can transmit it
        steeringOut.Transmit(pNewSample);
    }
}

void cMtumArduino::transmitAcceleration(unsigned char value) {
    // now we need a new media sample to forward the data.
    cObjectPtr<IMediaSample> pNewSample;
    if (IS_OK(AllocMediaSample(&pNewSample)))
    {
        // now set its data
        // we reuse the timestamp from the incoming media sample. Please see the api documentation
        // (ADTF Extreme Programmers -> The ADTF Streamtime) for further reference on how sample times are handled in ADTF
        tSignalValue data;
        data.value = (tFloat32)value;
        pNewSample->Update(_clock->GetStreamTime(), &data, sizeof(tSignalValue), 0);

        // and now we can transmit it
        accelerationOut.Transmit(pNewSample);
    }
}

tResult cMtumArduino::Shutdown(cFilter::tInitStage eStage, IException **__exception_ptr) {
    if (eStage == StageFirst)
    {

    }
    else if (eStage == StageNormal)
    {
    }
    else if (eStage == StageGraphReady)
    {
        cout << "Shutting Down Arduino Comm!" << endl;
        comm.Terminate();
    }
    RETURN_NOERROR;
}

void cMtumArduino::writeData(tUInt8 speed, tUInt8 steering) {
    transmitAcceleration(speed);
    transmitSteering(steering);
}
