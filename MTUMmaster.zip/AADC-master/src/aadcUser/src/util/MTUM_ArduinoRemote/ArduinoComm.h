//
// Created by aadc on 29.10.15.
//

#ifndef AADC_ARDUINO_COMM_H
#define AADC_ARDUINO_COMM_H

#include "stdafx.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <iostream>
#include <utils/base/types.h>
#include <adtf_utils.h>
#include "IParent.h"


class ArduinoComm : public cKernelThread {

public:
    ArduinoComm(IParent *parent);
    virtual ~ArduinoComm();

    virtual tResult ThreadFunc() override;

    virtual tResult ThreadInitFunc() override;

    virtual tResult ThreadExitFunc() override;



    void setPort(const char *port);

private:
    IParent* parent;
    int USB;

};


#endif //AADC_USER_COMM_H
