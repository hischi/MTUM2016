/**
Copyright (c)
Audi Autonomous Driving Cup. Team MomenTUM. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
3.  All advertising materials mentioning features or use of this software must display the following acknowledgement: "This product includes software developed by the Audi AG and its contributors for Audi Autonomous Driving Cup."
4.  Neither the name of Audi nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY AUDI AG AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL AUDI AG OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


**********************************************************************
* $Author:: MomenTUM#$  $Date:: 2015-10-10 15:10:07#$ $Rev:: 35043   $
**********************************************************************/

#include "stdafx.h"
#include "mtum_reference_filter.h"
#include "SignalValueType.h"
#include <sstream>

/// Create filter shell
ADTF_FILTER_PLUGIN("MTUM Reference From Odometry", OID_ADTF_MTUM_REF_FILTER, cReferenceFromOdometry);


cReferenceFromOdometry::cReferenceFromOdometry(const tChar* __info): cFilter(__info), m_FilterCore(this)
{
    SetPropertyStr("Reference Point File","");
    SetPropertyBool("Reference Point File" NSSUBPROP_FILENAME, tTrue);
    SetPropertyStr("Reference Point File" NSSUBPROP_FILENAME NSSUBSUBPROP_EXTENSIONFILTER, "xml Files (*.xml), yml Files (*.yml)");
    SetPropertyStr("Reference Point File" NSSUBPROP_DESCRIPTION, "The Reference Point file for the reference points");

}

cReferenceFromOdometry::~cReferenceFromOdometry()
{

}

tResult cReferenceFromOdometry::Init(tInitStage eStage, __exception)
{
    // never miss calling the parent implementation!!
    RETURN_IF_FAILED(cFilter::Init(eStage, __exception_ptr))
    
    // in StageFirst you can create and register your static pins.
    if (eStage == StageFirst)
    {
        RETURN_IF_FAILED(CreatePins(__exception_ptr));
    }
    else if (eStage == StageNormal)
    {
        // In this stage you would do further initialisation and/or create your dynamic pins.
        // Please take a look at the demo_dynamicpin example for further reference.
    }
    else if (eStage == StageGraphReady)
    {

        // All pin connections have been established in this stage so you can query your pins
        // about their media types and additional meta data.
        // Please take a look at the demo_imageproc example for further reference.
    }

    RETURN_NOERROR;
}

tResult cReferenceFromOdometry::Start(__exception)
{
    return cFilter::Start(__exception_ptr);
}

tResult cReferenceFromOdometry::Stop(__exception)
{
    return cFilter::Stop(__exception_ptr);
}

tResult cReferenceFromOdometry::Shutdown(tInitStage eStage, __exception)
{
    // In each stage clean up everything that you initiaized in the corresponding stage during Init.
    // Pins are an exception: 
    // - The base class takes care of static pins that are members of this class.
    // - Dynamic pins have to be cleaned up in the ReleasePins method, please see the demo_dynamicpin
    //   example for further reference.
    
    if (eStage == StageGraphReady)
    {
    }
    else if (eStage == StageNormal)
    {
        cFilename filen = GetPropertyStr("Reference Point File");
        string filename;
        if(filen.IsEmpty()){

            LOG_WARNING("ParkingFilter:  No Reference Point file specified!");


        }else {
            ADTF_GET_CONFIG_FILENAME(filen);
            filen = filen.CreateAbsolutePath(".");
            filename = filen.GetPtr();

            m_FilterCore.savePoints(filename);
        }
    }
    else if (eStage == StageFirst)
    {
    }

    // call the base class implementation
    return cFilter::Shutdown(eStage, __exception_ptr);
}

tResult cReferenceFromOdometry::OnPinEvent(IPin* pSource,
                                           tInt nEventCode,
                                           tInt nParam1,
                                           tInt nParam2,
                                           IMediaSample* pMediaSample)
{
    // first check what kind of event it is
    if (nEventCode == IPinEventSink::PE_MediaSampleReceived) {
        // so we received a media sample, so this pointer better be valid.
        RETURN_IF_POINTER_NULL(pMediaSample);

        // by comparing it to our member pin variable we can find out which pin received
        // the sample
        if (pSource == &m_oStatusInput) {
            DecodeStatusMessage(pMediaSample);
        }
        if (pSource == &m_oOdometryInput) {
            tOdometryData odo;
            {
                __sample_read_lock(pMediaSample, tOdometryData, pdata);
                odo = *pdata;
            }

            m_FilterCore.insertPoint(odo);
        }
    }

    RETURN_NOERROR;
}

tResult cReferenceFromOdometry::SendStatusFeedback(tInt feedback)
{
    // now we need a new media sample to forward the data.
    cObjectPtr<IMediaSample> pNewSample;
    if (IS_OK(AllocMediaSample(&pNewSample)))
    {
        // now set its data
        // we reuse the timestamp from the incoming media sample. Please see the api documentation
        // (ADTF Extreme Programmers -> The ADTF Streamtime) for further reference on how sample times are handled in ADTF
        tSignalValue data;
        data.value = feedback;
        pNewSample->Update(_clock->GetStreamTime(), &data, sizeof(tSignalValue), 0);

        // and now we can transmit it
        m_oStatusOutput.Transmit(pNewSample);
    }

    RETURN_NOERROR;
}

tResult cReferenceFromOdometry::DecodeStatusMessage(IMediaSample* pMediaSample)
{
    // this will store the value for our new sample
    tSignalValue status_message;

    // now lets access the data in the sample,
    // the Lock method gives you access to the buffer of the sample.
    // we use a scoped sample lock to ensure that the lock is released in all circumstances.

    {
        // this will aquire the read lock on the sample and declare and initialize a pointer to the data
        __sample_read_lock(pMediaSample, tSignalValue, pData);
        // now we can access the sample data through the pointer
        status_message = *pData;
        // the read lock on the sample will be released when leaving this scope
    }
    m_FilterCore.ProcessData(status_message.value);
    switch(tInt(status_message.value))
    {
    case 0: m_FilterCore.Status_SetInactive();
        break;
    case 1: m_FilterCore.Status_SetActive();
        break;
    case 2: m_FilterCore.Status_IsReady();
        break;
    case -1: m_FilterCore.Status_Reset();
        break;
    default: m_FilterCore.Status_ChangeMode(tInt(status_message.value));
    }

    RETURN_NOERROR;
}


tResult cReferenceFromOdometry::CreatePins(__exception)
{

    RETURN_IF_FAILED(m_oReferencePointOutput.Create("reference_output", new cMediaType(0,0,0,REFERENCEPOINTS), this));
    RETURN_IF_FAILED(RegisterPin(&m_oReferencePointOutput));

    RETURN_IF_FAILED(m_oOdometryInput.Create("odometry_input", new cMediaType(0,0,0,ODOMETRYDATA),this));
    RETURN_IF_FAILED(RegisterPin(&m_oOdometryInput));

    RETURN_NOERROR;
}

tResult cReferenceFromOdometry::SendReferencePoints(tReferencePoints &p){
    // now we need a new media sample to forward the data.
    tReferencePoints ref;
    cObjectPtr<IMediaSample> pNewSample;
    if (IS_OK(AllocMediaSample(&pNewSample)))
    {
        // now set its data
        // we reuse the timestamp from the incoming media sample. Please see the api documentation
        // (ADTF Extreme Programmers -> The ADTF Streamtime) for further reference on how sample times are handled in ADTF
        ref = p;
        //stringstream ss;
        //ss << "Send reference points: ";
        //for(int i = 0; i< 3; i++){
        //    tReferencePoint& p = ref.points[i];
        //    ss << "\nPoint " << i << ": x:" << p.x << " y: " << p.y << " phi: " << p.phi << " vel: " << p.vel;
        //}
        //ss << "\n size of tReferencePoints: " << sizeof(tReferencePoints) << "bytes";
      //  LOG_INFO(ss.str().c_str());
        pNewSample->Update(_clock->GetStreamTime(), &ref, sizeof(tReferencePoints), 0);

        // and now we can transmit it
        m_oReferencePointOutput.Transmit(pNewSample);
    }
    RETURN_NOERROR;
}

