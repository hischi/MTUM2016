/**
Copyright (c)
Audi Autonomous Driving Cup. Team MomenTUM. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
3.  All advertising materials mentioning features or use of this software must display the following acknowledgement: "This product includes software developed by the Audi AG and its contributors for Audi Autonomous Driving Cup."
4.  Neither the name of Audi nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY AUDI AG AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL AUDI AG OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


**********************************************************************
* $Author:: MomenTUM#$  $Date:: 2015-10-10 15:10:07#$ $Rev:: 35043   $
**********************************************************************/

#include "stdafx.h"
#include "mtum_filter_core.h"
#include <sstream>
#include <iostream>
#include <math.h>

FileStorage &operator<<(FileStorage &fs, tReferencePoint const &pt)
{
    fs << "{:" << "x" << pt.x << "y" << pt.y << "phi" << pt.phi << "vel" << pt.vel << "acc" << pt.acceleration << "curv" << pt.curvature << "}";
}


cRefFromOdo::cRefFromOdo(iTemplateInterface *parent)
{
    m_pFilterReference = parent;
    points = vector<tReferencePoint>();
    pointCounter =0;


}

cRefFromOdo::~cRefFromOdo()
{
}

tResult cRefFromOdo::ProcessData(tFloat32 val)
{
    //sort(points.begin(),points.end(),*this);

    RETURN_NOERROR;
}

void cRefFromOdo::insertPoint(const tOdometryData &actualPosition) {
    if(!actualPosition.valid)
        return;
   tReferencePoint p;
    p.x = actualPosition.x;
    p.y = actualPosition.y;
    p.vel = actualPosition.vel;
    p.phi = actualPosition.phi;
    p.acceleration = actualPosition.acc;

    double dx = actualPosition.x- lastPos.x;
    double dy = actualPosition.y - lastPos.y;
    double dphi = actualPosition.phi - lastPos.phi;
    if(dphi > M_PI)
        dphi -= 2*M_PI;
    if(dphi < -M_PI)
        dphi += 2*M_PI;

    lastPos = actualPosition;

    double d = sqrt(dx*dx+dy*dy);
    if(p.vel < 0)
        d *= -1;
    p.curvature= dphi/d;
    if( abs(p.vel) < 0.1)
        p.curvature = 0;
    if(p.curvature > 1.5)
        p.curvature = 1.5;
    if(p.curvature < -1.5)
        p.curvature = -1.5;

    points.push_back(p);

}

void cRefFromOdo::savePoints(const string &filename) {
    cout << "save file at:" << filename << endl;
    FileStorage fs(filename, FileStorage::WRITE);
    fs << "Points" << "[";
    for(int i =0; i< points.size(); i++){
        fs << points[i];
    }
    fs << "]";
    fs.release();
    points.clear();
    cout <<"..done!" << endl;

}
