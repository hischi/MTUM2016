
import csv, math
with open('driving.csv', 'w') as csvfile:
    spamwriter = csv.writer(csvfile, delimiter=',',
                            quotechar='|', quoting=csv.QUOTE_MINIMAL)
    x = 0
    y = 0
    phi =0
    steering =10
    vel =0
    acc =0
    spamwriter.writerow(['x','y','phi','vel'])
    for i in range(100):
        spamwriter.writerow([x,y,phi,vel])
    steering = 10.0
    while phi < 2* 3.141592654:
        if vel < 2:
            vel += 0.01
        dist = vel *0.05
        dphi = dist/0.36*math.tan(steering/180*3.141592654)
        phi += dphi
        x+= math.sin(-phi)*dist
        y += math.cos(phi)*dist
        spamwriter.writerow([x,y,phi,vel])
    steering =0; 
    while vel > 0:
        vel -= 0.1
        dist = vel *0.05
        dphi = dist/0.36*math.tan(steering/180*3.141592654)
        phi += dphi
        x+= math.sin(-phi)*dist
        y += math.cos(phi)*dist
        spamwriter.writerow([x,y,phi,vel])
    vel = 1
    phi = 0.2 * 3.141592654
    while y < 3:
	dist = vel *0.05
        dphi = dist/0.36*math.tan(steering/180*3.141592654)

        phi += dphi
        x+= math.sin(-phi)*dist
        y += math.cos(phi)*dist
        spamwriter.writerow([x,y,phi,vel])
    vel =-1
    phi =0
    while y >-3:
	dist = vel *0.05
        dphi = dist/0.36*math.tan(steering/180*3.141592654)
        phi += dphi
        x+= math.sin(-phi)*dist
        y += math.cos(phi)*dist
        spamwriter.writerow([x,y,phi,vel])
    vel = 1
    while y < 0:
	dist = vel *0.05
        dphi = dist/0.36*math.tan(steering/180*3.141592654)
        phi += dphi
        x+= math.sin(-phi)*dist
        y += math.cos(phi)*dist
        spamwriter.writerow([x,y,phi,vel])
    vel =0;
    for i in range(10):
        dist = vel *0.05
        dphi = dist/0.36*math.tan(steering/180*3.141592654)
        phi += dphi
        x+= math.sin(-phi)*dist
        y += math.cos(phi)*dist
        spamwriter.writerow([x,y,phi,vel])
    
