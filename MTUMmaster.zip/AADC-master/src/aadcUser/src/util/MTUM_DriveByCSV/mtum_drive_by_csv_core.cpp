/**
Copyright (c)
Audi Autonomous Driving Cup. Team MomenTUM. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
3.  All advertising materials mentioning features or use of this software must display the following acknowledgement: "This product includes software developed by the Audi AG and its contributors for Audi Autonomous Driving Cup."
4.  Neither the name of Audi nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY AUDI AG AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL AUDI AG OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


**********************************************************************
* $Author:: MomenTUM#$  $Date:: 2015-10-10 15:10:07#$ $Rev:: 35043   $
**********************************************************************/

#include "stdafx.h"
#include "mtum_drive_by_csv_core.h"
#include "mtum_drive_by_csv.h"


cDriveByCSVCore::cDriveByCSVCore(iDriveByCVSMapInterface *pFilter)
{
    m_pFilterReferenz = pFilter;
    m_pTimedSeries = 0;
    m_ExecutionIdx = 0;
    m_SeriesLength = 0;
}

cDriveByCSVCore::~cDriveByCSVCore()
{
    if(m_pTimedSeries != 0)
    {
        delete(m_pTimedSeries);
        m_pTimedSeries = 0;
    }
}

tResult cDriveByCSVCore::ProcessData()
{
    RETURN_NOERROR;
}

/*tResult cDriveByCSVCore::Run(tBool bWait)
{
    return cThread::Run(bWait);
}

tResult cDriveByCSVCore::Terminate(tBool bWait)
{
    return cThread::Terminate(bWait);
}*/

tResult cDriveByCSVCore::ThreadInitFunc()
{
    //m_pFilterReferenz->SendSteeringSpeed(90, 90);
    //cThread::Sleep(2000);
    //m_pFilterReferenz->SendSteeringSpeed(90, 90);
    RETURN_NOERROR;
}

tResult cDriveByCSVCore::ThreadExitFunc()
{
    //m_pFilterReferenz->SendSteeringSpeed(90, 90);
    //cThread::Sleep(2000);
    //m_pFilterReferenz->SendSteeringSpeed(90, 90);
    RETURN_NOERROR;
}

tResult cDriveByCSVCore::ThreadFunc()
{
    LOG_INFO("Drive by CSV: wait for next timestamp");

    if(m_ExecutionIdx >= m_SeriesLength)
        RETURN_ERROR(ERR_END_OF_FILE);

    tTimedSteeringSpeed elem =  m_pTimedSeries[m_ExecutionIdx];

    cThread::Sleep(elem.timestamp*1000);
    m_pFilterReferenz->SendSteeringSpeed(90+elem.steering, 90+elem.speed);

    m_ExecutionIdx++;
    RETURN_NOERROR;
}

tResult cDriveByCSVCore::SetCSVFile(cFilename csv_file)
{
    // check if given property is not empty
    if (csv_file.IsEmpty())
    {
        LOG_WARNING("ObstacleMap: Configuration file not found");
        RETURN_ERROR(ERR_INVALID_FILE);
    }
    //create path from path
    ADTF_GET_CONFIG_FILENAME(csv_file);
    csv_file = csv_file.CreateAbsolutePath(".");

    //Load file, parse configuration
    if (cFileSystem::Exists(csv_file))
    {
        cFile file;
        RETURN_IF_FAILED(file.Open(csv_file, cFile::OM_Read));

        cString line;
        tInt lineCount = 0;

        while(file.ReadLine(line))
        {
            if(line.IsEmpty())
                break;

            lineCount++;

            cStringList list;

            line.Split(list, ',');

            if(list.GetItemCount() != 3)
            {
                LOG_ERROR("Drive by CSV: You have at least one syntax error in your CSV file!");
                LOG_ERROR(cString::Format("Drive by CSV: The first error is at line %d", lineCount));
                file.Close();
                RETURN_ERROR(1);
            }
        }

        file.Close();

        if(lineCount == 0)
        {
            LOG_ERROR("Drive by CSV: Your CSV file is empty!");
            RETURN_ERROR(1);
        }
        m_pTimedSeries = new tTimedSteeringSpeed[lineCount];
        m_SeriesLength = lineCount;

        RETURN_IF_FAILED(file.Open(csv_file, cFile::OM_Read));

        int i = 0;
        while(file.ReadLine(line) && i < lineCount)
        {
            cStringList list;

            line.Split(list, ',');

            m_pTimedSeries[i].timestamp = list.Get(0).AsUInt32();
            m_pTimedSeries[i].steering = (tFloat32) list.Get(1).AsFloat64();
            m_pTimedSeries[i].speed = (tFloat32) list.Get(2).AsFloat64();
            i++;
        }
        LOG_INFO(cString::Format("Drive by CSV: %d lines read successfully!", i));

        file.Close();
    }

    RETURN_NOERROR;
}
