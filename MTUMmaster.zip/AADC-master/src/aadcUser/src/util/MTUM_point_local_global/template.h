/**
 *
 * ADTF Template Project Filter.
 *
 * @file
 * Copyright &copy; Audi Electronics Venture GmbH. All rights reserved
 *
 * $Author: belkera $
 * $Date: 2011-06-30 16:51:21 +0200 (Do, 30 Jun 2011) $
 * $Revision: 26514 $
 *
 * @remarks
 *
 */
#pragma once

#define OID_ADTF_TEMPLATE_FILTER "adtf.mtum.point2converter"
#include "ReferencePointsType.h"
#include "OdometryDataType.h"
#include "LaneStruct.h"
#include "PolyModel.h"
#define LANE_WIDTH 460.0
//*************************************************************************************************
class cTemplateProjectFilter : public adtf::cFilter
{
    ADTF_FILTER(OID_ADTF_TEMPLATE_FILTER, "Local 2 Global Filter", adtf::OBJCAT_DataFilter);

protected:
    cInputPin    m_oOdometryInput;
    cInputPin    m_oLaneInput;
    cOutputPin   m_oPointsOutput;
    tOdometryData odo;

public:
    cTemplateProjectFilter(const tChar* __info);
    virtual ~cTemplateProjectFilter();

protected:
    tResult SendReferencePoints(tReferencePoints &p);
    tResult Init(tInitStage eStage, __exception);
    tResult Shutdown(tInitStage eStage, __exception);

    // implements IPinEventSink
    tResult OnPinEvent(IPin* pSource,
                       tInt nEventCode,
                       tInt nParam1,
                       tInt nParam2,
                       IMediaSample* pMediaSample);
};

//*************************************************************************************************

