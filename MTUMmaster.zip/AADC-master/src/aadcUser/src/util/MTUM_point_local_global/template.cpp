/**
 *
 * ADTF Template Project
 *
 * @file
 * Copyright &copy; Audi Electronics Venture GmbH. All rights reserved
 *
 * $Author: belkera $
 * $Date: 2011-06-30 16:51:21 +0200 (Do, 30 Jun 2011) $
 * $Revision: 26514 $
 *
 * @remarks
 *
 */

#include "stdafx.h"
#include "template.h"
#include <iostream>
#include "math.h"
#include "car_geometry.h"

/// Create filter shell
ADTF_FILTER_PLUGIN("Local 2 Global Converter", OID_ADTF_TEMPLATE_FILTER, cTemplateProjectFilter);


cTemplateProjectFilter::cTemplateProjectFilter(const tChar* __info):cFilter(__info)
{

}

cTemplateProjectFilter::~cTemplateProjectFilter()
{

}

tResult cTemplateProjectFilter::Init(tInitStage eStage, __exception)
{
    // never miss calling the parent implementation!!
    RETURN_IF_FAILED(cFilter::Init(eStage, __exception_ptr))
    
    // in StageFirst you can create and register your static pins.
    if (eStage == StageFirst)
    {

        // create and register the input pin
        RETURN_IF_FAILED(m_oOdometryInput.Create("input_Odometry", new cMediaType(0,0,0,ODOMETRYDATA), this));
        RETURN_IF_FAILED(RegisterPin(&m_oOdometryInput));

        RETURN_IF_FAILED(m_oLaneInput.Create("input_Lane", new cMediaType(0,0,0,LANESTRUCT), this));
        RETURN_IF_FAILED(RegisterPin(&m_oLaneInput));
        
        // create and register the output pin

        RETURN_IF_FAILED(m_oPointsOutput.Create("output_Points",new cMediaType(0,0,0,REFERENCEPOINTS), this));
        RETURN_IF_FAILED(RegisterPin(&m_oPointsOutput));
    }
    else if (eStage == StageNormal)
    {
        // In this stage you would do further initialisation and/or create your dynamic pins.
        // Please take a look at the demo_dynamicpin example for further reference.
    }
    else if (eStage == StageGraphReady)
    {
        // All pin connections have been established in this stage so you can query your pins
        // about their media types and additional meta data.
        // Please take a look at the demo_imageproc example for further reference.
    }

    RETURN_NOERROR;
}

tResult cTemplateProjectFilter::Shutdown(tInitStage eStage, __exception)
{
    // In each stage clean up everything that you initiaized in the corresponding stage during Init.
    // Pins are an exception: 
    // - The base class takes care of static pins that are members of this class.
    // - Dynamic pins have to be cleaned up in the ReleasePins method, please see the demo_dynamicpin
    //   example for further reference.
    
    if (eStage == StageGraphReady)
    {
    }
    else if (eStage == StageNormal)
    {
    }
    else if (eStage == StageFirst)
    {
    }

    // call the base class implementation
    return cFilter::Shutdown(eStage, __exception_ptr);
}

tResult cTemplateProjectFilter::OnPinEvent(IPin* pSource,
                                           tInt nEventCode,
                                           tInt nParam1,
                                           tInt nParam2,
                                           IMediaSample* pMediaSample)
{
    // first check what kind of event it is
    if (nEventCode == IPinEventSink::PE_MediaSampleReceived)
    {
        // so we received a media sample, so this pointer better be valid.
        RETURN_IF_POINTER_NULL(pMediaSample);

        // by comparing it to our member pin variable we can find out which pin received
        // the sample
        if (pSource == &m_oOdometryInput)
        {
            // this will store the value for our new sample


            // now lets access the data in the sample,
            // the Lock method gives you access to the buffer of the sample.
            // we use a scoped sample lock to ensure that the lock is released in all circumstances.

            {

                // this will aquire the read lock on the sample and declare and initialize a pointer to the data
                __sample_read_lock(pMediaSample, tOdometryData, pData);
                // now we can access the sample data through the pointer

                odo = *pData;

                // the read lock on the sample will be released when leaving this scope
            }

        }
        if(pSource == &m_oLaneInput)
        {



            double x = 0;
            double y = 0;
            double theM = 0;
            {
                //cScopedSampleWriteLock oLock(pMediaSample);
                //s = oLock.GetPtr<tLaneStruct >();
                __sample_read_lock(pMediaSample, tLaneStruct, pData);



                y = 40;
                x = 0;
                int xCount = 0;
                double m, t;
                if(pData->lSplineCount > 0) {
                    xCount++;
                    switch(pData->flType) {
                        case LINE:
                            // mx+t = y
                            m = (pData->flly2-pData->flly1)/(pData->fllx2-pData->fllx1);
                            t = pData->flly1 - m*pData->fllx1;
                            x += m*y+t;
                            theM += m;
                            break;
                        case PARABOLA:
                            // ax^2+bx+c=y
                            x += pData->flpa*y*y+pData->flpb*y+pData->flpc;
                            theM += 2*pData->flpa*y+pData->flpb;
                            break;
                    }
                    x += LANE_WIDTH/20;
                }

                if(pData->rSplineCount > 0) {
                    xCount++;
                    switch(pData->frType) {
                        case LINE:
                            // mx+t = y
                            m = (pData->frly2-pData->frly1)/(pData->frlx2-pData->frlx1);
                            t = pData->frly1 - m*pData->frlx1;
                            x += m*y+t;
                            theM += m;
                            break;
                        case PARABOLA:
                            // ax^2+bx+c=y
                            x += pData->frpa*y*y+pData->frpb*y+pData->frpc;
                            theM += 2*pData->frpa*y+pData->frpb;
                            break;
                    }
                    x -= LANE_WIDTH/20;
                }

                if(xCount == 0) {
                    RETURN_NOERROR;
                }
                x /= xCount;
                theM /= xCount;
            }

            y += CAR_AXIS2AXIS;


            Point2d p(x,y);


            //Point2d p2(25, s->rightLane[0]->getY(25));

            tFloat32 rot = atan(theM);
            cout << "Point in " << p << " rot: " << rot << endl;

            tReferencePoint rp;
            rp.phi = odo.phi + rot;
            if(rp.phi > 3.141592654)
                rp.phi -= 2*3.141592654;
            if(rp.phi < -3.141592654)
                rp.phi += 2*3.141592654;
            rp.x = odo.x + (-sin(odo.phi)*p.y + cos(odo.phi)*p.x)/100.0;
            rp.y = odo.y + (cos(odo.phi)*p.y + sin(odo.phi)*p.x)/100.0;

             cout << "reference point: x:"<< rp.x << " y: "<< rp.y << " rot: " << rp.phi << endl;

            tReferencePoints ps;
            for(int i =0; i < REFERENCEPOINTSIZE; i++){
                ps.points[i] =rp;
            }

            SendReferencePoints(ps);



        }
    }

    RETURN_NOERROR;
}

tResult cTemplateProjectFilter::SendReferencePoints(tReferencePoints &p){
    // now we need a new media sample to forward the data.
    tReferencePoints ref;
    cObjectPtr<IMediaSample> pNewSample;
    if (IS_OK(AllocMediaSample(&pNewSample)))
    {

        ref = p;

        pNewSample->Update(_clock->GetStreamTime(), &ref, sizeof(tReferencePoints), 0);

        // and now we can transmit it
        m_oPointsOutput.Transmit(pNewSample);
    }
    RETURN_NOERROR;
}
