/**
Copyright (c)
Audi Autonomous Driving Cup. Team MomenTUM. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
3.  All advertising materials mentioning features or use of this software must display the following acknowledgement: "This product includes software developed by the Audi AG and its contributors for Audi Autonomous Driving Cup."
4.  Neither the name of Audi nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY AUDI AG AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL AUDI AG OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


**********************************************************************
* $Author:: MomenTUM#$  $Date:: 2015-10-10 15:10:07#$ $Rev:: 35043   $
**********************************************************************/

#include "stdafx.h"
#include "mtum_actuator_repeater.h"
#include "SignalValueType.h"
#include "BoolSignalValueType.h"

/// Create filter shell
ADTF_FILTER_PLUGIN("MTUM Template Filter", OID_ADTF_MTUM_ACTUATOR_REPEATER_FILTER, cActuatorRepeaterFilter);


cActuatorRepeaterFilter::cActuatorRepeaterFilter(const tChar* __info):cTimeTriggeredFilter(__info)
{
    m_UpdateFrequency = 40;
    SetPropertyInt("Updaterate [Hz]", m_UpdateFrequency);

    m_SteeringSpeed2LightFactor = 3;
    SetPropertyInt("(speed + steering) : light factor", m_SteeringSpeed2LightFactor);

    for(int i = 0; i < 8; i++)
        m_WasSet[i] = false;
}

cActuatorRepeaterFilter::~cActuatorRepeaterFilter()
{

}

tResult cActuatorRepeaterFilter::Init(tInitStage eStage, __exception)
{
    // never miss calling the parent implementation!!
    RETURN_IF_FAILED(cTimeTriggeredFilter::Init(eStage, __exception_ptr))
    
    // in StageFirst you can create and register your static pins.
    if (eStage == StageFirst)
    {
        RETURN_IF_FAILED(CreatePins(__exception_ptr));
    }
    else if (eStage == StageNormal)
    {
        // In this stage you would do further initialisation and/or create your dynamic pins.
        // Please take a look at the demo_dynamicpin example for further reference.

        m_UpdateFrequency = (tUInt) GetPropertyInt("Updaterate [Hz]");
        m_SteeringSpeed2LightFactor = (tUInt) GetPropertyInt("(speed + steering) : light factor");
        m_SteeringSpeed2LightFactor += 1;

        SetInterval(1000000/m_UpdateFrequency);
    }
    else if (eStage == StageGraphReady)
    {
        // All pin connections have been established in this stage so you can query your pins
        // about their media types and additional meta data.
        // Please take a look at the demo_imageproc example for further reference.
    }

    RETURN_NOERROR;
}

tResult cActuatorRepeaterFilter::Start(__exception)
{
    m_TotalCounter = 0;
    m_LightCounter = 0;
    m_SteeringSpeedCounter = 0;

    return cTimeTriggeredFilter::Start(__exception_ptr);
}

tResult cActuatorRepeaterFilter::Stop(__exception)
{
    return cTimeTriggeredFilter::Stop(__exception_ptr);
}

tResult cActuatorRepeaterFilter::Shutdown(tInitStage eStage, __exception)
{
    // In each stage clean up everything that you initiaized in the corresponding stage during Init.
    // Pins are an exception: 
    // - The base class takes care of static pins that are members of this class.
    // - Dynamic pins have to be cleaned up in the ReleasePins method, please see the demo_dynamicpin
    //   example for further reference.
    
    if (eStage == StageGraphReady)
    {
    }
    else if (eStage == StageNormal)
    {
    }
    else if (eStage == StageFirst)
    {
    }

    // call the base class implementation
    return cTimeTriggeredFilter::Shutdown(eStage, __exception_ptr);
}

tResult cActuatorRepeaterFilter::OnPinEvent(IPin* pSource,
                                           tInt nEventCode,
                                           tInt nParam1,
                                           tInt nParam2,
                                           IMediaSample* pMediaSample)
{
    // first check what kind of event it is
    if (nEventCode == IPinEventSink::PE_MediaSampleReceived)
    {
        // so we received a media sample, so this pointer better be valid.
        RETURN_IF_POINTER_NULL(pMediaSample);

        // by comparing it to our member pin variable we can find out which pin received
        // the sample
        if (pSource == &m_oStatusInput)
        {
            DecodeStatusMessage(pMediaSample);
        }
        else
        {
            pMediaSample->Ref();

            if(pSource == &m_oSteeringInput)
            {
                m_Mutexes[0].Enter();
                    m_MediaSamplePtrs[0].Attach(pMediaSample);
                    m_WasSet[0] = true;
                m_Mutexes[0].Leave();
                m_oSteeringOutput.Transmit(pMediaSample);
            }
            else if(pSource == &m_oSpeedInput)
            {
                m_Mutexes[1].Enter();
                    m_MediaSamplePtrs[1].Attach(pMediaSample);
                    m_WasSet[1] = true;
                m_Mutexes[1].Leave();
                m_oSpeedOutput.Transmit(pMediaSample);
            }
            else
            {
                tUInt idx = 2;
                if(pSource == &m_oHeadLightInput)
                    idx = 2;
                else if(pSource == &m_oReverseLightInput)
                    idx = 3;
                else if(pSource == &m_oBrakeLightInput)
                    idx = 4;
                else if(pSource == &m_oTurnRightInput)
                    idx = 5;
                else if(pSource == &m_oTurnLeftInput)
                    idx = 6;
                else if(pSource == &m_oHazzardLightInput)
                    idx = 7;
                else
                    RETURN_ERROR(ERR_NOT_FOUND);

                m_Mutexes[idx].Enter();
                    m_MediaSamplePtrs[idx].Attach(pMediaSample);
                    m_WasSet[idx] = true;
                m_Mutexes[idx].Leave();
            }

        }
    }

    RETURN_NOERROR;
}

tResult cActuatorRepeaterFilter::Cycle (__exception)
{
    if(m_TotalCounter == 0)
    {
        cOutputPin *pOutputPin = 0;

        m_Mutexes[m_LightCounter+2].Enter();

            switch(m_LightCounter)
            {
            case 0:
                pOutputPin = &m_oHeadLightOutput;
                break;
            case 1:
                pOutputPin = &m_oReverseLightOutput;
                break;
            case 2:
                pOutputPin = &m_oBrakeLightOutput;
                break;
            case 3:
                pOutputPin = &m_oTurnRightOutput;
                break;
            case 4:
                pOutputPin = &m_oTurnLeftOutput;
                break;
            case 5:
            default:
                pOutputPin = &m_oHazzardLightOutput;
            }

            if(pOutputPin == 0)
                RETURN_ERROR(ERR_NOT_FOUND);

            if(m_WasSet[m_LightCounter+2])
                pOutputPin->Transmit(m_MediaSamplePtrs[m_LightCounter+2]);

        m_Mutexes[m_LightCounter+2].Leave();

        m_LightCounter++;
        if(m_LightCounter > 5)
            m_LightCounter = 0;

    }
    else
    {
        if(m_SteeringSpeedCounter == 0)
        {
            m_Mutexes[0].Enter();
                if(m_WasSet[0])
                    m_oSteeringOutput.Transmit(m_MediaSamplePtrs[0]);
            m_Mutexes[0].Leave();

            m_SteeringSpeedCounter = 1;
        }
        else
        {
            m_Mutexes[1].Enter();
                if(m_WasSet[1])
                    m_oSpeedOutput.Transmit(m_MediaSamplePtrs[1]);
            m_Mutexes[1].Leave();
            m_SteeringSpeedCounter = 0;
        }
    }

    m_TotalCounter++;
    if(m_TotalCounter >= m_SteeringSpeed2LightFactor)
        m_TotalCounter = 0;

    RETURN_NOERROR;
}

tResult cActuatorRepeaterFilter::SendStatusFeedback(tInt feedback)
{
    // now we need a new media sample to forward the data.
    cObjectPtr<IMediaSample> pNewSample;
    if (IS_OK(AllocMediaSample(&pNewSample)))
    {
        // now set its data
        // we reuse the timestamp from the incoming media sample. Please see the api documentation
        // (ADTF Extreme Programmers -> The ADTF Streamtime) for further reference on how sample times are handled in ADTF
        tSignalValue data;
        data.value = feedback;
        pNewSample->Update(_clock->GetStreamTime(), &data, sizeof(tSignalValue), 0);

        // and now we can transmit it
        m_oStatusOutput.Transmit(pNewSample);
    }

    RETURN_NOERROR;
}

tResult cActuatorRepeaterFilter::DecodeStatusMessage(IMediaSample* pMediaSample)
{
    // this will store the value for our new sample
    tSignalValue status_message;

    // now lets access the data in the sample,
    // the Lock method gives you access to the buffer of the sample.
    // we use a scoped sample lock to ensure that the lock is released in all circumstances.

    {
        // this will aquire the read lock on the sample and declare and initialize a pointer to the data
        __sample_read_lock(pMediaSample, tSignalValue, pData);
        // now we can access the sample data through the pointer
        status_message = *pData;
        // the read lock on the sample will be released when leaving this scope
    }

    /*
    switch(tInt(status_message.value))
    {
    case 0: m_FilterCore.Status_SetInactive();
        break;
    case 1: m_FilterCore.Status_SetActive();
        break;
    case 2: m_FilterCore.Status_IsReady();
        break;
    case -1: m_FilterCore.Status_Reset();
        break;
    default: m_FilterCore.Status_ChangeMode(tInt(status_message.value));
    }*/

    RETURN_NOERROR;
}


tResult cActuatorRepeaterFilter::CreatePins(__exception)
{
    // create and register the status-input pin
    RETURN_IF_FAILED(m_oStatusInput.Create("status_input", new cMediaType(0,0,0,SIGNALVALUE), this));
    RETURN_IF_FAILED(RegisterPin(&m_oStatusInput));

    // create and register the output pin
    RETURN_IF_FAILED(m_oStatusOutput.Create("status_output", new cMediaType(0,0,0,SIGNALVALUE), this));
    RETURN_IF_FAILED(RegisterPin(&m_oStatusOutput));


    RETURN_IF_FAILED(m_oSteeringInput.Create("steering_input", new cMediaType(0,0,0,SIGNALVALUE), this));
    RETURN_IF_FAILED(RegisterPin(&m_oSteeringInput));

    RETURN_IF_FAILED(m_oSpeedInput.Create("speed_input", new cMediaType(0,0,0,SIGNALVALUE), this));
    RETURN_IF_FAILED(RegisterPin(&m_oSpeedInput));

    RETURN_IF_FAILED(m_oHeadLightInput.Create("head_light_input", new cMediaType(0,0,0,BOOLSIGNALVALUE), this));
    RETURN_IF_FAILED(RegisterPin(&m_oHeadLightInput));

    RETURN_IF_FAILED(m_oReverseLightInput.Create("reverse_light_input", new cMediaType(0,0,0,BOOLSIGNALVALUE), this));
    RETURN_IF_FAILED(RegisterPin(&m_oReverseLightInput));

    RETURN_IF_FAILED(m_oBrakeLightInput.Create("brake_light_input", new cMediaType(0,0,0,BOOLSIGNALVALUE), this));
    RETURN_IF_FAILED(RegisterPin(&m_oBrakeLightInput));

    RETURN_IF_FAILED(m_oTurnRightInput.Create("turn_right_light_input", new cMediaType(0,0,0,BOOLSIGNALVALUE), this));
    RETURN_IF_FAILED(RegisterPin(&m_oTurnRightInput));

    RETURN_IF_FAILED(m_oTurnLeftInput.Create("turn_left_light_input", new cMediaType(0,0,0,BOOLSIGNALVALUE), this));
    RETURN_IF_FAILED(RegisterPin(&m_oTurnLeftInput));

    RETURN_IF_FAILED(m_oHazzardLightInput.Create("hazzard_light_input", new cMediaType(0,0,0,BOOLSIGNALVALUE), this));
    RETURN_IF_FAILED(RegisterPin(&m_oHazzardLightInput));


    RETURN_IF_FAILED(m_oSteeringOutput.Create("steering_output", new cMediaType(0,0,0,SIGNALVALUE), this));
    RETURN_IF_FAILED(RegisterPin(&m_oSteeringOutput));

    RETURN_IF_FAILED(m_oSpeedOutput.Create("speed_output", new cMediaType(0,0,0,SIGNALVALUE), this));
    RETURN_IF_FAILED(RegisterPin(&m_oSpeedOutput));

    RETURN_IF_FAILED(m_oHeadLightOutput.Create("head_light_output", new cMediaType(0,0,0,BOOLSIGNALVALUE), this));
    RETURN_IF_FAILED(RegisterPin(&m_oHeadLightOutput));

    RETURN_IF_FAILED(m_oReverseLightOutput.Create("reverse_light_output", new cMediaType(0,0,0,BOOLSIGNALVALUE), this));
    RETURN_IF_FAILED(RegisterPin(&m_oReverseLightOutput));

    RETURN_IF_FAILED(m_oBrakeLightOutput.Create("brake_light_output", new cMediaType(0,0,0,BOOLSIGNALVALUE), this));
    RETURN_IF_FAILED(RegisterPin(&m_oBrakeLightOutput));

    RETURN_IF_FAILED(m_oTurnRightOutput.Create("turn_right_light_output", new cMediaType(0,0,0,BOOLSIGNALVALUE), this));
    RETURN_IF_FAILED(RegisterPin(&m_oTurnRightOutput));

    RETURN_IF_FAILED(m_oTurnLeftOutput.Create("turn_left_light_output", new cMediaType(0,0,0,BOOLSIGNALVALUE), this));
    RETURN_IF_FAILED(RegisterPin(&m_oTurnLeftOutput));

    RETURN_IF_FAILED(m_oHazzardLightOutput.Create("hazzard_light_output", new cMediaType(0,0,0,BOOLSIGNALVALUE), this));
    RETURN_IF_FAILED(RegisterPin(&m_oHazzardLightOutput));


    RETURN_NOERROR;
}
