/**
Copyright (c)
Audi Autonomous Driving Cup. Team MomenTUM. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
3.  All advertising materials mentioning features or use of this software must display the following acknowledgement: "This product includes software developed by the Audi AG and its contributors for Audi Autonomous Driving Cup."
4.  Neither the name of Audi nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY AUDI AG AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL AUDI AG OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


**********************************************************************
* $Author:: MomenTUM#$  $Date:: 2015-10-10 15:10:07#$ $Rev:: 35043   $
**********************************************************************/

#ifndef _MTUM_ACTUATOR_REPEATER_FILTER_H_
#define _MTUM_ACTUATOR_REPEATER_FILTER_H_

#define OID_ADTF_MTUM_ACTUATOR_REPEATER_FILTER "adtf.mtum.actuator_repeater_filter"


//*************************************************************************************************
class cActuatorRepeaterFilter : public adtf::cTimeTriggeredFilter
{
    ADTF_FILTER(OID_ADTF_MTUM_ACTUATOR_REPEATER_FILTER, "MTUM Actuator Repeater", adtf::OBJCAT_DataFilter);

private:
    cInputPin    m_oStatusInput;    // input pin for mtum-status-messages
    cOutputPin   m_oStatusOutput;   // output pin for mtum-status-feedback

    cInputPin   m_oSteeringInput;
    cInputPin   m_oSpeedInput;
    cInputPin   m_oHeadLightInput;
    cInputPin   m_oReverseLightInput;
    cInputPin   m_oBrakeLightInput;
    cInputPin   m_oTurnRightInput;
    cInputPin   m_oTurnLeftInput;
    cInputPin   m_oHazzardLightInput;

    cOutputPin   m_oSteeringOutput;
    cOutputPin   m_oSpeedOutput;
    cOutputPin   m_oHeadLightOutput;
    cOutputPin   m_oReverseLightOutput;
    cOutputPin   m_oBrakeLightOutput;
    cOutputPin   m_oTurnRightOutput;
    cOutputPin   m_oTurnLeftOutput;
    cOutputPin   m_oHazzardLightOutput;

    // Add here additional in/out/video pins:


public:
    cActuatorRepeaterFilter(const tChar* __info);
    virtual ~cActuatorRepeaterFilter();

    tResult SendStatusFeedback(tInt feedback);


protected:
    tResult Init(tInitStage eStage, __exception = NULL);
    tResult Start(__exception = NULL);
    tResult Stop(__exception = NULL);
    tResult Shutdown(tInitStage eStage, __exception = NULL);

    tResult OnPinEvent(IPin* pSource,
                       tInt nEventCode,
                       tInt nParam1,
                       tInt nParam2,
                       IMediaSample* pMediaSample);

    tResult Cycle (__exception=NULL);

private:

    tResult CreatePins(__exception = NULL);

    tResult DecodeStatusMessage(IMediaSample* pMediaSample);

    tUInt m_UpdateFrequency;
    tUInt m_SteeringSpeed2LightFactor;

    tUInt m_TotalCounter;
    tUInt m_LightCounter;
    tUInt m_SteeringSpeedCounter;

    cObjectPtr<IMediaSample> m_MediaSamplePtrs[8];
    cCriticalSection m_Mutexes[8];
    tBool m_WasSet[8];

    // Add additional member variables here:

};

//*************************************************************************************************
#endif // _MTUM_ACTUATOR_REPEATER_FILTER_H_
