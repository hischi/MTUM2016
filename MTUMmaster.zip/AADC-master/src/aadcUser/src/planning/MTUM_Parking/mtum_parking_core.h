/**
Copyright (c)
Audi Autonomous Driving Cup. Team MomenTUM. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
3.  All advertising materials mentioning features or use of this software must display the following acknowledgement: "This product includes software developed by the Audi AG and its contributors for Audi Autonomous Driving Cup."
4.  Neither the name of Audi nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY AUDI AG AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL AUDI AG OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


**********************************************************************
* $Author:: MomenTUM#$  $Date:: 2015-10-10 15:10:07#$ $Rev:: 35043   $
**********************************************************************/

#ifndef _MTUM_PARKING_FILTER_CORE_H_
#define _MTUM_PARKING_FILTER_CORE_H_

#include <adtf_plugin_sdk.h>
#include "mtum_parking_interface.h"
#include "OdometryDataType.h"
#include "ParkingStruct.h"
#include <random>
#include "mtum_parking_trajectory_driver.h"
#include "ParkingLotData.h"

#define DEBUG

//*************************************************************************************************
class cParkingCore
{

public:
    cParkingCore(iParkingInterface *parent);
    virtual ~cParkingCore();

    /**
     * Processes the data and performs some operations...
     */
    tResult ProcessData();

    // MTUM Statusupdate methods called by events on the status input pin
    tBool       Status_IsReady()                {return true;}
    tResult     Status_Reset();
    tResult     Status_ChangeMode(tInt mode);
    tResult     Status_SetActive();
    tResult     Status_SetInactive();

    enum state { PARK_IDLE, PARK_FIND, PARK_FIND_FIRST, PARK_CHECK, PARK_CROSS, PARK_CROSS_DOUBLECHECK, PARK_PARALLEL, PARK_PARALLEL_DOUBLECHECK, PARK_PARKING, PARK_PULL_OUT, PARK_PULL_BACK, PARK_IN_CROSS, PARK_IN_PARALLEL,
        PARK_CROSS_PULL_OUT_RIGHT, PARK_CROSS_PULL_OUT_LEFT, PARK_PARALLEL_PULL_OUT_RIGHT, PARK_PULL_OUT_DONE, PARK_WAIT_TYPE, FIND_FROM_START,PARK_PARKING_PARALLEL,PARK_PARKING_CROSS};

    tResult     UpdateOdometry(const tOdometryData *pData);
    tResult     UpdateParking(const tParkingStruct *pData);
    tResult     UpdateMap(Mat &obstacleMap);
    void        sendManeuverDone();
    void        setState(state s);
    void        waitDriverThenSetState(state s);
    state       getState();
    ParkingTrajectoryDriver driver;
    struct props{
        int dist_front;
        int dist_rear;
        int dist_left;
        int dist_right;
        int occupy_thres;
        double velocity =0.3;
        double acceleration = 1;
    };

    tResult     SetProperties(props p, string s);

private:
    void controlParking(tOdometryData const &odo);
    tUInt64 parktime;
    cMutex state_mux;
    bool active;
    state parkState;
    ParkingLotData parkingLotData_Cross;
    ParkingLotData parkingLotData_Parallel;
    ParkingLotData *parkingLotData;
    ParkingLotData::ParkingPoint* parkingLot;
    Point2d endPos;

    Point2d carPos;
    int referencePointCounter =10000;

    deque<Point2d> D_globalPoints;
    vector<ParkingLotData::ParkingPoint> D_parkingLotPoints;
    Point2d D_dir;

    cMutex pppmux;

    // Add additional methods and membervariables here:
    // tFloat32     m_TestValue;
    iParkingInterface  *m_pFilterReference;
    props           m_props;
    tOdometryData   m_Odometry;
    cMutex          m_OdometryMutex;
    cMutex       m_ObstacleMapMutex;


    void drawCar(GCLPainter &painter) const;
};

//*************************************************************************************************
#endif // _MTUM_PARKING_FILTER_CORE_H_
