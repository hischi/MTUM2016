//
// Created by aadc on 05.02.16.
//

#include "mtum_parking_core.h"
#include "stdafx.h"
#include "GCLPainter.h"

GCLPainter::GCLPainter() {

    cGCLWriter::GetDynamicMemoryBlock(pCommandBlock);
    odo.x = 0;
    odo.y = 0;
    odo.phi = 0;
    carInMap = Point2d(0,0);
}

void GCLPainter::setColor(cColor c)
{
    cGCLWriter::StoreCommand(pCommandBlock, GCL_CMD_FGCOL, c.GetRGBA());
}

void GCLPainter::drawRectangle(const Rect &r) {
    cGCLWriter::StoreCommand(pCommandBlock, GCL_CMD_DRAWRECT, r.x, r.y, r.x + r.width, r.y + r.height);
}

void GCLPainter::setPos(const tOdometryData &odo)
{
      this->odo = odo;

}

void GCLPainter::setCarInMap(const Point2d &car)
{
    this->carInMap = car;
}

void GCLPainter::drawRotRectangle(const RotatedRect &r) {
    Point2f ps[4];
    r.points(ps);
    tUInt32 arrPoints2[] = {8, (tUInt32)ps[0].x, (tUInt32)ps[0].y, (tUInt32)ps[1].x, (tUInt32)ps[1].y,(tUInt32) ps[2].x,(tUInt32) ps[2].y,(tUInt32) ps[3].x, (tUInt32)ps[3].y};
    cGCLWriter::StoreCommand(pCommandBlock, GCL_CMD_DRAWPOLYGON,
                             sizeof(arrPoints2) / sizeof(tUInt32),
                             arrPoints2);
}

void GCLPainter::drawLine(Point2d const &p1, Point2d const &p2)
{
    tUInt32 arrPoints2[] = {4, (tUInt32)p1.x, (tUInt32)p1.y, (tUInt32)p2.x, (tUInt32)p2.y};
    cGCLWriter::StoreCommand(pCommandBlock, GCL_CMD_DRAWPOLYGON,
                             sizeof(arrPoints2) / sizeof(tUInt32),
                             arrPoints2);
    //cGCLWriter::StoreCommand(cmds, GCL_CMD_DRAWLINE, (tFloat32)p1.x, (tFloat32)p1.y, (tFloat32)p2.x, (tFloat32)p2.y);
}

void GCLPainter::drawLineGlobal(const Point2d &p1, const Point2d &p2)
{
    Point2d g1 = ParkingLotData::Global2Map(p1,odo,carInMap);
    Point2d g2 = ParkingLotData::Global2Map(p2, odo, carInMap);
    drawLine(g1,g2);
}



void GCLPainter::drawPoint(const Point2d &p)
{
    Point2d p1 = ParkingLotData::Global2Map(p,odo,carInMap);
    Rect r(p1.x-2, p1.y-2,4,4);
    drawRectangle(r);
}
void GCLPainter::insertPainting(GCLPainter &p){
    pCommandBlock->Append(p.pCommandBlock->GetPtr(),p.pCommandBlock->GetSize());
}


IDynamicMemoryBlock *GCLPainter::getData() {
    cGCLWriter::StoreCommand(pCommandBlock, GCL_CMD_END);
    return pCommandBlock;
}

void GCLPainter::clear() {
    cGCLWriter::StoreCommand(pCommandBlock, GCL_CMD_CLEAR);
}

void GCLPainter::writeText(string const &text, int x, int y) {
    cString strSmallText = cString(text.c_str());
    // Draw a test string in small font size
    cGCLWriter::StoreCommand(pCommandBlock, GCL_CMD_TEXT_SIZE_NORMAL);
    cGCLWriter::StoreCommand(pCommandBlock, GCL_CMD_TEXT, x, y, strSmallText.GetLength());
    cGCLWriter::StoreData(pCommandBlock, strSmallText.GetLength(), strSmallText.GetPtr());
}

GCLPainter::~GCLPainter() {
    // we don't need it anymore
    cGCLWriter::FreeDynamicMemoryBlock(pCommandBlock);
}
