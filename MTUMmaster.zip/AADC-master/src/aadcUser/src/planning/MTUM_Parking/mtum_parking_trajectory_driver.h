/**
Copyright (c)
Audi Autonomous Driving Cup. Team MomenTUM. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
3.  All advertising materials mentioning features or use of this software must display the following acknowledgement: "This product includes software developed by the Audi AG and its contributors for Audi Autonomous Driving Cup."
4.  Neither the name of Audi nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY AUDI AG AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL AUDI AG OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


**********************************************************************
* $Author:: MomenTUM#$  $Date:: 2015-10-10 15:10:07#$ $Rev:: 35043   $
**********************************************************************/

#ifndef _MTUM_PARKING_TRAJECTORY_H_
#define _MTUM_PARKING_TRAJECTORY_H_

#include "stdafx.h"
#include "mtum_parking_trajectory.h"
#include "mtum_parking_commands.h"
#include <deque>

using namespace std;
FileStorage &operator<<(FileStorage &fs, ParkingCommand const &cmd);
FileStorage &operator<<(FileStorage &fs, const deque<ParkingCommand*> &cmds);




class ParkingTrajectoryDriver: public ParkingTrajectory{
public:
    ParkingTrajectoryDriver(unsigned int cycleTime, double speed, double acc);
    ~ParkingTrajectoryDriver();


    void setPosition(double x, double y, double vel, double phi, unsigned long time);
    void produceReferencePoints(int num, tReferencePoints &points, unsigned long time);
    void pushCommand(ParkingCommand *c);
    void goStraight(double dist);
    void goCurv(double angle, double dir, double curv);
    void Wait(double seconds);
    void WaitExecute(double seconds,  function<void(void)> fkt);
    void readCommands(string commandName);
    void clearCommands();
    tReferencePoint& getPos();
    
    void setCommandFile(string file);

     deque<ParkingCommand*> commands;

    void readCommandsReverse(string name);

private:

    tReferencePoint lastSentPoint;

    deque<tReferencePoint> history;
    cMutex mux;
    string commandFile;

    void predictStateEuler(tReferencePoint &pt, double dtime, double acc, double curv);
    void predictStateRungeKutta(tReferencePoint &pt, double dtime, double acc, double curv);

    tReferencePoint vehicleDynamics(tReferencePoint const &pt, double acc, double curv) const;
};

//*************************************************************************************************
#endif // _MTUM_PARKING_TRAJECTORY_H_
