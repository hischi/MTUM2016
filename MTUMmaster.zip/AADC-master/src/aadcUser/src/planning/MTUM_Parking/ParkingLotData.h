//
// Created by aadc on 27.01.16.
//

#ifndef AADC_USER_PARKINGLOTDATA_H
#define AADC_USER_PARKINGLOTDATA_H

#include "stdafx.h"
#include <iostream>
#include <OdometryDataType.h>
#include "GCLPainter.h"
#include "mtum_parking_core.h"



enum parkType{ PARKTYPE_CROSS, PARKTYPE_LONG, PARKTYPE_NONE};
class ParkingLotData {
public:
    struct ParkingPoint{
        Point2d center;
        double occupied;
        double occupied2;
        double weightL;
        double weightR;
        bool used;
    };

    void removeLot(ParkingPoint *pPoint);

    bool signPassed(Point2d odoPos);

    void getPathToRestart(ParkingTrajectoryDriver &driver);

    void getPathToRestart(ParkingTrajectoryDriver &driver, const tOdometryData &data);

    void PassSign(ParkingTrajectoryDriver &driver, const tOdometryData &data);

private:
     cMutex mux;
     Point2d dir;
     Point2d sign;
     Point2d oldSigns;
     Point2d lanePoint;
     double oldSignSum;
     double width; // in driving dir
     double minlength; // in driving dir
     double maxlength;
     double widthTestDriveBy;
     double lengthTestDriveBy;
      double driveByDist;
     double minPointDist;
    double thresholdDriveBy;
    double thresholdTest2;
    double widthTest2;
    double lengthTest2;
    double offsetGoToLot;
    double offsetTest2;
    double maxSum;
    double distLastLot;
    double distFirstLot;
     parkType myParkType;
     vector<ParkingPoint*> ParkingPoints;
     string filename;
    int tryCount;


public:
    ParkingLotData() {dir = Point2d(0,0);}

    ParkingLotData(parkType pt, double width, double length, double driveByDist);

    void reset(bool keepSign);
    void init(string filename, parkType pt);


   void insertPoints(vector<Point2d> points, Point2d dir, vector<ParkingPoint> D_parkingPoints, Point2d sign,
                        Point2d lanePoint);
   void checkFree(tOdometryData odo, Point2d carInMap, Mat &map, GCLPainter *painter);
   void drawParkingLots(GCLPainter &p, tOdometryData const &odo, Point2d const &carInMap);

   Point2d getLanePoint();



    ParkingPoint * getNextParkingPoint(tOdometryData const &odo);
    double getOccupied(ParkingPoint* p);
    Point2d const &getDir();
    Point2d const &getSign();
    void getPathToParkingLot(tOdometryData const &odo, ParkingPoint *parkingLot, double &startx, double &starty,double &startphi,double &dist);


    static Point2d Global2Map(Point2d const &in, tOdometryData const &odo, Point2d const &carInMap);

    static void Local2Global(Point2d in, tOdometryData const &odo, Point2d &out);
private:
    class compParkPoint{
    public:
        compParkPoint(Point2d dir):dir(dir){}
        bool operator()(ParkingPoint* a, ParkingPoint* b)const
        {
            return (dir.dot(a->center) < dir.dot(b->center));
        }
        Point2d dir;
    };

    tUInt checkRotRectangle(const Mat &m, const RotatedRect &r, double threshold);

    void ParkingMerge(vector<ParkingPoint*> &pts);




    static void Global2Local(Point2d in, tOdometryData const &odo, Point2d &out);



    static void Local2Map(Point2d const &in, Point2d const &carInMap, Point2d &out );


    double CheckLotFree(tOdometryData odo, Point2d carInMap, Mat map, GCLPainter &painter, ParkingPoint *Lot);

    void readProperties();

    double distToSign(Point2d odoPos);
};


#endif //AADC_USER_PARKINGLOTDATA_H
