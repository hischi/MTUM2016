/**
Copyright (c)
Audi Autonomous Driving Cup. Team MomenTUM. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
3.  All advertising materials mentioning features or use of this software must display the following acknowledgement: "This product includes software developed by the Audi AG and its contributors for Audi Autonomous Driving Cup."
4.  Neither the name of Audi nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY AUDI AG AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL AUDI AG OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


**********************************************************************
* $Author:: MomenTUM#$  $Date:: 2015-10-10 15:10:07#$ $Rev:: 35043   $
**********************************************************************/

#include <cmath>
#include <iostream>
#include "mtum_parking_trajectory_driver.h"
FileStorage &operator<<(FileStorage &fs, ParkingCommand const &cmd)
{
    cmd.toFs(fs);
    return fs;
}


FileStorage &operator<<(FileStorage &fs, const deque<ParkingCommand*> &cmds)
{ fs << "[";
    for( int i = 0; i < cmds.size(); i++ )
    {
        fs << *cmds[i];
    }
    fs << "]";
}




ParkingTrajectoryDriver::ParkingTrajectoryDriver(unsigned int cycleTime, double speed, double acc)
        : ParkingTrajectory(cycleTime,speed,acc) {

}


ParkingTrajectoryDriver::~ParkingTrajectoryDriver() {
    while(!commands.empty()){
        delete commands.front();
        commands.pop_front();

    }
}

void ParkingTrajectoryDriver::setPosition(double x, double y, double vel, double phi, unsigned long time) {
    cout << "set position was called!" << endl;
    clearCommands();
    cout << "cleared command" << endl;
    mux.Enter();
    currentPos.x = x;
    currentPos.y = y;
    currentPos.vel = vel;
    currentPos.phi = phi;
    currentPos.time = time;
    currentPos.curvature =0;
    currentPos.acceleration=0;
    currentPos.lightFlags = 0;

    cout << "Set currentPos: x: " << currentPos.x << " y: " << currentPos.y << " time: " << currentPos.time <<  endl;

    lastSentPoint =currentPos;
    mux.Leave();
}

void ParkingTrajectoryDriver::produceReferencePoints(int num, tReferencePoints &points, unsigned long time) {
    if( num > REFERENCEPOINTSIZE) num = REFERENCEPOINTSIZE;
    points.numPoints= num;

    // dump old points
    mux.Enter();
    while(!history.empty() && history.front().time < time){
         lastSentPoint = history.front();
         //cout << "Delete:  oldest time: " << history.front().time << " actual time: " << time << endl;
         history.pop_front();
    }

    if(history.size() == 0)
        currentPos.time = time;
    //cout << "Now, there are: " << history.size() << " points" << endl;


    tReferencePoint &pt = currentPos;

    while(!commands.empty() && history.size() < num){
        pt.time += cycle_time;
        double dtime = cycle_time * 1e-6;
        //predictStateRungeKutta(pt, dtime,pt.acceleration,pt.curvature);
        ReplayPoints *rps = dynamic_cast<ReplayPoints*> (commands.front());
       if(rps != NULL){
           pt = rps->nextRefPoint(pt);
       }else {
           double acc = commands.front()->getAcceleration(pt);
           double curv = commands.front()->getCurvature(pt);
           predictStateEuler(pt, dtime, acc, curv);
           pt.acceleration = acc;
           pt.curvature = curv;
       }
        int currentIndicator = commands.front()->getIndicator();

        if(currentIndicator >= 0)
            currentPos.lightFlags = currentIndicator;
        //cout << "acceleration: " << acc << " curvature: " << curv << endl;

        pt.lightFlags = currentPos.lightFlags;

        history.push_back(pt);
        if(commands.front()->endCommand()){
            delete commands.front();
            commands.pop_front();
        }

    }

    //cout << " Send Trajectory: num Points: " << history.size() << endl;
    points.numPoints = history.size();
    for(size_t i =0; i < history.size(); i++){
        //cout << "p " << i << ": x: " << history[i].x << " y: " << history[i].y << " time: " << history[i].time <<  endl;
        points.points[i] = history[i];
    }
    mux.Leave();
}

// binary operator as non-member function with 2 arguments
tReferencePoint operator+(const tReferencePoint& left, const tReferencePoint& right) {
    tReferencePoint result;
    result.x = left.x + right.x;
    result.y = left.y + right.y;
    result.phi = left.phi + right.phi;
    if(result.phi > M_PI){
        result.phi -= 2* M_PI;
    }
    if(result.phi < -M_PI){
        result.phi += 2* M_PI;
    }
    result.time = left.time + right.time;
    result.vel = left.vel + right.vel;
    result.curvature = left.curvature+right.curvature;
    result.acceleration = left.acceleration + right.acceleration;
    return result;
}
// binary operator as non-member function with 2 arguments
tReferencePoint operator+=(tReferencePoint& result, const tReferencePoint& right) {
    result.x = result.x + right.x;
    result.y = result.y + right.y;
    result.phi = result.phi + right.phi;
    if(result.phi > M_PI){
        result.phi -= 2* M_PI;
    }
    if(result.phi < -M_PI){
        result.phi += 2* M_PI;
    }
    result.time = result.time + right.time;
    result.vel = result.vel + right.vel;
    result.curvature = result.curvature+right.curvature;
    result.acceleration = result.acceleration + right.acceleration;
    return result;
}
tReferencePoint operator*(double multiplier, tReferencePoint const & point){
    tReferencePoint result;
    result.time = point.time;
    result.x = multiplier * point.x;
    result.y = multiplier * point.y;
    result.phi = multiplier* point.phi;
    if(result.phi > M_PI){
        result.phi -= 2* M_PI;
    }
    if(result.phi < -M_PI){
        result.phi += 2* M_PI;
    }
    result.vel = multiplier * point.vel;
    result.acceleration = multiplier * point.acceleration;
    result.curvature = multiplier * point.curvature;
    return result;

}

void ParkingTrajectoryDriver::predictStateEuler(tReferencePoint &pt, double dtime, double acc, double curv) {
    pt += dtime * vehicleDynamics(pt, acc, curv);
}


void ParkingTrajectoryDriver::pushCommand(ParkingCommand *c) {
    if(c == NULL){
        cerr << "tried to insert null command" << endl;
    }else {
        mux.Enter();
        commands.push_back(c);
        mux.Leave();
    }
}

tReferencePoint &ParkingTrajectoryDriver::getPos() {
    return currentPos;
}

void ParkingTrajectoryDriver::setCommandFile(string file)
{
    commandFile = file;
}

void ParkingTrajectoryDriver::predictStateRungeKutta(tReferencePoint &pt, double dtime, double acc, double curv) {
    tReferencePoint a = vehicleDynamics(pt,acc, curv);
    tReferencePoint b = vehicleDynamics(pt + dtime / 2 * a, acc, curv);
    tReferencePoint c = vehicleDynamics(pt + dtime / 2 * b, acc, curv);
    tReferencePoint d = vehicleDynamics(pt + dtime * c, acc, curv);
    pt += dtime/6 * (a + 2* b + 2 * c + d);
}

tReferencePoint ParkingTrajectoryDriver::vehicleDynamics(tReferencePoint const &pt, double acc, double curv) const {
    tReferencePoint deriv;
    deriv.time =0;
    deriv.x = sin(-pt.phi) * pt.vel;
    deriv.y = cos(pt.phi)* pt.vel;
    deriv.phi = pt.vel*curv;
    deriv.vel = acc;
    deriv.acceleration =0;
    deriv.curvature =0;
    return deriv;
}

void ParkingTrajectoryDriver::clearCommands() {
    mux.Enter();
    for(uint i =0; i< commands.size();i++){
        delete commands[i];
    }
    history.clear();
    commands.clear();
    mux.Leave();

}

void ParkingTrajectoryDriver::goStraight(double dist) {
    double dir = (dist > 0)?1:-1;
    pushCommand(new GoStraight(*this,speed*dir,dist,0,acc));

}

void ParkingTrajectoryDriver::goCurv(double angle, double dir, double curv){
    pushCommand(new GoConstantCurvature(*this,speed*dir,angle,0,acc,curv));
}

void ParkingTrajectoryDriver::Wait(double seconds){
    pushCommand(new Stop(*this));
    pushCommand(new WaitTime(*this,seconds));
}

void ParkingTrajectoryDriver::WaitExecute(double seconds, function<void ()> fkt)
{
    pushCommand(new Stop(*this));
    pushCommand(new WaitAndExecute(*this,seconds,fkt));
}

ostream &operator<<(ostream &out, const ParkingCommand &cmd){
    cmd.toString(out);
    return out;
}

void ParkingTrajectoryDriver::readCommands(string commandName)
{
    FileStorage fs(commandFile, FileStorage::READ);
    FileNode node = fs[commandName];
    FileNodeIterator it = node.begin(), it_end = node.end();
    int idx = 0;
    for(; it != it_end; ++it, idx++){
        cout << "node #" << idx << ": ";
        string type;
        (*it)["type"] >> type;
        cout << " type: "<< type << endl;
        ParkingCommand* cmd = NULL;
        if(type == "GoStraight")
            cmd = new GoStraight(*this,(double)(*it)["speed"],(double)(*it)["dist"],(double)(*it)["endSpeed"],(double)(*it)["acc"]);
        else if( type == "GoCurve")
            cmd = new GoConstantCurvature(*this,(double)(*it)["speed"],(double)(*it)["angle"],(double)(*it)["endSpeed"],(double)(*it)["acc"], (double)(*it)["curvature"]);
        else if( type == "Stop")
            cmd = new Stop(*this);
        else if( type == "Wait")
            cmd = new WaitTime(*this,(double)(*it)["seconds"]);
        else if( type == "SetIndicator")
        {
            string str;
            (*it)["value"] >> str;
           if(str == "Left")
                cmd = new SetIndicator(*this,SetIndicator::INDICATE_LEFT);
            else if(str == "Right")
                cmd = new SetIndicator(*this,SetIndicator::INDICATE_RIGHT);
            else if(str == "Hazzard")
                cmd = new SetIndicator(*this,SetIndicator::INDICATE_HAZZARD);
            else
                cmd = new SetIndicator(*this,SetIndicator::INDICATE_NONE);
        }
        else if( type == "Points"){
            string str;
            (*it)["file"] >> str;
            string file = commandFile.substr(0,commandFile.find_last_of('/')+1).append(str);
            cmd = new ReplayPoints(*this,file);
            
        }

        cout << "read command: " << *cmd << endl;
        pushCommand(cmd);

    }
    fs.release();
}


