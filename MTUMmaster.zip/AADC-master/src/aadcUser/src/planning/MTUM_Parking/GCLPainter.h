//
// Created by aadc on 05.02.16.
//

#ifndef AADC_USER_GCLPAINTER_H
#define AADC_USER_GCLPAINTER_H

#include "stdafx.h"
#include "OdometryDataType.h"


class GCLPainter {
private:
    IDynamicMemoryBlock *pCommandBlock;
    tOdometryData odo;
    Point2d carInMap;

public:
    GCLPainter();
    ~GCLPainter();

    IDynamicMemoryBlock* getData();

    void setColor(cColor c);

    void drawLine(Point2d const &p1, Point2d const &p2);
    void drawLineGlobal(Point2d const &p1, Point2d const &p2);
    void drawRotRectangle(const RotatedRect &r);
    void drawPoint(Point2d const &p);
    void drawPointGlobal(Point2d const &p);
    void clear();
    void writeText(string const &text, int x, int y);
    void drawRectangle(const Rect &r);
    void setPos(tOdometryData const &odo);
    void setCarInMap(Point2d const &car);

    void insertPainting(GCLPainter & p);
};


#endif //AADC_USER_GCLPAINTER_H
