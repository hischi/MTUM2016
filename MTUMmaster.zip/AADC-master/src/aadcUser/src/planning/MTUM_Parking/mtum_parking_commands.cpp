/**
Copyright (c)
Audi Autonomous Driving Cup. Team MomenTUM. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
3.  All advertising materials mentioning features or use of this software must display the following acknowledgement: "This product includes software developed by the Audi AG and its contributors for Audi Autonomous Driving Cup."
4.  Neither the name of Audi nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY AUDI AG AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL AUDI AG OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


**********************************************************************
* $Author:: MomenTUM#$  $Date:: 2015-10-10 15:10:07#$ $Rev:: 35043   $
**********************************************************************/


#pragma once

#include <cmath>
#include <iostream>
#include "mtum_parking_commands.h"

void operator>>(const FileNode& n, vector<tReferencePoint>& value) {
    FileNodeIterator it = n.begin(), it_end = n.end();
    int idx = 0;
    value.clear();
    cout << "read points: " << n.size() << endl;
// iterate through a sequence using FileNodeIterator
    for( ; it != it_end; ++it, idx++ ) {
        cout << "point #" << idx << ": ";


        tReferencePoint val;

        (*it)["x"] >> val.x;
        (*it)["y"] >> val.y;
        (*it)["phi"] >> val.phi;
        (*it)["acc"] >> val.acceleration;
        (*it)["curv"] >> val.curvature;
        (*it)["vel"] >> val.vel;

        cout << val << endl;
        value.push_back(val);
    }
}

GoStraight::~GoStraight() {

}

double GoStraight::getAcceleration(tReferencePoint const &p) {
    double brakeDist;

    double remaining_dist = max(abs(distance - distGone) - 2.5 * abs(p.vel) * pt.cycle_time* 1e-6,0.0);

    double brakeableSpeed = this->acc* pt.cycle_time* 1e-6*0.5;
    double speedEnd = endSpeed;
    if(speed > 0 && endSpeed == 0 )
        speedEnd = brakeableSpeed;
    else if (speed < 0 && endSpeed  == 0)
        speedEnd  = -brakeableSpeed;

    double allowed_vel_max = speedEnd + sqrt(speedEnd*speedEnd + 2* remaining_dist* acc) ;
    double allowed_vel_min = speedEnd - sqrt(speedEnd*speedEnd + 2 * remaining_dist* acc);

    //cout << " remaining dist: " << remaining_dist << " allowed_vel_max: " << allowed_vel_max << " allowed_vel_min: " << allowed_vel_min << endl;

    if(p.vel >= allowed_vel_max){
        //cout << "Over vel max: remaining dist: " << remaining_dist << " allowed_vel_max: " << allowed_vel_max << " allowed_vel_min: " << allowed_vel_min << endl;
        return -this->acc;
    }
    if(p.vel <= allowed_vel_min){
        //cout << "Under Vel min: remaining dist: " << remaining_dist << " allowed_vel_max: " << allowed_vel_max << " allowed_vel_min: " << allowed_vel_min << endl;

        return this->acc;
    }

    if((allowed_vel_max-p.vel) < acc *pt.cycle_time*1e-6 ){
        //cout << "near vel max: remaining dist: " << remaining_dist << " allowed_vel_max: " << allowed_vel_max << " allowed_vel_min: " << allowed_vel_min << " set acc to"  << -(allowed_vel_max - p.vel )/(pt.cycle_time*1e-6) << endl;
        return -(allowed_vel_max - p.vel )/(pt.cycle_time*1e-6);
    }
    if((p.vel -allowed_vel_min) < acc *pt.cycle_time*1e-6 ){
        //cout << "near vel min: remaining dist: " << remaining_dist << " allowed_vel_max: " << allowed_vel_max << " allowed_vel_min: " << allowed_vel_min << " set acc to: "<< -(allowed_vel_min - p.vel )/(pt.cycle_time*1e-6) << endl;

        return -(allowed_vel_min - p.vel )/(pt.cycle_time*1e-6);
    }


    //cout << "not catched" << endl;


    if(abs(p.vel -this->speed) < abs(acc *pt.cycle_time*1e-6) ){
        return (this->speed - p.vel )/(pt.cycle_time*1e-6);
    }
    if(p.vel < this->speed)
        return this->acc;
    if(p.vel > this->speed)
        return -this->acc;

   return 0;
}


GoStraight::GoStraight(ParkingTrajectory &t, double speed, double distance, double endSpeed, double acc)
        : ParkingCommand(t) {
    this->distance = abs(distance);
    this->endSpeed = endSpeed;
    this->speed = speed;
    distGone =0;
    lastPoint.x =0;
    lastPoint.y =0;
    lastPoint.phi =0;
    lastPoint.time =0;
    this->acc =abs(acc);
}
GoStraight::GoStraight(ParkingTrajectory *t, double speed, double distance):ParkingCommand(*t) {
    this->distance = abs(distance);
    this->endSpeed = 0;
    this->speed = speed;
    distGone =0;
    lastPoint.x =0;
    lastPoint.y =0;
    lastPoint.phi =0;
    lastPoint.time =0;
    this->acc =0;
}

void GoStraight::toFs(FileStorage &fs) const
{
        string type = "GoStraight";
        fs << "{:" << "type" << type.c_str() << "dist" << distance << "speed" << speed<< "acc"<< acc << "endSpeed" << endSpeed << "}";
}

void GoStraight::toString(ostream &out) const
{
    out << "Go Straight: { dist: " << distance << " speed: " << speed << " acc: "<< acc << " endSpeed: " << endSpeed << " }" ;
}

bool GoStraight::endCommand() {
    if(lastPoint.x ==0 && lastPoint.y ==0 && lastPoint.time ==0){
        lastPoint = pt.currentPos;
    }
    double dx = lastPoint.x - pt.currentPos.x;
    double dy = lastPoint.y - pt.currentPos.y;
    lastPoint.x = pt.currentPos.x;
    lastPoint.y = pt.currentPos.y;
    distGone += sqrt(dx*dx + dy*dy);
    //cout << "Go straight: gone Dist" << distGone << endl;
    //if(distance < distGone){
     //   cout << "Gone dist reached: wanted end vel: "<< endSpeed << " real speed: " << pt.currentPos.vel << endl;

    //}
    return distance <= distGone;
}


GoStraight::GoStraight(ParkingTrajectory &t, double distance, double endSpeed):ParkingCommand(t) {
    this->distance = distance;
    this->endSpeed = endSpeed;
    this->speed = t.speed;
    this->acc = abs(t.acc);
    distGone = 0;
    lastPoint.x =0;
    lastPoint.y =0;
    lastPoint.phi =0;
    lastPoint.time =0;


}

GoStraight::GoStraight(ParkingTrajectory &t, double distance) :ParkingCommand(t){
    this->distance = distance;
    this->endSpeed = 0;
    this->speed = t.speed;
    this->acc = abs(t.acc);
    distGone = 0;
    lastPoint.x =0;
    lastPoint.y =0;
    lastPoint.phi =0;
    lastPoint.time =0;
}

GoToPoint::GoToPoint(ParkingTrajectory &pt, double x, double y, double phi, double curvature) : GoStraight(pt,0) {
    this->x=x;
    this->y=y;
    this->phi=phi*M_PI/180;
    this->phi = fmod(this->phi,2*M_PI);
    if(this->phi>M_PI)
        this->phi -= 2*M_PI;
    this->speed = pt.speed;
    this->state=0;
    this->curvature = curvature;
    distGone =0;

}

double GoToPoint::getAcceleration(tReferencePoint const &p) {
    double dir =0;
    switch (state){
        case 0:
           setPoints();
            if(state != 1)
                return 0;
        case 1:
            dir=  dirs[0];
            endSpeed = 0;
            speed = pt.speed* dirs[0];
            break;
        case 2:
            dir= dirs[1];
            endSpeed = 0;
            speed = pt.speed * dirs[1];

            break;
        case 3:
            dir= dirs[2];
            speed = pt.speed * dirs[2];
            endSpeed =0;
            break;


    }
   double val = GoStraight::getAcceleration(p);
    return val;
}

double GoToPoint::getCurvature(tReferencePoint const &p) {
switch (state){
    case 1:
        return  curvs[0];
        break;
    case 2:
        return curvs[1];
        break;
    case 3:
        return curvs[2];
        break;
    default:
        state = 0;
        return 0;
}
}

bool GoToPoint::endCommand() {
    cout << " Go to end command: state: " << state << " dist Gone: " << distGone << " distance: " << distance << endl;
    switch (state){
        case 1:
            distance = dists[0];
            if ( GoStraight::endCommand()){
                state = 2;
                distGone =0;
                cout << " finished first round" << endl;
            }
            break;
        case 2:
            distance = dists[1];
            if ( GoStraight::endCommand()){
                state = 3;
                distGone =0;
                cout << " finished second round" << endl;
            }
            break;
        case 3:
            distance = dists[2];
            return GoStraight::endCommand();
            break;
        default:
            cout << "Got to point: undefined state: " << state << endl;
            return true;
            break;
    }
    return false;

}

void GoToPoint::setPoints() {
    cout << "set points is called!" << " start phi: " << pt.currentPos.phi << " end phi: " << phi << endl;
    Point2d start(pt.currentPos.x,pt.currentPos.y);
    Point2d startDir(-sin(pt.currentPos.phi),cos(pt.currentPos.phi));
    Point2d end(x,y);
    Point2d endDir(-sin(phi),cos(phi));
    Point2d starts[2];
    double curvRadius = 1/this->curvature;
    starts[0] = start + Point2d(startDir.y,-startDir.x)* curvRadius;
    starts[1]= start + Point2d(-startDir.y,startDir.x)* curvRadius;
    Point2d ends[2];
    ends[0] = end + Point2d(endDir.y,-endDir.x)*curvRadius;
    ends[1] = end + Point2d(-endDir.y, endDir.x)*curvRadius;
    Point2d *startP = starts;
    Point2d *endP = ends;
    double dist =norm(startP-endP);

    for(uint i =0; i< 2; i++){
        for(uint j =0; j < 2; j++){
            if(norm(starts[i]-ends[j])<dist){
                startP= starts+i;
                endP = ends+j;
                dist =norm(starts[i]-ends[j]);
            }
        }
    }
    cout << "dist: " << dist << " startP: " << *startP << " endP: " << *endP << endl;
    if(dist >= 2* curvRadius) {
        double goDistMin = 1e10;

        for (int i = 0; i < 3; i++) {
            double d = 2*curvRadius * (i - 1);
            Point2d dir( endP->y-startP->y , ( startP->x - endP->x+d) );
            dir /= norm(dir);
            if((startP == starts && i == 2 )||( startP == starts+1 && i == 0 )){
                dir *= -1;
                cout << "rotated dir: startP: " << *startP << " starts: " << starts[0] << starts[1] << endl;
            }
            cout << " dir: " << dir << endl;

            double t = curvRadius - dir.dot(*startP);
            double distStraight = Point2d(-dir.y, dir.x).ddot(*endP - *startP);
            double angleFirst = (atan2(dir.y, dir.x) - pt.currentPos.phi);

            if (angleFirst > M_PI) {
                angleFirst -= 2 * M_PI;
            }
            if (angleFirst < -M_PI)
                angleFirst += 2 * M_PI;

            double angleLast = ( phi - atan2(dir.y, dir.x));

            double goDist = abs(distStraight) + abs(angleFirst * curvRadius) + abs(angleLast * curvRadius);

            double di = Point2d(-dir.y,dir.x).ddot(*endP-*startP);
            di = (di > 0)?1:-1;

            cout << "d: " << d << " dist Straight: " << distStraight*180/M_PI << " angle First: " << angleFirst*180/M_PI << " angle Last: " << angleLast*180/M_PI << "phi end: " << phi*180/M_PI << " dir: " << atan2(dir.y,dir.x)*180/M_PI << " distance: " << goDist << endl;

            if (goDist < goDistMin) {
                goDistMin = goDist;
                dirs[0] = di;
                curvs[0] = ((Point2d(-startDir.y, startDir.x).dot(end - start) > 0) ? 1 : -1);
                dists[0] = abs(angleFirst*curvRadius);

                curvs[1] = 0;
                dirs[1] = di;
                dists[1] = abs(distStraight);

                dirs[2] = di;
                curvs[2] = (Point2d(-endDir.y, endDir.x).dot(end - start) > 0) ? -1 : 1;
                dists[2] = abs(angleLast*curvRadius);

            }
        }
        state =1;
        distGone =0;
        cout << "best distance: " << goDistMin << " first: distance: " <<  dists[0] << " straight: dist: " << dists[1] << " last dist: " << dists[2] << endl;
        for(int i =0; i < 3; i++){
        cout << " command " << i << " curvature: " << curvs[i] << " direction: " << dirs[i] << " distance: " << dists[i] << endl;
        }
    }
    else{
        cout << "Problem: points too close: " << dist << endl;
        state =-1;
    }

}


tReferencePoint ReplayPoints::nextRefPoint(tReferencePoint const &p) {

    if(counter == 0){
        cout << "get next ref point: path:" <<path << endl;
        FileStorage fs(path,FileStorage::READ);
        fs["Points"] >> points;
        firstP = points.front();
        float angle = -firstP.phi;
        float alpha = cos(angle);
        float beta = sin(angle);
        rotation =(Mat_<float>(3,3) << alpha, -beta,-alpha * firstP.x+beta*firstP.y, beta, alpha,-beta*firstP.x -alpha*firstP.y, 0, 0, 1);
        angle = -p.phi;
        alpha = cos(angle);
        beta = sin(angle);
        Mat rotation2;
        rotation2= (Mat_<float>(3,3) << alpha, beta, p.x, -beta, alpha, p.y, 0, 0, 1);
        rotation = rotation2 * rotation;
        firstP.phi += angle;
        cout << "first p:" << firstP.x << " y: " << firstP.y << " phi: " << firstP.phi << endl;

        cout << "rotation matrix: " << rotation << endl;


    }
    counter ++;
    if(counter < points.size()){
        tReferencePoint &ps = points[counter];
        double dphi = ps.phi - firstP.phi;
        Point3f refp(ps.x,ps.y,1);


        Mat temp(refp,false);
        cout << "rotation:" << rotation <<endl;
        cout << " * " << temp << endl;
        cout << " = " << rotation*temp << endl;
        temp = rotation*temp;
        ps.x = refp.x;
        ps.y = refp.y;
        ps.phi = dphi;
        ps.time = p.time;
        return ps;

    }
    return p;

}

bool ReplayPoints::endCommand() {
    return counter >= points.size();
}

