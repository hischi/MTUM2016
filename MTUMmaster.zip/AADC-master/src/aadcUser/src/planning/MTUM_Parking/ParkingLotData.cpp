//
// Created by aadc on 27.01.16.
//

#include <iomanip>
#include <car_geometry.h>
#include "mtum_parking_core.h"
#include "stdafx.h"
#include "ParkingLotData.h"

ostream &operator<<(ostream &out, const ParkingLotData::ParkingPoint &vec)
{
    out << "ParkingPoint: center:"<< vec.center << " weight L: " << vec.weightL << " R: "<< vec.weightR << " occupied: " << vec.occupied << " used: " << vec.used;
}



ParkingLotData::ParkingLotData(parkType pt, double width, double length, double driveByDist)
{
    myParkType = pt;

    dir = Point2d(0,0);
    sign = Point2d(0,0);
    oldSigns = Point2d(0,0);
    lanePoint =Point2d(0,0);
    oldSignSum =0;
    this->driveByDist = driveByDist;
}



void ParkingLotData::checkFree(tOdometryData odo, Point2d carInMap, Mat &map, GCLPainter * painter) {
   
        

    if(map.cols < 100 || map.rows < 100){
        return;
    }

    mux.Enter();


    for(uint i =0; i< ParkingPoints.size(); i++){
        double rrangle = 180 / M_PI * (-atan2(dir.y, dir.x) + odo.phi);

        Point2d newCenter = ParkingPoints[i]->center + (width-widthTestDriveBy)/2 * Point2d(-dir.y,dir.x);
        RotatedRect rrl(Global2Map(newCenter, odo, carInMap), Size2f(100 *lengthTestDriveBy, widthTestDriveBy * 100), rrangle);
        Point2d newCenter2 = ParkingPoints[i]->center+ ((width-widthTest2)/2-offsetTest2)*Point2d(-dir.y,dir.x);
        RotatedRect rrl2(Global2Map(newCenter2, odo, carInMap), Size2f(100 * lengthTest2, widthTest2 * 100), rrangle);
        ParkingPoints[i]->occupied = checkRotRectangle(map,rrl,thresholdDriveBy);
        ParkingPoints[i]->occupied2 = checkRotRectangle(map,rrl2,thresholdTest2);
        if(painter != NULL) {
            stringstream ss;
            ss << "Sum:" << ParkingPoints[i]->occupied << " and " << ParkingPoints[i]->occupied2;

            if (ParkingPoints[i]->occupied > 10) {
                painter->setColor(cColor(255, 0, 255));
            } else {
                painter->setColor(cColor(0, 255, 255));
            }
            if (ParkingPoints[i]->weightL <= 3 || ParkingPoints[i]->weightR <= 3) {
                painter->setColor(cColor(0, 0, 0));
            }
            painter->writeText(ss.str(), rrl.center.x, rrl.center.y);
            painter->drawRotRectangle(rrl);
            if (ParkingPoints[i]->occupied2 > 10) {
                painter->setColor(cColor(255, 0, 255));
            } else {
                painter->setColor(cColor(0, 255, 255));
            }
            painter->drawRotRectangle(rrl2);
        }

    }
    mux.Leave();

}



tUInt ParkingLotData::checkRotRectangle(const Mat &m, const RotatedRect &r, double threshold) {
    Rect boundingR = r.boundingRect();
    RotatedRect rt = r;

    if(boundingR.x < 0 || boundingR.x+boundingR.width >= m.cols || boundingR.y <0 || boundingR.y + boundingR.height >= m.rows )
        return 10000;
    rt.center -= Point2f(boundingR.x, boundingR.y);


    Point2f vs[4];
    rt.points(vs);
    tUInt sum = 0;
    //if(m_props.debug) cout << "points: " << vs[0] << ", "<< vs[1] << ", " << vs[2] << ", " << vs[3] << endl;
    try {
        Mat check = Mat(m, boundingR);
        Point2f normals[4];
        tFloat32 distances[4];
        for (int i = 0; i < 4; i++) {
            Point2f temp = vs[(i + 1) % 4] - vs[i];
            normals[i].x = -temp.y;
            normals[i].y = temp.x;

            normals[i] /= norm(normals[i]);
            distances[i] = vs[i].dot(normals[i]);
            //if(m_props.debug) cout << "normals [" << i << "]: " << normals[i] << " distance: " << distances[i] << endl;
        }

        for (int row = 0; row < check.rows; row++) {
            tUInt8 *ptr = check.ptr(row);
            for (int col = 0; col < check.cols; col++) {
                Point2f cp(col, row);
                if (cp.dot(normals[0]) > distances[0] && cp.dot(normals[1]) > distances[1] &&
                        cp.dot(normals[2]) > distances[2] && cp.dot(normals[3]) > distances[3]) {
                    if (ptr[col] < threshold)sum++;
                }
            }
        }

    } catch (cv::Exception e) {
        cout << "not able to test Rectangle." << e.what() << endl;
        cout << "size of mat: " << m.size() << endl;
        cout << "size of bounding rectangle: " << boundingR << endl;
        cout << "position of center: " << rt.center << endl;
        sum = 10000;
    }
    return sum;
}

void ParkingLotData::Local2Global(Point2d in, tOdometryData const &odo, Point2d &out ) {
    double iny = in.y + CAR_REARAXIS2CAM;
    out.y =  (odo.y + (cos(odo.phi) * iny + sin(odo.phi) * in.x) / 100.0);
    out.x = odo.x + (-sin(odo.phi) * iny + cos(odo.phi) * in.x) / 100.0;

}

void ParkingLotData::Global2Local(Point2d in, tOdometryData const &odo, Point2d &out) {
    out.x = ((in.x - odo.x) * cos(-odo.phi) - (in.y - odo.y) * sin(-odo.phi)) * 100;
    out.y = ((in.x - odo.x) * sin(-odo.phi) + (in.y - odo.y) * cos(-odo.phi)) * 100 - CAR_REARAXIS2CAM;

}

Point2d ParkingLotData::Global2Map(const Point2d &in, const tOdometryData &odo, const Point2d &carInMap)
{
    Point2d local,map;
    Global2Local(in, odo, local);
    Local2Map(local,carInMap,map);
    return map;
}

void ParkingLotData::Local2Map(const Point2d &in, const Point2d &carInMap, Point2d &out)
{
    out = carInMap + Point2d(-in.x,in.y);

}

ParkingLotData::ParkingPoint * ParkingLotData::getNextParkingPoint(tOdometryData const &odo) {
    mux.Enter();
    uint min_i =0;
    double mindist = INFINITY;
    Point2d odoPos(odo.x,odo.y);
    for(uint i =0; i< ParkingPoints.size(); i++) {
       double dist = ParkingPoints[i]->center.dot(dir) - Point2d(odo.x, odo.y).dot(dir);
        //TODO: SOMETIMES PARKING LOTS ARE IGNORED
        double distPoint = distToSign(ParkingPoints[i]->center);
        bool secondTry = (tryCount>0 && oldSignSum > 0 && distPoint >= -distFirstLot && distPoint <=distLastLot);
        bool useLot = secondTry && ParkingPoints[i]->weightR >= 1;
        bool thirdTry = (tryCount>1 && sign.x < 1 && sign.y < 1 && distPoint >= -distFirstLot && distPoint <=distLastLot);
        useLot |= thirdTry && (ParkingPoints[i]->weightL >= 1 || ParkingPoints[i]->weightR >= 1);
    cout << "Check for next Point: dist: " << dist << " tryCount: "<<tryCount  <<  " secondTry: " << secondTry << " weight L: " << ParkingPoints[i]->weightL << " weight R: " << ParkingPoints[i]->weightR << endl;
        if (dist > 0 && dist < mindist && (ParkingPoints[i]->weightL > 3 && ParkingPoints[i]->weightR > 3 ||useLot)) {
            mindist = dist;
            min_i = i;
        }
    }
    //cout << "parking lot number: " << i << endl;
    if(mindist > 2 ){
        mux.Leave();
        return NULL;
    }
    ParkingPoints[min_i]->used = true;
    mux.Leave();
    return ParkingPoints[min_i];

}

double ParkingLotData::getOccupied(ParkingPoint * p) {
    double d;
    mux.Enter();
    d = p->occupied;
    mux.Leave();
    return d;
}

const Point2d &ParkingLotData::getDir()
{
    return dir;

}

void ParkingLotData::getPathToParkingLot(const tOdometryData &odo, ParkingLotData::ParkingPoint *parkingLot, double &startx, double &starty, double &startphi, double &dist)
{

    Point2d dirO(dir.y,-dir.x); // points to the left

    //double t = center.dot(dirO) - driveByDist;

    Point2d car(odo.x,odo.y);
    dist = dir.dot(parkingLot->center-car);

    Point2d car_t = -dist*dir + parkingLot->center - dirO * (driveByDist+width/2);

    startphi = atan2(-dir.x,dir.y);

    dist += minlength/2;
    dist += offsetGoToLot;
    startx = car_t.x;
    starty = car_t.y;
    parkingLot->used = true;

}



void ParkingLotData::reset(bool keepSign) {
    mux.Enter();
    dir = Point2d(0,0);
    lanePoint = Point2d(0,0);
    for(int i=0;i<ParkingPoints.size(); i++){
        delete ParkingPoints[i];
    }
    ParkingPoints.clear();
    if(!keepSign){
        oldSigns = Point2d(0,0);
        oldSignSum =0;
        sign = Point2d(0,0);
        tryCount = 0;
    }else{
        tryCount++;
    }

    readProperties();

    mux.Leave();
}

void ParkingLotData::init(string filename, parkType pt)
{
    this->filename = filename;

    this->myParkType= pt;

    readProperties();

}

void ParkingLotData::readProperties() {
    FileStorage fs(filename, FileStorage::READ);
    string NodeName;
    if(myParkType == PARKTYPE_CROSS){
       NodeName = "parking_lot_cross";
    }else
        NodeName = "parking_lot_parallel";

    FileNode Lot = fs[NodeName];
    width = Lot["width"];
    minlength = Lot["minLength"];
    maxlength = Lot["maxLength"];
    driveByDist = Lot["driveByDist"];
    minPointDist = Lot["minPointDist"];
    widthTestDriveBy = Lot["widthTestDriveBy"];
    lengthTestDriveBy = Lot["lengthTestDriveBy"];
    thresholdDriveBy = Lot["thresholdDriveBy"];
    widthTest2 = Lot["widthTest2"];
    lengthTest2 = Lot["lengthTest2"];
    thresholdTest2 = Lot["thresholdTest2"];
    offsetGoToLot = Lot["offsetGoToLot"];
    offsetTest2 =Lot["offsetTest2"];
    maxSum = Lot["maxSum"];
    distLastLot = Lot["distSignLastLot"];
    distFirstLot = Lot["distSignFirstLot"];

    cout << "parkingLot: " << NodeName << " width: " << width << " length: " << minlength << " - " << maxlength << " driveByDist: " <<
    driveByDist << endl;
    fs.release();
}

void ParkingLotData::insertPoints(vector<Point2d> points, Point2d dir, vector<ParkingPoint> D_ParkingPoints, Point2d sign,
                                  Point2d lanePoint)
{
    mux.Enter();

    bool PointUsed = false;
    for(int i = 0; i< ParkingPoints.size(); i++){
        if(ParkingPoints[i]->used){
            PointUsed = true;
            break;
        }
    }
    if(!PointUsed && dir.x <=1  && dir.y <= 1) {
        this->dir = dir;
    }
    if(sign.x != 0 && sign.y != 0) {
        this->oldSigns += sign;
        oldSignSum++;
        this->sign = oldSigns / oldSignSum;
    }
    Point2d orth(dir.y,-dir.x);
    this->lanePoint = lanePoint;

    /*
    for(int i = 0;i < ParkingPoints.size(); i++){

         if(!(ParkingPoints[i]->used)){
            ParkingPoints[i]-> weightL = fmax(0, ParkingPoints[i]->weightL-0.25);
            ParkingPoints[i]->weightR  = fmax(0, ParkingPoints[i]->weightR- 0.25);
          }

    }
    */
    for(int i = 0; i < points.size(); i++)
    {
        for(int j = 0; j < 2; j++){
            ParkingPoint* p = new ParkingPoint;
            p->center = points[i]+ ((j==0)?1:-1)*dir*minlength*0.5+ orth* width * 0.5;
            p->occupied = 0;
            p->used = false;
            p->weightL = (j==0)?1:0;
            p->weightR = (j==0)?0:1;
            ParkingPoints.push_back(p);
        }
    }
    compParkPoint pcomp(dir);
    sort(ParkingPoints.begin(),ParkingPoints.end(),pcomp);

    for (int i = 0; i < ParkingPoints.size(); i++) {
        D_ParkingPoints.push_back(*ParkingPoints[i]);
    }



    if(ParkingPoints.size() > 2)

    ParkingMerge(ParkingPoints);



    mux.Leave();
}

void ParkingLotData::ParkingMerge(vector<ParkingPoint *> &pts){
    ParkingPoint* last = pts.front();
    vector<ParkingPoint *> ptn;
    for(int i = 1;  i< pts.size(); i++){

        double dist = norm(last->center-pts[i]->center);
        double wpt =fmin(pts[i]->weightL,pts[i]->weightR);
        double wl = fmin(last->weightL, last->weightR);
        double wges = fmin(pts[i]->weightL+last->weightL, pts[i]->weightR+ last->weightR);
        double wges1 = pts[i]->weightL + pts[i]->weightR + last->weightL + last->weightR;
        double wpt1 = pts[i]->weightL + pts[i]->weightR;
        double wl1 = last->weightL + last->weightR;
        double adddistLast = (maxlength-minlength)*last->weightR/wl1*0.5;
        double adddistPt = (maxlength-minlength)*pts[i]->weightL/wpt1*0.5;
        double improvedDist = dist - adddistLast - adddistPt;
        //cout << "dist: " << dist << " wl: " << last->weightL << " wr: " << last->weightR << " adddistLast: " << adddistLast << " wnl:" << pts[i]->weightL << " wnr: " << pts[i]->weightR<< " adddistPt: " << adddistPt << " improved dist: " << improvedDist << endl;
        if(improvedDist <= minPointDist ){
            if(!last->used){
                if(wges >0){
                pts[i]->center = last->center* wl1/wges1 + pts[i]->center * wpt1/wges1;
                pts[i]->occupied = (wpt>wl)?pts[i]->occupied:last->occupied;
                pts[i]->weightL = fmin(pts[i]->weightL + last->weightL,maxSum);
                pts[i]->weightR = fmin(pts[i]->weightR + last->weightR,maxSum);
                }

                delete last;
                last = pts[i];
            }
            else if(!pts[i]->used){
                if(wges > 0){
                last->center = last->center* wl1/wges1 + pts[i]->center * wpt1/wges1;
                last->occupied = (wpt > wl)?pts[i]->occupied:last->occupied;
                last->weightL = fmin(pts[i]->weightL + last->weightR,100);
                last->weightR = fmin(pts[i]->weightR + last->weightR,100);
                }
                delete pts[i];

            } else{
                ptn.push_back(last);
                last = pts[i];
            }
        } else if( dist < (minlength- minPointDist)){
            if(wl > wpt){
                delete pts[i];
            }else{
                delete last;
                last = pts[i];
            }
        }else{
            if(last->weightL>=1 || last->weightR >=1)
                ptn.push_back(last);
            else
                delete last;
            last = pts[i];
        }
    }
    if(last->weightL>=1 || last->weightR >=1)
        ptn.push_back(last);
    else
        delete last;

   /* for(int i = 0; i < ptn.size(); i++){
        cout << *(ptn[i]) << endl;
    }
    */
    pts = ptn;
}

void ParkingLotData::drawParkingLots(GCLPainter &p, tOdometryData const &odo, Point2d const &carInMap) {
    mux.Enter();
    //cout << "size of ParkingPoints: " << ParkingPoints.size() << endl;
    for( uint i =0; i< ParkingPoints.size(); i++) {

        if(ParkingPoints[i]->weightR==0 || ParkingPoints[i]->weightL==0)
            continue;
        cColor col(0,0,255);
        if(ParkingPoints[i]->weightL > 3)
            col.nGreen = 128;
        if(ParkingPoints[i]->weightR > 3)
            col.nRed = 128;
        p.setColor(col);


        double dist_Horiz = dir.dot(ParkingPoints[i]->center-Point2d(odo.x,odo.y));
        Point2d dirO=Point2d(-dir.y,dir.x);
        double dist_Vert = dirO.dot(ParkingPoints[i]->center-Point2d(odo.x,odo.y));
        dist_Vert += (width+CAR_WIDTH/100)/2 ;
        dist_Horiz += minlength/2;
        stringstream ss;
        ss << setprecision(3) << "v: " << dist_Vert << " h: " << dist_Horiz;

        double rrangle = 180 / M_PI * (-atan2(dir.y, dir.x) + odo.phi);
        RotatedRect rrl(ParkingLotData::Global2Map(ParkingPoints[i]->center, odo, carInMap), Size2f(100 * minlength, width * 100), rrangle);
        p.writeText(ss.str(), rrl.center.x, rrl.center.y);
        p.drawRotRectangle(rrl);
        cColor color;
        if(ParkingPoints[i]->occupied > 10){
            color = cColor(255,0,0);
        }else{
            color = cColor(0,255,0);
        }
        p.setColor(color);
        Point2d newCenter = ParkingPoints[i]->center + (width-widthTestDriveBy)/2 * Point2d(-dir.y,dir.x);
        RotatedRect rrl2(Global2Map(newCenter, odo, carInMap), Size2f(100 *lengthTestDriveBy, widthTestDriveBy * 100), rrangle);
        p.drawRotRectangle(rrl2);
    }
    mux.Leave();
}

void ParkingLotData::removeLot(ParkingLotData::ParkingPoint *pPoint) {

    mux.Enter();
    for(int i = 0; i<ParkingPoints.size(); i++){
        if(ParkingPoints[i] == pPoint){
            ParkingPoints.erase(ParkingPoints.begin()+i);
            delete pPoint;
            break;
        }
    }
    mux.Leave();
}

Point2d const &ParkingLotData::getSign() {
    return sign;
}

Point2d ParkingLotData::getLanePoint() {
    return lanePoint;

}

double ParkingLotData::distToSign(Point2d odoPos){
    if(oldSignSum == 0)
        return 0;
    return (odoPos - getSign()).dot(dir);
}

bool ParkingLotData::signPassed(Point2d odoPos) {
    if(oldSignSum == 0)
    return false;
    //cout << "signdist: " << distToSign(odoPos) << " distLastLot: " << distLastLot << " dir: " << dir << endl;
    return distToSign(odoPos) > distLastLot;
}


void ParkingLotData::getPathToRestart(ParkingTrajectoryDriver &driver, const tOdometryData &data) {

    Point2d odoPos(data.x,data.y);
    double dist = dir.dot(odoPos-sign) + 2;
    Point2d orth(-dir.y,dir.x);
    double distLaneToCar = (odoPos - lanePoint).dot(orth);
    Point2d pos = odoPos + (driveByDist - distLaneToCar + 0.1)*orth;
    double phi = atan2(-dir.x,dir.y);
    cout << "phi: " << phi << " dir: " << dir << " driveBy Dist: " << driveByDist << " orth: " << orth << endl;
    cout << "Path to restart: length:" << dist << " StartPos: " << pos << " odometry pos: " << odoPos << " distance Lane, car: " << distLaneToCar << endl;    driver.setPosition(pos.x, pos.y,0,phi,driver.getPos().time);
    driver.setPosition(pos.x,pos.y,0,phi,driver.getPos().time);
    driver.pushCommand(new GoStraight(driver,-0.5,dist,0,0.5));



}

void ParkingLotData::PassSign(ParkingTrajectoryDriver &driver, const tOdometryData &data) {
    cout << "pass sign!" << endl;
    Point2d odoPos(data.x,data.y);
    double dist = (sign -odoPos).dot(dir) + distLastLot + 0.3;
    Point2d orth(-dir.y,dir.x);
    double distLaneToCar = (odoPos - lanePoint).dot(orth);
    Point2d pos = odoPos + (driveByDist - distLaneToCar)*orth;
    double phi = atan2(-dir.x,dir.y);
     cout << "phi: " << phi << " dir: " << dir << " driveBy Dist: " << driveByDist << " orth: " << orth << endl;
    cout << "Path: length:" << dist << " StartPos: " << pos << " odometry pos: " << odoPos << " distance Lane, car: " << distLaneToCar << endl;    driver.setPosition(pos.x, pos.y,0,phi,driver.getPos().time);

    driver.setPosition(pos.x, pos.y,0,phi,driver.getPos().time);
    driver.pushCommand(new GoStraight(driver,0.5,1));
}
