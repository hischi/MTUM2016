/**
Copyright (c)
Audi Autonomous Driving Cup. Team MomenTUM. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
3.  All advertising materials mentioning features or use of this software must display the following acknowledgement: "This product includes software developed by the Audi AG and its contributors for Audi Autonomous Driving Cup."
4.  Neither the name of Audi nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY AUDI AG AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL AUDI AG OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


**********************************************************************
* $Author:: MomenTUM#$  $Date:: 2015-10-10 15:10:07#$ $Rev:: 35043   $
**********************************************************************/

#include "stdafx.h"
#include "mtum_parking_core.h"
#include <iostream>
#include "car_geometry.h"
#include "GCLPainter.h"
#include "StatusMessage.h"

inline std::ostream &operator<<(std::ostream &os, cParkingCore::state const &m) {
    string s;
    switch(m){
        case cParkingCore::PARK_IDLE:
            s = "idle";
            break;
        case cParkingCore::PARK_FIND_FIRST:
            s= "find first lot";
            break;
        case cParkingCore::PARK_FIND:
            s ="find parking lot";
            break;
        case cParkingCore::PARK_PARKING:
            s = "doing a park maneuver";
            break;
        case cParkingCore::PARK_CHECK:
            s = "check if Lot is free";
            break;
        case cParkingCore::PARK_CROSS_DOUBLECHECK:
            s = "second check if Lot is free";
            break;
        case cParkingCore::PARK_PARALLEL_DOUBLECHECK:
            s = "second check if Lot is free";
            break;
        case cParkingCore::PARK_CROSS:
            s = "in cross parking lot";
            break;
        case cParkingCore::PARK_PARALLEL:
            s = "in parallel parking lot";
            break;
        case cParkingCore::PARK_CROSS_PULL_OUT_LEFT:
        case cParkingCore::PARK_CROSS_PULL_OUT_RIGHT:
            s = "pull out from cross parking lot";
        break;
        case cParkingCore::PARK_PARALLEL_PULL_OUT_RIGHT:
            s= "pull out from parallel parking lot";
            break;
        case cParkingCore::PARK_PULL_OUT_DONE:
            s = "done with pull out";
            break;
        default:
            s="unknown";
    }

    return os << "Parking maneuver: " << s;
}

cParkingCore::cParkingCore(iParkingInterface *parent): driver(25000, 0, 0)
{
    m_pFilterReference = parent;
    m_Odometry.acc =0;
    m_Odometry.vel =0;
    m_Odometry.x =0;
    m_Odometry.dPhi =0;
    m_Odometry.phi =0;
    m_Odometry.y =0;
    parkState = PARK_IDLE;
    driver.setPosition(0,0,0,0,0);
    carPos = Point2d(m_props.dist_right,m_props.dist_rear);
    //parkingLotData_Cross.init(m_props.cross_width, m_props.cross_length,  PARKTYPE_CROSS);
    //parkingLotData_Parallel.init(m_props.parallel_width, m_props.parallel_length, PARKTYPE_LONG);
    parkingLotData = &parkingLotData_Parallel;
    endPos = Point2d(0,0);
    driver.speed = m_props.velocity;
    driver.acc = m_props.acceleration;


    //driver.speed = 0.2;
    //driver.pushCommand(new WaitTime(driver,5));
    //driver.pushCommand(new WaitAndExecute(driver,1,[this]()->void {testFileStream();}));
    //cout << "Hallo Welt hier bin ich!" << endl;
    //driver.readCommands("light_test");
    // driver.goStraight(4);
    //driver.speed=m_props.velocity;
    /*driver.goCurv(45,-1,1);
   driver.goStraight(-3);
   driver.goStraight(3);
   driver.goCurv(45,1,1);
   driver.Wait(2);
   driver.pushCommand(new GoToPoint(driver,5,5,0,1));
    */

}


cParkingCore::~cParkingCore()
{
}

tResult cParkingCore::ProcessData()
{
    RETURN_NOERROR;
}

tResult cParkingCore::UpdateMap(Mat &obstacleMap)
{
    m_ObstacleMapMutex.Enter();
    //m_ObstacleMap = obstacleMap;
    tOdometryData odo;
    m_OdometryMutex.Enter();
    odo = m_Odometry;
    m_OdometryMutex.Leave();
#ifdef DEBUG
    GCLPainter painter;
    if(!active)
        painter.setColor(cColor(255,0,0));
    stringstream ss;
    ss << getState() << "; " << ((active)?"active":"inactive");
    painter.writeText(ss.str(),10,30);
    painter.setPos(odo);
    painter.setCarInMap(carPos);
   // painter.setColor(cColor(0,0,255));
    for(int i= 0; i< D_globalPoints.size(); i++){
        painter.setColor(cColor(i,0,255-i));
        painter.drawPoint(D_globalPoints[i]);
    }
    Point2d od(odo.x,odo.y);
    painter.drawLineGlobal(od,od+D_dir);
    for(int i =0; i< D_parkingLotPoints.size();i++){
        cColor col(0,255-D_parkingLotPoints[i].weightL, 255-D_parkingLotPoints[i].weightR);
        if(D_parkingLotPoints[i].weightL < 3){
            col = cColor(255,0,0);
        }if(D_parkingLotPoints[i].weightR < 3){
            col = cColor(0,255,0);
        }
        painter.setColor(col);
        painter.drawPoint(D_parkingLotPoints[i].center);

    }
    painter.setColor(cColor(255,0,0));
    Point2d s = parkingLotData->getSign();
    Point2d norm(-D_dir.y,D_dir.x);
    painter.drawLineGlobal(s+0.4*norm,s-0.4*norm);

    drawCar(painter);

#endif

    if(parkingLotData != nullptr)
#ifdef DEBUG
   parkingLotData->checkFree(odo, carPos, obstacleMap, &painter);
#else
    parkingLotData->checkFree(odo, carPos, obstacelMap, NULL);
#endif


    m_ObstacleMapMutex.Leave();
#ifdef DEBUG
    m_pFilterReference->DrawGCL(painter.getData());
#endif
}

void cParkingCore::sendManeuverDone()
{
    m_pFilterReference->SendStatusMessage(CAR_CONTROL, MANEUVER_DONE);
}

tResult cParkingCore::SetProperties(cParkingCore::props p, string s)
{
    m_props = p;
    carPos = Point2d(m_props.dist_right,m_props.dist_rear);
    driver.setCommandFile(s);
    parkingLotData_Cross.init(s,PARKTYPE_CROSS);
    parkingLotData_Parallel.init(s,PARKTYPE_LONG);
}

tResult cParkingCore::UpdateOdometry(const tOdometryData *pData)
{
    m_OdometryMutex.Enter();
    m_Odometry = *pData;
    controlParking(m_Odometry);
    m_OdometryMutex.Leave();
    tReferencePoints pts;
    if(referencePointCounter++ > 20) {
        driver.produceReferencePoints(25, pts, m_pFilterReference->getTime());
        m_pFilterReference->SendTrajectory(pts);
        referencePointCounter =0;
    }

}

void cParkingCore::setState(cParkingCore::state s)
{
    state_mux.Enter();
    parkState = s;
    state_mux.Leave();



}

cParkingCore::state cParkingCore::getState()
{
    state s;
    state_mux.Enter();
    s= parkState;
    state_mux.Leave();
    return s;
}

tResult cParkingCore::UpdateParking(const tParkingStruct *pData) {
    int state = getState();
    if (state == PARK_CHECK || state == PARK_FIND || state == PARK_FIND_FIRST || state == PARK_PULL_BACK) {

        m_OdometryMutex.Enter();
        tOdometryData currentOdometry = m_Odometry;
        m_OdometryMutex.Leave();



        vector <Point2d> globalPoints;
        for (int i = 0; i < pData->count; i++) {
            Point2d p = Point2d(pData->ys[i], pData->xs[i] + CAR_REARAXIS2CAM);

            Point2d globalP;
            ParkingLotData::Local2Global(p, currentOdometry, globalP);
            globalPoints.push_back(globalP);
            D_globalPoints.push_back(globalP);
            if(D_globalPoints.size()>100)D_globalPoints.pop_front();

        }




            double phiLane = atan2(pData->dirx, pData->diry);
           // cout << "x: " << pData->dirx << "y:" << pData->diry << " phi: " << phiLane << endl;
            phiLane -= currentOdometry.phi;
            Point2d dir(sin(phiLane), cos(phiLane));
            Point2d carDir(-sin(currentOdometry.phi), cos(currentOdometry.phi));

            if (dir.dot(carDir) < 0)
                dir *= -1;
            Point2d sign(0,0);
            if(pData->signFound){
                Point2d l_sign(pData->signX,pData->signY);
                ParkingLotData::Local2Global(l_sign,currentOdometry,sign);

            }


            D_dir = dir;
            D_parkingLotPoints.clear();
            Point2d lanePoint;
            ParkingLotData::Local2Global(Point2d(pData->lanePtX,pData->lanePtY),currentOdometry,lanePoint);
        parkingLotData->insertPoints(globalPoints, dir, D_parkingLotPoints,
                                     sign, lanePoint);







    }
    RETURN_NOERROR;
}

void cParkingCore::drawCar(GCLPainter &painter) const {// draw Car
    cColor c(0, 0, 255);
    painter.setColor(c);


    Rect r(m_props.dist_right - CAR_WIDTH / 2, m_props.dist_rear - CAR_REARAXIS2REAR, CAR_WIDTH, CAR_LENGTH);

    painter.drawRectangle(r);
}


void cParkingCore::controlParking(tOdometryData const &odo) {
    if(parkingLotData == nullptr || !active)
        return;
    //cout << "control Parking: state: " << getState() << endl;
    Point2d odoPoint(odo.x,odo.y);
    Point2d odoDir(-sin(odo.phi),cos(odo.phi));

    switch (getState()) {
        case PARK_FIND:
        case PARK_FIND_FIRST:
            parkingLot = parkingLotData->getNextParkingPoint(odo);
            if (parkingLot != nullptr) {
                double startx, starty, startphi, dist;
                parkingLotData->getPathToParkingLot(odo, parkingLot, startx, starty, startphi, dist);
                stringstream ss;
                ss << " path to parking lot: STARTX: " << startx << " STARTY: " << starty << " startphi: " <<
                startphi << " dist: " << dist << endl;

                driver.setPosition(startx, starty, 0, startphi, m_pFilterReference->getTime());

                endPos = Point2d(startx, starty) + parkingLotData->getDir() * dist;


                ss << "Parking: endPos: " << endPos;
                LOG_INFO(ss.str().c_str());
                driver.clearCommands();
                driver.pushCommand(new GoStraight(driver, m_props.velocity, dist + 0.3, 0, m_props.acceleration));
                driver.pushCommand(new Stop(driver));
                driver.pushCommand(new WaitTime(driver, 1));
                driver.pushCommand(new GoStraight(driver, -m_props.velocity, dist, 0, m_props.acceleration));
                driver.pushCommand(new Stop(driver));
                driver.pushCommand(new WaitAndExecute(driver, 1, [this]() -> void {parkingLotData->removeLot(parkingLot); setState(PARK_FIND); }));

                m_pFilterReference->SendStatusMessage(CAR_CONTROL, PARKING_LOTS_FOUND);
                setState(PARK_CHECK);
            } else if(parkingLotData->signPassed(odoPoint)){
                cout << "Parking: sign passed! go back!" << endl;
                parkingLotData->getPathToRestart(driver,odo);
                waitDriverThenSetState(FIND_FROM_START);

            } else if (getState() == PARK_FIND ) {
                driver.clearCommands();
                Point2d driverPos(driver.getPos().x, driver.getPos().y);
                Point2d dir =parkingLotData->getDir();
                cout << "search for parking lot: signPos: " << parkingLotData->getSign();
                if(parkingLotData->getSign().x != 0 || parkingLotData->getSign().y != 0){
                    cout << "Parking Search 1m in front." << endl;
                    parkingLotData->PassSign(driver,odo);
                    driver.WaitExecute(0.1,[this]()->void{setState(PARK_FIND);});
                    setState(PARK_FIND_FIRST);
                    break;
                }
                if(!(dir.x <= 1 && dir.y <= 1 )){
                   float angle = odo.phi;
                   dir = Point2d(-sin(angle),cos(angle));
                    dir = dir/norm(dir);
                    cout << "use odometry for direction!!!" << endl;
                }
                Point2d orth(-dir.y,dir.x);
                double distLaneCar = (driverPos - parkingLotData->getLanePoint()).ddot(orth);
                cout << "distance lane car:" << distLaneCar << endl;
                Point2d newpos2 = driverPos - dir * 3 + orth * (distLaneCar - 0.2);

                Point2d newpos = driverPos + orth * (distLaneCar - 0.2);
                cout << "driverPos: " << driverPos << " newpos: " << newpos << " newpos2: " << newpos2 << endl;
                cout << "driver dir: " << dir << endl;
                setState(PARK_FIND_FIRST);

                float myangle = atan2(-dir.x,dir.y);
                driver.setPosition(driverPos.x, driverPos.y, 0, myangle, driver.getPos().time);
                if(parkingLotData == &parkingLotData_Parallel) {
                    driver.readCommands("search_next_lot_parallel");
                }else{
                    driver.readCommands("search_next_lot_cross");
                }
                driver.pushCommand(new SetPos(driver,newpos.x,newpos.y,myangle));
                //driver.setPosition(newpos.x,newpos.y,0, atan2(-dir.x,dir.y),driver.getPos().time);
                driver.pushCommand(new WaitAndExecute(driver,0,[this]()->void{setState(PARK_PARKING);}));
                double distGoBack = 3;
                Point2d sign = parkingLotData->getSign();
                if(sign.x != 0 || sign.y != 0 ){
                   double distCarToSign = dir.ddot(sign - driverPos);
                    double distStartBeforeSign = 2;
                    distGoBack = distStartBeforeSign -distCarToSign;
                    cout << "Parking: go back for " << distGoBack << "m. distCarToSign: "<< distCarToSign << endl;
                }
                driver.pushCommand(new GoStraight(driver, -driver.speed, distGoBack, 0, driver.acc));
                driver.pushCommand(new Stop(driver));
                driver.WaitExecute(0,[this]()->void{setState(PARK_FIND_FIRST);parkingLotData->reset(true);});
                driver.pushCommand(new SetPos(driver,newpos2.x,newpos2.y,myangle));
                driver.pushCommand(new GoStraight(driver, driver.speed * 0.5, distGoBack, 0, driver.acc));
                driver.WaitExecute(0,[this]()->void{setState(PARK_FIND);});




            }
            break;
        case FIND_FROM_START:

            parkingLotData->reset(true);

            parkingLotData->PassSign(driver, odo);
            driver.WaitExecute(0.1,[this]()->void{setState(PARK_FIND);});
            setState(PARK_FIND_FIRST);

            break;
        case PARK_CHECK:
            /*if(parkingLotData->getNextParkingPoint(odo) != parkingLot){
                LOG_INFO("Found parking point less distant");
                double startx, starty, startphi, dist;
                parkingLotData->getPathToParkingLot(odo, parkingLot, startx, starty, startphi, dist);

                driver.clearCommands();
                driver.pushCommand(new GoStraight(driver, m_props.velocity, dist + 0.3, 0, m_props.acceleration));
                driver.pushCommand(new Stop(driver));
                driver.pushCommand(new WaitTime(driver, 10));
                driver.pushCommand(new GoStraight(driver, -m_props.velocity, dist, 0, m_props.acceleration));
                driver.pushCommand(new Stop(driver));
                driver.pushCommand(new WaitAndExecute(driver, 10, [this]() -> void {parkingLotData->removeLot(parkingLot); setState(PARK_FIND); }));

            }*/
            if (parkingLotData->getDir().dot(endPos - Point2d(odo.x, odo.y)) < 0) {
                driver.clearCommands();
                LOG_INFO(cString::Format("Parking: state: Check: %s",
                                         (parkingLotData->getOccupied(parkingLot)>10)?"occupied":"free"));
                //driver.pushCommand(new Stop(driver));
                //driver.pushCommand(new WaitTime(driver,5));
                //setState(PARK_IDLE);
                //break;
                if (parkingLotData->getOccupied(parkingLot) > 10) {
                     setState(PARK_FIND);
                } else {
                    if (parkingLotData == &parkingLotData_Cross) {

                        LOG_INFO("Cross Parking: start Parking");
                        driver.readCommands("park_cross_1");
                        waitDriverThenSetState(PARK_CROSS_DOUBLECHECK);


                    } else {

                        LOG_INFO("Parallel Parking: start Parking");
                        driver.readCommands("park_parallel_1");
                        waitDriverThenSetState(PARK_PARALLEL_DOUBLECHECK);

                    }
                }
            }
            break;
        case PARK_PARKING:
            break;

        case PARK_CROSS_DOUBLECHECK:
            if(parkingLot == nullptr){
                LOG_INFO("Could not finish parking. go back now!");
                driver.readCommands("park_cross_1_reverse");
                waitDriverThenSetState(PARK_FIND);
           } /* else if ( parkingLot->occupied2 > 10) {
                LOG_INFO("Checked again: parking lot is occupied!");
                parkingLotData->removeLot(parkingLot);
                parkingLot = NULL;
                driver.readCommands("park_cross_1_reverse");
                waitDriverThenSetState(PARK_FIND);
            } */
                else {
                LOG_INFO("PARKING: Parking Lot is still free!!");
                driver.readCommands("park_cross_2");
                waitDriverThenSetState(PARK_CROSS);
            }
            break;

        case PARK_PARALLEL_DOUBLECHECK:
        {
            Point2f odoPos(odo.x, odo.y);
            Point2f driverPos(driver.currentPos.x, driver.currentPos.y);
            Point2f driverDir(-sin(driver.currentPos.phi),cos(driver.currentPos.phi));
            double dist = driverDir.dot(odoPos-driverPos);
            if( dist > 0.10){
                parkingLotData->removeLot(parkingLot);
                LOG_INFO(cString::Format("Could not park. Probably, there is an Obstacle: dist: %f",dist));
                driver.readCommands("park_parallel_1_reverse");
                waitDriverThenSetState(PARK_FIND);
            }else{
                driver.readCommands("park_parallel_2");
                waitDriverThenSetState(PARK_PARALLEL);
            }
            break;
        }
        case PARK_CROSS: {

            Point2f odoPos(odo.x, odo.y);
            Point2f driverPos(driver.currentPos.x, driver.currentPos.y);
            Point2f driverDir(-sin(driver.currentPos.phi),cos(driver.currentPos.phi));
            double dist = driverDir.dot(odoPos-driverPos);
            cout << "Parking: dist: " << dist <<endl;
            if (dist < -0.10) {
                parkingLotData->removeLot(parkingLot);
                parkingLot = NULL;
                driver.readCommands("park_cross_2_reverse");
                waitDriverThenSetState(PARK_CROSS_DOUBLECHECK);

            } else {
                setState(PARK_PARKING_CROSS);
                driver.pushCommand(new SetIndicator(driver,SetIndicator::INDICATE_HAZZARD));
                parktime = m_pFilterReference->getTime();
                m_pFilterReference->SendStatusMessage(LOW_LEVEL_CONTROL,LL_EMERGENCY_STOP);
                //driver.readCommands("parked");
                //driver.WaitExecute(0.5, [this]() -> void {


            }
        }
            break;
        case PARK_PARALLEL:
            LOG_INFO("Parallel parking done");
            setState(PARK_PARKING_PARALLEL);
            driver.pushCommand(new SetIndicator(driver,SetIndicator::INDICATE_HAZZARD));
            parktime = m_pFilterReference->getTime();
            m_pFilterReference->SendStatusMessage(LOW_LEVEL_CONTROL,LL_EMERGENCY_STOP);
            //driver.readCommands("parked");
            //driver.WaitExecute(0.5, [this]() -> void { setState(PARK_IN_PARALLEL);LOG_INFO("maneuver done");sendManeuverDone(); });
            break;
        case PARK_CROSS_PULL_OUT_LEFT:
            driver.readCommands("pull_out_cross_left");
            waitDriverThenSetState(PARK_PULL_OUT_DONE);
            break;
        case PARK_CROSS_PULL_OUT_RIGHT:
            driver.readCommands("pull_out_cross_right");
            waitDriverThenSetState(PARK_PULL_OUT_DONE);
            break;
        case PARK_PARALLEL_PULL_OUT_RIGHT:
            LOG_INFO("Pull out parallel started");
            driver.readCommands("pull_out_parallel");
            waitDriverThenSetState(PARK_PULL_OUT_DONE);
            break;
        default:
            break;

        case PARK_IDLE:

            break;
        case PARK_PULL_OUT:
            break;
        case PARK_PULL_BACK:
            break;
        case PARK_IN_CROSS:
            break;
        case PARK_IN_PARALLEL:
            break;
        case PARK_PULL_OUT_DONE:
            setState(PARK_IDLE);
            LOG_INFO("PULL OUT Done");
            parkingLotData->reset(false);
            sendManeuverDone();
            break;


        case PARK_WAIT_TYPE:break;
        case PARK_PARKING_PARALLEL:
            if(m_pFilterReference->getTime()-parktime > 4 * 1e6){
                setState(PARK_IN_PARALLEL);

                driver.pushCommand(new SetIndicator(driver,SetIndicator::INDICATE_NONE));
                cout << "parking parallel: waited 3 s" << endl;
                m_pFilterReference->SendStatusMessage(LOW_LEVEL_CONTROL,LL_EMERGENCY_STOP_FREE);

                sendManeuverDone();


            }

            break;
        case PARK_PARKING_CROSS:
            if(m_pFilterReference->getTime()-parktime > 4 * 1e6){
                setState(PARK_IN_CROSS);
                cout << "parking parallel: waited 3 s" << endl;
                driver.pushCommand(new SetIndicator(driver,SetIndicator::INDICATE_NONE));
                m_pFilterReference->SendStatusMessage(LOW_LEVEL_CONTROL,LL_EMERGENCY_STOP_FREE);
                 sendManeuverDone();
            }

            break;

    }
}


tResult cParkingCore::Status_ChangeMode(tInt mode) {

    switch (mode){
    case MANEUVER_PARK_CROSS:
        LOG_INFO("PARKING: find Cross parking lot");

            driver.clearCommands();
        parkingLotData = &parkingLotData_Cross;
        parkingLotData->reset(false);
            setState(PARK_FIND_FIRST);
        break;
    case MANEUVER_PARK_PARALLEL:

           // driver.clearCommands();
        LOG_INFO("PARKING: find parallel parking lot");
        {
        m_OdometryMutex.Enter();
        tOdometryData odo= m_Odometry;
        m_OdometryMutex.Leave();
        driver.setPosition(odo.x,odo.y,0,odo.phi,0);
        }
            driver.clearCommands();
        parkingLotData = &parkingLotData_Parallel;
        parkingLotData->reset(false);
        setState(PARK_FIND_FIRST);

        break;
    case MANEUVER_PULL_OUT_RIGHT:
    {

        LOG_INFO("PARKING: pull out right");
        m_OdometryMutex.Enter();
            tOdometryData odo= m_Odometry;
            m_OdometryMutex.Leave();
        if(getState() == PARK_IN_CROSS ){
            driver.setPosition(odo.x,odo.y,0,odo.phi,0);
            setState(PARK_CROSS_PULL_OUT_RIGHT);
        }else if (getState() == PARK_IN_PARALLEL){
           driver.setPosition(odo.x,odo.y,0,odo.phi,0);
            setState(PARK_PARALLEL_PULL_OUT_RIGHT);
        }else if(getState() == PARK_IDLE){
            cout << "Parking: ask for direction" << endl;

            driver.setPosition(odo.x,odo.y,0,odo.phi,0);
            m_pFilterReference->SendStatusMessage(LANE_DETECTION, PARKING_LOT_TYPE_REQUEST);
            setState(PARK_WAIT_TYPE);

        }}
        break;
        case PARKING_LOT_PARALLEL:
            LOG_INFO("Got Parking lot parallel message");
            if(getState() == PARK_WAIT_TYPE)
                setState(PARK_PARALLEL_PULL_OUT_RIGHT);
            break;
        case PARKING_LOT_CROSS:
            LOG_INFO("Got Parking lot cross message");
            if(getState() == PARK_WAIT_TYPE){
                setState(PARK_CROSS_PULL_OUT_RIGHT);
            }
            break;
    case MANEUVER_PULL_OUT_LEFT:
        LOG_INFO("PARKING: pull out left");
        if(getState() == PARK_IN_CROSS ){
            setState(PARK_CROSS_PULL_OUT_LEFT);
        }else if( getState() == PARK_IDLE){
            m_OdometryMutex.Enter();
            tOdometryData odo= m_Odometry;
            m_OdometryMutex.Leave();
            driver.setPosition(odo.x,odo.y,0,odo.phi,0);
            setState(PARK_CROSS_PULL_OUT_LEFT);
        }
        break;

    default:
        setState(PARK_IDLE);
            D_globalPoints.clear();

        break;
    }
}

tResult cParkingCore::Status_Reset()
{
    parkingLotData->reset(false);
    driver.clearCommands();
    D_globalPoints.clear();
    setState(PARK_IDLE);
}

void cParkingCore::waitDriverThenSetState(cParkingCore::state s) {
    setState(PARK_PARKING);
    driver.WaitExecute(0.4,[this,s]()->void{setState(s);});

}

tResult cParkingCore::Status_SetActive() {
    LOG_INFO("Parking filter: Set active");
    active = true;
    return 0;
}

tResult cParkingCore::Status_SetInactive() {
    LOG_INFO("Parking filter: Set inactive");
    driver.clearCommands();
    active = false;
    return 0;
}
