/**
Copyright (c)
Audi Autonomous Driving Cup. Team MomenTUM. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
3.  All advertising materials mentioning features or use of this software must display the following acknowledgement: "This product includes software developed by the Audi AG and its contributors for Audi Autonomous Driving Cup."
4.  Neither the name of Audi nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY AUDI AG AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL AUDI AG OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


**********************************************************************
* $Author:: MomenTUM#$  $Date:: 2015-10-10 15:10:07#$ $Rev:: 35043   $
**********************************************************************/


#pragma once

#include "stdafx.h"
#include "mtum_parking_trajectory.h"
#include <iostream>
#include <functional>

void operator>>(const FileNode& n, vector<tReferencePoint>& value);


class ParkingCommand{
public:
    ParkingCommand(ParkingTrajectory &pt) : pt(pt) {}
    virtual ~ParkingCommand(){}
    virtual double getAcceleration(tReferencePoint const &p) = 0;
    virtual double getCurvature(tReferencePoint const &p) = 0;
    virtual bool   endCommand() = 0;
    virtual int getIndicator(){return -1;}
    virtual void toFs(FileStorage& fs)const { fs << "{:" << "type" <<  string("invalid").c_str() << "}";}
    virtual void toString(ostream &out) const{ out << "ParkingCommand {}";}
    ParkingTrajectory& pt;
};

class ReplayPoints:public ParkingCommand{
public:
    ReplayPoints(ParkingTrajectory &pt, string path): ParkingCommand(pt), path(path){counter = 0;}
    virtual ~ReplayPoints(){}
    virtual double getAcceleration(tReferencePoint const &p) {return 0;}
    virtual double getCurvature(tReferencePoint const &p) {return 0;}
    virtual tReferencePoint nextRefPoint(tReferencePoint const &p);

    virtual bool endCommand();

private:
    string path;
    vector<tReferencePoint> points;
    tReferencePoint firstP;
    Mat rotation;
    uint counter;
};
class SetPos:public ReplayPoints{
public:
    SetPos(ParkingTrajectory &pt, double x, double y, double phi):ReplayPoints(pt,""),x(x),y(y),phi(phi){ };
    virtual ~SetPos(){}
    tReferencePoint nextRefPoint(tReferencePoint const &p){
        tReferencePoint p1;
        p1.acceleration =0;
        p1.vel =0;
        p1.curvature =0;
        p1.x = x;
        p1.y = y;
        p1.phi = phi;
        p1.lightFlags = p.lightFlags;
        p1.time=p.time;
        return p1;
    }
    bool endCommand(){return true;}
private:
    double x,y,phi;

};
class WaitTime: public ParkingCommand{
public:
    WaitTime(ParkingTrajectory &pt, double seconds):ParkingCommand(pt),seconds(seconds){ time =0;}
    virtual double getAcceleration(tReferencePoint const &p) {return 0;}
    virtual double getCurvature(tReferencePoint const &p) {return 0;}
    virtual bool endCommand(){
        if(time == 0){
            time = pt.currentPos.time;
            cout << "wait time: " << seconds << endl;
        }
        return (pt.currentPos.time-time > seconds * 1e6);
    }
    virtual void toString(ostream &out) const{
        out << " Wait { seconds: " << seconds;
    }
    virtual void toFs(FileStorage& fs)const { fs << "{:" << "type" <<  string("Wait").c_str() << "seconds"<< seconds << "}";}
    double seconds;
    unsigned long time;
};

class SetIndicator: public ParkingCommand{

public:
    enum INDICATOR_SETTING{
        INDICATE_LEFT=1,
        INDICATE_RIGHT=2,
        INDICATE_HAZZARD=4,
        INDICATE_NONE=0
    };

    SetIndicator(ParkingTrajectory &pt, int indicator):ParkingCommand(pt),indicator(indicator){}
    virtual double getAcceleration(tReferencePoint const &p) {return 0;}
    virtual double getCurvature(tReferencePoint const &p) {return 0;}
    virtual int getIndicator(){return indicator;}
    virtual bool endCommand(){
        return true;
    }
    virtual void toString(ostream &out) const{
        out << " Indicator { " << indicator;
    }
    virtual void toFs(FileStorage& fs)const {

        fs << "{:" << "type" <<  string("Indicator").c_str() << "value";

        switch(indicator)
        {
        case INDICATE_LEFT:
            fs << string("Left").c_str();
            break;
        case INDICATE_RIGHT:
            fs << string("Right").c_str();
            break;
        case INDICATE_HAZZARD:
            fs << string("Hazzard").c_str();
            break;
        default:
            fs << string("None").c_str();
        }

        fs << "}";
    }
    int indicator;
};

class WaitAndExecute: public WaitTime{
public:
    function<void(void)> fkt;
    WaitAndExecute(ParkingTrajectory &pt, double seconds, function<void(void)> fkt):WaitTime(pt,seconds){
        this->fkt = fkt;
    }
    virtual bool endCommand(){
        if(WaitTime::endCommand()){
            fkt();
            return true;
        }
        return false;
    }
};

class Stop: public ParkingCommand{
public:
    Stop(ParkingTrajectory &pt):ParkingCommand(pt){}
    virtual double getAcceleration(tReferencePoint const &p) { cout << "Stop: acceleration: " << -pt.currentPos.vel / (pt.cycle_time * 1e-6) << endl; return -pt.currentPos.vel / (pt.cycle_time * 1e-6);}
    virtual double getCurvature(tReferencePoint const &p) {return 0;}
    virtual void toString(ostream &out) const{
        out << " Stop {}";
    }
    virtual void toFs(FileStorage& fs)const { fs << "{:" << "type" <<  string("Stop").c_str() << "}";}
    virtual bool endCommand(){
        cout << "stop" << endl;
        return pt.currentPos.vel<0.001;
    }
};

class GoStraight: public ParkingCommand{
public:
    GoStraight(ParkingTrajectory &t, double speed, double distance, double endSpeed, double acc);
    GoStraight(ParkingTrajectory &t, double distance,double endSpeed);
    GoStraight(ParkingTrajectory &t, double distance);
    GoStraight(ParkingTrajectory *t, double speed, double distance);
    virtual void toFs(FileStorage &fs) const;
    virtual void toString(ostream &out) const;
    virtual ~GoStraight();
    virtual double getAcceleration(tReferencePoint const &p);
    virtual double getCurvature(tReferencePoint const &p) { return 0;}
    virtual bool endCommand();

    double speed, distance, endSpeed, acc;
    double distGone;
    tReferencePoint lastPoint;

};



class GoConstantCurvature: public GoStraight{
public:

    GoConstantCurvature(ParkingTrajectory &t, double speed, double angle, double endSpeed, double acc, double curvature):GoStraight(t,speed,distance,endSpeed,acc), curvature(curvature){
        distance = abs(angle * M_PI / 180 /curvature);

        cout << " goConstant curvature computed distance: "<< distance << endl;
    }
    GoConstantCurvature(ParkingTrajectory &t, double angle,double curvature):GoStraight(t,abs(angle*M_PI  /180/curvature)),curvature(curvature){    }

    GoConstantCurvature(ParkingTrajectory &t, double speed, double angle, double curvature):GoStraight(t,speed,0,0,0.5),curvature(curvature){
        distance = abs(angle * M_PI /180 / curvature);
    }
    void toFs(FileStorage &fs) const
    {
            string type = "GoCurve";
            fs << "{:" << "type" << type.c_str() << "angle" << fabs(distance*curvature)*180/M_PI << "speed" << speed<< "acc"<< acc << "endSpeed" << endSpeed << "curvature" << curvature << "}";

    }

    virtual void toString(ostream &out) const{
        out << "GoCurvature: { dist: " << distance << " speed: " << speed << " acc: "<< acc << " endSpeed: " << endSpeed << " curvature: "<< curvature << " }" ;

    }
    virtual double getCurvature(tReferencePoint const &p) { return curvature;}

    double curvature;
};
class GoToPoint: public GoStraight{
public:
    GoToPoint(ParkingTrajectory &pt, double x, double y, double phi, double curvature);
    virtual double getAcceleration(tReferencePoint const &p);
    virtual double getCurvature(tReferencePoint const &p);
    virtual bool endCommand();
    void setPoints();
    double x, y,phi,curvature;
    double dirs[3];
    double curvs[3];
    double dists[3];
    int state;
};
ostream &operator<<(ostream &out, const ParkingCommand &cmd);
