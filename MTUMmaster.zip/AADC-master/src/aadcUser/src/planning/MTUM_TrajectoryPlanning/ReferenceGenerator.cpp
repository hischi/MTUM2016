//
// Created by clemens on 21.01.16.
//

#include "ReferenceGenerator.h"
#include "PlanningUtils.h"
#include <iostream>
#include <car_geometry.h>
#include "ReferenceCandidate.h"
#include "spline.h"
#include "aadc_roadSign_enums.h"

using namespace std;
using namespace cv;

#define CG_LANE_WIDTH 0.47

// 10cm to support the shift
#define SHIFT_SUPPORT 0.1

// Points to keep behind the car
#define POINTS_BEHIND_CAR .5

ReferenceGenerator::ReferenceGenerator() : activeCrossing(Point2d(0, 0), Point2d(0, 0), -1, false, false, false, 1, 1),  globalMutex() {
    nextManeuver = TurningMode::RIGHT;
    hasActiveCrossing = false;
}

void ReferenceGenerator::SetProperties(tUInt max_lane_points) {
    this->max_lane_points = max_lane_points;
}

void ReferenceGenerator::resetGenerator() {
    globalMutex.Enter();
    // Reset Generator: Insert Odometry
    globalPoints.clear();
    crossings.clear();
    tOdometryData odo = PlanningUtils::get().GetOdoF();
    globalMutex.Leave();

    if (!odo.valid)
        return;

/*
    Point2d directionVector(cos(odo.phi), sin(odo.phi));
    directionVector /= norm(directionVector);

    for(double d = 0; d < .5; d+=0.1) {
        globalPoints.push_back(PPoint(odo.x + d*directionVector.x, odo.y + d*directionVector.y, odo.phi));
    }
*/
    globalPoints.push_back(PPoint(odo.x, odo.y, odo.phi));

    hasActiveCrossing = false;
    m_NoOvertaking = false;
}


vector<PPoint> ReferenceGenerator::GetReference() {

    globalMutex.Enter();
    vector<PPoint> result(globalPoints.size());

    for (int i = 0; i < globalPoints.size(); i++)
        result[i] = globalPoints[i];


    globalMutex.Leave();
    return result;
}



// Returns true, if maneuver was done
bool ReferenceGenerator::ProcessLaneStruct(tLaneStruct laneStruct, bool onlySign) {
    // Init the generator if not ready
    if (!isReady())
        resetGenerator();
    if (!isReady())
        return false;

    globalMutex.Enter();

    bool maneuverDone = false;

    PlanningUtils &utils = PlanningUtils::get();

    Mat debug = PlanningUtils::get().GetDebug();

    tOdometryData odo = utils.GetOdoF();

    bool updatesIgnored = true;
    updatesIgnored = false;
    if(abs(odo.vel) > 0.1 && nextManeuver != UNKNOWN)
        UpdateCrossing(laneStruct, onlySign);
    UpdateLane(laneStruct);


    if (hasActiveCrossing) {
        // Check if we have left the crossing
        PPoint odoPt(odo.x, odo.y, odo.phi);
        if (odoPt.IsInFrontOf(activeCrossing.GetEndPoint(nextManeuver))) {
            hasActiveCrossing = false;
            maneuverDone = (activeCrossing.sign != MARKER_ID_PEDESTRIANCROSSING) && (nextManeuver != UNKNOWN);
            if(maneuverDone && nextManeuver != STRAIGHT )
                m_NoOvertaking = false;
        }
//        // Check, if still active (i.e. has LaneMarkings)
//        if(!activeCrossing.IsOnReference(globalPoints)){
//            hasActiveCrossing = false;
//        }
    }

    // We are not in a maneuver
    if (!hasActiveCrossing) {
        // Find all crossings that is on a reference
        vector<cCrossing *> onReference;
        for (int c = 0; c < crossings.size(); c++) {
            if (crossings[c].IsValid() && crossings[c].IsOnReference(globalPoints)) {
                onReference.push_back(&crossings[c]);
            }
        }

        cCrossing *best = NULL;
        for (int c = 0; c < onReference.size(); c++) {
            if (best == NULL || best->life < onReference[c]->life)
                best = onReference[c];
        }

        if (best != NULL) {
            activeCrossing = *best;
            hasActiveCrossing = true;

            // We have an active crossing, clear all lane markings that are not allowed for it
            deque<PPoint> allowedPoints;
            for (int i = 0; i < globalPoints.size(); i++) {
                if (best->LaneMarkingAllowed(globalPoints[i], nextManeuver)) {
                    allowedPoints.push_back(globalPoints[i]);
                }
            }
            globalPoints = allowedPoints;

            vector<bool> toDelete(crossings.size());
            for (int j = 0; j < crossings.size(); ++j) {
                toDelete[j] = false;

                if (best != &crossings[j]) {

                    if (!crossings[j].GetStartPoint().IsInFrontOf(best->GetEndPoint(nextManeuver)) ||
                        norm(crossings[j].GetStartPoint()() - best->GetStartPoint()()) < 1.8 ||
                            best->GetEndPoint(nextManeuver).GetDir().dot(crossings[j].GetDir()) * 180/M_PI > 45) {
                        toDelete[j] = true;
                    }
                }
                else{
                    toDelete[j] = true;
                }
            }

            for (int j = 0; j < crossings.size(); ++j) {
                if(toDelete[j])
                {
                    crossings.erase(crossings.begin()+j);
                    toDelete.erase(toDelete.begin()+j);
                    j--;
                }
            }
        }
    }


    // DEBUG


    if (!hasActiveCrossing) {
        for (int c = 0; c < crossings.size(); c++) {
            crossings[c].DrawPolygon(debug, nextManeuver);
        }
    } else {
        activeCrossing.DrawPolygon(debug, nextManeuver);
    }


    if (hasActiveCrossing) {
        deque<PPoint> pts;
        activeCrossing.GenerateTurningPoints(nextManeuver, pts);
        for (int i = 0; i < pts.size(); i++) {
            debug.at<Vec3b>(utils.ToDebug(pts[i]())) = Vec3b(255, 255, 0);
        }
    }


    if (updatesIgnored) {
        putText(debug, "Updates Off!", Point(0, 500), CV_FONT_VECTOR0, 1, Scalar(0, 0, 255));
    }

    for (int i = 0; i < globalPoints.size(); i++) {
        if(globalPoints[i].scriptMode == SCRIPT_UNSCRIPTED)
            debug.at<Vec3b>(utils.ToDebug(globalPoints[i]())) = Vec3b(255, 0, 255);
        else
            debug.at<Vec3b>(utils.ToDebug(globalPoints[i]())) = Vec3b(255, 255, 0);
    }
    // END DEBUG

    globalMutex.Leave();
    return maneuverDone;
}

// Moves the lane .5 left .5 right and 1.5 right
void movePoints(vector<PPoint> &lanePoints, vector<vector<PPoint>> &result) {
    for (double toShift = -CG_LANE_WIDTH / 2.0; toShift <= 1.5 * CG_LANE_WIDTH; toShift += CG_LANE_WIDTH) {
        vector<PPoint> shiftedPPoints;
        for (int i = 0; i < lanePoints.size(); i++) {
            PPoint shifted = lanePoints[i];
            Point2d laneNormal(-sin(lanePoints[i].theta), cos(lanePoints[i].theta));
            laneNormal /= norm(laneNormal);

            shifted.x -= toShift * laneNormal.x;
            shifted.y -= toShift * laneNormal.y;

            shiftedPPoints.push_back(shifted);
        }
        result.push_back(shiftedPPoints);
    }
}

// Moves the lane .5 left .5 right and 1.5 right
void movePointsGlobal(vector<PPoint> &lanePoints, vector<vector<PPoint>> &result) {
    for (double toShift = -CG_LANE_WIDTH; toShift <= 2 * CG_LANE_WIDTH; toShift += CG_LANE_WIDTH) {
        vector<PPoint> shiftedPPoints;
        for (int i = 0; i < lanePoints.size(); i++) {
            PPoint shifted = lanePoints[i];
            Point2d laneNormal(-sin(lanePoints[i].theta), cos(lanePoints[i].theta));
            laneNormal /= norm(laneNormal);

            shifted.x -= toShift * laneNormal.x;
            shifted.y -= toShift * laneNormal.y;

            shiftedPPoints.push_back(shifted);
        }
        result.push_back(shiftedPPoints);
    }
}

// Gets supporting points for the shift
int getSupportingPointsForShift(deque<PPoint> &reference, vector<PPoint> &shiftedPoints, double distToSupport) {
    int supporting = 0;
    for (int pt = 0; pt < shiftedPoints.size(); pt++) {
        // Find the nearest point on the reference
        PPoint minPoint;
        Point2d minDirection;
        double minDist = INFINITY;
        for (int i = 0; i < reference.size(); i++) {
            // We ignore points that are completely wrong regarding orientation
            if (abs(shiftedPoints[pt].theta - reference[i].theta) > M_PI / 4)
                continue;

            Point2d direction = shiftedPoints[pt]() - reference[i]();
            double length = norm(direction);

            if (minDist > length) {
                minDirection = direction;
                minPoint = reference[i];
                minDist = length;
            }

            // If the length is smaller than supporting, we are finished already
            if (length <= distToSupport) {
                supporting++;
            }
        }

        if (minDist <= distToSupport) {
            supporting++;
            continue;
        }

        Point2d laneNormal(-sin(shiftedPoints[pt].theta), cos(shiftedPoints[pt].theta));
        laneNormal /= norm(laneNormal);
        double distance = abs(minDirection.dot(laneNormal));

        if (distance <= distToSupport) {
            supporting++;
        }
    }
    return supporting;
}

void ReferenceGenerator::UpdateLaneNoCenter(const tLaneStruct &laneStruct) {

    PlanningUtils &utils = PlanningUtils::get();

    Mat debug = utils.GetDebug();

    deque<PPoint> newGlobals;
    if (hasActiveCrossing) {
        // Remove lane markings that are not allowed and generate new oned
        for (int i = 0; i < globalPoints.size(); i++) {
            if (globalPoints[i].scriptMode == SCRIPT_UNSCRIPTED && activeCrossing.LaneMarkingAllowed(globalPoints[i], nextManeuver)) {
                newGlobals.push_back(globalPoints[i]);
            }
        }
        activeCrossing.GenerateTurningPoints(nextManeuver, newGlobals);
    } else {
        for (int i = 0; i < globalPoints.size(); i++)
            if(globalPoints[i].scriptMode == SCRIPT_UNSCRIPTED)
                newGlobals.push_back(globalPoints[i]);
    }
    globalPoints = newGlobals;


    vector<PPoint> toInsert;

    // Local -> Global and add to the points
    for (int lane = 0; lane < laneStruct.laneCount; lane++) {
        // We want at least one point on the lane.
        if (laneStruct.counts[lane] == 0)
            continue;

        vector<PPoint> lanePoints;
        for (int pt = 0; pt < laneStruct.counts[lane]; pt++) {
            PPoint newPoint;
            utils.Lane2Ferdi(laneStruct.xs[lane][pt], laneStruct.ys[lane][pt], laneStruct.dirs[lane][pt] * M_PI / 180,
                             newPoint.x, newPoint.y, newPoint.theta);
            lanePoints.push_back(newPoint);
        }


        // Shift the points in all possibilities
        vector<vector<PPoint>> allShifts;
        movePoints(lanePoints, allShifts);


        vector<int> qualities(allShifts.size());
        for (int j = 0; j < allShifts.size(); j++) {
            qualities[j] = getSupportingPointsForShift(globalPoints, allShifts[j], SHIFT_SUPPORT);
        }

        int maxQuality = -1;
        int bestShift = 0;

        for (int i = 0; i < allShifts.size(); i++) {
            if (qualities[i] > maxQuality) {
                bestShift = i;
                maxQuality = qualities[i];
            }
        }

        if (maxQuality <= 0)
            continue;

        for (int i = 0; i < allShifts[bestShift].size(); i++) {
            PPoint current = allShifts[bestShift][i];
            if (!hasActiveCrossing || activeCrossing.LaneMarkingAllowed(current, nextManeuver)) {
                toInsert.push_back(current);
            } else {
                debug.at<Vec3b>(utils.ToDebug(current())) = Vec3b(0, 0, 255);
            }
        }


    }

    for (int i = 0; i < toInsert.size(); i++) {
        globalPoints.push_back(toInsert[i]);
    }
}


void ReferenceGenerator::UpdateLaneCenter(const tLaneStruct &laneStruct, int centerLineIdx) {

    PlanningUtils &utils = PlanningUtils::get();
    // We need to do this first, because we don't want to shift crossing points
    vector<PPoint> newGlobals;
    if (hasActiveCrossing) {
        // Remove lane markings that are not allowed and generate new oned
        for (int i = 0; i < globalPoints.size(); i++) {
            if (globalPoints[i].scriptMode == SCRIPT_UNSCRIPTED && activeCrossing.LaneMarkingAllowed(globalPoints[i], nextManeuver)) {
                newGlobals.push_back(globalPoints[i]);
            }
        }
    } else {
        for(int i = 0; i < globalPoints.size(); i++)
            if(globalPoints[i].scriptMode == SCRIPT_UNSCRIPTED)
                newGlobals.push_back(globalPoints[i]);
    }


    // Clear the world, we will add the current reference and turning points later
    globalPoints.clear();

    // Add the center line so that the matching will fit to that
    for (int pt = 0; pt < laneStruct.counts[centerLineIdx]; pt++) {
        PPoint lanePoint;
        utils.Lane2Ferdi(laneStruct.xs[centerLineIdx][pt], laneStruct.ys[centerLineIdx][pt],
                         laneStruct.dirs[centerLineIdx][pt] * M_PI / 180, lanePoint.x, lanePoint.y, lanePoint.theta);

        PPoint shifted = lanePoint;
        Point2d laneNormal(-sin(lanePoint.theta), cos(lanePoint.theta));
        laneNormal /= norm(laneNormal);

        shifted.x -= CG_LANE_WIDTH / 2 * laneNormal.x;
        shifted.y -= CG_LANE_WIDTH / 2 * laneNormal.y;

        globalPoints.push_back(shifted);
    }


    // Shift the globals so that it matches the center line
    vector<vector<PPoint>> allShifts;
    movePointsGlobal(newGlobals, allShifts);
    vector<int> qualities(allShifts.size());
    for (int j = 0; j < allShifts.size(); j++) {
        qualities[j] = getSupportingPointsForShift(globalPoints, allShifts[j], SHIFT_SUPPORT);
    }

    int maxQuality = -1;
    int bestShift = 0;

    for (int i = 0; i < allShifts.size(); i++) {
        if (qualities[i] > maxQuality) {
            bestShift = i;
            maxQuality = qualities[i];
        }
    }

    if (maxQuality > 0) {
        // If there is a 'good' shift, do it. If not we drop the points
        for (int i = 0; i < allShifts[bestShift].size(); i++) {
            PPoint current = allShifts[bestShift][i];
            if (!hasActiveCrossing || activeCrossing.LaneMarkingAllowed(current, nextManeuver)) {
                globalPoints.push_back(current);
            }
        }
    } else {
        cout << "planner: dropping old reference, should not happen" << endl;
    }

    Mat debug = utils.GetDebug();

    vector<PPoint> toInsert;

    // Local -> Global and add to the points
    for (int lane = 0; lane < laneStruct.laneCount; lane++) {
        // We want at least one point on the lane.
        if (laneStruct.counts[lane] == 0 || lane == centerLineIdx)
            continue;

        vector<PPoint> lanePoints;
        for (int pt = 0; pt < laneStruct.counts[lane]; pt++) {
            PPoint newPoint;
            utils.Lane2Ferdi(laneStruct.xs[lane][pt], laneStruct.ys[lane][pt], laneStruct.dirs[lane][pt] * M_PI / 180,
                             newPoint.x, newPoint.y, newPoint.theta);
            lanePoints.push_back(newPoint);
        }


        // Shift the points in all possibilities
        vector<vector<PPoint>> allShifts;
        movePoints(lanePoints, allShifts);


        vector<int> qualities(allShifts.size());
        for (int j = 0; j < allShifts.size(); j++) {
            qualities[j] = getSupportingPointsForShift(globalPoints, allShifts[j], SHIFT_SUPPORT);
        }

        int maxQuality = -1;
        int bestShift = 0;

        for (int i = 0; i < allShifts.size(); i++) {
            if (qualities[i] > maxQuality) {
                bestShift = i;
                maxQuality = qualities[i];
            }
        }

        if (maxQuality <= 0)
            continue;

        for (int i = 0; i < allShifts[bestShift].size(); i++) {
            PPoint current = allShifts[bestShift][i];
            if (!hasActiveCrossing || activeCrossing.LaneMarkingAllowed(current, nextManeuver)) {
                toInsert.push_back(current);
            } else {
                debug.at<Vec3b>(utils.ToDebug(current())) = Vec3b(0, 0, 255);
            }
        }


    }

    for (int i = 0; i < toInsert.size(); i++) {
        globalPoints.push_back(toInsert[i]);
    }

    // Finally add the turning points, we can do this in the end because the matching does not depend on it in this mode
    if (hasActiveCrossing) {
        activeCrossing.GenerateTurningPoints(nextManeuver, globalPoints);
    }
}

void ReferenceGenerator::UpdateLane(const tLaneStruct &laneStruct)  {


    PlanningUtils &utils = PlanningUtils::get();

    int centerLineIdx = -1;
    for (int lane = 0; lane < laneStruct.laneCount; lane++) {
        if (laneStruct.centerLine[lane]) {
            centerLineIdx = lane;
            break;
        }
    }

    if (centerLineIdx >= 0) {
        UpdateLaneCenter(laneStruct, centerLineIdx);
    } else {
        // Handle lane update as before i.e. brute force it
        UpdateLaneNoCenter(laneStruct);
    }

    while (globalPoints.size() > 1500)
        globalPoints.pop_front();
}


void ReferenceGenerator::UpdateCrossing(const tLaneStruct &laneStruct, bool onlySign) {


    if (laneStruct.crossingCount > 0) {
        // Check if there are still crossing in the list which are far away those should be at the front in the deque
        // Therefore we need our odometry
        tOdometryData odo = PlanningUtils::get().GetOdoF();


        for (int k = 0; k < laneStruct.crossingCount; k++) {
            // Is it a good crossing? (quality > 0)
            if (laneStruct.crossingQualityPosition[k] <= 0 && laneStruct.crossingQualityDirection[k] <= 0)
                continue; // no, its not,

            if(laneStruct.signID[k] == MARKER_ID_NOOVERTAKING) {
                cout << "No overtaking sign !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1" << endl;
                m_NoOvertaking = true;
                continue;
            }

            // Transformiere rohdaten in global
            Point2d global_point;
            tFloat global_theta;
            tFloat local_theta = atan2(-laneStruct.crossingDX[k], laneStruct.crossingDY[k]);
            PlanningUtils::get().Lane2Ferdi(laneStruct.crossingX[k], laneStruct.crossingY[k], local_theta,
                                            global_point.x, global_point.y, global_theta);


            Point2d dir(cos(global_theta), sin(global_theta));

            if(onlySign && laneStruct.signID[k] < 0)
                continue;

            // If we are here, there is no similar crossing => just insert a new one
            cCrossing newCrossing(global_point, dir, laneStruct.signID[k], laneStruct.leftOpen[k],
                                  laneStruct.rightOpen[k], laneStruct.frontOpen[k],
                                  laneStruct.crossingQualityPosition[k], laneStruct.crossingQualityDirection[k]);

            if (!hasActiveCrossing) {
                // We have successfully generated a new Crossing and can finally insert it into the list
                crossings.push_back(newCrossing);

                while (mergeCrossings());
            } else {
                if (activeCrossing.IsSimilar(newCrossing)) {
                    activeCrossing.Update(newCrossing);
                }
            }
        }
    }
    deque<cCrossing> aliveCrossings;
    // Decrement invalid crossings
    for (int i = 0; i < crossings.size(); i++) {
        if (crossings[i].IsValid()) {
            aliveCrossings.push_back(crossings[i]);
        } else {
            crossings[i].Hurt();
            if (crossings[i].IsAlive()) {
                aliveCrossings.push_back(crossings[i]);
            }
        }
    }
    crossings = aliveCrossings;
}


// Returns true, if the generator is able to generate reference
bool ReferenceGenerator::isReady() {
    int size;
    globalMutex.Enter();
    size = globalPoints.size();

    globalMutex.Leave();
    return size > 0;
}


void ReferenceGenerator::RemoveOldPoints() {
    deque<PPoint> newGloabalPoints;

    if (!PlanningUtils::get().GetOdoF().valid)
        return;

    tOdometryData odo = PlanningUtils::get().GetOdoF();
    Point2d odoPt(odo.x, odo.y);
    Point2d directionVector(cos(odo.phi), sin(odo.phi));
    directionVector /= norm(directionVector);

    globalMutex.Enter();

    for (int i = 0; i < globalPoints.size(); i++) {
        Point2d pointVector = globalPoints[i]() - odoPt;
        double distance = norm(pointVector);
        pointVector = pointVector / distance;


        if (distance <= POINTS_BEHIND_CAR || abs((acos(directionVector.dot(pointVector)))) * 180 / M_PI < 90) {
            newGloabalPoints.push_back(globalPoints[i]);
        }
    }

    globalPoints = newGloabalPoints;

    globalMutex.Leave();
}

bool ReferenceGenerator::ManeuverStarted() {
    return hasActiveCrossing;
}

cCrossing ReferenceGenerator::GetActiveCrossing() {
    return activeCrossing;
}

bool ReferenceGenerator::mergeCrossings() {
    // Check if there is already a similar crossing
    for (int i = 0; i < crossings.size(); ++i) {
        for (int j = i + 1; j < crossings.size(); ++j) {
            if (crossings[i].IsSimilar(crossings[j])) {
                // We have found a similar crossing, we try to update the existing crossing
                crossings[i].Update(crossings[j]);
                crossings.erase(crossings.begin() + j);
                return true;
            }
        }
    }
    return false;
}
