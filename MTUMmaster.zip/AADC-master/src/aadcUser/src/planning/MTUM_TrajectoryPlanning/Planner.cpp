//
// Created by clemens on 21.01.16.
//

#include <iostream>
#include "Planner.h"

using namespace std;

Planner::Planner() : trajectoryGenerator(){
}

Planner::~Planner() {

}

void Planner::generateTrajectory(RPoints rPoints, TPoint planningStart, cv::Mat ObstacleMap, TPoints &result) {


    TPoints selectedTrajectory;

    vector<vector<vector<TPoints> > > allTrajectoryOptions;

    trajectoryGenerator.generateTrajectories(planningStart, rPoints, allTrajectoryOptions);

//    int a, b, c;
//    a = allTrajectoryOptions.size();
//    b = allTrajectoryOptions.back().size();
//    c = allTrajectoryOptions.back().back().size();
//
//
//    cout << "Number of Trajectory options: " << a << "*" << b << "*" << c << " = " << a * b * c << endl;


   // trajectorySelector.selectTrajectory(allTrajectoryOptions, selectedTrajectory, ObstacleMap);

//    cout << endl << endl << "NEW selected Trajectory!" << endl << endl;
//
//
//    for (int i = 0; i < selectedTrajectory.size(); i++) {
//
//        cout << i << ": " "x: " << selectedTrajectory[i].x << " y: " << selectedTrajectory[i].y << " kappa: " << selectedTrajectory[i].kappa << " theta: " << selectedTrajectory[i].theta * 180/3.14 <<  endl;
//
//    }

    //result = selectedTrajectory;
//
//
//    cThread::Sleep(1000000000);

//}

    if(allTrajectoryOptions.size() == 0)
        result =  TPoints();

//    if(allTrajectoryOptions.back().size() > 1 && allTrajectoryOptions[4][5][1].front().s < 1)
//    {
//        return allTrajectoryOptions[4][5][1];
//    }
//    else if (allTrajectoryOptions.back().size() > 1 ) {
//        return allTrajectoryOptions[4][5][2];
//    }

    cout << "Sizes: ";
    cout << allTrajectoryOptions.size() << ", ";
    if(allTrajectoryOptions.size() > 0) {
        cout << allTrajectoryOptions[0].size() << ", ";
        if(allTrajectoryOptions[0].size() > 0) {
            cout << allTrajectoryOptions[0][0].size();
        }
    }
    cout << endl;

    if(allTrajectoryOptions.back().size() > 1)
   {
       cout << "allTrajectoryOptions: " << allTrajectoryOptions[4][5][1].size() << endl;
        result =  allTrajectoryOptions[4][2][0];
   }


    if (allTrajectoryOptions.back().back().size() > 3)
        result =  allTrajectoryOptions.back().back()[3];
    else{
        result =  allTrajectoryOptions.back().back().back();
    }
}


void Planner::setMapProperties(tInt rear, tInt front, tInt left, tInt right) {

    m_MapdistFront = front;
    m_MapdistRear = rear;
    m_MapdistLeft = left;
    m_MapdistRight = right;

    //trajectorySelector.setMapProperties(rear, front, left, right);

}

