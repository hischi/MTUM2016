//
// Created by clemens on 21.01.16.
//

#ifndef AADC_USER_REFERENCEGENERATOR_H
#define AADC_USER_REFERENCEGENERATOR_H

#define DEBUG_DRAW_CANDIDATES
//#define DEBUG_DRAW_SPLINES
#define DEBUG_DRAW_POINTLIST
#define DEBUG_DRAW_CROSSINGS
//#define DEBUG_NO_CROSSINGS

#include "stdafx.h"
#include "OdometryDataType.h"
#include "LaneStruct.h"
#include "DataTypes.h"
#include "ReferenceCandidate.h"
#include <deque>


using namespace cv;

class ReferenceGenerator {
public:
    virtual ~ReferenceGenerator() { }

    ReferenceGenerator();

    bool ProcessLaneStruct(tLaneStruct laneStruct, bool onlySign);

    void resetGenerator();

    void SetProperties(tUInt max_lane_points);


    void RemoveOldPoints();

    vector<PPoint> GetReference();

    void SetNextManeuver(TurningMode mode) {
        nextManeuver = mode;
    }

    bool ManeuverStarted();

    cCrossing GetActiveCrossing();

    bool IsOvertakingAllowed()
    {
        return !m_NoOvertaking;
    }


private:
    bool hasActiveCrossing = false;

    bool m_NoOvertaking = false;

    cCrossing activeCrossing;

    deque<PPoint> globalPoints;
    deque<cCrossing> crossings;
    TurningMode nextManeuver;

    cMutex globalMutex;

    void UpdateLane(const tLaneStruct &laneStruct);

    void UpdateCrossing(const tLaneStruct &laneStruct, bool onlySign);

    tUInt max_lane_points;

    bool isReady();


    bool mergeCrossings();

    void UpdateLaneNoCenter(const tLaneStruct &laneStruct);

    void UpdateLaneCenter(const tLaneStruct &laneStruct, int centerLineIdx);
};


#endif //AADC_USER_REFERENCEGENERATOR_H
