//
// Created by clemens on 21.01.16.
//

#include "stdafx.h"
#include <ReferencePointsType.h>
#include <iostream>
#include "Backend.h"


Backend::Backend() : lastSentTrajectory(){
}

Backend::~Backend() {
}

void Backend::ResetBackend() {
    // Brauchen wir das ueberhaupt?
    lastSentTrajectory = TPoints();
}


bool Backend::GetPlanningStartPoint(tTimeStamp time, TPoint *point) {
    // Suche denjenigen Punkt in der letzten Trajectorie der zum gegebenen zeitpunkt passt, das ist unser neuer ausgangspunkt
    // Falls es keinen solchen punkt gibt gib ein invalid zurueck

    for(int i = 0; i < lastSentTrajectory.size(); i++)
    {
        if(lastSentTrajectory[i].time > time)
        {
            *point = lastSentTrajectory[i];
            return true;
        }
    }

    return false;
}

void Backend::PrepareTrajectory(TPoints &newTrajectory, tReferencePoints &output) {


    output.numPoints = MIN(newTrajectory.size(), REFERENCEPOINTSIZE);

    if(newTrajectory.size() == 0)
        return;

    tFloat xOut, yOut, thetaOut;

    for(int i = 0; i < newTrajectory.size() && i < REFERENCEPOINTSIZE; i++)
    {
        PlanningUtils::get().Ferdi2Andy(newTrajectory[i].x, newTrajectory[i].y, newTrajectory[i].theta, xOut, yOut, thetaOut);
        output.points[i].x = xOut;
        output.points[i].y = yOut;
        output.points[i].phi = thetaOut;
        output.points[i].acceleration = newTrajectory[i].acc;
        output.points[i].time = newTrajectory[i].time;
        output.points[i].curvature = newTrajectory[i].kappa;
        output.points[i].vel = newTrajectory[i].vel;
    }

    lastSentTrajectory = newTrajectory;



}
