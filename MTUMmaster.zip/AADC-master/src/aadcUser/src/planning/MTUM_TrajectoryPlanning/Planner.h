//
// Created by clemens on 21.01.16.
//

#ifndef AADC_USER_PLANNER_H
#define AADC_USER_PLANNER_H


#include "DataTypes.h"
#include "TrajectoryGenerator.h"
#include "TrajectorySelector.h"
#include "mtum_trajectory_planning_interface.h"

#define PLANNER_MAX_SPEED 0.4


class Planner {
public:
    Planner();
    virtual ~Planner();
    void generateTrajectory(RPoints rPoints, TPoint planningStart, cv::Mat ObstacleMap, TPoints &result);
    void setMapProperties(tInt rear, tInt front, tInt left, tInt right);

private:
    TrajectoryGenerator trajectoryGenerator;
    TrajectorySelector trajectorySelector;

    tInt m_MapdistRear, m_MapdistFront, m_MapdistLeft, m_MapdistRight;


};


#endif //AADC_USER_PLANNER_H
