//
// Created by clemens on 25.01.16.
//

#ifndef AADC_USER_TRAJECTORYSELECTOR_H
#define AADC_USER_TRAJECTORYSELECTOR_H


#include "DataTypes.h"
#include "mtum_trajectory_planning_interface.h"

class TrajectorySelector {

public:
    TrajectorySelector() {}
    virtual ~TrajectorySelector() { }

    void selectTrajectory(vector<vector<vector<TPoints>>> &AllTrajectories, TPoints &selectedTrajectory,
                          cv::Mat ObstacleMap);

    void setMapProperties(tInt rear, tInt front, tInt left, tInt right);

private:


    bool DropInvalidTrajs(TPoints currenTrajectory, cv::Mat mat);

    bool checkPhysicalLimits(TPoints &currentTrajectory);

    tFloat CalcTrajectoryCosts(TPoints &currenTrajectory);

    tFloat distToRef(TPoints &currentTrajectory);

    bool collisionCheck(TPoints vector, cv::Mat mat);

    tFloat LowSpeedCost(TPoints &currentTrajectory);

    tFloat SpeedCost(TPoints &currentTrajectory);

    tInt m_MapdistRear, m_MapdistFront, m_MapdistLeft, m_MapdistRight;

};


#endif //AADC_USER_TRAJECTORYSELECTOR_H
