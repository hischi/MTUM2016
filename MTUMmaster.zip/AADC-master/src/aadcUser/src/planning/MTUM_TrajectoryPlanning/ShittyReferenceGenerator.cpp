//
// Created by clemens on 21.01.16.
//

#include "ReferenceGenerator.h"
#include "PlanningUtils.h"
#include <iostream>

using namespace std;
using namespace cv;


ReferenceGenerator::ReferenceGenerator() : lastReference() {
    isFirst = true;
}


void ReferenceGenerator::getReference(tUInt64 startPointIndex, RPoints &toReturn) {



    for(int i = 0; i < lastReference.size(); i++) {
        if(lastReference[i].rIndex >= startPointIndex) {
            toReturn.push_back(lastReference[i]);

        }
    }

    lastReference = toReturn;


}

bool ReferenceGenerator::ProcessLaneStruct(tLaneStruct laneStruct, tUInt64 i) {
    if(!isFirst)
        return true;
    isFirst = false;


    double geradeVorU = 800.0;


    // Generate 3m of reference
    tUInt64 index = 0;
    for(double y = 0; y < geradeVorU; y+=1) {
        double x=0;
        double theta = 0;

        double xOut, yOut, thetaOut;
        PlanningUtils::Lane2Ferdi(x,y,theta, xOut, yOut, thetaOut);
        lastReference.push_back(RPoint(xOut, yOut, thetaOut, 0, 0, STATE_GO, index,index*0.01));

        index++;
    }
    double lastX = lastReference.back().x;
    double lastY = lastReference.back().y;
    for(double angle = 0; angle <= M_PI; angle+=M_PI/200.0) {

        double x = cos(angle) * 200.0 - 200.0;
        double y = sin(angle) * 200.0 + geradeVorU;


        double theta = angle;

        double xOut, yOut, thetaOut;
        PlanningUtils::Lane2Ferdi(x,y,theta, xOut, yOut, thetaOut);
        lastReference.push_back(RPoint(xOut, yOut, thetaOut, 0.5, 0, STATE_GO, index,lastReference.back().length+cv::norm(Point2d(lastX, lastY) - Point2d(xOut,yOut))));
        lastX = xOut;
        lastY = yOut;
        index++;
    }


    for(double y = geradeVorU-1; y > 0; y--) {
        double x=-400;
        double theta = -M_PI;

        double xOut, yOut, thetaOut;
        PlanningUtils::Lane2Ferdi(x,y,theta, xOut, yOut, thetaOut);
        lastReference.push_back(RPoint(xOut, yOut, thetaOut, 0, 0, STATE_STOP, index,lastReference.back().length+0.01));
        index++;
    }

}

void ReferenceGenerator::removeScriptedStopPoints() {

}

bool ReferenceGenerator::isStopMode() {
    return false;
}

bool ReferenceGenerator::isScriptedMode() {
    return false;
}

void ReferenceGenerator::resetGenerator() {

}

bool ReferenceGenerator::matchSpline(Model **result, vector<cv::Point2d> points, double slope, cv::Point2d splineStart,
                                     cv::Point2d **start, cv::Point2d **end) {
    return true;
}

void ReferenceGenerator::generateCrossingReference(tLaneStruct laneStruct, tUInt64 startIndex) {

}

void ReferenceGenerator::generateTurningPoints(tFloat lengthBefore, tFloat lengthAfter, tFloat radius, TurningMode mode,
                                               RPoints &result) {

}
