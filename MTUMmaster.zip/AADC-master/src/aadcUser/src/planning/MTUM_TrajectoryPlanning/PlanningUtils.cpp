//
// Created by clemens on 21.01.16.
//

#include <car_geometry.h>
#include "PlanningUtils.h"
#include "StatusMessage.h"
#include "DataTypes.h"

using namespace cv;

tOdometryData PlanningUtils::GetOdo()
{
    tOdometryData result;
    odometryMutex.Enter();
    result = odo;
    odometryMutex.Leave();
    return result;
}

/**
 * @brief PlanningUtils::GetOdoF returns Odometry in Ferdi
 * @return odomentry in ferdi coord.
 */
tOdometryData PlanningUtils::GetOdoF()
{
    tOdometryData result;
    odometryMutex.Enter();
    result = odo;
    odometryMutex.Leave();

    tFloat tmpx, tmpy, tmptheta;
    Andy2Ferdi(result.x, result.y, result.phi, tmpx, tmpy, tmptheta);
    result.x = tmpx;
    result.y = tmpy;
    result.phi = tmptheta;
    return result;
}

void PlanningUtils::SetOdo(tOdometryData newodo)
{
    odometryMutex.Enter();
    odo = newodo;
    odometryMutex.Leave();
}

void PlanningUtils::SendDebug(Mat &debug)
{
    if(parent != 0)
        parent->SendDebug(debug);
}

void PlanningUtils::SendDebug2(Mat &debug)
{
    if(parent != 0)
        parent->SendDebug2(debug);
}

void PlanningUtils::SendDone()
{
    if(parent != 0)
        parent->SendStatusMessage(CAR_CONTROL, MANEUVER_DONE);
}

Mat& PlanningUtils::GetDebug()
{
    return debug;
}

Mat& PlanningUtils::GetDebug2()
{
    return debug2;
}

void PlanningUtils::SetDebugParams(Point2d mean, double scale)
{
    this->mean = mean;
    this->scale = scale;
}

Point PlanningUtils::ToDebug(Point2d p)
{
    return (p-Point2d(odo.y, -odo.x))*scale + Point2d(250,250);
}

double PlanningUtils::ToDebugScale(double d)
{
    return d * scale;
}

void PlanningUtils::SetParent(iTrajectoryPlanningInterface *parent)
{
    this->parent = parent;
}

void PlanningUtils::Lane2Andy(tFloat x, tFloat y, tFloat theta, tFloat &xout, tFloat &yout,
                                        tFloat &thetaOut) {
    odometryMutex.Enter();
        y += CAR_REARAXIS2CAM;
        yout =  (odo.y + (cos(odo.phi) * y + sin(odo.phi) * x) / 100.0);
        xout = odo.x + (-sin(odo.phi) * y + cos(odo.phi) * x) / 100.0;
        thetaOut = fixAngle(odo.phi + theta);

    odometryMutex.Leave();
}

void PlanningUtils::Andy2Lane(tFloat x, tFloat y, tFloat theta, tFloat &xout, tFloat &yout,
                                        tFloat &thetaOut) {
    odometryMutex.Enter();
        xout = ((x - odo.x) * cos(-odo.phi) -
                (y - odo.y) * sin(-odo.phi)) * 100;
        yout = (((x - odo.x) * sin(-odo.phi) +
                (y - odo.y) * cos(-odo.phi)) * 100) - CAR_REARAXIS2CAM;

        thetaOut = fixAngle(odo.phi - theta);

    odometryMutex.Leave();
}

void PlanningUtils::Ferdi2Andy(tFloat x, tFloat y, tFloat theta, tFloat &xout, tFloat &yout,
                                         tFloat &thetaOut) {
    xout =  -y;
    yout =  x;
    thetaOut =  fixAngle(theta);
}

void PlanningUtils::Andy2Ferdi(tFloat x, tFloat y, tFloat theta, tFloat &xout, tFloat &yout,
                                         tFloat &thetaOut) {
    xout =  y;
    yout =  -x;
    thetaOut =  fixAngle(theta);
}

void PlanningUtils::Lane2Ferdi(tFloat x, tFloat y, tFloat theta, tFloat &xout, tFloat &yout,
                                         tFloat &thetaOut) {
    tFloat tmpx, tmpy, tmptheta;
    Lane2Andy(x,y,theta,tmpx, tmpy, tmptheta);
    Andy2Ferdi(tmpx,tmpy,tmptheta,xout, yout, thetaOut);
}

void PlanningUtils::Ferdi2Lane(tFloat x, tFloat y, tFloat theta, tFloat &xout, tFloat &yout,
                                         tFloat &thetaOut) {
    tFloat tmpx, tmpy, tmptheta;
    Ferdi2Andy(x,y,theta,tmpx, tmpy, tmptheta);
    Andy2Lane(tmpx,tmpy,tmptheta,xout, yout, thetaOut);
}



void PlanningUtils::Lane2Andy(Point2d p, tFloat theta, Point2d &n, tFloat &thetaOut) {
    Lane2Andy(p.x, p.y, theta, n.x, n.y, thetaOut);
}

void PlanningUtils::Andy2Lane(Point2d p, tFloat theta, Point2d &n, tFloat &thetaOut) {
    Andy2Lane(p.x, p.y, theta, n.x, n.y, thetaOut);
}

void PlanningUtils::Ferdi2Andy(Point2d p, tFloat theta, Point2d &n, tFloat &thetaOut) {
    Ferdi2Andy(p.x, p.y, theta, n.x, n.y, thetaOut);
}

void PlanningUtils::Andy2Ferdi(Point2d p, tFloat theta, Point2d &n, tFloat &thetaOut) {
    Andy2Ferdi(p.x, p.y, theta, n.x, n.y, thetaOut);
}

void PlanningUtils::Lane2Ferdi(Point2d p, tFloat theta, Point2d &n, tFloat &thetaOut) {
    Lane2Ferdi(p.x, p.y, theta, n.x, n.y, thetaOut);
}


void PlanningUtils::Ferdi2Lane(Point2d p, tFloat theta, Point2d &n, tFloat &thetaOut) {
    Ferdi2Lane(p.x, p.y, theta, n.x, n.y, thetaOut);
}


void PlanningUtils::ClearDebug() {
    debug = 0;
//    arrowedLine(debug, Point2d(250,250), Point2d(400,250), Scalar(255,255,255), 1, 8, 0, 0.03);
//    putText(debug, "x", Point2d(450,250), CV_FONT_VECTOR0,.4, Scalar(255,255,255));
//
//    arrowedLine(debug, Point2d(250,250), Point2d(250,400), Scalar(255,255,255), 1, 8, 0, 0.03);
//    putText(debug, "y", Point2d(250,450), CV_FONT_VECTOR0,.4, Scalar(255,255,255));

    circle(debug, ToDebug(Point2d(GetOdoF().x, GetOdoF().y)), ToDebugScale(CAR_AXIS2AXIS_M), Scalar(0,0,255), 1);
    Point2d directionVector(cos(odo.phi), sin(odo.phi));
    line(debug, ToDebug(Point2d(GetOdoF().x, GetOdoF().y)), ToDebug(Point2d(GetOdoF().x, GetOdoF().y) + directionVector*.7), Scalar(0,255,255), 1);

}

void PlanningUtils::ClearDebug2() {
    debug2 = 0;
    circle(debug2, ToDebug2(Point2d(0,0)), 3, Scalar(0,0,255), 10);
}

Point PlanningUtils::ToDebug2(Point2d p) {
    return p*.5 + Point2d(250,250);
}

double PlanningUtils::fixAngle(double theta) {
    if(theta < -M_PI) {
        do {
            theta += 2*M_PI;
        } while(theta < -M_PI);
    } else if(theta > M_PI) {
        do {
            theta -= 2*M_PI;
        } while(theta > 2*M_PI);
    }
    return theta;
}

void PlanningUtils::Global2Local(Point2d in, Point2d &out) {
    odometryMutex.Enter();
    out.x = ((in.x - odo.x) * cos(-odo.phi) - (in.y - odo.y) * sin(-odo.phi)) * 100;
    out.y = ((in.x - odo.x) * sin(-odo.phi) + (in.y - odo.y) * cos(-odo.phi)) * 100;
    odometryMutex.Leave();
}

void PlanningUtils::Local2Map(const Point2d &in, Point2d &out)
{
    out = carInMap + Point2d(-in.x,in.y);
}

Point2d PlanningUtils::Global2Map(const Point2d &in)
{
    Point2d local,map;
    Global2Local(in, local);
    Local2Map(local,map);
    return map;
}

void PlanningUtils::SetCarInMap(Point2d carInMap) {
    this->carInMap = carInMap;
}

void PlanningUtils::Ferdi2Obstacle(tFloat x, tFloat y, tFloat &xout, tFloat &yout) {
    tFloat tmpx, tmpy, tmptheta;
    Ferdi2Andy(x,y,0,tmpx, tmpy, tmptheta);
    Point2d map = Global2Map(Point2d(tmpx, tmpy));
    xout = map.x;
    yout = map.y;
}

void PlanningUtils::Lane2Obstacle(tFloat x, tFloat y, tFloat &xout, tFloat &yout) {
    tFloat tmpx, tmpy, tmptheta;
    Lane2Andy(x,y,0,tmpx, tmpy, tmptheta);
    Point2d map = Global2Map(Point2d(tmpx, tmpy));
    xout = map.x;
    yout = map.y;
}


void PlanningUtils::Ferdi2Obstacle(Point2d in, Point2d &out) {
    Ferdi2Obstacle(in.x, in.y, out.x, out.y);
}

void PlanningUtils::Lane2Obstacle(Point2d in, Point2d &out) {
    Lane2Obstacle(in.x, in.y, out.x, out.y);
}
