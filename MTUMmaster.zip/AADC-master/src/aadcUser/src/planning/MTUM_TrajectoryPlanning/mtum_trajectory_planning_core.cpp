/**
Copyright (c)
Auvdi Autonomous Driving Cup. Team MomenTUM. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
3.  All advertising materials mentioning features or use of this software must display the following acknowledgement: "This product includes software developed by the Audi AG and its contributors for Audi Autonomous Driving Cup."
4.  Neither the name of Audi nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY AUDI AG AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL AUDI AG OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


**********************************************************************
* $Author:: MomenTUM#$  $Date:: 2015-10-10 15:10:07#$ $Rev:: 35043   $
**********************************************************************/

#include <car_geometry.h>
#include "stdafx.h"
#include "mtum_trajectory_planning_core.h"
#include "aadc_roadSign_enums.h"

// in cm
#define RPOINT_SAMPLE_DISTANCE 1.25

using namespace cv;
using namespace std;


#ifdef DEBUG

Point2d toDebug(Point2d in) {
    return in * 50 + Point2d(200, 200);
}

#endif


cTrajectoryPlanningCore::cTrajectoryPlanningCore(iTrajectoryPlanningInterface *parent)
        : referenceGenerator(), backend(), planner(), debug(500, 500, CV_8UC3), ransac() {
    this->parent = parent;
    hasMap = false;
    offset = 0;
}

cTrajectoryPlanningCore::~cTrajectoryPlanningCore() {

}

void cTrajectoryPlanningCore::removeOutliers(vector<Point2d> &points, vector<Point2d> &result) {
    vector<Model *> models = ransac.matchModel(points, 5, 100, 5);
    if (models.size() == 0)
        return;;

    Model *best = models.front();
    for (int i = 0; i < models.size(); i++) {
        if (models[i]->quality > best->quality) {
            best = models[i];
        }
    }

    for (int i = 0; i < best->supporting.size(); i++)
        result.push_back(best->supporting[i]);

    for (int i = 0; i < models.size(); i++)
        delete models[i];
}


Model *cTrajectoryPlanningCore::matchSplineRansac(vector<Point2d> &local, Point2d startPoint, Point2d &start,
                                                  Point2d &end, bool stabilize) {

    vector<Model *> models = ransac.matchModelWith(local, startPoint, 5, 50, 10, 0, 0);
    // No match :(
    if (models.size() == 0)
        return NULL;

    Model *best = models.front();
    for (int i = 1; i < models.size(); i++) {
        if (models[i]->quality > best->quality) {
            best = models[i];
        }
    }

    if (stabilize)
        ransac.stabilizeLeastSquares(best);

    Point2d *s = NULL;
    Point2d *e = NULL;

    ransac.fixModel(best->supporting, best, 200, &startPoint, &s, &e);

    if (s == NULL || e == NULL) {
        best = NULL;
    } else {
        start = *s;
        end = *e;
    }

    for (int i = 0; i < models.size(); i++) {
        if (models[i] != best)
            delete models[i];
    }

    return best;
}

bool cTrajectoryPlanningCore::getKappaGlobal(vector<PPoint> &reference, double &kappa) {
    PlanningUtils &utils = PlanningUtils::get();
    tOdometryData odo = utils.GetOdoF();
    PPoint odoP(odo.x, odo.y, odo.phi);

    Mat debug = utils.GetDebug();

    double dist = 50;
    double distDelta = 10;

    circle(debug, utils.ToDebug(odoP()), utils.ToDebugScale((dist + distDelta) / 100), Scalar(255, 0, 0));
    circle(debug, utils.ToDebug(odoP()), utils.ToDebugScale((dist - distDelta) / 100), Scalar(255, 0, 0));

    Point2d average(0, 0);
    int averageCount = 0;
    for (int i = 0; i < reference.size(); i++) {
        if (reference[i].IsInFrontOf(odoP) && abs(dist / 100 - norm(odoP() - reference[i]())) <= distDelta / 100) {
            average += reference[i]();
            averageCount++;
            debug.at<Vec3b>(utils.ToDebug(reference[i]())) = Vec3b(0, 255, 255);
        }
    }

    if (averageCount > 0) {
        average /= averageCount;
        Point2d followDirection = average - odoP();
        double length = norm(followDirection);
        followDirection /= length;
        Point2d frontDir = odoP.GetDir();
        float tmp = followDirection.x * frontDir.y - followDirection.y * frontDir.x;
        double angle = (float) atan2(tmp, followDirection.dot(frontDir));

        kappa = (-2 * sin(angle) / length);

        {
            if (abs(kappa) > 0.01) {
                Point2d odoDir = odoP.GetDir();
                Point2d odoNorm(-odoDir.y, odoDir.x);
                double r = 1 / kappa;
                circle(debug, utils.ToDebug(odoP() + r * odoNorm), utils.ToDebugScale(abs(r)), Scalar(255, 255, 255));
            }
        }
        return true;
    }
    return false;
}


bool cTrajectoryPlanningCore::getKappaRansac2(vector<PPoint> &reference, double &kappa) {

    PlanningUtils &utils = PlanningUtils::get();
    Mat debug = utils.GetDebug2();

    bool startFound = false, endFound = false;
    PPoint scriptStart;
    PPoint scriptEnd;

    for (int i = 0; i < reference.size(); i++) {
        if (reference[i].scriptMode == SCRIPT_SCRIPT_START) {
            scriptStart = reference[i];
            startFound = true;
        } else if (reference[i].scriptMode == SCRIPT_SCRIPT_END) {
            scriptEnd = reference[i];
            endFound = true;
        }
    }

    vector<Point2d> beforeScriptLocal, afterScriptLocal;
    vector<Point2d> withoutOutliers;

    tFloat notUsed;
    for (int i = 0; i < reference.size(); i++) {
        Point2d pt;
        utils.Ferdi2Lane(reference[i](), reference[i].theta, pt, notUsed);

        if (startFound || endFound) {
            if (reference[i].scriptMode == SCRIPT_SCRIPT_MIDDLE) {
                withoutOutliers.push_back(pt);
                debug.at<Vec3b>(utils.ToDebug2(pt)) = Vec3b(0, 255, 0);
                continue;
            }

            if (reference[i].scriptMode == SCRIPT_UNSCRIPTED || reference[i].scriptMode == SCRIPT_SCRIPT_TMP) {
                if (startFound && reference[i].IsInFrontOf(scriptStart)) {
                    beforeScriptLocal.push_back(pt);
                    debug.at<Vec3b>(utils.ToDebug2(pt)) = Vec3b(255, 0, 0);
                } else if (endFound && reference[i].IsInFrontOf(scriptEnd)) {
                    afterScriptLocal.push_back(pt);
                    debug.at<Vec3b>(utils.ToDebug2(pt)) = Vec3b(0, 0, 255);
                }
            }
        } else {
            beforeScriptLocal.push_back(pt);
        }
    }


    removeOutliers(beforeScriptLocal, withoutOutliers);
    removeOutliers(afterScriptLocal, withoutOutliers);

    for (int i = 0; i < withoutOutliers.size(); i++) {
        debug.at<Vec3b>(utils.ToDebug2(withoutOutliers[i])) = Vec3b(255, 0, 255);
    }


    if (withoutOutliers.size() == 0)
        return false;

    Point2d average(0, 0);
    int averageCount = 0;

    double pointToTake = 50;
    circle(debug, utils.ToDebug2(Point2d(0, 0)), pointToTake * .5, Scalar(255, 255, 255));

    for (int i = 0; i < withoutOutliers.size(); i++) {
        if (withoutOutliers[i].y < 0)
            continue;
        if (abs(norm(withoutOutliers[i]) - 50) < 10) {
            average += withoutOutliers[i];
            averageCount++;
        }
    }

    if (averageCount == 0) {
        double maxDist = abs(norm(withoutOutliers.front()) - 50);
        average = withoutOutliers.front();
        averageCount = 1;
        for (int i = 0; i < withoutOutliers.size(); i++) {
            if (abs(norm(withoutOutliers[i]) - 50) > maxDist) {
                average = withoutOutliers[i];
                maxDist = abs(norm(withoutOutliers[i]) - 50);
            }
        }

        if (maxDist > 20)
            return false;
    }

    Point2d localPt = average / averageCount;
    localPt.x += offset * 100;
    circle(debug, utils.ToDebug2(localPt), 2, Scalar(0, 255, 255), 2);
    localPt.y += 28.0;

    Point2d followDirection = localPt;
    double length = norm(followDirection);
    followDirection /= length;
    float tmp = followDirection.x * 1 - followDirection.y * 0;
    double angle = (float) atan2(tmp, followDirection.dot(Point2d(0, 1)));

    kappa = (-2 * sin(angle) / (length / 100));

    return true;
}

bool cTrajectoryPlanningCore::getKappaRansac(vector<PPoint> &reference, double &kappa) {
    PlanningUtils &utils = PlanningUtils::get();
    Mat debug = utils.GetDebug2();
    deque<Point2d> local;
    tFloat notUsed;
    for (int i = 0; i < reference.size(); i++) {
        Point2d pt;
        utils.Ferdi2Lane(reference[i](), reference[i].theta, pt, notUsed);
        if (pt.y > 0) {
            local.push_back(pt);
            debug.at<Vec3b>(utils.ToDebug2(pt)) = Vec3b(255, 0, 0);
        }
    }


    if (local.size() == 0) {
//	cout << "No Local Points" << endl;
        return false;
    }

    // Insert Odometry
    //tOdometryData currentOdo = utils.GetOdoF();
    sort(local.begin(), local.end(), [](Point2d const &a, Point2d const &b) { return a.y < b.y; });

    //Point2d localOdo;
    //utils.Ferdi2Lane(currentOdo.x, currentOdo.y, currentOdo.phi, localOdo.x, localOdo.y, notUsed);
    //local.push_front(localOdo);

    Point2d startPoint = local.front();


    vector<Model *> splines;
    vector<double> splineValidPos;

    Model *spline = NULL;
    do {
        circle(debug, utils.ToDebug2(startPoint), 3, Scalar(255, 0, 255), 2);
        Point2d start(0, 0), end(0, 0);
        vector<Point2d> localCpy;
        localCpy.insert(localCpy.begin(), local.begin(), local.end());

        spline = matchSplineRansac(localCpy, startPoint, start, end, true);
        if (spline != NULL) {
            // If its the first spline, push the start
            if (splines.size() == 0) {
                splineValidPos.push_back(start.y);
            }

            splines.push_back(spline);
            splineValidPos.push_back(end.y);
            for (double d = start.y; d < end.y; d++) {
                debug.at<Vec3b>(utils.ToDebug2(Point2d(spline->getY(d), d))) = Vec3b(0, 255, 0);
            }

            while (local.size() > 0 && local.front().y <= end.y) {
                local.pop_front();
            }

            startPoint = end;
        }
    } while (spline != NULL && local.size() > 0);


    if (splines.size() == 0) {
//	cout << "No Spline" << endl;
        return false;
    }


    double pointToTake = 50;
    Point2d localPt;


    bool localFound = false;
    int splineToUse = 0;
    for (int i = 1; i < splineValidPos.size(); i++) {
        if (splineValidPos[i] >= pointToTake) {
            splineToUse = i - 1;
            localFound = true;
            break;
        }
    }
    if (!localFound)
        pointToTake = splineValidPos.back();


    PolyModel *model = (PolyModel *) splines[splineToUse];
    localPt = Point2d(model->getY(pointToTake), pointToTake);


    localPt.x += offset * 100;
    circle(debug, utils.ToDebug2(localPt), 2, Scalar(0, 255, 255), 2);
    localPt.y += 26.0;

    Point2d followDirection = localPt;
    double length = norm(followDirection);
    followDirection /= length;
    float tmp = followDirection.x * 1 - followDirection.y * 0;
    double angle = (float) atan2(tmp, followDirection.dot(Point2d(0, 1)));

    kappa = (-2 * sin(angle) / (length / 100));

    return true;
}

tResult cTrajectoryPlanningCore::ThreadFunc() {

    PlanningUtils &utils = PlanningUtils::get();

    parent->SetOdoTimeToNow();
    // Gueltige Odometry? sonst return
    if (!PlanningUtils::get().GetOdo().valid)
        RETURN_NOERROR;


    tLaneStruct laneStruct;
    bool maneuverDone = false;
    bool hasNewLaneData = false;
    while (IS_OK(parent->GetLaneData(laneStruct))) {
        PlanningUtils::get().ClearDebug();
        maneuverDone |= referenceGenerator.ProcessLaneStruct(laneStruct, (offset<-CG_LANE_WIDTH/2));
        PlanningUtils::get().SendDebug(PlanningUtils::get().GetDebug());

        parent->SetOdoTimeToNow();

        // Remove all points behind the car
        referenceGenerator.RemoveOldPoints();
        hasNewLaneData = true;
    }
    if (!hasNewLaneData) {
        parent->SetOdoTimeToNow();
        referenceGenerator.RemoveOldPoints();
        //cout << "no lane updates" << endl;
    }


    if (maneuverDone) {
        // DONE!!!
        cout << "DONE!!!" << endl;

        stopTimerStarted = false;
        rowTimerStarted = false;
        PlanningUtils::get().SendDone();
    }


    Mat debug = utils.GetDebug2();
    utils.ClearDebug2();

    // We now have reference, match splines
    vector<PPoint> reference = referenceGenerator.GetReference();
    tOdometryData odo = PlanningUtils::get().GetOdoF();

    double farthestPoint = 0;
    for (int i = 0; i < reference.size(); i++) {
        farthestPoint = MAX(farthestPoint, norm(reference[i]() - Point2d(odo.x, odo.y)));
    }


    double kappa;
    bool kappaFound = false;

    kappaFound = getKappaRansac2(reference, kappa) || getKappaRansac(reference, kappa);

    if (!kappaFound) {
        parent->SendSteering(0, 0, LIGHT_INDICATOR_HAZARD | LIGHT_BRAKELIGHTS);
        RETURN_NOERROR;
    }


    // Obstacle Handling
    Mat mapCopy;

    bool mapAvailable = false;
    m_MapMutex.Enter();
    mapAvailable = this->hasMap;
    if (mapAvailable) {
        m_ObstacaleMap.copyTo(mapCopy);
    }
    m_MapMutex.Leave();

    Mat debug2 = Mat(mapCopy.rows, mapCopy.cols, CV_8UC3, Scalar(0, 0, 0));
    cv::cvtColor(mapCopy, debug2, COLOR_GRAY2BGR);


    bool allowOvertaking = referenceGenerator.IsOvertakingAllowed();
    double vel;
    tUInt8 lights = 0;
    if (!mapAvailable) {
        allowOvertaking = false;
        vel = 0.5;
        lights = LIGHT_INDICATOR_HAZARD;
    }
    else if(m_Maneuver == UNKNOWN)
    {
        vel = 0.5;
        allowOvertaking = false;
    }
    else {
        vel = 1;
        if (referenceGenerator.ManeuverStarted()) {

            cCrossing active = referenceGenerator.GetActiveCrossing();

            PPoint stopLine = active.GetStartPoint();
            Point2d v(cos(stopLine.theta), sin(stopLine.theta));
            Point2d n(-v.y, v.x);

            tOdometryData odo = PlanningUtils::get().GetOdoF();
            PPoint O(odo.x, odo.y, odo.phi);
            PPoint F(odo.x + cos(odo.phi) * CAR_REARAXIS2FRONTBUMPER / 100.0,
                     odo.y + sin(odo.phi) * CAR_REARAXIS2FRONTBUMPER / 100.0, odo.phi);


            double dist = norm(n.cross(F() - stopLine()));
            if (!F.IsInFrontOf(stopLine))
                dist *= -1;

            if (dist > -CG_STOP_LINE_SETBACK && !(offset < -CG_LANE_WIDTH/2))
                vel = CheckTrafficRules(mapCopy, active, dist, debug2, &allowOvertaking);
            else
                vel = 0.5;

            if (dist < 1) {
                if (m_Maneuver == LEFT)
                    lights |= LIGHT_INDICATOR_LEFT;
                else if (m_Maneuver == RIGHT)
                    lights |= LIGHT_INDICATOR_RIGHT;
            }


        } else {
            // No maneuver started, let's see if we can go faster than .8
            if (farthestPoint > 2) {
                vel = 1.2;
            }
            else {
                //allowOvertaking = false;

            }
        }
    }

    //PlanningUtils::get().SendDebug2(debug2);

    if(!allowOvertaking)
        cout << "No Overtaking! " << endl;

    double newOffset = offset;

    double distanceToCheck = 2;
    erode(mapCopy, mapCopy, getStructuringElement(CV_SHAPE_ELLIPSE, Size(CAR_AXIS2AXIS * .8, CAR_AXIS2AXIS * .8)));
    threshold(mapCopy, mapCopy, 80, 255, CV_THRESH_BINARY);
    cv::cvtColor(mapCopy, debug2, COLOR_GRAY2BGR);

    if (!checkCollision(mapCopy, reference, 0, distanceToCheck, debug2)) {
        newOffset = 0;
    }
    else if (!checkCollision(mapCopy, reference, offset, distanceToCheck, debug2)) {
        newOffset = offset;
    }
    else if (allowOvertaking && !checkCollision(mapCopy, reference, -CG_LANE_WIDTH, distanceToCheck, debug2)) {
        newOffset = -CG_LANE_WIDTH;
    }
    else if (!checkCollision(mapCopy, reference, offset, 0.5, debug2)) {
        newOffset = offset;
    }
    else {
        vel = 0;
        cout << "Overtaking will also crash" << endl;
    }


    if(newOffset == 0) {
        offset = .7 * offset + .3 * newOffset;
        if(offset > -2*CG_LANE_WIDTH/3 && offset < -CG_LANE_WIDTH/3)
            lights |= LIGHT_INDICATOR_RIGHT;
    }
    else {
        offset = .9 * offset + .1 * newOffset;
        if(offset < -CG_LANE_WIDTH/3)
            lights |= LIGHT_INDICATOR_LEFT;
    }

    offset = MAX(offset, -CG_LANE_WIDTH);


    cout << "Offset " << offset << endl;

    if (vel == 0)
        lights |= LIGHT_BRAKELIGHTS;

    parent->SendSteering(kappa, vel, lights);


    PlanningUtils::get().SendDebug(PlanningUtils::get().GetDebug());
    PlanningUtils::get().SendDebug2(debug2);


    RETURN_NOERROR;
}

double cTrajectoryPlanningCore::CheckTrafficRules(Mat &mapCopy, const cCrossing &active, double dist, Mat &debug2,
                                                  bool *allowOvertaking) {
    bool checkFront = false;
    bool checkLeft = false;
    bool checkRight = false;
    bool checkPedestrian = false;
    bool stop = false;
    bool enableOvertaking = false;

    switch (active.sign) {
        case MARKER_ID_PEDESTRIANCROSSING:
            checkPedestrian = true;
            break;

        case MARKER_ID_GIVEWAY:

            //checkLeft = true;

            if (m_Maneuver == STRAIGHT)
                checkRight = true;
            else if (m_Maneuver == LEFT) {
                checkRight = true;
                checkFront = true;
            }
            break;

        case MARKER_ID_UNMARKEDINTERSECTION:

            if (m_Maneuver == STRAIGHT)
                checkRight = true;
            else if (m_Maneuver == LEFT) {
                checkRight = true;
                checkFront = true;
            }
            break;

        case MARKER_ID_HAVEWAY:

            if (m_Maneuver == LEFT) {
                checkFront = true;
            }
            if (m_Maneuver == STRAIGHT)
                enableOvertaking = true;
            break;

        case MARKER_ID_AHEADONLY:
            break;

        case MARKER_ID_ROUNDABOUT:
            if (m_Maneuver == RIGHT) {
                checkLeft = true;
            }
            break;

        case MARKER_ID_STOPANDGIVEWAY:
        default:
            if (!stopTimerStarted && dist < 0.07) {
                stopTimer = parent->getTime() + 4000000;
                stopTimerStarted = true;
            }

            if (!stopTimerStarted || parent->getTime() < stopTimer) {
                stop = true;
            }

            //checkLeft = true;

            if (m_Maneuver == STRAIGHT)
                checkRight = true;
            else if (m_Maneuver == LEFT) {
                checkRight = true;
                checkFront = true;
            }
            break;
    }

    //*allowOvertaking &= enableOvertaking;

    checkFront &= active.frontOpen;
    checkRight &= active.rightOpen;
    checkLeft &= active.leftOpen;

    if (checkFront || checkRight || checkLeft || stop || checkPedestrian) {

        if (dist < 0.07) {
            bool row = !stop;
            if (checkFront)
                row &= CheckFrontRoW(mapCopy, debug2);

            if (checkRight)
                row &= CheckRightRoW(mapCopy, debug2);

            if (checkLeft)
                row &= CheckLeftRoW(mapCopy, debug2);

            if (checkPedestrian)
                row &= CheckPedestrianRoW(mapCopy, debug2);
            else {
                if (m_Maneuver == STRAIGHT)
                    row &= CheckDriveStraightRoW(mapCopy, debug2);
                else if (m_Maneuver == RIGHT)
                    row &= CheckDriveRightRoW(mapCopy, debug2);
                else
                    row &= CheckDriveLeftRoW(mapCopy, debug2);
            }

            if (!rowTimerStarted) {
                rowTimer = parent->getTime() + 20000000;
                rowTimerStarted = true;
            }

            if (rowTimerStarted && rowTimer < parent->getTime()) {
                row = true;
            }

            if (!row)
                return 0;
        }
        else if (dist < 0.3)
            return 0.3;
        else
            return 0.5;

    }
    return 0.5;
}


bool cTrajectoryPlanningCore::CheckDriveStraightRoW(Mat &map, Mat &debug) {
    cCrossing active = referenceGenerator.GetActiveCrossing();
    Point2d Center = active.GetPosCenter();
    Point2d v = active.GetDir();
    Point2d n(-v.y, v.x);

    vector<vector<Point>> polies;
    vector<Point> poly(4);
    Point2d A = Center - 0.46 * v;
    Point2d B = A - 0.40 * n;
    Point2d C = B + 0.95 * v;
    Point2d D = A + 0.95 * v;

    Point2d A_loc, B_loc, C_loc, D_loc, Center_loc;
    PlanningUtils::get().Ferdi2Obstacle(A, A_loc);
    PlanningUtils::get().Ferdi2Obstacle(B, B_loc);
    PlanningUtils::get().Ferdi2Obstacle(C, C_loc);
    PlanningUtils::get().Ferdi2Obstacle(D, D_loc);
    PlanningUtils::get().Ferdi2Obstacle(Center, Center_loc);

    poly[0] = A_loc;
    poly[1] = B_loc;
    poly[2] = C_loc;
    poly[3] = D_loc;
    polies.push_back(poly);


    int count = 0;
    for (int y = 0; y < map.rows; y++)
        for (int x = 0; x < map.cols; x++) {
            if (cv::pointPolygonTest(poly, Point(x, y), false) < 0)
                continue;

            if (map.at<tUInt8>(y, x) < 80)
                count++;
        }

    bool row = (count < 5);

    circle(debug, Center, 2, Scalar(255, 255, 0), -1);

    if (row)
        cv::drawContours(debug, polies, 0, Scalar(0, 255, 0));
    else
        cv::drawContours(debug, polies, 0, Scalar(0, 0, 255));

    return row;
}

bool cTrajectoryPlanningCore::CheckPedestrianRoW(Mat &map, Mat &debug) {
    cCrossing active = referenceGenerator.GetActiveCrossing();
    Point2d Center = active.GetPosCenter();
    Point2d v = active.GetDir();
    Point2d n(-v.y, v.x);

    vector<vector<Point>> polies;
    vector<Point> poly(4);
    Point2d A = Center - 0.46 * v + 1 * n;
    Point2d B = A - 2 * n;
    Point2d C = B + 0.95 * v;
    Point2d D = A + 0.95 * v;

    Point2d A_loc, B_loc, C_loc, D_loc, Center_loc;
    PlanningUtils::get().Ferdi2Obstacle(A, A_loc);
    PlanningUtils::get().Ferdi2Obstacle(B, B_loc);
    PlanningUtils::get().Ferdi2Obstacle(C, C_loc);
    PlanningUtils::get().Ferdi2Obstacle(D, D_loc);
    PlanningUtils::get().Ferdi2Obstacle(Center, Center_loc);

    poly[0] = A_loc;
    poly[1] = B_loc;
    poly[2] = C_loc;
    poly[3] = D_loc;
    polies.push_back(poly);


    int count = 0;
    for (int y = 0; y < map.rows; y++)
        for (int x = 0; x < map.cols; x++) {
            if (cv::pointPolygonTest(poly, Point(x, y), false) < 0)
                continue;

            if (map.at<tUInt8>(y, x) < 80)
                count++;
        }

    bool row = (count < 5);

    circle(debug, Center, 2, Scalar(255, 255, 0), -1);

    if (row)
        cv::drawContours(debug, polies, 0, Scalar(0, 255, 0));
    else
        cv::drawContours(debug, polies, 0, Scalar(0, 0, 255));

    return row;
}

bool cTrajectoryPlanningCore::CheckDriveRightRoW(Mat &map, Mat &debug) {
    cCrossing active = referenceGenerator.GetActiveCrossing();
    Point2d Center = active.GetPosCenter();
    Point2d v = active.GetDir();
    Point2d n(-v.y, v.x);

    vector<vector<Point>> polies;
    vector<Point> poly(4);
    Point2d A = Center - 0.46 * v;
    Point2d B = A - 0.40 * n;
    Point2d C = B + 0.4 * v;
    Point2d D = A + 0.4 * v;

    Point2d A_loc, B_loc, C_loc, D_loc, Center_loc;
    PlanningUtils::get().Ferdi2Obstacle(A, A_loc);
    PlanningUtils::get().Ferdi2Obstacle(B, B_loc);
    PlanningUtils::get().Ferdi2Obstacle(C, C_loc);
    PlanningUtils::get().Ferdi2Obstacle(D, D_loc);
    PlanningUtils::get().Ferdi2Obstacle(Center, Center_loc);

    poly[0] = A_loc;
    poly[1] = B_loc;
    poly[2] = C_loc;
    poly[3] = D_loc;
    polies.push_back(poly);


    int count = 0;
    for (int y = 0; y < map.rows; y++)
        for (int x = 0; x < map.cols; x++) {
            if (cv::pointPolygonTest(poly, Point(x, y), false) < 0)
                continue;

            if (map.at<tUInt8>(y, x) < 80)
                count++;
        }

    bool row = (count < 5);

    circle(debug, Center, 2, Scalar(255, 255, 0), -1);

    if (row)
        cv::drawContours(debug, polies, 0, Scalar(0, 255, 0));
    else
        cv::drawContours(debug, polies, 0, Scalar(0, 0, 255));

    return row;
}

bool cTrajectoryPlanningCore::CheckDriveLeftRoW(Mat &map, Mat &debug) {
    cCrossing active = referenceGenerator.GetActiveCrossing();
    Point2d Center = active.GetPosCenter();
    Point2d v = active.GetDir();
    Point2d n(-v.y, v.x);

    vector<vector<Point>> polies;
    vector<Point> poly(4);
    Point2d A = Center - 0.46 * v + 0.46 * n;
    Point2d B = A - 0.95 * n;
    Point2d C = B + 0.95 * v;
    Point2d D = A + 0.95 * v;

    Point2d A_loc, B_loc, C_loc, D_loc, Center_loc;
    PlanningUtils::get().Ferdi2Obstacle(A, A_loc);
    PlanningUtils::get().Ferdi2Obstacle(B, B_loc);
    PlanningUtils::get().Ferdi2Obstacle(C, C_loc);
    PlanningUtils::get().Ferdi2Obstacle(D, D_loc);
    PlanningUtils::get().Ferdi2Obstacle(Center, Center_loc);

    poly[0] = A_loc;
    poly[1] = B_loc;
    poly[2] = C_loc;
    poly[3] = D_loc;
    polies.push_back(poly);


    int count = 0;
    for (int y = 0; y < map.rows; y++)
        for (int x = 0; x < map.cols; x++) {
            if (cv::pointPolygonTest(poly, Point(x, y), false) < 0)
                continue;

            if (map.at<tUInt8>(y, x) < 80)
                count++;
        }

    bool row = (count < 5);

    circle(debug, Center, 2, Scalar(255, 255, 0), -1);

    if (row)
        cv::drawContours(debug, polies, 0, Scalar(0, 255, 0));
    else
        cv::drawContours(debug, polies, 0, Scalar(0, 0, 255));

    return row;
}


bool cTrajectoryPlanningCore::CheckFrontRoW(Mat &map, Mat &debug) {
    cCrossing active = referenceGenerator.GetActiveCrossing();
    Point2d Center = active.GetPosCenter();
    Point2d v = active.GetDir();
    Point2d n(-v.y, v.x);

    vector<vector<Point>> polies;
    vector<Point> poly(4);
    Point2d A = Center + 0.36 * n + 0.46 * v;
    Point2d B = Center + 0.46 * v;
    Point2d C = B + 0.5 * v;
    Point2d D = A + 0.5 * v;

    Point2d A_loc, B_loc, C_loc, D_loc, Center_loc;
    PlanningUtils::get().Ferdi2Obstacle(A, A_loc);
    PlanningUtils::get().Ferdi2Obstacle(B, B_loc);
    PlanningUtils::get().Ferdi2Obstacle(C, C_loc);
    PlanningUtils::get().Ferdi2Obstacle(D, D_loc);
    PlanningUtils::get().Ferdi2Obstacle(Center, Center_loc);

    poly[0] = A_loc;
    poly[1] = B_loc;
    poly[2] = C_loc;
    poly[3] = D_loc;
    polies.push_back(poly);

    int count = 0;
    for (int y = 0; y < map.rows; y++)
        for (int x = 0; x < map.cols; x++) {
            if (cv::pointPolygonTest(poly, Point(x, y), false) < 0)
                continue;

            if (map.at<tUInt8>(y, x) < 80)
                count++;
        }

    bool row = (count < 5);

    circle(debug, Center, 2, Scalar(255, 255, 0), -1);

    if (row)
        cv::drawContours(debug, polies, 0, Scalar(0, 255, 0));
    else
        cv::drawContours(debug, polies, 0, Scalar(0, 0, 255));

    return row;
}

bool cTrajectoryPlanningCore::CheckRightRoW(Mat &map, Mat &debug) {
    cCrossing active = referenceGenerator.GetActiveCrossing();
    Point2d Center = active.GetPosCenter();
    Point2d v = active.GetDir();
    Point2d n(-v.y, v.x);

    vector<vector<Point>> polies;
    vector<Point> poly(4);
    Point2d A = Center - 0.46 * n;
    Point2d B = A - 0.46 * n;
    Point2d C = B + 0.4 * v;
    Point2d D = A + 0.4 * v;

    Point2d A_loc, B_loc, C_loc, D_loc, Center_loc;
    PlanningUtils::get().Ferdi2Obstacle(A, A_loc);
    PlanningUtils::get().Ferdi2Obstacle(B, B_loc);
    PlanningUtils::get().Ferdi2Obstacle(C, C_loc);
    PlanningUtils::get().Ferdi2Obstacle(D, D_loc);
    PlanningUtils::get().Ferdi2Obstacle(Center, Center_loc);

    poly[0] = A_loc;
    poly[1] = B_loc;
    poly[2] = C_loc;
    poly[3] = D_loc;
    polies.push_back(poly);


    int count = 0;
    for (int y = 0; y < map.rows; y++)
        for (int x = 0; x < map.cols; x++) {
            if (cv::pointPolygonTest(poly, Point(x, y), false) < 0)
                continue;

            if (map.at<tUInt8>(y, x) < 80)
                count++;
        }

    bool row = (count < 5);
    circle(debug, Center, 2, Scalar(255, 255, 0), -1);

    if (row)
        cv::drawContours(debug, polies, 0, Scalar(0, 255, 0));
    else
        cv::drawContours(debug, polies, 0, Scalar(0, 0, 255));

    return row;
}

bool cTrajectoryPlanningCore::CheckLeftRoW(Mat &map, Mat &debug) {
    cCrossing active = referenceGenerator.GetActiveCrossing();
    Point2d Center = active.GetPosCenter();
    Point2d v = active.GetDir();
    Point2d n(-v.y, v.x);

    vector<vector<Point>> polies;
    vector<Point> poly(4);
    Point2d A = Center - 0.4 * v;
    Point2d B = A + 0.46 * v;
    Point2d C = B + 0.8 * n;
    Point2d D = A + 0.8 * n;

    Point2d A_loc, B_loc, C_loc, D_loc, Center_loc;
    PlanningUtils::get().Ferdi2Obstacle(A, A_loc);
    PlanningUtils::get().Ferdi2Obstacle(B, B_loc);
    PlanningUtils::get().Ferdi2Obstacle(C, C_loc);
    PlanningUtils::get().Ferdi2Obstacle(D, D_loc);
    PlanningUtils::get().Ferdi2Obstacle(Center, Center_loc);

    poly[0] = A_loc;
    poly[1] = B_loc;
    poly[2] = C_loc;
    poly[3] = D_loc;
    polies.push_back(poly);


    int count = 0;
    for (int y = 0; y < map.rows; y++)
        for (int x = 0; x < map.cols; x++) {
            if (cv::pointPolygonTest(poly, Point(x, y), false) < 0)
                continue;

            if (map.at<tUInt8>(y, x) < 80)
                count++;
        }

    bool row = (count < 5);


    circle(debug, Center, 2, Scalar(255, 255, 0), -1);

    if (row)
        cv::drawContours(debug, polies, 0, Scalar(0, 255, 0));
    else
        cv::drawContours(debug, polies, 0, Scalar(0, 0, 255));

    return row;
}


tResult cTrajectoryPlanningCore::ThreadInitFunc() {
    stopTimerStarted = false;
    rowTimerStarted = false;
    RETURN_NOERROR;
}

tResult cTrajectoryPlanningCore::ThreadExitFunc() {
    RETURN_NOERROR;
}


void cTrajectoryPlanningCore::sleep(tTimeStamp duration) {
    tTimeStamp waitStart = parent->getTime();
    while ((parent->getTime() - waitStart) < duration) {
        cThread::YieldExecution();
    }
}

void cTrajectoryPlanningCore::init() {
    referenceGenerator.resetGenerator();
    backend.ResetBackend();
}


void cTrajectoryPlanningCore::SetProperties(tInt rear, tInt front, tInt left, tInt right, tUInt max_lane_points) {
//
//    m_MapdistFront = front;
//    m_MapdistRear = rear;
//    m_MapdistLeft = left;
//    m_MapdistRight = right;

    PlanningUtils::get().SetCarInMap(Point2d(right, rear));
    referenceGenerator.SetProperties(max_lane_points);
}

bool cmp_p2d(Point2d a, Point2d b)
{
    return (a.y < b.y);
}

bool cTrajectoryPlanningCore::checkCollision(Mat mapCopy, vector<PPoint> reference, double offset,
                                             double distanceToCheck, Mat &debug) {

    PlanningUtils &utils = PlanningUtils::get();

    vector<Point2d> locals;
    vector<Point2d> withoutOutliers;

    tFloat notUsed;
    for (int i = 0; i < reference.size(); i++) {
        Point2d p_local;
        PPoint refP = reference[i];
        Point2d p = refP() - offset *refP.GetNorm();

        utils.Ferdi2Lane(p, refP.theta, p_local, notUsed);

        if(p_local.y > 20 && p_local.y < 100*distanceToCheck)
            locals.push_back(p_local);
    }

    removeOutliers(locals, withoutOutliers);

    std::sort(withoutOutliers.begin(), withoutOutliers.end(), cmp_p2d);

    int badPts = 0;

    for(int i = 0; i < withoutOutliers.size(); i++) {
        Point2d inMap;
        utils.Lane2Obstacle(withoutOutliers[i], inMap);

        if (inMap.x < 0 || inMap.x >= mapCopy.cols || inMap.y < 0 || inMap.y >= mapCopy.rows)
            continue;

        circle(debug, inMap, 1, Scalar(255, 0, 0), -1);

        if (mapCopy.at<uchar>(inMap) == 0) {
            badPts++;
        }
    }

    if(badPts > 5)
        return true;
    return false;
}
