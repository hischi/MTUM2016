//
// Created by clemens on 25.01.16.
//


#define KAPPA_MAX 1.1
#define SACC_MAX 3
#define SACC_MIN -5
#define DACC_MAX 4

#define FAVOURED_VEL 0.6


#include <iostream>
#include <car_geometry.h>
#include "TrajectorySelector.h"
#include "TrajectoryGenerator.h"
#include "PlanningUtils.h"

using namespace cv;

void TrajectorySelector::selectTrajectory(vector<vector<vector<TPoints>>> &AllTrajectories, TPoints &selectedTrajectory, cv::Mat ObstacleMap) {


    tFloat cheapest = INFINITY;

    tUInt bestI =0 , bestJ = 0, bestK = 0;

    tUInt DebugCounterAll = 0;
    tUInt DebugCounterLeft = 0;
    tUInt EmptyTrajectory = 0;



   cv::Mat threshObstacleMap;
    // Todo make threshold configurable
    threshold(ObstacleMap, threshObstacleMap, 127, 255, CV_THRESH_BINARY);


//    //
//    cv::Mat debug;
//
//    cvtColor(threshObstacleMap, debug, CV_GRAY2BGR); //debug
//    cv::Point CarBackRight(m_MapdistRight-CAR_WIDTH/2,m_MapdistRear - CAR_REARAXIS2REAR);
//    cv::Point CarFrontLeft(m_MapdistRight+CAR_WIDTH/2,m_MapdistRear + CAR_REARAXIS2FRONTBUMPER);
//    cv::rectangle(debug,CarBackRight,CarFrontLeft,Scalar(255,0,0), 2);
//
//    PlanningUtils::parent->SendDebug(debug);
//    cThread::Sleep(1000000);
//    //

    int erosion_type;
    //erosion_type = MORPH_RECT;
    erosion_type = MORPH_ELLIPSE;

    tInt erosion_size = (tUInt)(CAR_WIDTH*0.7);

    Mat element = getStructuringElement( erosion_type,
                                         Size( erosion_size , erosion_size));


    cv::Mat erosionObstacleMap;
    erode( threshObstacleMap, erosionObstacleMap, element );


//    //
//    cvtColor(erosionObstacleMap, debug, CV_GRAY2BGR); //debug
//    cv::rectangle(debug,CarBackRight,CarFrontLeft,Scalar(255,0,0), 2);
//
//    PlanningUtils::parent->SendDebug(debug);
//    cThread::Sleep(1000000);
//    //


    for (tUInt i=0; i < AllTrajectories.size(); i++){
        for (tUInt j=0; j < AllTrajectories[i].size(); j++) {
            for (tUInt k=0; k < AllTrajectories[i][j].size(); k++){

                TPoints currentTrajectory = AllTrajectories[i][j][k];


                if (currentTrajectory.size() ==0) {

                    EmptyTrajectory++;

                }


                DebugCounterAll++;

               if (DropInvalidTrajs(currentTrajectory, erosionObstacleMap)) {

                    continue;


                };

                DebugCounterLeft++;

                tFloat cost = CalcTrajectoryCosts(currentTrajectory);

                //cout << "cost: " << cheapest << endl;

                if (cost <= cheapest){
                    cheapest = cost;
                    bestI = i;
                    bestJ = j;
                    bestK = k;

                }


            }
        }
    }

//   cout << "DebugCounterAll: " << DebugCounterAll << endl;
//    cout << "DebugCounterLeft: " << DebugCounterLeft << endl;
//    cout << "EmptyTrajectory: " << EmptyTrajectory << endl;
//
//    cout << "bestI: " << bestI << endl;
//    cout << "bestJ: " << bestJ << endl;
//    cout << "bestK: " << bestK << endl;


//    //DEBUG
//    TPoints debugTrajectory = AllTrajectories[bestI][bestJ][bestK];
//
//    cv::Mat debug;
//
//    cvtColor(ObstacleMap, debug, CV_GRAY2BGR); //debug
//
//    Scalar Tcolor = Scalar(0, 255, 0);
//
//    tBool Debugout = false;
//
//
//    if (debugTrajectory.front().x > 2){
//
//        for(int i=0 ; i < debugTrajectory.size(); i++) {
//
//
//
//
//            tUInt Drow, Dclm;
//
//
//            PlanningUtils::FerdiTest2ObstacleMap(debugTrajectory[i].x, debugTrajectory[i].y, Dclm, Drow,
//                                                 debugTrajectory.front().x, debugTrajectory.front().y,
//                                                 debugTrajectory.front().theta);
//
//
//            cv::circle(debug, Point(Dclm, Drow), 1, Tcolor, 1);
//
//
//
//            cv::Point CarBackRight(m_MapdistRight-CAR_WIDTH/2,m_MapdistRear - CAR_REARAXIS2REAR);
//            cv::Point CarFrontLeft(m_MapdistRight+CAR_WIDTH/2,m_MapdistRear + CAR_REARAXIS2FRONTBUMPER);
//            cv::rectangle(debug,CarBackRight,CarFrontLeft,Scalar(255,0,0), 2);
//
//            PlanningUtils::parent->SendDebug(debug);
//
//
//        }
//
//
//    }
//    //DEBUG




  // cThread::Sleep(10000000000);

    selectedTrajectory = AllTrajectories[bestI][bestJ][bestK];
}

bool TrajectorySelector::DropInvalidTrajs(TPoints currentTrajectory, cv::Mat ObstacleMap) {

    if (checkPhysicalLimits(currentTrajectory)){

        return true;
    }
//    else if (collisionCheck(currentTrajectory, ObstacleMap)){
//        return true;
//    }

    else{
        return false;
    }

}

bool TrajectorySelector::checkPhysicalLimits(TPoints &currentTrajectory) {

    tBool result = false;

    for (int i=0; i < currentTrajectory.size(); i++){

        TPoint currentTPoint = currentTrajectory[i];

        if (abs(currentTPoint.kappa) > KAPPA_MAX){
            result = true;
            break;
        }

        if (currentTPoint.sAcc < SACC_MIN){
            result = true;
            break;
        }

        if (currentTPoint.sAcc > SACC_MAX){
            result = true;
            break;
        }

        if (currentTPoint.sVel > PLAN_SP_MAX){
            result = true;
            break;
        }

        if (abs(currentTPoint.dAcc) > DACC_MAX){
            result = true;
            break;
        }


    }

    return result;
}

//bool TrajectorySelector::collisionCheck(TPoints currentTrajectory, cv::Mat ObstacleMap) {
//
//
//    //
////    cv::Mat debug;
////
////    cvtColor(ObstacleMap, debug, CV_GRAY2BGR); //debug
////
////    Scalar Tcolor = Scalar(0, 255, 0);
////
////    tBool Debugout = false;
//    //
//
//
//    tUInt MaxRow = ObstacleMap.rows;
//    tUInt MaxCol = ObstacleMap.cols;
//
//    tUInt LastRow = INFINITY;
//    tUInt LastClm = INFINITY;
//
//    for(int i=0 ; i < currentTrajectory.size(); i++) {
//
//
//        if (currentTrajectory[i].x > 2 && currentTrajectory[i].x < 2.5) {
//
//            if (currentTrajectory[i].y < 0.4 && currentTrajectory[i].y > -0.4) {
//
//
//                return true;
//
//            }
//
//        }
//
//
////        tUInt row,clm;
////        //PlanningUtils::FerdiTest2ObstacleMap(currentTrajectory[i].x,currentTrajectory[i].y,clm,row,currentTrajectory.front().x, currentTrajectory.front().y, currentTrajectory.front().theta);
////        PlanningUtils::Ferdi2ObstacleMap(currentTrajectory[i].x,currentTrajectory[i].y, clm,row);
////
////        if (LastRow == row && LastClm==clm){
////            continue;
////        }
////
////        LastRow = row;
////        LastClm = clm;
////
////        //cout << "Map: " << (int)(ObstacleMap.at<uchar>(row,clm)) << endl;
////
////
////
////        if (row < MaxRow && row >=0 && clm < MaxCol && clm >=0){
////
////            if ((int)(ObstacleMap.at<uchar>(row,clm)) == 0){
////
////                 return true;
////                //Tcolor = Scalar(0, 0, 255);
////                //Debugout =true;
////
////            }
////          }
//    }
////
//////DEBUG
////    if (currentTrajectory.front().x > 2){
////
////        for(int i=0 ; i < currentTrajectory.size()/10; i++) {
////
////
////
////
////            tUInt Drow, Dclm;
////
//////
//////           && PlanningUtils::FerdiTest2ObstacleMap(currentTrajectory[i].x, currentTrajectory[i].y, Dclm, Drow,
//////                                                 currentTrajectory.front().x, currentTrajectory.front().y,
//////                                                 currentTrajectory.front().theta);
////
////            PlanningUtils::Ferdi2ObstacleMap(currentTrajectory[i].x,currentTrajectory[i].y, Dclm,Drow);
////
////
////            cv::circle(debug, Point(Dclm, Drow), 1, Tcolor, 1);
////
////
////
////            cv::Point CarBackRight(m_MapdistRight-CAR_WIDTH/2,m_MapdistRear - CAR_REARAXIS2REAR);
////            cv::Point CarFrontLeft(m_MapdistRight+CAR_WIDTH/2,m_MapdistRear + CAR_REARAXIS2FRONTBUMPER);
////            cv::rectangle(debug,CarBackRight,CarFrontLeft,Scalar(255,0,0), 2);
////
////            PlanningUtils::parent->SendDebug(debug);
////
////
////        }
//////        cThread::Sleep(100000);
//////
//////        if (Debugout){
//////            cout << "Raus: " << endl;
//////            cThread::Sleep(500000);
//////        }
////
////    }
//    //DEBUG
//
//    return false;
//}

tFloat TrajectorySelector::CalcTrajectoryCosts(TPoints &currentTrajectory) {

    tFloat costDist2Ref=0, costLowSpeed=0, costSpeed=0, result;

    costDist2Ref = distToRef(currentTrajectory);

   // costLowSpeed = LowSpeedCost(currentTrajectory);

    costSpeed = SpeedCost(currentTrajectory);

    result = 3 * costDist2Ref + costLowSpeed + costSpeed;


//    cout << "costDist2Ref: " << costDist2Ref << endl;
//    cout << "costLowSpeed: " << costLowSpeed << endl;

    //cThread::Sleep(1000000);

    return result;

}

tFloat TrajectorySelector::distToRef(TPoints &currentTrajectory) {

    tFloat dSum = 0;
    tFloat result = 0;

    for (int i =0; i < currentTrajectory.size(); i++ ){

        dSum += (currentTrajectory[i].d*currentTrajectory[i].d);
    }

    result = dSum/((PLAN_D_MAX*PLAN_D_MAX)*currentTrajectory.size());

    return result;

}


tFloat TrajectorySelector::LowSpeedCost(TPoints &currentTrajectory) {


    tFloat costSum=0;
    tFloat result = 0;

    for (int i =0; i < currentTrajectory.size(); i++ ){

        costSum +=  (PLAN_SP_MAX - currentTrajectory[i].sVel);
    }

    result = costSum/(currentTrajectory.size() * PLAN_SP_MAX);

    return result;

}


void TrajectorySelector::setMapProperties(tInt rear, tInt front, tInt left, tInt right) {

    m_MapdistFront = front;
    m_MapdistRear = rear;
    m_MapdistLeft = left;
    m_MapdistRight = right;


}


tFloat TrajectorySelector::SpeedCost(TPoints &currentTrajectory) {

    tFloat costSum=0;
    tFloat result = 0;




    for (int i =0; i < currentTrajectory.size(); i++ ){

        tFloat MaxVelKappa = sqrt(DACC_MAX / currentTrajectory[i].kappa);

        tFloat curRcmdVel = MIN(FAVOURED_VEL, MaxVelKappa);

        costSum +=  abs(curRcmdVel - currentTrajectory[i].sVel);
    }

    result = costSum/(currentTrajectory.size() * PLAN_SP_MAX);

    return result;

}