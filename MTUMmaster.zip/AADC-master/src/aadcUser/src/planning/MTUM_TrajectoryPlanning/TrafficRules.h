//
// Created by clemens on 21.01.16.
//

#ifndef _MTUM_TRAFFIC_RULES_H
#define _MTUM_TRAFFIC_RULES_H

#include "stdafx.h"
#include "PlanningUtils.h"
#include "DataTypes.h"
#include <deque>
#include <vector>
#include <iostream>

using namespace std;

using namespace cv;

class cTrafficRules
{
public:

    cTrafficRules()
    {
        currentCrossingValid = false;
        wasInCrossing = false;
    }

    tResult CheckRoW(RPoints &ref, cCrossing crossing, TurningMode mode, tTimeStamp time)
    {

        tOdometryData odo = PlanningUtils::get().GetOdoF();
        Point2d O(odo.x, odo.y);
        Point2d v(cos(odo.phi), sin(odo.phi));
        Point2d n(-v.y, v.x);

        bool row = true;

        if(!row)
        {
            for(int i = 0; i < ref.size(); i++)
            {
                if(crossing.IsInside(ref[i]()))
                {
                    ref[i].state = STATE_STOP;
                    break;
                }
            }
        }
    }

    cCrossing currentCrossing;
    bool currentCrossingValid;
    bool wasInCrossing;

    tTimeStamp stopTimer;
    bool stopTimerStarted;
};

#endif //_MTUM_TRAFFIC_RULES_H
