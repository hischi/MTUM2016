//
// Created by clemens on 21.01.16.
//

#ifndef AADC_USER_TRAJECTORYGENERATOR_H
#define AADC_USER_TRAJECTORYGENERATOR_H


#include <vector>
#include "DataTypes.h"

#define PLAN_DELTA_TAU 0.3
#define PLAN_MAX_TAU 3.0

// T Steps = (PLAN_MAX_TAU/PLAN_T_DELTA)+1
#define PLAN_T_STEPS 121
#define PLAN_T_DELTA 0.025

#define PLAN_SP_MAX 2
#define PLAN_SP_MIN 0.3


#define PLANNINGLENGTH 2.0

#define PLAN_D_MIN 0
#define PLAN_D_MAX 0.5

#define PLAN_DELTA_D 0.1
#define PLAN_DELTA_SP 0.1


class TrajectoryGenerator {

public:
    TrajectoryGenerator();
    virtual ~TrajectoryGenerator() { }
    void generateTrajectories(TPoint startPoint, RPoints &reference, vector<vector<vector<vector<TPoint>>>> &result);

private:
    tFloat timePowers[PLAN_T_STEPS][12];
    void generateTargetValuesDriving(vector<tFloat> &spTargets, vector<tFloat> &dTargets, vector<tFloat> &tauTargets);
    void generateTargetValuesStopping(RPoints &reference, tFloat &sTarget, vector<tFloat> &dTargets,
                                                           vector<tFloat> &tauTargets, TPoint startPoint);
    void computeTimePowers();


    void generateSComponentsDriving(TPoint startPoint, tFloat targetTau, vector<tFloat> &spTargets, cv::Matx33d M10,
                                    cv::Matx33d M1Tau, cv::Matx33d M2Tau, tUInt &MaxSComponentSize,
                                    vector<vector<tTrajComponentPoint>> &result);


    void generateDComponents(TPoint startPoint, tFloat targetTau, vector<tFloat> &dTargets, cv::Matx33d M10,
                             cv::Matx33d M1Tau, cv::Matx33d M2Tau, tUInt MaxSComponentSize,
                             vector<vector<tTrajComponentPoint>> &result);


    void generateTrajectoriesDriving(TPoint startPoint, RPoints &reference, vector<tFloat> &spTargets,
                                     vector<tFloat> &dTargets, vector<tFloat> &tauTargets,
                                     vector<vector<vector<TPoints>>> &result);

    void combineSDComponents(RPoints &reference, vector<vector<tTrajComponentPoint>> sTauTraj,
                             vector<vector<tTrajComponentPoint>> dTauTraj, vector<vector<TPoints>> &result);


    void generateTrajectoriesStopping(TPoint startPoint, RPoints &reference, tFloat &spTargets,
                                     vector<tFloat> &dTargets, vector<tFloat> &tauTargets,
                                     vector<vector<vector<TPoints>>> &result);


    void generateSComponentsStopping(TPoint startPoint, tFloat targetTau, tFloat &sTarget, cv::Matx33d M10,
                                     cv::Matx33d M1Tau, cv::Matx33d M2Tau, vector<vector<tTrajComponentPoint>> &result);

    void generateDComponentsStopping(TPoint startPoint, tFloat targetTau, vector<tFloat> &dTargets,
                                         vector<vector<tTrajComponentPoint>> &result);


    void generateTrajectoriesDrivingWAYMODE(TPoint startPoint, RPoints &reference, vector<tFloat> &spTargets,
                                            vector<tFloat> &dTargets, vector<tFloat> &tauTargets,
                                            vector<vector<vector<TPoints>>> &result);


    void generateDComponentsWAYMODE(TPoint startPoint, tFloat targetTau, vector<tFloat> &dTargets,
                                    cv::Matx33d M1Tau, cv::Matx33d M2Tau, tUInt &MaxSComponentSize,
                                    vector<tFloat> &resultingSTargets,
                                    vector<vector<tTrajComponentPoint>> &sTauTraj,
                                    vector<vector<vector<tTrajComponentPoint>>> &result) ;

    void generateSComponentsDrivingWAYMODE(TPoint startPoint, tFloat targetTau, vector<tFloat> &spTargets, cv::Matx33d M10,
                                           cv::Matx33d M1Tau, cv::Matx33d M2Tau, tUInt &MaxSComponentSize,
                                           vector<tFloat> &resultingSTargets,
                                           vector<vector<tTrajComponentPoint>> &result);

    void combineSDComponentsWAYMODE(RPoints &reference, vector<vector<tTrajComponentPoint>> sTauTraj,
                                    vector<vector<vector<tTrajComponentPoint>>> dTauTraj, vector<vector<TPoints>> &result);
};


#endif //AADC_USER_TRAJECTORYGENERATOR_H
