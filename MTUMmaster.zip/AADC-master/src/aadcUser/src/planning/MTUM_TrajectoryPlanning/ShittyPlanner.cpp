//
// Created by clemens on 21.01.16.
//

#include <iostream>
#include "Planner.h"

using namespace std;

Planner::Planner() {
}

Planner::~Planner() {

}

TPoints Planner::generateTrajectory(RPoints &rPoints, TPoint planningStart) {

    tTimeStamp lastTimeStamp = planningStart.time;

    TPoints output;

    bool inPMode = false;
    double pCount = 0;
    int pStart;

    for(int i = 0; i < rPoints.size(); i++) {
        if(rPoints[i].state == STATE_D) {
            inPMode = false;
            output.push_back(TPoint(rPoints[i].x, rPoints[i].y, PLANNER_MAX_SPEED, 0, 0, 0,0,0,0,0,rPoints[i].theta,0, lastTimeStamp, rPoints[i].rIndex));
        } else {
            if(!inPMode) {
                pStart = i;
                // Walk through points and find the last P mode point
                for(int j = i+1; j < rPoints.size(); j++) {
                    pCount = j - i;
                    if(rPoints[j].state != STATE_P) {
                        break;
                    }
                }
            }
            inPMode = true;
            double speed = planningStart.vel - (i-pStart)*(planningStart.vel/pCount);

            output.push_back(TPoint(rPoints[i].x, rPoints[i].y, speed, 0, 0, 0,0,0,0,0,rPoints[i].theta,0, lastTimeStamp, rPoints[i].rIndex));
        }

        lastTimeStamp += 25000;
    }

    return output;
}
