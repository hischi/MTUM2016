//
// Created by clemens on 21.01.16.
//

#ifndef AADC_USER_PLANNINGUTILS_H
#define AADC_USER_PLANNINGUTILS_H


#include "stdafx.h"
#include <OdometryDataType.h>
#include "mtum_trajectory_planning_interface.h"

using namespace cv;

class PlanningUtils {

public:

    static PlanningUtils& get()
    {
        static PlanningUtils singleton;
        return singleton;
    }


    tOdometryData GetOdo();
    tOdometryData GetOdoF();

    void SetOdo(tOdometryData newodo);

    void SendDone();

    void SendDebug(Mat &debug);
    Mat& GetDebug();
    Mat& GetDebug2();
    void SetDebugParams(Point2d mean, double scale);
    Point ToDebug(Point2d p);
    Point ToDebug2(Point2d p);
    double ToDebugScale(double d);
    void SetParent(iTrajectoryPlanningInterface *parent);
    void SetCarInMap(Point2d carInMap);

    void Lane2Andy(tFloat x, tFloat y,  tFloat theta,  tFloat &xout, tFloat &yout, tFloat &thetaOut);
    void Andy2Lane(tFloat x, tFloat y,  tFloat theta, tFloat &xout, tFloat &yout, tFloat &thetaOut);
    void Ferdi2Andy(tFloat x, tFloat y, tFloat theta, tFloat &xout, tFloat &yout, tFloat &thetaOut);
    void Andy2Ferdi(tFloat x, tFloat y, tFloat theta, tFloat &xout, tFloat &yout, tFloat &thetaOut);
    void Lane2Ferdi(tFloat x, tFloat y, tFloat theta, tFloat &xout, tFloat &yout, tFloat &thetaOut);
    void Ferdi2Lane(tFloat x, tFloat y, tFloat theta, tFloat &xout, tFloat &yout, tFloat &thetaOut);
    void Ferdi2Obstacle(tFloat x, tFloat y, tFloat theta, tFloat &xout, tFloat &yout, tFloat &thetaOut);


    void Lane2Andy(Point2d p, tFloat theta, Point2d &n, tFloat &thetaOut);
    void Andy2Lane(Point2d p, tFloat theta, Point2d &n, tFloat &thetaOut);
    void Ferdi2Andy(Point2d p, tFloat theta, Point2d &n, tFloat &thetaOut);
    void Andy2Ferdi(Point2d p, tFloat theta, Point2d &n, tFloat &thetaOut);
    void Lane2Ferdi(Point2d p, tFloat theta, Point2d &n, tFloat &thetaOut);
    void Ferdi2Lane(Point2d p, tFloat theta, Point2d &n, tFloat &thetaOut);




    void ClearDebug();
    void ClearDebug2();
    void SendDebug2(Mat &debug);

    static double fixAngle(double theta);

    void Ferdi2Obstacle(tFloat x, tFloat y, tFloat &xout, tFloat &yout);
    void Ferdi2Obstacle(Point2d in, Point2d &out);
    void Lane2Obstacle(tFloat x, tFloat y, tFloat &xout, tFloat &yout);
    void Lane2Obstacle(Point2d in, Point2d &out);

private:

    tOdometryData odo;
    cMutex odometryMutex;

    iTrajectoryPlanningInterface *parent;

    PlanningUtils(){
        odo.valid = false;
        parent = 0;
        mean=Point2d(0,0);
        //scale = 100;
        debug = Mat(500, 500, CV_8UC3, Scalar(0,0,0));
        debug2 = Mat(500, 500, CV_8UC3, Scalar(0,0,0));
    };

    PlanningUtils(PlanningUtils const&);
    void operator=(PlanningUtils const&);

    Mat debug, debug2;
    Point2d mean;
    double scale = 50;


    void Global2Local(Point2d in, Point2d &out);

    void Local2Map(const Point2d &in, Point2d &out);

    Point2d Global2Map(const Point2d &in);

    Point2d carInMap;
};


#endif //AADC_USER_PLANNINGUTILS_H
