//
// Created by clemens on 21.01.16.
//

#ifndef AADC_USER_DATATYPES_H
#define AADC_USER_DATATYPES_H

#include "stdafx.h"
#include "PlanningUtils.h"
#include <vector>
#include <list>
#include <iostream>
#include "aadc_roadSign_enums.h"

using namespace std;

#define STATE_GO 1
#define STATE_STOP 2

#define CG_LANE_WIDTH 0.47
#define CG_STOP_LINE_SETBACK 0.135

#define SCRIPT_UNSCRIPTED -1
#define SCRIPT_SCRIPT_START 0
#define SCRIPT_SCRIPT_MIDDLE 1
#define SCRIPT_SCRIPT_END 2
#define SCRIPT_SCRIPT_TMP 3

enum TurningMode {
    LEFT, RIGHT, STRAIGHT, UNKNOWN
};

using namespace cv;

class RPoint {

public:


    RPoint(tFloat x, tFloat y, tFloat theta, tFloat kappa, tFloat kappaDash, tUInt8 state, tUInt64 rIndex,
           tFloat length, tUInt8 lights) : x(x), y(y),
                                           theta(theta),
                                           kappa(kappa),
                                           kappaDash(
                                                   kappaDash),
                                           state(state),
                                           rIndex(rIndex),
                                           length(length), lights(lights) { }


    RPoint() { }

    Point2d operator()() {
        return Point2d(x, y);
    }

    tFloat x, y, theta, kappa, kappaDash, length;
    tUInt8 state;
    tUInt64 rIndex;
    tUInt8 lights;
};

class PPoint {

public:
    PPoint(tFloat x, tFloat y, tFloat theta) : x(x), y(y), theta(theta) { scriptMode = SCRIPT_UNSCRIPTED; }

    PPoint(tFloat x, tFloat y, tFloat theta, int scriptMode) : x(x), y(y), theta(theta), scriptMode(scriptMode) { }

    PPoint() {
        scriptMode = SCRIPT_UNSCRIPTED;
    }

    Point2d operator()() {
        return Point2d(x, y);
    }

    Point2d GetDir() {
        return Point2d(cos(theta), sin(theta));
    }

    Point2d GetNorm() {
        return Point2d(-sin(theta), cos(theta));
    }

    bool IsInFrontOf(PPoint other) {
        // Get the direction
        Point2d dir = Point2d(x, y) - other();
        dir /= norm(dir);

        Point2d front(cos(other.theta), sin(other.theta));

        double angle = acos(front.dot(dir)) * 180 / M_PI;

        return abs(angle) <= 45;
    }

    tFloat x, y, theta;
    int scriptMode;
};

struct TPoint {
public:
    TPoint(tFloat x, tFloat y, tFloat vel, tFloat acc, tFloat s, tFloat sVel, tFloat sAcc, tFloat d, tFloat dVel,
           tFloat dAcc, tFloat theta, tFloat kappa, tTimeStamp time, tUInt64 rIndex, tUInt8 lights) : x(x), y(y),
                                                                                                      vel(vel),
                                                                                                      acc(acc),
                                                                                                      s(s), sVel(sVel),
                                                                                                      sAcc(sAcc),
                                                                                                      d(d), dVel(dVel),
                                                                                                      dAcc(dAcc),
                                                                                                      theta(theta),
                                                                                                      kappa(kappa),
                                                                                                      time(time),
                                                                                                      rIndex(rIndex),
                                                                                                      lights(lights) { }

    TPoint() { }

    TPoint(RPoint r, double v, tTimeStamp time) {
        this->x = r.x;
        this->y = r.y;
        this->vel = v;
        this->acc = 0;

        this->theta = r.theta;
        this->kappa = r.kappa;

        this->lights = r.lights;

        this->time = time;
    }

    Point2d operator()() {
        return Point2d(x, y);
    }

    tFloat x, y, vel, acc;
    tFloat s, sVel, sAcc;
    tFloat d, dVel, dAcc;
    tFloat theta, kappa;
    tTimeStamp time;
    tUInt64 rIndex;
    tUInt8 lights;
};

struct tTrajComponentPoint {
    tFloat mov, vel, acc;
    tTimeStamp time;
};

typedef vector<RPoint> RPoints;
typedef vector<TPoint> TPoints;
typedef vector<PPoint> PPoints;

class cCrossing {
public:

    cCrossing(Point2d pos, Point2d dir, int sign, bool leftOpen, bool rightOpen, bool frontOpen, double qualityPos,
              double qualityDir) {
        this->maneuverStarted = false;
        this->posSum = qualityPos * pos;
        this->initialPos = pos;
        this->directionSum = qualityDir * dir;

        this->qualitySumDir = qualityDir;
        this->qualitySumPos = qualityPos;

        this->leftOpen = leftOpen;
        this->rightOpen = rightOpen;
        this->frontOpen = frontOpen;


        this->sign = sign;

        life = 10;
    }

    void StartManeuver() {
        maneuverStarted = true;
    }

    bool WasManeuverStarted() {
        return maneuverStarted;
    }

    bool IsSimilar(cCrossing other) {

        return (norm(GetPos() - other.GetPos()) < .5 && abs(GetTheta() - other.GetTheta()) * 180 / M_PI < 10);
    }

    double GetTheta() {
        Point2d dir = GetDir();
        return atan2(dir.y, dir.x);
    }


    bool IsValid() {
        return life >= 100 || sign >= 0;
    }

    void Hurt() {
        life--;
    }

    bool IsAlive() {
        return life > 0;
    }

    TurningMode CheckMode(TurningMode mode) {
        if (sign == MARKER_ID_PEDESTRIANCROSSING)
            return STRAIGHT;
        else
            return mode;
    }

    Point2d GetPos() {
        return posSum / qualitySumPos;
    }

    Point2d GetPosCenter() {
        Point2d dir = GetDir();
        Point2d n(-dir.y, dir.x);
        return GetPos() + dir * (CG_STOP_LINE_SETBACK + CG_LANE_WIDTH) + n * CG_LANE_WIDTH / 2;
    }

    Point2d GetDir() {
        Point2d dir = directionSum / qualitySumDir;
        return dir / norm(dir);
    }

    PPoint GetEndPoint(TurningMode mode) {
        mode = CheckMode(mode);

        Point2d stopLinePos = GetPos();
        Point2d dir = GetDir();
        Point2d normal(-dir.y, dir.x);
        double endTheta = GetEndTheta(mode);

        if (mode == RIGHT) {
            Point2d end = stopLinePos - normal * (CG_STOP_LINE_SETBACK + CG_LANE_WIDTH / 2.0) +
                          dir * (CG_STOP_LINE_SETBACK + CG_LANE_WIDTH / 2.0);
            return PPoint(end.x, end.y, endTheta);
        }
        if (mode == LEFT) {
            Point2d end = stopLinePos + normal * (CG_STOP_LINE_SETBACK + 1.5 * CG_LANE_WIDTH) +
                          dir * (CG_STOP_LINE_SETBACK + 1.5 * CG_LANE_WIDTH);
            return PPoint(end.x, end.y, endTheta);
        }
        Point2d end = stopLinePos + dir * (2 * CG_LANE_WIDTH);
        return PPoint(end.x, end.y, endTheta);
    }

    PPoint GetStartPoint() {
        double angle = PlanningUtils::fixAngle(GetTheta() + M_PI);
        Point2d pos = GetPos();
        return PPoint(pos.x, pos.y, angle);
    }

    bool LaneMarkingAllowed(PPoint marking, TurningMode mode) {
        mode = CheckMode(mode);

        PPoint start = GetStartPoint();
        PPoint end = GetEndPoint(mode);
        return marking.IsInFrontOf(start) || marking.IsInFrontOf(end);
    }

    bool IsOnReference(deque<PPoint> &ref) {
        PPoint start = GetStartPoint();
        for (int i = 0; i < ref.size(); i++) {
            if (norm(ref[i]() - start()) < CG_LANE_WIDTH && ref[i].IsInFrontOf(start))
                return true;
        }
        return false;
    }

    void Update(cCrossing &other) {
        this->posSum += other.posSum;
        this->directionSum += other.directionSum;

        this->qualitySumDir += other.qualitySumDir;
        this->qualitySumPos += other.qualitySumPos;

        this->leftOpen |= other.leftOpen;
        this->rightOpen |= other.rightOpen;
        this->frontOpen |= other.frontOpen;

        if (other.sign >= 0) // valid sign => valid crossing
        {
            this->sign = other.sign;
        }

        life += other.life;

        // We have dragged the crossing with us..? Kill it WITH FIRE!
        if (norm(initialPos - GetPos()) >= 1) {
            life = 0;
            sign = -1;
        }
    }


    void GenerateTurningPoints(TurningMode mode, deque<PPoint> &pts) {
        mode = CheckMode(mode);

        Point2d stopLinePos = GetPos();
        Point2d dir = GetDir();
        Point2d normal(-dir.y, dir.x);

        double theta = GetTheta();

        if (mode == STRAIGHT) {
            for (double d = 0; d < CG_LANE_WIDTH * 2; d += 0.05) {
                Point2d p = stopLinePos + d * dir;
                pts.push_back(PPoint(p.x, p.y, theta, SCRIPT_SCRIPT_MIDDLE));
            }
        }
        else if (mode == RIGHT) {
            Point2d M = stopLinePos - normal * (CG_STOP_LINE_SETBACK + CG_LANE_WIDTH / 2.0);
            for (double a = M_PI / 2; a >= 0; a -= 0.01) {
                Point2d p = M + (CG_STOP_LINE_SETBACK + CG_LANE_WIDTH / 2.0) * Point2d(sin(a - theta), cos(a - theta));
                pts.push_back(PPoint(p.x, p.y, theta - a, SCRIPT_SCRIPT_MIDDLE));
            }
        }
        else {
            Point2d M = stopLinePos + normal * (CG_STOP_LINE_SETBACK + 1.5 * CG_LANE_WIDTH);
            for (double a = 0; a >= -M_PI / 2; a -= 0.01) {
                Point2d p = M - (CG_STOP_LINE_SETBACK + 1.5 * CG_LANE_WIDTH) * Point2d(sin(a - theta), cos(a - theta));
                pts.push_back(PPoint(p.x, p.y, theta - a, SCRIPT_SCRIPT_MIDDLE));
            }
        }

        PPoint startPointP = GetStartPoint();
        startPointP.scriptMode = SCRIPT_SCRIPT_START;
        PPoint endPointP = GetEndPoint(mode);
        endPointP.scriptMode = SCRIPT_SCRIPT_END;

        pts.push_back(startPointP);
        pts.push_back(endPointP);

        Point2d endPoint = endPointP();
        Point2d endPointDir = endPointP.GetDir();
        double endPointTheta = endPointP.theta;

        for (double d = 0; d < 1; d += 0.05) {
            Point2d p = d * endPointDir + endPoint;
            pts.push_back(PPoint(p.x, p.y, endPointTheta, SCRIPT_SCRIPT_TMP));
        }
    }

    double GetEndTheta(TurningMode mode) {
        mode = CheckMode(mode);

        double theta = GetTheta();
        if (mode == STRAIGHT) {
            return PlanningUtils::fixAngle(theta);
        }
        else if (mode == RIGHT) {
            return PlanningUtils::fixAngle(theta - M_PI / 2);
        }
        else {
            return PlanningUtils::fixAngle(theta + M_PI / 2);
        }
    }


    void DrawPolygon(Mat &debug, TurningMode mode) {
        mode = CheckMode(mode);

        Point2d pos = GetPos();
        Point2d dir = GetDir();
        Point2d n(-dir.y, dir.x);

        Scalar color(0, 255, 0);
        if (!IsValid())
            color = Scalar(0, 0, 255);

        // StopLine
        PlanningUtils &utils = PlanningUtils::get();
        circle(debug, utils.ToDebug(pos), 3, Scalar(0, 255, 255), 2);
        line(debug, utils.ToDebug(pos - CG_LANE_WIDTH / 2.0 * n), utils.ToDebug(pos + CG_LANE_WIDTH / 2.0 * n), color);

//        vector<Point2d> corners;
//        corners.push_back(pos + dir*(CG_LANE_WIDTH*2+CG_STOP_LINE_SETBACK) + n*CG_LANE_WIDTH*1.5);
//        corners.push_back(pos + dir*(CG_LANE_WIDTH*2+CG_STOP_LINE_SETBACK) - n*CG_LANE_WIDTH*.5);
//        corners.push_back(pos + dir*(CG_STOP_LINE_SETBACK) - n*CG_LANE_WIDTH*.5);
//        corners.push_back(pos + dir*(CG_STOP_LINE_SETBACK) + n*CG_LANE_WIDTH*1.5);
//
//        for(int i = 0; i <= corners.size(); i++)
//            line(debug, utils.ToDebug(corners[i]), utils.ToDebug(corners[(i+1)%corners.size()]), Scalar(255,255,255));

        putText(debug, String(cString::FromFloat64(life)), PlanningUtils::get().ToDebug(GetPosCenter()), CV_FONT_NORMAL,
                1 / 3.0, Scalar(255, 255, 255));


        // Draw EndPoints with orientation
        vector<PPoint> endPoints;
        endPoints.push_back(GetStartPoint());
        endPoints.push_back(GetEndPoint(mode));
        //endPoints.push_back(GetEndPoint(STRAIGHT));
        //endPoints.push_back(GetEndPoint(RIGHT));

        for (int i = 0; i < endPoints.size(); i++) {
            Point2d dir(cos(endPoints[i].theta), sin(endPoints[i].theta));
            Point2d pos = endPoints[i]();
            arrowedLine(debug, utils.ToDebug(pos), utils.ToDebug(pos + dir), Scalar(255, 0, 0));
        }
    }

    Point2d posSum, initialPos;
    Point2d directionSum;
    int sign;
    bool leftOpen;
    bool rightOpen;
    bool frontOpen;
    double qualitySumPos;
    double qualitySumDir;
    double life;
    bool maneuverStarted;
};

#endif //AADC_USER_DATATYPES_H
