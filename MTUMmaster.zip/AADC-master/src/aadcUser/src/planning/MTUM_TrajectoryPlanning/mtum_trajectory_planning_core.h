/**
Copyright (c)
Audi Autonomous Driving Cup. Team MomenTUM. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
3.  All advertising materials mentioning features or use of this software must display the following acknowledgement: "This product includes software developed by the Audi AG and its contributors for Audi Autonomous Driving Cup."
4.  Neither the name of Audi nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY AUDI AG AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL AUDI AG OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


**********************************************************************
* $Author:: MomenTUM#$  $Date:: 2015-10-10 15:10:07#$ $Rev:: 35043   $
**********************************************************************/

#ifndef _MTUM_TRAJECTORY_PLANNING_FILTER_CORE_H_
#define _MTUM_TRAJECTORY_PLANNING_FILTER_CORE_H_

#include <adtf_plugin_sdk.h>
#include "mtum_trajectory_planning_interface.h"
#include "ReferenceGenerator.h"
#include "Backend.h"
#include "Planner.h"

#include <OdometryDataType.h>
#include <LaneStruct.h>
#include "Ransac.h"
#include "DataTypes.h"
#include "PlanningUtils.h"


#define DEBUG


//*************************************************************************************************
class cTrajectoryPlanningCore : public cKernelThread {
public:
    cTrajectoryPlanningCore(iTrajectoryPlanningInterface *parent);

    virtual ~cTrajectoryPlanningCore();

    // MTUM Statusupdate methods called by events on the status input pin
    tBool Status_IsReady() { return true; }

    tResult Status_Reset() {
        referenceGenerator.resetGenerator();
        RETURN_NOERROR;
    }

    tResult Status_ChangeMode(tInt mode) { RETURN_NOERROR; }

    tResult Status_SetActive() { RETURN_NOERROR; }

    tResult Status_SetInactive() { RETURN_NOERROR; }

    tResult SetManeuver(TurningMode mode) {
        /*if (mode == STRAIGHT)
            cout << "The current maneuver is straight" << endl;
        else if (mode == LEFT)
            cout << "The current maneuver is left" << endl;
        else if (mode == RIGHT)
            cout << "The current maneuver is right" << endl;
        else
            cout << "the current maneuver is bloedsinn" << endl;*/
        m_Maneuver = mode;
        referenceGenerator.SetNextManeuver(mode);
        RETURN_NOERROR;
    }

    void SetProperties(tInt rear, tInt front, tInt left, tInt right, tUInt max_lane_points);

    cv::Mat debug;

    cMutex m_MapMutex;
    Mat m_ObstacaleMap;
    bool hasMap;

protected:
    tResult ThreadFunc();

    tResult ThreadInitFunc();

    tResult ThreadExitFunc();

    // Functions
private:
    void sleep(tTimeStamp duration);

    // Members
private:
    Ransac ransac;
    iTrajectoryPlanningInterface *parent;
    ReferenceGenerator referenceGenerator;
    Planner planner;
    Backend backend;

    void init();

    TurningMode m_Maneuver;

    bool CheckPedestrianRoW(Mat &map, Mat &debug);

    bool CheckFrontRoW(Mat &map, Mat &debug);

    bool CheckRightRoW(Mat &map, Mat &debug);

    bool CheckLeftRoW(Mat &map, Mat &debug);

    bool CheckDriveStraightRoW(Mat &map, Mat &debug);

    bool CheckDriveRightRoW(Mat &map, Mat &debug);

    bool CheckDriveLeftRoW(Mat &map, Mat &debug);

    Model *matchSplineRansac(vector<Point2d> &local, Point2d startPoint, Point2d &start, Point2d &end);

    Model *matchSplineRansac(vector<Point2d> &local, Point2d startPoint, Point2d &start, Point2d &end, bool stabilize);


    bool checkCollision(Mat mapCopy, vector<PPoint> reference, double offset,
                            double distanceToCheck, Mat &debug);

    double offset = 0;

    tTimeStamp stopTimer;
    bool stopTimerStarted;

    tTimeStamp rowTimer;
    bool rowTimerStarted;

    bool getKappaRansac(vector<PPoint> &reference, double &kappa);

    bool getKappaGlobal(vector<PPoint> &reference, double &kappa);

    bool getKappaRansac2(vector<PPoint> &reference, double &kappa);

    void removeOutliers(vector<Point2d> &points, vector<Point2d> &result);

    double CheckTrafficRules(Mat &mapCopy, const cCrossing &active, double dist, Mat &debug2,
                                 bool *allowOvertaking);
};

//*************************************************************************************************
#endif // _MTUM_TRAJECTORY_PLANNING_FILTER_CORE_H_
