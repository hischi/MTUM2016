//
// Created by clemens on 21.01.16.
//

#include <iostream>
#include "TrajectoryGenerator.h"

using namespace cv;

TrajectoryGenerator::TrajectoryGenerator() : timePowers() {
    // This can be done here, because it is the same for every step
    computeTimePowers();
}

void TrajectoryGenerator::computeTimePowers() {
    // Compute the time powers for later use
    for(int i = 0; i < PLAN_T_STEPS; i++) {
        double t = i*PLAN_T_DELTA;
        timePowers[i][0] = t*t*t*t*t;
        timePowers[i][1] = t*t*t*t;
        timePowers[i][2] = t*t*t;
        timePowers[i][3] = t*t;
        timePowers[i][4] = t;

        timePowers[i][5] = 5*t*t*t*t;
        timePowers[i][6] = 4*t*t*t;
        timePowers[i][7] = 3*t*t;
        timePowers[i][8] = 2*t;

        timePowers[i][9] = 5*4*t*t*t;
        timePowers[i][10] = 4*3*t*t;
        timePowers[i][11] = 3*2*t;
    }
}

void TrajectoryGenerator::generateTrajectories(TPoint startPoint, RPoints &reference,
                                               vector<vector<vector<vector<TPoint>>>> &result) {
    if(reference.size() == 0)
        return;

    if(reference.front().state == STATE_GO) {
        vector<tFloat> spTargets, dTargets, tauTargets;
        generateTargetValuesDriving(spTargets, dTargets, tauTargets);

//       if (startPoint.sVel < 0.3){
//           generateTrajectoriesDrivingWAYMODE(startPoint, reference, spTargets, dTargets, tauTargets, result);
//       }
//       else{
            generateTrajectoriesDriving(startPoint, reference, spTargets, dTargets, tauTargets, result);
//       }


    }
//    else {
//        vector<tFloat> tauTargets, dTargets;
//        tFloat sTarget;
//        generateTargetValuesStopping(reference, sTarget, dTargets, tauTargets, startPoint);
//        generateTrajectoriesStopping(startPoint, reference, sTarget, dTargets, tauTargets, result);
//    }


}

void TrajectoryGenerator::generateTargetValuesDriving(vector<tFloat> &spTargets, vector<tFloat> &dTargets,
                                                      vector<tFloat> &tauTargets) {
    tauTargets.clear();
    for(double t = PLAN_DELTA_TAU; t <= PLAN_MAX_TAU; t+=PLAN_DELTA_TAU) {
        tauTargets.push_back(t);
    }

    spTargets.clear();

//    double t = 0;
//    spTargets.push_back(t);
    
    for(double t = PLAN_SP_MIN; t <= PLAN_SP_MAX; t+=PLAN_DELTA_SP) {
        spTargets.push_back(t);
    }

    dTargets.clear();
    for(double t = PLAN_D_MIN; t <= PLAN_D_MAX; t+=PLAN_DELTA_D) {
        dTargets.push_back(t);
    }
}

void TrajectoryGenerator::generateTargetValuesStopping(RPoints &reference, tFloat &sTarget, vector<tFloat> &dTargets,
                                                       vector<tFloat> &tauTargets, TPoint startPoint) {
    //Determine  distance left to stop
    int i = 0;
    for(i = 0; i < reference.size() && reference.at(i).state == STATE_STOP; i++);
    i = min((int)reference.size() - 1, i);

    sTarget = reference.at(i).length;

    tauTargets.clear();
    double tau = -(4.0*(startPoint.s-sTarget))/startPoint.vel;
    tauTargets.push_back(tau);

    dTargets.clear();
    dTargets.push_back(0.0);
}

void TrajectoryGenerator::generateTrajectoriesDriving(TPoint startPoint,
                                                      RPoints &reference,
                                                      vector<tFloat> &spTargets, vector<tFloat> &dTargets,
                                                      vector<tFloat> &tauTargets,
                                                      vector<vector<vector<TPoints>>> &result) {


    for(int tauIdx = 0; tauIdx < tauTargets.size(); tauIdx++) {
        tFloat tau = tauTargets.at(tauIdx);
        tFloat tau2 = tau*tau;
        tFloat tau3 = tau2 * tau;
        tFloat tau4 = tau3 * tau;
        tFloat tau5 = tau4 * tau;

        Matx33d M10(1, 0, 0,
                        0, 1, 0,
                        0, 0, 2);

        Matx33d M1Tau(1, tau, tau2 ,
                          0, 1  , 2*tau,
                          0, 0  , 2    );

        Matx33d M2Tau(tau3  , tau4   , tau5   ,
                          3*tau2, 4*tau3 , 5*tau4 ,
                          6*tau , 12*tau2, 20*tau3);


        tUInt  MaxSComponentSize = 0;

        vector<vector<tTrajComponentPoint>> sTauTraj;
        generateSComponentsDriving(startPoint, tau, spTargets, M10, M1Tau, M2Tau, MaxSComponentSize, sTauTraj);


        vector<vector<tTrajComponentPoint>> dTauTraj;
        generateDComponents(startPoint, tau, dTargets, M10, M1Tau, M2Tau, MaxSComponentSize, dTauTraj);

        vector<vector<TPoints>> combinedTrajectories;
        combineSDComponents(reference, sTauTraj, dTauTraj, combinedTrajectories);

        result.push_back(combinedTrajectories);
    }
}

void TrajectoryGenerator::generateTrajectoriesStopping(TPoint startPoint,
                                                       RPoints &reference,
                                                       tFloat &sTarget, vector<tFloat> &dTargets,
                                                       vector<tFloat> &tauTargets,
                                                       vector<vector<vector<TPoints>>> &result) {

    for (int tauIdx = 0; tauIdx < tauTargets.size(); tauIdx++) {
        tFloat tau = tauTargets.at(tauIdx);

        tFloat tau2 = tau * tau;
        tFloat tau3 = tau2 * tau;
        tFloat tau4 = tau3 * tau;
        tFloat tau5 = tau4 * tau;

        Matx33d M10(1, 0, 0,
                    0, 1, 0,
                    0, 0, 2);

        Matx33d M1Tau(1, tau, tau2,
                      0, 1, 2 * tau,
                      0, 0, 2);

        Matx33d M2Tau(tau3, tau4, tau5,
                      3 * tau2, 4 * tau3, 5 * tau4,
                      6 * tau, 12 * tau2, 20 * tau3);


        vector<vector<tTrajComponentPoint>> sTauTraj;
        generateSComponentsStopping(startPoint, tau, sTarget, M10, M1Tau, M2Tau, sTauTraj);

        vector<vector<tTrajComponentPoint>> dTauTraj;
        generateDComponentsStopping(startPoint, tau, dTargets, dTauTraj);



        vector<vector<TPoints>> combinedTrajectories;
        combineSDComponents(reference, sTauTraj, dTauTraj, combinedTrajectories);

        result.push_back(combinedTrajectories);


    }

}


void TrajectoryGenerator::generateSComponentsDriving(TPoint startPoint, tFloat targetTau, vector<tFloat> &spTargets, Matx33d M10,
                                                     Matx33d M1Tau, Matx33d M2Tau, tUInt &MaxSComponentSize,
                                                     vector<vector<tTrajComponentPoint>> &result) {


    Matx33d M10Inv = M10.inv();
    Matx22d M2TauInv = M2Tau.get_minor<2,2>(1,0).inv();



    Vec3d xi0(startPoint.s, startPoint.sVel, startPoint.sAcc);

    tFloat c0, c1, c2, c3, c4;

    for(int spIdx = 0; spIdx < spTargets.size(); spIdx++) {


        vector<tTrajComponentPoint> currentSPts;
        Vec3d xiTau(0, spTargets[spIdx], 0);
        
        Vec3d c012 = M10Inv * xi0;

        Vec3d tmp = xiTau  - M1Tau * c012;
        Matx21d c345 = M2TauInv * tmp.get_minor<2,1>(1,0);

        c0 = c012[0];
        c1 = c012[1];
        c2 = c012[2];
        c3 = c345(0,0);
        c4 = c345(0,1);


        int i = 0;
        while(true) {
            tTrajComponentPoint s;
            if(i < PLAN_T_STEPS-1 && timePowers[i][4] <= targetTau){
                s.mov     = c4 * timePowers[i][1] + c3 * timePowers[i][2] + c2 * timePowers[i][3] + c1 * timePowers[i][4] + c0;
                s.vel     = c4 * timePowers[i][6] + c3 * timePowers[i][7] + c2 * timePowers[i][8] + c1;
                s.acc     = c4 * timePowers[i][10] + c3 * timePowers[i][11] + c2*2;
                s.time    = startPoint.time + (tTimeStamp)(timePowers[i][4] * 1000000);
            }
            else{
                s.mov     = currentSPts.back().mov + spTargets[spIdx] * PLAN_T_DELTA;
                s.vel     = spTargets[spIdx];
                s.acc     = 0;
                s.time    = currentSPts.back().time + (tTimeStamp)(PLAN_T_DELTA * 1000000);

            }

            if (s.mov-startPoint.s > PLANNINGLENGTH){
                break;
            }

            if (spTargets[spIdx] < 0.05 && i > PLAN_T_STEPS){
                break;
            }
            currentSPts.push_back(s);

            i++;


           // cout << i << ": mov: " <<  s.mov << " vel: " << s.vel << " acc: " << s.acc << " time: " << s.time << endl;
        }


        //cThread::Sleep(1000000);

            MaxSComponentSize = MAX(MaxSComponentSize, currentSPts.size());

        result.push_back(currentSPts);
    }

   // cout << "finish! MaxSComponentSize:" << MaxSComponentSize << endl;
}

void TrajectoryGenerator::generateDComponents(TPoint startPoint, tFloat targetTau, vector<tFloat> &dTargets, cv::Matx33d M10,
                                              cv::Matx33d M1Tau, cv::Matx33d M2Tau, tUInt MaxSComponentSize,

                                              vector<vector<tTrajComponentPoint>> &result) {
    Matx33d M10Inv = M10.inv();
    Matx33d M2TauInv = M2Tau.inv();

    Vec3d xi0(startPoint.d, startPoint.dVel, startPoint.dAcc);

    tFloat c0, c1, c2, c3, c4, c5;


    for(int dIdx = 0; dIdx < dTargets.size(); dIdx++) {
        vector<tTrajComponentPoint> currentDPts;
        Vec3d xiTau(dTargets[dIdx], 0, 0);

        Vec3d c012 = M10Inv * xi0;

        Vec3d c345 = M2TauInv * (xiTau - M1Tau * c012);

        c0 = c012[0];
        c1 = c012[1];
        c2 = c012[2];
        c3 = c345[0];
        c4 = c345[1];
        c5 = c345[2];

        int i =0;


        while(true){
            tTrajComponentPoint d;
            if(i < PLAN_T_STEPS-1  && timePowers[i][4] <= targetTau){
                d.mov     = c5 * timePowers[i][0] + c4 * timePowers[i][1] + c3 * timePowers[i][2] + c2 * timePowers[i][3] + c1 * timePowers[i][4] + c0;
                d.vel     = c5 * timePowers[i][5] + c4 * timePowers[i][6] + c3 * timePowers[i][7] + c2 * timePowers[i][8] + c1;
                d.acc     = c5 * timePowers[i][9] + c4 * timePowers[i][10] + c3 * timePowers[i][11] + c2*2;
                d.time    = startPoint.time + (tTimeStamp)(timePowers[i][4] * 1000000);
            }
            else{
                d.mov     = dTargets[dIdx];
                d.mov     = dTargets[dIdx];
                d.vel     = 0;
                d.acc     = 0;
                d.time    = currentDPts.back().time + (tTimeStamp)(PLAN_T_DELTA * 1000000);

            }
            currentDPts.push_back(d);

            if (i > MaxSComponentSize){
                break;
            }

            i++;

        }
        result.push_back(currentDPts);

    }

}

void TrajectoryGenerator::generateDComponentsStopping(TPoint startPoint, tFloat targetTau, vector<tFloat> &dTargets,
                                                      vector<vector<tTrajComponentPoint>> &result) {

    tFloat tauVar = targetTau;
    tFloat tauReduce = 0.1 * targetTau;

    while (tauVar > 0)
    {

        tFloat tau2 = tauVar * tauVar;
        tFloat tau3 = tau2 * tauVar;
        tFloat tau4 = tau3 * tauVar;
        tFloat tau5 = tau4 * tauVar;

        Matx33d M10(1, 0, 0,
                    0, 1, 0,
                    0, 0, 2);

        Matx33d M1Tau(1, tauVar, tau2,
                      0, 1, 2 * tauVar,
                      0, 0, 2);

        Matx33d M2Tau(tau3, tau4, tau5,
                      3 * tau2, 4 * tau3, 5 * tau4,
                      6 * tauVar, 12 * tau2, 20 * tau3);



        Matx33d M10Inv = M10.inv();
        Matx33d M2TauInv = M2Tau.inv();

        Vec3d xi0(startPoint.d, startPoint.dVel, startPoint.dAcc);

        tFloat c0, c1, c2, c3, c4, c5;


        for(int dIdx = 0; dIdx < dTargets.size(); dIdx++) {
            vector<tTrajComponentPoint> currentDPts;
            Vec3d xiTau(dTargets[dIdx], 0, 0);

            Vec3d c012 = M10Inv * xi0;

            Vec3d c345 = M2TauInv * (xiTau - M1Tau * c012);

            c0 = c012[0];
            c1 = c012[1];
            c2 = c012[2];
            c3 = c345[0];
            c4 = c345[1];
            c5 = c345[2];


            for(double t = 0; t < targetTau; t +=PLAN_T_DELTA) {
                tTrajComponentPoint d;
                if (t <= tauVar) {
                    d.mov = c5 * t * t * t * t * t + c4 * t * t * t * t + c3 * t * t * t + c2 * t * t + c1 * t + c0;
                    d.vel = c5 * 5 * t * t * t * t + c4 * 4 * t * t * t + c3 * 3 * t * t + c2 * 2 * t + c1;
                    d.acc = c5 * 5 * 4 * t * t * t + c4 * 4 * 3 * t * t + c3 * 3 * 2 * t + c2 * 2;
                }
                else {
                    d.mov = 0;
                    d.vel = 0;
                    d.acc = 0;
                }
                d.time = startPoint.time + (tTimeStamp) (t * 1000000);


                currentDPts.push_back(d);
            }
            result.push_back(currentDPts);
        }

        tauVar -= tauReduce;
    }
}

void TrajectoryGenerator::combineSDComponents(RPoints &reference, vector<vector<tTrajComponentPoint>> sTauTraj,
                                              vector<vector<tTrajComponentPoint>> dTauTraj, vector<vector<TPoints>> &result) {

    // Fill the result vector with empty space, so that we can push the points later.
    for(int sIdx = 0; sIdx < sTauTraj.size(); sIdx++) {
        vector<TPoints> sResult;
        sResult.reserve(dTauTraj.size());
        for(int dIdx = 0; dIdx < dTauTraj.size(); dIdx++) {
            TPoints dResult;
            sResult.push_back(dResult);
        }
        result.push_back(sResult);
    }

    for(int sIdx = 0; sIdx < sTauTraj.size(); sIdx++) {

        int refIndex = 0;
        for(int tIdx = 0; tIdx < sTauTraj[sIdx].size(); tIdx++) {
            tTrajComponentPoint currentS = sTauTraj[sIdx][tIdx];

            // Find the reference point to work on
            tBool foundPoint = false;
            while(refIndex+1 < reference.size()) {
                if(reference[refIndex+1].length < currentS.mov) {
                    refIndex++;
                    continue;
                }
                foundPoint = true;
                break;
            }
            // If we didnt find a reference point because it was too short, we break out of the loop.
            if(!foundPoint) {
                break;
            }



            RPoint currentRef = reference[refIndex];
            RPoint nextRef = reference[refIndex+1];

            tFloat deltaS = currentS.mov - currentRef.length;
            tFloat deltaL = nextRef.length - currentRef.length;
            tFloat deltaKappa = nextRef.kappa - currentRef.kappa;
            tFloat deltaKappaDash = nextRef.kappaDash - currentRef.kappaDash;

            tFloat tanX = (nextRef.x - currentRef.x) / deltaL;
            tFloat tanY = (nextRef.y - currentRef.y) / deltaL;

            tFloat interpolatedXOnRef = currentRef.x + tanX * deltaS;
            tFloat interpolatedYOnRef = currentRef.y + tanY * deltaS;
            tFloat interpolatedKappa = currentRef.kappa + (deltaKappa / deltaL) * deltaS;
            tFloat interpolatedKappaDash = currentRef.kappaDash + (deltaKappaDash / deltaL) * deltaS;

            tFloat normalX = -tanY;
            tFloat normalY = tanX;


            for(int dIdx = 0; dIdx < dTauTraj.size(); dIdx++) {
                tTrajComponentPoint currentD = dTauTraj[dIdx][tIdx];
                TPoint tPoint;
                tPoint.x = interpolatedXOnRef + normalX * currentD.mov;
                tPoint.y = interpolatedYOnRef + normalY * currentD.mov;
                tPoint.kappa = interpolatedKappa;
                tPoint.s = currentS.mov;
                tPoint.d = currentD.mov;
                tPoint.vel = sqrt((1-currentRef.kappa*currentD.mov)*(1-currentRef.kappa*currentD.mov)*currentS.vel*currentS.vel+currentD.vel*currentD.vel);
                // TODO: Compute Acceleration in a nicer way
                tPoint.acc = sqrt(currentS.acc*currentS.acc + currentD.acc*currentD.acc);

                if(currentS.acc < 0)
                    tPoint.acc *= -1;

                tPoint.sVel = currentS.vel;
                tPoint.dVel = currentD.vel;
                tPoint.sAcc = currentS.acc;
                tPoint.dAcc = currentD.acc;

                tPoint.theta = currentRef.theta;
                tPoint.rIndex = currentRef.rIndex;
                tPoint.lights = currentRef.lights;
                tPoint.time = currentD.time;

                //if(abs(currentD.mov) > 0.01) {
                    tFloat dDash = 0;
                    if(currentS.vel > 0) {
                        dDash = currentD.vel / currentS.vel;
                    }

                    tFloat dDashDash = 0;
                    if(currentS.vel > 0) {
                        dDashDash = (currentD.acc - dDash*currentS.acc)/(currentS.vel*currentS.vel);
                    }

                    if(abs(currentD.mov * interpolatedKappa - 1) > 0.001) {
//                        tFloat deltaTheta = atan2(dDash , (currentD.mov * interpolatedKappa - 1));
//                        cout << "delaTheta: " << deltaTheta << endl;
//
//
//                        tPoint.theta += deltaTheta;

//                        tPoint.kappa = (pow(cos(deltaTheta),3) * (dDashDash + dDash * interpolatedKappa + currentD.mov * interpolatedKappaDash
//                                                  - ((interpolatedKappa * (currentD.mov*interpolatedKappa-1))/pow(cos(deltaTheta),2))))/pow(currentD.mov * interpolatedKappa -1,2);
                    }
//              }

                result.at(sIdx).at(dIdx).push_back(tPoint);
            }
        }
    }
}


void TrajectoryGenerator::generateSComponentsStopping(TPoint startPoint, tFloat targetTau, tFloat &sTarget, Matx33d M10,
                                                      Matx33d M1Tau, Matx33d M2Tau,
                                                      vector<vector<tTrajComponentPoint>> &result) {


    double v0 = startPoint.vel;
    double sTau = sTarget;
    double s0 = startPoint.s;



    double c1 = (0.375*v0*v0*v0)/pow(s0-sTau,2);

    double c2 = (0.046875*v0*v0*v0*v0)/pow(s0-sTau,3);

    double tau = -(4.0*(s0-sTau))/v0;

    double a0 = (0.75*v0*v0)/(s0-sTau);

    vector<tTrajComponentPoint> currentSPts;

    for(double t = 0; t < tau; t +=PLAN_T_DELTA) {
        tTrajComponentPoint s;
        s.mov     = (1.0/12.0) * c2 * t*t*t*t + (1.0/6.0) * c1 * t*t*t + 0.5 * a0 * t*t + v0 * t + s0;
        s.vel     = (1.0/3.0) * c2 * t*t*t + (1.0/2.0) * c1 * t*t + a0*t + v0;
        s.acc     = c2*t*t + c1*t + a0;
        s.time    = startPoint.time + (tTimeStamp)(t * 1000000);


        currentSPts.push_back(s);
    }
    result.push_back(currentSPts);
}


void TrajectoryGenerator::generateTrajectoriesDrivingWAYMODE(TPoint startPoint, RPoints &reference, vector<tFloat> &spTargets,
                                                             vector<tFloat> &dTargets, vector<tFloat> &tauTargets,
                                                             vector<vector<vector<TPoints>>> &result)  {


    for(int tauIdx = 0; tauIdx < tauTargets.size(); tauIdx++) {
        tFloat tau = tauTargets.at(tauIdx);
        tFloat tau2 = tau*tau;
        tFloat tau3 = tau2 * tau;
        tFloat tau4 = tau3 * tau;
        tFloat tau5 = tau4 * tau;

        Matx33d M10(1, 0, 0,
                    0, 1, 0,
                    0, 0, 2);

        Matx33d M1Tau(1, tau, tau2 ,
                      0, 1  , 2*tau,
                      0, 0  , 2    );

        Matx33d M2Tau(tau3  , tau4   , tau5   ,
                      3*tau2, 4*tau3 , 5*tau4 ,
                      6*tau , 12*tau2, 20*tau3);


        tUInt  MaxSComponentSize = 0;

        vector<vector<tTrajComponentPoint>> sTauTrajs;
        vector<tFloat> resultingSTargets;
        generateSComponentsDrivingWAYMODE(startPoint, tau, spTargets, M10, M1Tau, M2Tau, MaxSComponentSize, resultingSTargets, sTauTrajs);


        // s // d
        vector<vector<vector<tTrajComponentPoint>>> dTauTrajOnSTrajs;
        generateDComponentsWAYMODE(startPoint, tau, dTargets, M1Tau, M2Tau, MaxSComponentSize, resultingSTargets, sTauTrajs, dTauTrajOnSTrajs);


        vector<vector<TPoints>> combinedTrajectories;
        combineSDComponentsWAYMODE(reference, sTauTrajs, dTauTrajOnSTrajs, combinedTrajectories);


        result.push_back(combinedTrajectories);
    }
}



void TrajectoryGenerator::generateDComponentsWAYMODE(TPoint startPoint, tFloat targetTau, vector<tFloat> &dTargets,
                                                     cv::Matx33d M1Tau, cv::Matx33d M2Tau, tUInt &MaxSComponentSize,
                                                     vector<tFloat> &resultingSTargets,
                                                     vector<vector<tTrajComponentPoint>> &sTauTraj,
                                                     vector<vector<vector<tTrajComponentPoint>>> &result)  {

    tFloat sStart = startPoint.s;

    Matx33d M10(1, sStart, sStart*sStart,
                0, 1, 2*sStart,
                0, 0, 2);

    Matx33d M10Inv = M10.inv();


    tFloat dDashStart = 0;
    if(startPoint.sVel > 0) {
        dDashStart = startPoint.dVel / startPoint.sVel;
    }

    tFloat dDashDashStart = 0;
    if(startPoint.sVel > 0) {
        dDashDashStart = (startPoint.dAcc - dDashStart*startPoint.sAcc)/(startPoint.sVel*startPoint.sVel);
    }

    Vec3d xi0(startPoint.d, dDashStart, dDashDashStart);

    tFloat c0, c1, c2, c3, c4, c5;


    for (int sIdx = 0; sIdx < resultingSTargets.size(); sIdx++){

        vector<vector<tTrajComponentPoint>> currentDPtsOnSPts;

        tFloat sEnd = resultingSTargets[sIdx];
        tFloat sEnd2 = sEnd*sEnd;
        tFloat sEnd3 = sEnd2 * sEnd;
        tFloat sEnd4 = sEnd2 * sEnd2;
        tFloat sEnd5 = sEnd4 * sEnd;

        Matx33d M1End(1, sEnd, sEnd2 ,
                      0, 1  , 2*sEnd,
                      0, 0  , 2    );

        Matx33d M2End(sEnd3  , sEnd4   , sEnd5   ,
                      3*sEnd2, 4*sEnd3 , 5*sEnd4 ,
                      6*sEnd , 12*sEnd2, 20*sEnd3);

        Matx33d M2EndInv = M2End.inv();

        for(int dIdx = 0; dIdx < dTargets.size(); dIdx++) {
            vector<tTrajComponentPoint> currentDPts;
            Vec3d xiTau(dTargets[dIdx], 0, 0);

            Vec3d c012 = M10Inv * xi0;

            Vec3d c345 = M2EndInv * (xiTau - M1Tau * c012);

            c0 = c012[0];
            c1 = c012[1];
            c2 = c012[2];
            c3 = c345[0];
            c4 = c345[1];
            c5 = c345[2];


            for (int i=0; i < sTauTraj[sIdx].size(); i++){
                tTrajComponentPoint d;

                tFloat cS = sTauTraj[sIdx][i].mov;
                tFloat cS2 = cS*cS;
                tFloat cS3 = cS*cS2;
                tFloat cS4 = cS*cS3;
                tFloat cS5 = cS*cS4;

                tFloat cSp = sTauTraj[sIdx][i].vel;
                tFloat cSpp = sTauTraj[sIdx][i].acc;

                tFloat curDDash, curDDashDash;

                if(cS <= sEnd){
                    d.mov     = c5*cS5 + c4*cS4 + c3*cS3 + c2*cS2 + c1*cS + c0;

                    curDDash = c5*5.0*cS4 + c4*4.0*cS3 + c3*3.0*cS2 + c2*cS + c1;
                    d.vel     =  cSp * curDDash;

                    curDDashDash = c5*5.0*4.0*cS3 + c4*4.0*3.0*cS2 + c3*3.0*2.0*cS + c2*2.0;
                    d.acc     = cSpp * curDDash + cSp*cSp*curDDashDash;
                }
                else{
                    d.mov     = dTargets[dIdx];
                    d.vel     = 0;
                    d.acc     = 0;
                }
                d.time    = sTauTraj[sIdx][i].time;
                currentDPts.push_back(d);
                // cout << i << ": Dmov: " <<  d.mov << " Dvel: " << d.vel << " Dacc: " << d.acc << " Dtime: " << d.time << endl;


            }

            currentDPtsOnSPts.push_back(currentDPts);


        }

        result.push_back(currentDPtsOnSPts);
    }



}

void TrajectoryGenerator::generateSComponentsDrivingWAYMODE(TPoint startPoint, tFloat targetTau, vector<tFloat> &spTargets, cv::Matx33d M10,
                                                            cv::Matx33d M1Tau, cv::Matx33d M2Tau, tUInt &MaxSComponentSize,
                                                            vector<tFloat> &resultingSTargets,
                                                            vector<vector<tTrajComponentPoint>> &result) {


    Matx33d M10Inv = M10.inv();
    Matx22d M2TauInv = M2Tau.get_minor<2,2>(1,0).inv();



    Vec3d xi0(startPoint.s, startPoint.sVel, startPoint.sAcc);

    tFloat c0, c1, c2, c3, c4;

    for(int spIdx = 0; spIdx < spTargets.size(); spIdx++) {


        vector<tTrajComponentPoint> currentSPts;
        Vec3d xiTau(0, spTargets[spIdx], 0);

        Vec3d c012 = M10Inv * xi0;

        Vec3d tmp = xiTau  - M1Tau * c012;
        Matx21d c345 = M2TauInv * tmp.get_minor<2,1>(1,0);

        c0 = c012[0];
        c1 = c012[1];
        c2 = c012[2];
        c3 = c345(0,0);
        c4 = c345(0,1);

        tFloat currentMaxS;
        int i = 0;
        while(true) {
            tTrajComponentPoint s;
            if(i < PLAN_T_STEPS-1 && timePowers[i][4] <= targetTau){
                s.mov     = c4 * timePowers[i][1] + c3 * timePowers[i][2] + c2 * timePowers[i][3] + c1 * timePowers[i][4] + c0;
                currentMaxS = s.mov;
                s.vel     = c4 * timePowers[i][6] + c3 * timePowers[i][7] + c2 * timePowers[i][8] + c1;
                s.acc     = c4 * timePowers[i][10] + c3 * timePowers[i][11] + c2*2;
                s.time    = startPoint.time + (tTimeStamp)(timePowers[i][4] * 1000000);
            }
            else{
                s.mov     = currentSPts.back().mov + spTargets[spIdx] * PLAN_T_DELTA;
                s.vel     = spTargets[spIdx];
                s.acc     = 0;
                s.time    = currentSPts.back().time + (tTimeStamp)(PLAN_T_DELTA * 1000000);

            }

            if (s.mov-startPoint.s > PLANNINGLENGTH){
                break;
            }

            if (spTargets[spIdx] < 0.05 && i > PLAN_T_STEPS){
                break;
            }
            currentSPts.push_back(s);

            i++;


            // cout << i << ": mov: " <<  s.mov << " vel: " << s.vel << " acc: " << s.acc << " time: " << s.time << endl;
        }

        resultingSTargets.push_back(currentMaxS);

//        cThread::Sleep(1000000);
//
//        cout << "currentMaxS: " << currentMaxS << " targetTau: " << targetTau << endl;



        MaxSComponentSize = MAX(MaxSComponentSize, currentSPts.size());

        result.push_back(currentSPts);
    }

    // cout << "finish! MaxSComponentSize:" << MaxSComponentSize << endl;

}

void TrajectoryGenerator::combineSDComponentsWAYMODE(RPoints &reference, vector<vector<tTrajComponentPoint>> sTauTraj,
        vector<vector<vector<tTrajComponentPoint>>> dTauTraj, vector<vector<TPoints>> &result) {

    // Fill the result vector with empty space, so that we can push the points later.
    for(int sIdx = 0; sIdx < sTauTraj.size(); sIdx++) {
        vector<TPoints> sResult;
        sResult.reserve(dTauTraj.size());
        for(int dIdx = 0; dIdx < dTauTraj[sIdx].size(); dIdx++) {
            TPoints dResult;
            sResult.push_back(dResult);
        }
        result.push_back(sResult);
    }

    for(int sIdx = 0; sIdx < sTauTraj.size(); sIdx++) {

        int refIndex = 0;
        for(int tIdx = 0; tIdx < sTauTraj[sIdx].size(); tIdx++) {
            tTrajComponentPoint currentS = sTauTraj[sIdx][tIdx];

            // Find the reference point to work on
            tBool foundPoint = false;
            while(refIndex+1 < reference.size()) {
                if(reference[refIndex+1].length < currentS.mov) {
                    refIndex++;
                    continue;
                }
                foundPoint = true;
                break;
            }
            // If we didnt find a reference point because it was too short, we break out of the loop.
            if(!foundPoint) {
                break;
            }



            RPoint currentRef = reference[refIndex];
            RPoint nextRef = reference[refIndex+1];

            tFloat deltaS = currentS.mov - currentRef.length;
            tFloat deltaL = nextRef.length - currentRef.length;
            tFloat deltaKappa = nextRef.kappa - currentRef.kappa;
            tFloat deltaKappaDash = nextRef.kappaDash - currentRef.kappaDash;

            tFloat tanX = (nextRef.x - currentRef.x) / deltaL;
            tFloat tanY = (nextRef.y - currentRef.y) / deltaL;

            tFloat interpolatedXOnRef = currentRef.x + tanX * deltaS;
            tFloat interpolatedYOnRef = currentRef.y + tanY * deltaS;
            tFloat interpolatedKappa = currentRef.kappa + (deltaKappa / deltaL) * deltaS;
            tFloat interpolatedKappaDash = currentRef.kappaDash + (deltaKappaDash / deltaL) * deltaS;

            tFloat normalX = -tanY;
            tFloat normalY = tanX;


            for(int dIdx = 0; dIdx < dTauTraj[sIdx].size(); dIdx++) {
                tTrajComponentPoint currentD = dTauTraj[sIdx][dIdx][tIdx];
                TPoint tPoint;
                tPoint.x = interpolatedXOnRef + normalX * currentD.mov;
                tPoint.y = interpolatedYOnRef + normalY * currentD.mov;
                tPoint.kappa = interpolatedKappa;
                tPoint.s = currentS.mov;
                tPoint.d = currentD.mov;
                tPoint.vel = sqrt((1-currentRef.kappa*currentD.mov)*(1-currentRef.kappa*currentD.mov)*currentS.vel*currentS.vel+currentD.vel*currentD.vel);
                // TODO: Compute Acceleration in a nicer way
                tPoint.acc = sqrt(currentS.acc*currentS.acc + currentD.acc*currentD.acc);

                if(currentS.acc < 0)
                    tPoint.acc *= -1;

                tPoint.sVel = currentS.vel;
                tPoint.dVel = currentD.vel;
                tPoint.sAcc = currentS.acc;
                tPoint.dAcc = currentD.acc;

                tPoint.theta = currentRef.theta;
                tPoint.rIndex = currentRef.rIndex;
                tPoint.time = currentD.time;

                //if(abs(currentD.mov) > 0.01) {
                tFloat dDash = 0;
                if(currentS.vel > 0) {
                    dDash = currentD.vel / currentS.vel;
                }

                tFloat dDashDash = 0;
                if(currentS.vel > 0) {
                    dDashDash = (currentD.acc - dDash*currentS.acc)/(currentS.vel*currentS.vel);
                }

                if(abs(currentD.mov * interpolatedKappa - 1) > 0.001) {
//                    tFloat deltaTheta = atan2(dDash , (currentD.mov * interpolatedKappa - 1));
//                    tPoint.theta += deltaTheta;

//                    tPoint.kappa = (pow(cos(deltaTheta),3) * (dDashDash + dDash * interpolatedKappa + currentD.mov * interpolatedKappaDash
//                                                              - ((interpolatedKappa * (currentD.mov*interpolatedKappa-1))/pow(cos(deltaTheta),2))))/pow(currentD.mov * interpolatedKappa -1,2);
                }


                result.at(sIdx).at(dIdx).push_back(tPoint);
            }
        }
    }
}
