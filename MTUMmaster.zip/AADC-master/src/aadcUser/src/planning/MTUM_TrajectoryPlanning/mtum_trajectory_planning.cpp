/**
Copyright (c)
Audi Autonomous Driving Cup. Team MomenTUM. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
3.  All advertising materials mentioning features or use of this software must display the following acknowledgement: "This product includes software developed by the Audi AG and its contributors for Audi Autonomous Driving Cup."
4.  Neither the name of Audi nor the names of its contributors may be used to endorse or promote products derived from this software without speciđffc prior written permission.

THIS SOFTWARE IS PROVIDED BY AUDI AG AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL AUDI AG OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


**********************************************************************
* $Author:: MomenTUM#$  $Date:: 2015-10-10 15:10:07#$ $Rev:: 35043   $
**********************************************************************/

#include "stdafx.h"
#include "mtum_trajectory_planning.h"
#include "SignalValueType.h"
#include "StatusMessage.h"
#include "ReferencePointsType.h"
#include "PlanningUtils.h"
#include "DynamicControlValueType.h"

/// Create filter shell
ADTF_FILTER_PLUGIN("MTUM Trajectory Planning", OID_ADTF_MTUM_TRAJECTORY_PLANNING_FILTER, cTrajectoryPlanningFilter);


cTrajectoryPlanningFilter::cTrajectoryPlanningFilter(const tChar *__info) : cFilter(__info), m_FilterCore(this) {
    SetPropertyFloat("start_velocity in s direction", 0);
    SetPropertyFloat("max_velocity in s direction", 2);
    SetPropertyFloat("max_acceleration in s direction", 2);

    SetPropertyFloat("max_velocity in d direction", 1);
    SetPropertyFloat("max_acceleration in d direction", 1.2);

    SetPropertyFloat("planning_length", 2.5);
    SetPropertyFloat("boundary velocity", 0);

    //define Properties globally
    SetPropertyInt("Max front distance", 400);
    SetPropertyStr("Max front distance" NSSUBPROP_GLOBALCONFIGPROPERTYNAME, "Map front distance");
    SetPropertyStr("Max front distance" NSSUBPROP_GLOBALCONFIGPROPERTYNAME NSSUBPROP_DESCRIPTION,
                   "The distance in front of the vehicle in centimeters");

    SetPropertyInt("Max right distance", 300);
    SetPropertyStr("Max right distance" NSSUBPROP_GLOBALCONFIGPROPERTYNAME, "Map right distance");
    SetPropertyStr("Max right distance" NSSUBPROP_GLOBALCONFIGPROPERTYNAME NSSUBPROP_DESCRIPTION,
                   "The distance right of the vehicle in centimeters");

    SetPropertyInt("Max left distance", 200);
    SetPropertyStr("Max left distance" NSSUBPROP_GLOBALCONFIGPROPERTYNAME, "Map left distance");
    SetPropertyStr("Max left distance" NSSUBPROP_GLOBALCONFIGPROPERTYNAME NSSUBPROP_DESCRIPTION,
                   "The distance left of the vehicle in centimeters");

    SetPropertyInt("Max rear distance", 300);
    SetPropertyStr("Max rear distance" NSSUBPROP_GLOBALCONFIGPROPERTYNAME, "Map rear distance");
    SetPropertyStr("Max rear distance" NSSUBPROP_GLOBALCONFIGPROPERTYNAME NSSUBPROP_DESCRIPTION,
                   "The distance behind of the vehicle in centimeters");

    SetPropertyInt("max_lane_points", 5000);

    PlanningUtils::get().SetParent(this);
}

cTrajectoryPlanningFilter::~cTrajectoryPlanningFilter() {

}

tResult cTrajectoryPlanningFilter::Init(tInitStage eStage, __exception) {
    // never miss calling the parent implementation!!
    RETURN_IF_FAILED(cFilter::Init(eStage, __exception_ptr))

    // in StageFirst you can create and register your static pins.
    if (eStage == StageFirst) {
        RETURN_IF_FAILED(CreatePins(__exception_ptr));
    }
    else if (eStage == StageNormal) {
        tInt distRear = GetPropertyInt("Max rear distance");
        tInt distFront = GetPropertyInt("Max front distance");
        tInt distLeft = GetPropertyInt("Max left distance");
        tInt distRight = GetPropertyInt("Max right distance");
        tUInt max_lane_points = GetPropertyInt("max_lane_points");

        //set the videoformat of the rgb video pin
        m_sDebugFormat.nWidth = 500;
        m_sDebugFormat.nHeight = 500;
        m_sDebugFormat.nBitsPerPixel = 24;
        m_sDebugFormat.nPixelFormat = cImage::PF_RGB_888;
        m_sDebugFormat.nBytesPerLine = m_sDebugFormat.nWidth * 3;
        m_sDebugFormat.nSize = m_sDebugFormat.nBytesPerLine * m_sDebugFormat.nHeight;
        m_sDebugFormat.nPaletteSize = 0;
        m_oDebug.SetFormat(&m_sDebugFormat, NULL);
        m_oDebug2.SetFormat(&m_sDebugFormat, NULL);

        dropLaneUpdates = false;


        m_FilterCore.SetProperties(distRear, distFront, distLeft, distRight, max_lane_points);
    }
    else if (eStage == StageGraphReady) {
        m_FilterCore.Create();
    }

    RETURN_NOERROR;
}

tResult cTrajectoryPlanningFilter::Start(__exception) {
    RETURN_IF_FAILED(cFilter::Start(__exception_ptr));

    RETURN_NOERROR;
}

tResult cTrajectoryPlanningFilter::Stop(__exception) {
    RETURN_IF_FAILED(cFilter::Stop(__exception_ptr));

    m_FilterCore.Suspend();

    RETURN_NOERROR;
}

tResult cTrajectoryPlanningFilter::Shutdown(tInitStage eStage, __exception) {
    // In each stage clean up everything that you initiaized in the corresponding stage during Init.
    // Pins are an exception: 
    // - The base class takes care of static pins that are members of this class.
    // - Dynamic pins have to be cleaned up in the ReleasePins method, please see the demo_dynamicpin
    //   example for further reference.
    if (eStage == StageGraphReady) {
        m_FilterCore.Terminate(true);
        m_FilterCore.Release();

        RETURN_IF_FAILED(m_pLaneQueue->Clear());
        RETURN_IF_FAILED(m_pOdometryQueue->Clear());
    }
    else if (eStage == StageNormal) {
    }
    else if (eStage == StageFirst) {
        m_pLaneQueue = NULL;
        m_pOdometryQueue = NULL;
    }

    // call the base class implementation
    return cFilter::Shutdown(eStage, __exception_ptr);
}

tResult cTrajectoryPlanningFilter::OnPinEvent(IPin *pSource,
                                              tInt nEventCode,
                                              tInt nParam1,
                                              tInt nParam2,
                                              IMediaSample *pMediaSample) {
    // first check what kind of event it is
    if (nEventCode == IPinEventSink::PE_MediaSampleReceived) {
        // so we received a media sample, so this pointer better be valid.
        RETURN_IF_POINTER_NULL(pMediaSample);

        // by comparing it to our member pin variable we can find out which pin received
        // the sample
        if (pSource == &m_oStatusInput) {
            DecodeStatusMessage(pMediaSample);
        } else if (pSource == &m_laneInput) {
            //__sample_read_lock(pMediaSample, tLaneStruct, pData);

            //m_FilterCore.UpdateLane(*pData);


        } else if (pSource == &m_odometry) {

        }
        else if (pSource == &m_oMapInput) {


            m_FilterCore.m_MapMutex.Enter();

            //creating new pointer for input data
            const tVoid *l_pSrcBuffer;

            //receiving data from input sample, and saving to inputFrame
            if (IS_OK(pMediaSample->Lock(&l_pSrcBuffer))) {
                //creating the matrix with the data
                m_FilterCore.m_ObstacaleMap = Mat(m_sMapInputFormat.nHeight, m_sMapInputFormat.nWidth, CV_8UC1,
                                                  (tVoid *) l_pSrcBuffer, m_sMapInputFormat.nBytesPerLine);

                m_FilterCore.hasMap = true;
                //TODO: alternative solution -> copy Mat?

                pMediaSample->Unlock(l_pSrcBuffer);
            }
            m_FilterCore.m_MapMutex.Leave();
        }
    }
    else if (nEventCode == IPinEventSink::PE_MediaTypeChanged) {
        if (pSource == &m_oMapInput) {
            //the input format was changed, so the imageformat has to changed in this filter also
            cObjectPtr<IMediaType> pType;
            RETURN_IF_FAILED(m_oMapInput.GetMediaType(&pType));

            cObjectPtr<IMediaTypeVideo> pTypeVideo;
            RETURN_IF_FAILED(pType->GetInterface(IID_ADTF_MEDIA_TYPE_VIDEO, (tVoid **) &pTypeVideo));

            const tBitmapFormat *pNewFormat = m_oMapInput.GetFormat();
            if (pNewFormat != NULL) {
                m_sMapInputFormat = (*pNewFormat);
                LOG_INFO("Low Level Controller: ObstacleMap format was changed!");
            }
        }
    }

    RETURN_NOERROR;
}

tResult cTrajectoryPlanningFilter::GetLaneData(tLaneStruct &lanestruct) {
    if (dropLaneUpdates) {
        m_pLaneQueue->Clear();
        cout << "Clear lane queue" << endl;
        RETURN_ERROR(ERR_EMPTY);
    }

    cObjectPtr<IMediaSample> pSample = NULL;
    if (IS_OK(m_pLaneQueue->Pop(&pSample))) {
        __sample_read_lock(pSample, tLaneStruct, pData);

        lanestruct = *pData;

        cObjectPtr<IMediaSample> pOdoSample = NULL;
        if (IS_OK(m_pOdometryQueue->Get(&pOdoSample, pSample->GetTime(), 1000000, ISampleQueue::SQG_GetNearest))) {
            __sample_read_lock(pOdoSample, tOdometryData, pOdoData);
            PlanningUtils::get().SetOdo(*pOdoData);
        }

        RETURN_NOERROR;
    }
    RETURN_ERROR(ERR_EMPTY);
}

tResult cTrajectoryPlanningFilter::SetOdoTimeToNow() {
    cObjectPtr<IMediaSample> pOdoSample = NULL;
    if (IS_OK(m_pOdometryQueue->Get(&pOdoSample, getTime(), 1000000, ISampleQueue::SQG_GetNewest))) {
        __sample_read_lock(pOdoSample, tOdometryData, pOdoData);
        PlanningUtils::get().SetOdo(*pOdoData);
    }

    RETURN_NOERROR;

}

tResult cTrajectoryPlanningFilter::SendStatusMessage(mtum_filters destination, mtum_status_messages content) {
    // now we need a new media sample to forward the data.
    cObjectPtr<IMediaSample> pNewSample;
    if (IS_OK(AllocMediaSample(&pNewSample))) {
        // now set its data
        // we reuse the timestamp from the incoming media sample. Please see the api documentation
        // (ADTF Extreme Programmers -> The ADTF Streamtime) for further reference on how sample times are handled in ADTF
        tStatusMessage message;
        message.source = mtum_filters(CAR_CONTROL);
        message.destination = mtum_filters(destination);
        message.content = mtum_status_messages(content);
        pNewSample->Update(_clock->GetStreamTime(), &message, sizeof(tStatusMessage), 0);

        // and now we can transmit it
        m_oStatusOutput.Transmit(pNewSample);
    }

    RETURN_NOERROR;
}

tResult cTrajectoryPlanningFilter::SendTargetTrajectory(tReferencePoints &points) {
    // now we need a new media sample to forward the data.
    cObjectPtr<IMediaSample> pNewSample;
    if (IS_OK(AllocMediaSample(&pNewSample))) {
        // now set its data
        // we reuse the timestamp from the incoming media sample. Please see the api documentation
        // (ADTF Extreme Programmers -> The ADTF Streamtime) for further reference on how sample times are handled in ADTF
        tReferencePoints data;
        data = points;
        pNewSample->Update(_clock->GetStreamTime(), &data, sizeof(tReferencePoints), 0);

        // and now we can transmit it
        m_oTargetTrajectory.Transmit(pNewSample);
    }

    RETURN_NOERROR;
}

tResult cTrajectoryPlanningFilter::SendSteering(double steering, double speed, tUInt8 lights) {
    // now we need a new media sample to forward the data.
    steering = MAX(MIN(steering,1.2), -1.2);

    cObjectPtr<IMediaSample> pNewSample;
    if (IS_OK(AllocMediaSample(&pNewSample))) {
        tDynamicControlValue data;
        data.setPointCurvature = steering;
        data.setPointSpeed = speed;
        data.setPointAcceleration = 0;
        data.LightFlags = lights;

        pNewSample->Update(_clock->GetStreamTime(), &data, sizeof(tDynamicControlValue), 0);

        // d now we can transmit it
        m_oReferenceTrajectory.Transmit(pNewSample);
    }

    RETURN_NOERROR;
}

tResult cTrajectoryPlanningFilter::DecodeStatusMessage(IMediaSample *pMediaSample) {
    // this will store the value for our new sample
    tStatusMessage status_message;

    // now lets access the data in the sample,
    // the Lock method gives you access to the buffer of the sample.
    // we use a scoped sample lock to ensure that the lock is released in all circumstances.

    {
        // this will aquire the read lock on the sample and declare and initialize a pointer to the data
        __sample_read_lock(pMediaSample, tStatusMessage, pData);
        // now we can access the sample data through the pointer
        status_message = *pData;
        // the read lock on the sample will be released when leaving this scope
    }

    if (status_message.destination == mtum_filters(PLANNING) || status_message.destination == mtum_filters(ALL)) {

        switch (mtum_status_messages(status_message.content)) {
            case SET_INACTIVE:
                m_FilterCore.Status_SetInactive();
                m_FilterCore.Suspend();
                break;
            case SET_ACTIVE:
                m_FilterCore.Run();
                break;
            case IS_READY:
                m_FilterCore.Status_IsReady();
                break;
            case RESET:
                m_FilterCore.Status_Reset();
                dropLaneUpdates = false;
                break;
            case MANEUVER_GO_STRAIGHT:
                m_FilterCore.SetManeuver(TurningMode(STRAIGHT));
                m_FilterCore.Run();
                break;
            case MANEUVER_TURN_LEFT:
                m_FilterCore.SetManeuver(TurningMode(LEFT));
                m_FilterCore.Run();
                break;
            case MANEUVER_TURN_RIGHT:
                m_FilterCore.SetManeuver(TurningMode(RIGHT));
                m_FilterCore.Run();
                break;
            case MANEUVER_PARK_CROSS:
            case MANEUVER_PARK_PARALLEL:
                m_FilterCore.SetManeuver(TurningMode(UNKNOWN));
                m_FilterCore.Run();
                break;
            case MANEUVER_PULL_OUT_LEFT:
            case MANEUVER_PULL_OUT_RIGHT:
                m_FilterCore.Status_Reset();
                m_pLaneQueue->Clear();
                m_FilterCore.Suspend();
                break;

            case LL_EMERGENCY_STOP:
                dropLaneUpdates = true;
                cout << "We are now in a emergency stop" << endl;
                break;

            case LL_EMERGENCY_STOP_FREE:
                dropLaneUpdates = false;
                cout << "We are now not in a emergency stop" << endl;
                break;
            default:
                break;
        }
    }

    RETURN_NOERROR;
}

tResult cTrajectoryPlanningFilter::SendDebug(cv::Mat debug) {
    cObjectPtr<IMediaSample> pNewSample;
    if (IS_OK(AllocMediaSample(&pNewSample))) {
        pNewSample->Update(_clock->GetStreamTime(), debug.data, m_sDebugFormat.nSize, 0);
        m_oDebug.Transmit(pNewSample);
    }
    RETURN_NOERROR;
}

tResult cTrajectoryPlanningFilter::SendDebug2(cv::Mat debug) {
    cObjectPtr<IMediaSample> pNewSample;
    if (IS_OK(AllocMediaSample(&pNewSample))) {
        pNewSample->Update(_clock->GetStreamTime(), debug.data, m_sDebugFormat.nSize, 0);
        m_oDebug2.Transmit(pNewSample);
    }
    RETURN_NOERROR;
}

tUInt64 cTrajectoryPlanningFilter::getTime() {
    return _clock->GetStreamTime();
}

tResult cTrajectoryPlanningFilter::CreatePins(__exception) {
    // create and register the status-input pin
    RETURN_IF_FAILED(m_oStatusInput.Create("status_input", new cMediaType(0, 0, 0, STATUSMESSAGE), this));
    RETURN_IF_FAILED(RegisterPin(&m_oStatusInput));

    // create and register the output pin
    RETURN_IF_FAILED(m_oStatusOutput.Create("status_output", new cMediaType(0, 0, 0, STATUSMESSAGE), this));
    RETURN_IF_FAILED(RegisterPin(&m_oStatusOutput));

    RETURN_IF_FAILED(
            m_oReferenceTrajectory.Create("dynamic_control", new cMediaType(0, 0, 0, DYNAMICCONTROLVALUE), this));
    RETURN_IF_FAILED(RegisterPin(&m_oReferenceTrajectory));

    RETURN_IF_FAILED(m_oTargetTrajectory.Create("target_trajectory", new cMediaType(0, 0, 0, REFERENCEPOINTS), this));
    RETURN_IF_FAILED(RegisterPin(&m_oTargetTrajectory));

    RETURN_IF_FAILED(m_oDebug.Create("debug", IPin::PD_Output, static_cast<IPinEventSink *>(this)));
    RETURN_IF_FAILED(RegisterPin(&m_oDebug));

    RETURN_IF_FAILED(m_oDebug2.Create("debug2", IPin::PD_Output, static_cast<IPinEventSink *>(this)));
    RETURN_IF_FAILED(RegisterPin(&m_oDebug2));

    RETURN_IF_FAILED(m_laneInput.Create("LaneData", new cMediaType(0, 0, 0, LANESTRUCT), this,
                                        static_cast<ISampleQueue *>(new cSampleQueue(100000, 10))));
    RETURN_IF_FAILED(m_laneInput.GetSampleQueue(&m_pLaneQueue));
    RETURN_IF_FAILED(RegisterPin(&m_laneInput));

    RETURN_IF_FAILED(m_odometry.Create("Odometry", new cMediaType(0, 0, 0, ODOMETRYDATA), this,
                                       static_cast<ISampleQueue *>(new cSampleQueue(1000000, 0))));
    RETURN_IF_FAILED(m_odometry.GetSampleQueue(&m_pOdometryQueue));
    RETURN_IF_FAILED(RegisterPin(&m_odometry));

    // BGR Video Input
    RETURN_IF_FAILED(m_oMapInput.Create("Map_Input", IPin::PD_Input, static_cast<IPinEventSink *>(this)));
    RETURN_IF_FAILED(RegisterPin(&m_oMapInput));

    RETURN_NOERROR;
}


