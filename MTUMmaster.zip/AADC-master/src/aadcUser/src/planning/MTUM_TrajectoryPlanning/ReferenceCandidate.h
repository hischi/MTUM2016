//
// Created by clemens on 21.01.16.
//

#ifndef _MTUM_REFERENCE_CANDIDATE_H
#define _MTUM_REFERENCE_CANDIDATE_H

#include "stdafx.h"
#include "PlanningUtils.h"
#include "DataTypes.h"
#include "spline.h"
#include <list>
#include <vector>
#include <iostream>

using namespace std;

using namespace cv;

class cReferenceCandidate
{
public:

    cReferenceCandidate(vector<Point2d> &refVec)
    {
        ref.insert(ref.begin(), refVec.begin(), refVec.end());
    }

    bool IsValid()
    {
        return (ref.size() >= 2);
    }

    bool Join(cReferenceCandidate &other, double condition)
    {
        // Check at which side of the references they can be joint
        double distFF = norm(ref.front() - other.ref.front());
        double distRF = norm(ref.back() - other.ref.front());
        double distFR = norm(ref.front() - other.ref.back());
        double distRR = norm(ref.back() - other.ref.back());

        double minDist = MIN(distFF, MIN(distRF, MIN(distFR, distRR)));

        if(minDist > condition) // no end qualifies for joint
            return false;

        if(minDist == distFF) // they are close front to front
        {
            if(norm(*(ref.begin()++) - *(other.ref.begin()++)) > distFF) // and are in opposite directions
            {
                other.ref.reverse();
                ref.insert(ref.begin(), other.ref.begin(), other.ref.end());
                other.ref.clear();
                return true;
            }
        }
        else if(minDist == distRF) // they are close rear to front
        {
            if(norm(*(ref.end()----) - *(other.ref.begin()++)) > distFF) // and are in opposite directions
            {
                ref.insert(ref.end(), other.ref.begin(), other.ref.end());
                other.ref.clear();
                return true;
            }
        }
        else if(minDist == distFR) // they are close front to rear
        {
            if(norm(*(ref.begin()++) - *(other.ref.end()----)) > distFF) // and are in opposite directions
            {
                ref.insert(ref.begin(), other.ref.begin(), other.ref.end());
                other.ref.clear();
                return true;
            }
        }
        else // they are close rear to rear
        {
            if(norm(*(ref.end()----) - *(other.ref.end()----)) > distFF) // and are in opposite directions
            {
                other.ref.reverse();
                ref.insert(ref.end(), other.ref.begin(), other.ref.end());
                other.ref.clear();
                return true;
            }
        }

        return false;
    }

    void Resample(double d)
    {
        // If there are not enuogh points return immediatly
        if(!IsValid())
            return;

        // Was a spline already calculated?
        if(!x_spline.isvalid()) // no, then calculate it
            UpdateSpline();

        ref.clear();

        double l = 0;
        while(l <= x_spline.maxArg())
        {
            ref.push_back(Point2d(x_spline(l), y_spline(l)));
            l += d;
        }

        UpdateSpline();
    }

    void UpdateSpline()
    {
        // If there are not enuogh points return immediatly
        if(!IsValid())
            return;

        // Fill the data vectors
        vector<double> X(ref.size()), Y(ref.size()), D(ref.size());
        double d = 0;
        Point2d last = ref.front();
        X[0] = last.x;
        Y[0] = last.y;
        D[0] = d;

        int i = 1;
        for (list<Point2d>::iterator it = ++ref.begin(); it != ref.end();it++) {
            Point2d p = *it;
            d += norm(p - last);
            last = p;

            X[i] = it->x;
            Y[i] = it->y;
            D[i] = d;
            i++;
        }

        // If there is not enough data return
        if(D.size() < 2)
        {
            cout << "This should never happen!" << endl;
            return;
        }

        x_spline.set_points(D, X);
        y_spline.set_points(D, Y);
    }

    RPoints GenerateRPoints(double d)
    {
        // If there are not enuogh points return immediatly
        if(!IsValid())
            return RPoints();

        // Was a spline already calculated?
        if(!x_spline.isvalid()) // no, then calculate it
            UpdateSpline();

        // Generate RPoints
        RPoints result;
        int idx = 0;            // idx of RPoints
        double rLength = 0;     // length which increases with the euclidian dist between two RPoints

        // Start from spline argument l=0 an go to the max. argument
        // This represents the estimated dist beween two RPoints which can vary a little bit from the real
        // dist between two points
        for (double l = 0; l <= x_spline.maxArg(); l+=d) {

            double dx = x_spline(l, 1);     // x'(d)
            double ddx = x_spline(l, 2);    // x''(d)
            double dddx = x_spline(l, 3);   // x'''(d)
            double dy = y_spline(l, 1);     // y'(d)
            double ddy = y_spline(l, 2);    // y''(d)
            double dddy = y_spline(l, 3);   // y'''(d)

            double theta = atan2(dy , dx);
            double kappa = (dx*ddy - ddx*dy) / pow(dx*dx + dy*dy, 3.0/2.0);
            double kappaPrime = (dx*dddy-dddx*dy) * pow(dx*dx + dy*dy, 3.0/2.0) - 3 * (dx*ddy-ddx*dy) * (dx*dx+dy*dy) * (dx+dy);
            kappaPrime /= (dx*dx*dx+dy*dy*dy);

            if(!result.empty()) // Increase the length with the euclidian dist to the previous RPoint
            {
                rLength += norm(result.back()() - Point2d(x_spline(l), y_spline(l)));
            }

            // Insert a new Rpoint
            RPoint p(x_spline(l), y_spline(l), theta, kappa, kappaPrime, STATE_GO, idx++, rLength, 0);
            result.push_back(p);
        }

        return result;
    }

    void DrawCandidate(Mat &debug, Scalar color)
    {
        for (list<Point2d>::iterator it = ref.begin(); it != ref.end(); it++) {
            circle(debug, PlanningUtils::get().ToDebug(*it), PlanningUtils::get().ToDebugScale(0.1), color);
        }
    }

    void DrawCandidateArrows(Mat &debug, Scalar color)
    {
        list<Point2d>::iterator prev = ref.begin();
        for (list<Point2d>::iterator it = ++ref.begin(); it != ref.end(); it++, prev++) {
            cv::arrowedLine(debug, PlanningUtils::get().ToDebug(*prev), PlanningUtils::get().ToDebug(*it), color, 1, 8, 0, 1);
        }
    }

    void DrawSpline(Mat &debug, Scalar color, double d)
    {
        // If there are not enuogh points return immediatly
        if(!IsValid())
            return;

        // Was a spline already calculated?
        if(!x_spline.isvalid()) // no, then calculate it
            UpdateSpline();

        Point2d last(x_spline(0), y_spline(0));
        for (double l = d; l < x_spline.maxArg(); l+=d) {

            Point2d p(x_spline(l), y_spline(l));
            line(debug, PlanningUtils::get().ToDebug(last), PlanningUtils::get().ToDebug(p), color);
            last = p;
        }
    }

    double GetMinDistTo(Point2d p)
    {
        double min = INFINITY;

        for (list<Point2d>::iterator it = ref.begin(); it != ref.end(); it++) {
            double d = norm(p - *it);
            min = MIN(min, d);
        }
        return min;
    }

    list<Point2d>::iterator GetNearestPoint(Point2d p)
    {
        double min = INFINITY;
        list<Point2d>::iterator at = ref.begin();

        for (list<Point2d>::iterator it = ref.begin(); it != ref.end(); it++) {
            double d = norm(p - *it);
            if(d < min)
            {
                min = d;
                at = it;
            }
        }

        return at;
    }

    list<Point2d> ref;
    tk::spline x_spline, y_spline;

};

#endif //_MTUM_REFERENCE_CANDIDATE_H
