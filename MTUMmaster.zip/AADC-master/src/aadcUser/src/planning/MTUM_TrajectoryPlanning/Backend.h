//
// Created by clemens on 21.01.16.
//

#ifndef AADC_USER_BACKEND_H
#define AADC_USER_BACKEND_H


#include "stdafx.h"
#include "DataTypes.h"
#include "mtum_trajectory_planning_interface.h"


class Backend {
public:
    Backend();
    virtual ~Backend();

    bool GetPlanningStartPoint(tTimeStamp time, TPoint *point);
    void PrepareTrajectory(TPoints &newTrajectory, tReferencePoints &output);
    void ResetBackend();

private:

    TPoints lastSentTrajectory;

};


#endif //AADC_USER_BACKEND_H
