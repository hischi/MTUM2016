/**
Copyright (c)
Audi Autonomous Driving Cup. Team MomenTUM. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
3.  All advertising materials mentioning features or use of this software must display the following acknowledgement: "This product includes software developed by the Audi AG and its contributors for Audi Autonomous Driving Cup."
4.  Neither the name of Audi nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY AUDI AG AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL AUDI AG OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


**********************************************************************
* $Author:: MomenTUM#$  $Date:: 2015-10-10 15:10:07#$ $Rev:: 35043   $
**********************************************************************/

#pragma once


#include "car_geometry.h"
#include "mtum_SteerControllerInterface.h"

#define MAXVEL 2.0f



//*************************************************************************************************
class cController
{

public:
    cController(iSteerController *parent, tFloat32 k1, tFloat32 k2, tFloat32 k3, tFloat32 odoCycleTime, tBool debugText, tFloat32 cutOffDistance);
    virtual ~cController();



    /**
     * Processes the data and performs some operations...
     */

    tResult ProcessData();
    tResult UpdateMeasurement(tOdometryData &u);
    tResult UpdateReference(const tReferencePoints &reference);

    // MTUM Statusupdate methods called by events on the status input pin
    tBool       Status_IsReady()                {return true;}
    tResult     Status_Reset();
    tResult     Status_ChangeMode(tInt mode)    {RETURN_NOERROR;}
    tResult     Status_SetActive()              {RETURN_NOERROR;}
    tResult     Status_SetInactive()            {RETURN_NOERROR;}


private:
    // Add additional methods and membervariables here:
    // tFloat32     m_TestValue;
    iSteerController* const m_pFilterReference;
    const tFloat32 k1, k2,  k3, odoCycleTime;
    tOdometryData measurement;
    cLockFreeQueue<tReferencePoints> *queue;
    tReferencePoints reference;
    tUInt refnum;
    tFloat32 m_vel;
    tFloat32 cutOffDist;
    tBool m_debug;
    tReferencePoint m_LastPoint;
    tUInt64 lastPointTime;
    tUInt64 lastUpdateTime;
    tReferencePoint &findBestReference(tOdometryData &odo);

    bool reference_compare(tReferencePoint a, tReferencePoint b);

    // Debug:
    enum state{CONTROLLER_INIT, CONTROLLER_STOP, CONTROLLER_GO, CONTROLLER_TOOFAR};
    state m_ControllerState;
    void setState(state state);
    vector<pair<tReferencePoint,bool> > workedPoints;
    void writePoints();
};

//*************************************************************************************************
