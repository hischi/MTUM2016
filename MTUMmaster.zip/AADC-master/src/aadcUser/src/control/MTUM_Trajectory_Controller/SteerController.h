#pragma once
class SteerController
{
public:
	struct Odometry{
		float X;
		float Y;
		float Psi;
		float v;
	};
	struct DesiredState{
		float X;
		float Y;
		float Psi;
		float v;
		float kappa;
		float acc;
	};
	struct controlValues{
		float delta;
		float acc;
	};
	SteerController(float l, float k1 = 1, float k2 = 1, float k3 = 1);
	controlValues control(Odometry, DesiredState);
	~SteerController();
protected:
	const float k1;
	const float k2;
	const float k3;
	const float l;
};

