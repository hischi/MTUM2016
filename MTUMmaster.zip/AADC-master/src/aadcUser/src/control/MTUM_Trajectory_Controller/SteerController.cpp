#include "stdafx.h"
#include "SteerController.h"


SteerController::SteerController(float l, float k1, float k2, float k3) :k1(k1), k2(k2), k3(k3), l(l)
{

}

SteerController::controlValues SteerController::control(SteerController::Odometry x, SteerController::DesiredState u){
	float dx = x.X - u.X;
	float dy = x.Y - u.Y;
	float cospsi = cos(u.Psi);
	float sinpsi = sin(u.Psi);
	float e_t =cospsi*dx + sinpsi * dy;
	float e_n = -sinpsi*dx + cospsi * dy;
	float e_psi = x.Psi - u.Psi;
	float e_v = x.v - u.v;

	controlValues cv;
	cv.delta = atan(l*(u.kappa - k1*(e_t*(cos(e_psi) - 1) / e_psi + e_n*sin(e_psi) / e_psi)) - k2 * e_psi);
	cv.acc = u.acc - k1 * e_t - k3*e_v + k2*e_psi*e_psi - e_psi * u.kappa;
	return cv;
}


SteerController::~SteerController()
{
}
