/**
Copyright (c)
Audi Autonomous Driving Cup. Team MomenTUM. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
3.  All advertising materials mentioning features or use of this software must display the following acknowledgement: "This product includes software developed by the Audi AG and its contributors for Audi Autonomous Driving Cup."
4.  Neither the name of Audi nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY AUDI AG AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL AUDI AG OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


**********************************************************************
* $Author:: MomenTUM#$  $Date:: 2015-10-10 15:10:07#$ $Rev:: 35043   $
**********************************************************************/

#include "stdafx.h"
#include "mtum_controller_core.h"
#include "mtum_controller_filter.h"

#include <cmath>
#include <sstream>
#include <iostream>
#include <iomanip>

cController::cController(iSteerController *parent, tFloat32 k1, tFloat32 k2, tFloat32 k3, tFloat32 odoCycleTime,
                         tBool debugText, tFloat32 cutOffDistance)
    : m_pFilterReference(parent), k1(k1), k2(k2), k3(k3),cutOffDist(cutOffDistance),
      odoCycleTime(odoCycleTime) {
    m_vel = 0;
    m_debug = debugText;
    refnum =0;
    reference.numPoints=0;
    lastPointTime =0;
    lastUpdateTime =0;
    queue = new cLockFreeQueue<tReferencePoints>(5, tFalse);
    for (int i = 0; i < REFERENCEPOINTSIZE; i++) {
        reference.points[i].x = 0;
        reference.points[i].y = 0;
        reference.points[i].vel = 0;
        reference.points[i].phi = 0;
        reference.points[i].time=0;
        reference.points[i].curvature=0;
        reference.points[i].acceleration=0;
    }
    m_LastPoint.time = 0;
    setState(CONTROLLER_INIT);
}

cController::~cController() {
}

tResult cController::ProcessData() {


}

tResult cController::UpdateMeasurement(tOdometryData &x) {
    if(m_ControllerState == CONTROLLER_INIT){
        setState(CONTROLLER_STOP);
        tDynamicControlValue dcv;
        dcv.setPointAcceleration =0;
        dcv.setPointCurvature = 0;
        dcv.setPointSpeed =0.2;
        refnum =0;
        return m_pFilterReference->SendLLControllerValue(dcv);
        reference.numPoints =0;
        lastUpdateTime =0;
        lastPointTime =0;

    }else{



        while (IS_OK(queue->Pop(&reference))) {

            refnum = 0;

        }
        if(lastUpdateTime == 0)
            lastUpdateTime =m_pFilterReference->getTime();


        tUInt64 time = m_pFilterReference->getTime()-lastUpdateTime + lastPointTime;
        if(lastPointTime ==0){
            time =0;

        }

        lastUpdateTime = m_pFilterReference->getTime();
        while(refnum < reference.numPoints && time > reference.points[refnum].time){

            //cout << "increase from refnum: " << refnum << " time: " << time << " reference time: " << reference.points[refnum].time <<endl;
            refnum++;
        }

        if(refnum >= reference.numPoints  || reference.points[refnum].time < time){

            tDynamicControlValue out;
            out.setPointSpeed = 0;
            out.setPointCurvature = 0;
            out.setPointAcceleration =0;
            out.LightFlags = LIGHT_NOMOREPOINTS;
            refnum = (reference.numPoints ==0)?0:reference.numPoints;
            lastPointTime = 0;
            if( m_ControllerState != CONTROLLER_STOP){
                cout << "Trajectory controller: No more trajectory points" << endl;
                setState(CONTROLLER_STOP);
            }


            //cout << "Trajectory controller: stream time: "<< m_pFilterReference->getTime() << " got no more reference, STOP "<<  endl;
            return m_pFilterReference->SendLLControllerValue(out);
        }

        if(refnum > 0 && time - reference.points[refnum-1].time < reference.points[refnum].time-time) // if previous point is nearer than actual point
        {
            refnum--;
            //cout << "prevous point is nearer" << endl;
        }

        if(time == 0){
            setState(CONTROLLER_GO);
        }
        tReferencePoint u = reference.points[refnum];
        //cout << "Trajectory controller: stream time: "<< m_pFilterReference->getTime() <<" work on refnum:" << refnum << " time to work: " << u.time << " intended timediff: "<< u.time-lastPointTime << " real timediff: "<< m_pFilterReference->getTime()-lastStreamTime << endl;
        lastPointTime = u.time;


        //workedPoints.push_back(make_pair(u,true));
        m_LastPoint = u;



        if(m_debug) cout << "position of reference point: " << u.x << ", " << u.y << endl;
        tFloat32 dx = x.x - u.x;
        tFloat32 dy = x.y - u.y;
        tFloat32 cospsi = cos(u.phi+M_PI_2);
        tFloat32 sinpsi = sin(u.phi+M_PI_2);
        tFloat32 e_t = cospsi * dx + sinpsi * dy;
        tFloat32 e_n = -sinpsi * dx + cospsi * dy;
        //tFloat32 e_g = e_t*e_t+e_n*e_n;
        tFloat32 e_psi = x.phi - u.phi;
        tFloat32 e_d = sqrt(dx*dx+dy*dy);
        if (e_psi > M_PI) {
            e_psi -= 2 * M_PI;
        }
        if (e_psi < -M_PI) {
            e_psi += 2 * M_PI;
        }


        tFloat32 e_v = x.vel - u.vel;

        tFloat es[6] = {e_n, e_t, e_v, e_psi, u.acceleration, u.curvature};
        m_pFilterReference->SendSignalData(es);
        if(m_debug) cout <<   " dx: " << dx << " dy: " << dy << " e_t: " << e_t << " e_n: "<< e_n << " e_psi: " << e_psi << " e_v: " << e_v << " des Curvature: " << u.curvature << std::fixed << std::setprecision(2) << endl;
        tDynamicControlValue output;
        tFloat32 curvature;
        tFloat32 acc_rot = k2 * e_psi * e_psi;//- e_psi * u.dPhi; // + u.acc
        tFloat32 acc_curv = fabs(e_psi*u.curvature);
        //if(m_debug) cout << "odo cycle time:" << odoCycleTime;
        //if(m_debug) cout << "weight for et: " << (cos(e_psi)-1)/(-e_psi) << " Weight for e_n: "<< sin(e_psi)/e_psi << endl;
        //if(m_debug) cout << "m_acc:" << m_acc << " acc_rot: " << acc_rot <<endl;
        //cout << "curvature: " <<u.curvature << endl;
        tFloat32 rotatione =u.curvature-k1 *( e_t * (cos(e_psi) - 1) / (e_psi)+  e_n * (sin(e_psi)) / e_psi);
        if(e_psi==0){
            rotatione = u.curvature - e_n*k1;
        }
        tFloat32 rotepsi = -k2 * e_psi / CAR_AXIS2AXIS_M;
        if (m_vel < 0 || fabs(m_vel) < 0.01 && u.vel < 0){
            rotepsi *= -1;
            acc_rot *= -1;
            acc_curv *= -1;
        }
        tFloat32 acc_g =  u.acceleration - k1*e_t - k3*e_v +acc_rot- acc_curv;
        m_vel += acc_g* 1e-6*odoCycleTime;
        //m_vel = acc_g;
        curvature = rotatione + rotepsi;
        if (curvature > 1.5) curvature = 1.5;
        if (curvature < -1.5) curvature = -1.5;


        if(m_debug) cout << "vel: " << m_vel << " curvature: " << curvature << " rote: "<< rotatione << " rotpsi: " << rotepsi << endl;
        if (m_vel > MAXVEL) {
            m_vel = MAXVEL;
        }
        if (m_vel < -MAXVEL) {
            m_vel = -MAXVEL;
        }
        if(e_d > cutOffDist && cutOffDist >0){
            cout << "Trajectory Controller: Distance too far: " << e_d << "m " << endl;
            if(m_ControllerState != CONTROLLER_TOOFAR){
                LOG_ERROR(cString::Format("TrajectoryController: Distance too far: %fm",e_d));
                setState(CONTROLLER_TOOFAR);
            }
        }
        if(m_ControllerState == CONTROLLER_TOOFAR && e_d < 2/3*cutOffDist){
            setState(CONTROLLER_GO);
        }
        /*
    if(m_ControllerState == CONTROLLER_STOP && (abs(x.vel) > 0.001 || abs(e_t)>0.03)){
        m_ControllerState = CONTROLLER_GO;
    }
    if(m_ControllerState == CONTROLLER_GO && abs(e_t) < 0.05 && abs(x.vel) < 0.01){
        m_ControllerState = CONTROLLER_STOP;
    }
    */
        if(m_ControllerState == CONTROLLER_GO){
            output.setPointAcceleration=acc_g;
            output.setPointSpeed = m_vel;
            output.setPointCurvature = curvature;
            output.LightFlags= u.lightFlags;
        }else{
            output.setPointAcceleration =0;
            output.setPointCurvature =0;
            output.setPointSpeed =0;
            output.LightFlags = LIGHT_INDICATOR_HAZARD | LIGHT_REVERSE;
            m_vel =0;
        }


        return m_pFilterReference->SendLLControllerValue(output);
    }

}

tResult cController::UpdateReference(const tReferencePoints &reference) {

    if (IS_FAILED(queue->Push(reference))) {
        tReferencePoints old;
        queue->Pop(&old);
        queue->Push(reference);
    }
    RETURN_NOERROR;

}

tResult cController::Status_Reset()
{
    m_LastPoint.time =0;
}

void cController::setState(cController::state state)
{
    m_pFilterReference->SendStatusFeedback(state);
    m_ControllerState = state;
}

void cController::writePoints()
{
    static bool success = true;
    if(success){
        string filename = "/home/aadc/trajectoryPoints.txt";
        string s = "save data: " + filename;
        LOG_INFO(s.c_str());

        if (filename.size()==0)
        {
            LOG_ERROR("TrajectoryController: No filename");
            success = false;
            //RETURN_ERROR(ERR_INVALID_FILE);
        }
        //create path from path
        cFilename filen = filename.c_str();
        //ADTF_GET_CONFIG_FILENAME(filen);
        //filen = filen.CreateAbsolutePath(".");
        cFile file;
        if(file.Open(filen, cFile::OM_Write)<0){
            LOG_ERROR("Could not open file");
            success = false;
            return;
        }

        for(int i=0; i< workedPoints.size(); i++){

            stringstream ss;
            ss << workedPoints[i].first << "; used: " <<std::fixed << std::setprecision(2) <<workedPoints[i].second ;
            file.WriteLine(ss.str().c_str());
        }

        file.Close();
    }
}





