/**
Copyright (c)
Audi Autonomous Driving Cup. Team MomenTUM. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
3.  All advertising materials mentioning features or use of this software must display the following acknowledgement: "This product includes software developed by the Audi AG and its contributors for Audi Autonomous Driving Cup."
4.  Neither the name of Audi nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY AUDI AG AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL AUDI AG OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


**********************************************************************
* $Author:: MomenTUM#$  $Date:: 2015-10-10 15:10:07#$ $Rev:: 35043   $
**********************************************************************/
#include "stdafx.h"
#include <additional/signal_registry/signal_types.h>
#include <additional/signal_registry/signal_registry_srv_intf.h>
#include <additional/signal_registry/signal_provider_intf.h>
#include <cmath>

#include "mtum_controller_filter.h"
#include "SignalValueType.h"
#include "OdometryDataType.h"
#include "ReferencePointsType.h"


/// Create filter shell
ADTF_FILTER_PLUGIN("MTUM Trajectory Controller", OID_ADTF_MTUM_TRAJECTORY_CONTROLLER, cControllerFilter);


cControllerFilter::cControllerFilter(const tChar* __info):cFilter(__info){
    SetPropertyFloat("k1",1);
    SetPropertyStr("k1" NSSUBPROP_DESCRIPTION, "The first controller parameter(Distance)");

    SetPropertyFloat("k2",1);
    SetPropertyStr("k2" NSSUBPROP_DESCRIPTION, "The second controller parameter(Steering)");

    SetPropertyFloat("k3",0.3);
    SetPropertyStr("k3" NSSUBPROP_DESCRIPTION, "The third controller parameter(Velocity)");


    SetPropertyInt("Odometry cycle time",25000);
    SetPropertyStr("Odometry cycle time" NSSUBPROP_GLOBALCONFIGPROPERTYNAME, "Odometry cycle time");
    SetPropertyStr("Odometry cycle time" NSSUBPROP_GLOBALCONFIGPROPERTYNAME NSSUBPROP_DESCRIPTION, "The cycle time of the odometry filter in us");

    SetPropertyFloat("distance limit",2);

    SetPropertyBool("debug",true);

    m_pISignalRegistry = NULL;
    m_nCount = 0;

    UCOM_REGISTER_TIMING_SPOT(cString(OIGetInstanceName()) + "::PreConversion", m_oPreConversion);
    UCOM_REGISTER_TIMING_SPOT(cString(OIGetInstanceName()) + "::PastConversion", m_oPastConversion);
}

cControllerFilter::~cControllerFilter()
{


}

tResult cControllerFilter::Init(tInitStage eStage, __exception)
{
    // never miss calling the parent implementation!!
    RETURN_IF_FAILED(adtf::cFilter::Init(eStage, __exception_ptr))
    
    // in StageFirst you can create and register your static pins.
    if (eStage == StageFirst)
    {
        RETURN_IF_FAILED(CreatePins(__exception_ptr));
    }
    else if (eStage == StageNormal)
    {
        // In this stage you would do further initialisation and/or create your dynamic pins.
        // Please take a look at the demo_dynamicpin example for further reference.
        RETURN_IF_FAILED(RegisterSignals(__exception_ptr));

    }
    else if (eStage == StageGraphReady)
    {
        // All pin connections have been established in this stage so you can query your pins
        // about their media types and additional meta data.
        // Please take a look at the demo_imageproc example for further reference.
        m_FilterCore = new cController(this, GetPropertyFloat("k1"), GetPropertyFloat("k2"), GetPropertyFloat("k3"),
                                       GetPropertyInt("Odometry cycle time"),
                                       GetPropertyBool("debug"),GetPropertyFloat("distance limit"));
    }

    RETURN_NOERROR;
}

tResult cControllerFilter::Start(__exception)
{
    m_FilterCore->Status_Reset();
    return adtf::cFilter::Start(__exception_ptr);
}

tResult cControllerFilter::Stop(__exception)
{
    return adtf::cFilter::Stop(__exception_ptr);
}

tResult cControllerFilter::Shutdown(tInitStage eStage, __exception)
{
    // In each stage clean up everything that you initiaized in the corresponding stage during Init.
    // Pins are an exception: 
    // - The base class takes care of static pins that are members of this class.
    // - Dynamic pins have to be cleaned up in
    // the ReleasePins method, please see the demo_dynamicpin
    //   example for further reference.
    
    if (eStage == StageGraphReady)
    {
         delete m_FilterCore;
    }
    else if (eStage == StageNormal)
    {
            ucom::cObjectPtr<adtf::ISignalRegistry> pSignalRegistry;
            if (IS_OK(_runtime->GetObject(OID_ADTF_SIGNAL_REGISTRY,
                                          IID_ADTF_SIGNAL_REGISTRY,
                                          (tVoid**)&pSignalRegistry)))
            {
                // Unregister the provider
                pSignalRegistry->UnregisterSignalProvider(this);
            }
            m_oActive.clear();

            m_oLock.Release();


    }
    else if (eStage == StageFirst)
    {
    }

    // call the base class implementation
    return adtf::cFilter::Shutdown(eStage, __exception_ptr);
}

tResult cControllerFilter::OnPinEvent(adtf::IPin* pSource,tInt nEventCode,tInt nParam1, tInt nParam2, adtf::IMediaSample* pMediaSample)
{

    // first check what kind of event it is
    if (nEventCode == adtf::IPinEventSink::PE_MediaSampleReceived)
    {

        // so we received a media sample, so this pointer better be valid.
        RETURN_IF_POINTER_NULL(pMediaSample);


        // by comparing it to our member pin variable we can find out which pin received
        // the sample
        if (pSource == &m_oStatusInput)
        {
            DecodeStatusMessage(pMediaSample);
        }else
            if (pSource == &m_oOdometryInput){
                UCOM_TIMING_SPOT(m_oPreConversion)
                        tOdometryData data;
                DecodeOdometryMessage(pMediaSample,data);
                m_FilterCore->UpdateMeasurement(data);
                UCOM_TIMING_SPOT(m_oPastConversion);
            }else
                if (pSource == &m_oReferenceInput){
                    DecodeReferenceMessage(pMediaSample);
                }


    }


    RETURN_NOERROR;
}

tResult cControllerFilter::SendStatusFeedback(tInt feedback)
{
    // now we need a new media sample to forward the data.
    cObjectPtr<adtf::IMediaSample> pNewSample;
    if (IS_OK(AllocMediaSample(&pNewSample)))
    {
        // now set its data
        // we reuse the timestamp from the incoming media sample. Please see the api documentation
        // (ADTF Extreme Programmers -> The ADTF Streamtime) for further reference on how sample times are handled in ADTF
        tSignalValue data;
        data.value = feedback;
        pNewSample->Update(_clock->GetStreamTime(), &data, sizeof(tSignalValue), 0);

        // and now we can transmit it
        m_oStatusOutput.Transmit(pNewSample);
    }

    RETURN_NOERROR;
}

tResult cControllerFilter::SendLLControllerValue(tDynamicControlValue &val)
{
    // now we need a new media sample to forward the data.
    cObjectPtr<adtf::IMediaSample> pNewSample;
    if (IS_OK(AllocMediaSample(&pNewSample)))
    {
        // now set its data
        // we reuse the timestamp from the incoming media sample. Please see the api documentation
        // (ADTF Extreme Programmers -> The ADTF Streamtime) for further reference on how sample times are handled in ADTF


        pNewSample->Update(_clock->GetStreamTime(), &val, sizeof(tDynamicControlValue), 0);

        // and now we can transmit it
        m_oLowLevelControllerOutput.Transmit(pNewSample);
    }

    RETURN_NOERROR;
}

tUInt64 cControllerFilter::getTime()
{
    return _clock->GetStreamTime();
}



tResult cControllerFilter::DecodeStatusMessage(adtf::IMediaSample* pMediaSample)
{
    // this will store the value for our new sample
    tSignalValue status_message;

    // now lets access the data in the sample,
    // the Lock method gives you access to the buffer of the sample.
    // we use a scoped sample lock to ensure that the lock is released in all circumstances.

    {
        // this will aquire the read lock on the sample and declare and initialize a pointer to the data
        __sample_read_lock(pMediaSample, tSignalValue, pData);
        // now we can access the sample data through the pointer
        status_message = *pData;
        // the read lock on the sample will be released when leaving this scope
    }

    switch(tInt(status_message.value))
    {
    case 0: m_FilterCore->Status_SetInactive();
        break;
    case 1: m_FilterCore->Status_SetActive();
        break;
    case 2: m_FilterCore->Status_IsReady();
        break;
    case -1: m_FilterCore->Status_Reset();
        break;
    default: m_FilterCore->Status_ChangeMode(tInt(status_message.value));
    }

    RETURN_NOERROR;
}
tResult cControllerFilter::DecodeOdometryMessage(adtf::IMediaSample* pMediaSample,tOdometryData &odometry)
{


    // now lets access the data in the sample,
    // the Lock method gives you access to the buffer of the sample.
    // we use a scoped sample lock to ensure that the lock is released in all circumstances.

    {
        // this will aquire the read lock on the sample and declare and initialize a pointer to the data
        __sample_read_lock(pMediaSample, tOdometryData, pData);
        // now we can access the sample data through the pointer
        odometry = *pData;
        // the read lock on the sample will be released when leaving this scope
    }


   RETURN_NOERROR;
}

tResult cControllerFilter::DecodeReferenceMessage(adtf::IMediaSample *pMediaSample)
{
    //LOG_INFO("reference points");
    // this will store the value for our new sample
    tReferencePoints reference;

    // now lets access the data in the sample,
    // the Lock method gives you access to the buffer of the sample.
    // we use a scoped sample lock to ensure that the lock is released in all circumstances.

    {
        // this will aquire the read lock on the sample and declare and initialize a pointer to the data
        __sample_read_lock(pMediaSample, tReferencePoints, pData);
        // now we can access the sample data through the pointer
        reference = *pData;
        // the read lock on the sample will be released when leaving this scope
    }

   m_FilterCore->UpdateReference(reference);

   RETURN_NOERROR;
}
tResult cControllerFilter::SendSignalData(tFloat const *errors)
{
    adtf::tSignalProviderEvent* pEvent = 0;
    tSize nSize = 0;

    {
        __synchronized_kernel(m_oLock);
        tUInt nActiveCount = (tUInt)m_oActive.size();
        if (0 == nActiveCount)
        {
            RETURN_NOERROR;
        }

        tTimeStamp tmStreamTime = _clock->GetStreamTime();

        // calculate the size of our event structure and allocate it
        nSize = adtf::tSignalProviderEvent::CalculateSize(nActiveCount);
        pEvent = (adtf::tSignalProviderEvent*) new tUInt8[nSize];

        if (pEvent)
        {
            // fill the header
            pEvent->nEventCount = nActiveCount;
            pEvent->pProvider = static_cast<adtf::ISignalProvider*>(this);

            // generate our sinus data
            tInt nEvent = 0;
            for (tActiveSignals::iterator oIt = m_oActive.begin();
                 oIt != m_oActive.end();
                 oIt++)
            {
                pEvent->aEvents[nEvent].nSignalID = *oIt;

                pEvent->aEvents[nEvent].sValue.nRawValue = 5;
                pEvent->aEvents[nEvent].sValue.nTimeStamp = tmStreamTime;
                pEvent->aEvents[nEvent].sValue.strTextValue = "Signal";

                pEvent->aEvents[nEvent].sValue.f64Value = errors[nEvent];
                nEvent++;
            }
        }
    }

    if (pEvent && m_pISignalRegistry)
    {
        m_pISignalRegistry->Run(adtf::RUN_SIGNAL_PROVIDER_EVENT,
                                pEvent,
                                (tInt)nSize);

        delete [] pEvent;
    }

    RETURN_NOERROR;
}

tResult cControllerFilter::CreatePins(__exception)
{
    // create and register the status-input pins
    RETURN_IF_FAILED(m_oStatusInput.Create("status_input", new adtf::cMediaType(0,0,0,SIGNALVALUE), this));
    RETURN_IF_FAILED(RegisterPin(&m_oStatusInput));

    RETURN_IF_FAILED(m_oOdometryInput.Create("odometry_input", new adtf::cMediaType(0,0,0,ODOMETRYDATA),this));
    RETURN_IF_FAILED(RegisterPin(&m_oOdometryInput));

    RETURN_IF_FAILED(m_oReferenceInput.Create("reference_input", new adtf::cMediaType(0,0,0,REFERENCEPOINTS),this));
    RETURN_IF_FAILED(RegisterPin(&m_oReferenceInput));


    // create and register the output pins
    RETURN_IF_FAILED(m_oStatusOutput.Create("status_output", new adtf::cMediaType(0,0,0,SIGNALVALUE), this));
    RETURN_IF_FAILED(RegisterPin(&m_oStatusOutput));

    RETURN_IF_FAILED(m_oLowLevelControllerOutput.Create("LowLevelControl", new adtf::cMediaType(0,0,0,DYNAMICCONTROLVALUE), this));
    RETURN_IF_FAILED(RegisterPin(&m_oLowLevelControllerOutput));


    RETURN_NOERROR;
}

tResult cControllerFilter::RegisterSignals(__exception) {
    THROW_IF_FAILED(m_oLock.Create(adtf_util::cString(OIGetInstanceName()) + ".active_signals"));

    m_oActive.clear();


    // create a temporary string storage
    std::vector<adtf_util::cString> oDescStrings;
    oDescStrings.push_back("e_n");
    oDescStrings.push_back("e_t");
    oDescStrings.push_back("e_v");
    oDescStrings.push_back("e_psi");
    oDescStrings.push_back("acc_d");
    oDescStrings.push_back("curv_d");
    m_nCount = oDescStrings.size();

    // create the signal descriptions that we will pass to the signal registry,
    // these will be presented to the user.
    adtf::tSignalDescription* pDescs = new adtf::tSignalDescription[m_nCount];


    for (tInt nI = 0; nI < m_nCount; ++nI)
    {
        pDescs[nI].nSignalID = nI;
        pDescs[nI].strName = oDescStrings[nI].GetPtr();
        pDescs[nI].strUnit = 0;
        pDescs[nI].strDescription = 0;
        pDescs[nI].f64MinValue = -1.0;
        pDescs[nI].f64MaxValue = 1.0;
    }
    ucom::cObjectPtr<adtf::ISignalRegistry> pSignalRegistry = NULL;
    if (IS_OK(_runtime->GetObject(OID_ADTF_SIGNAL_REGISTRY,
                                  IID_ADTF_SIGNAL_REGISTRY,
                                  (tVoid**)&pSignalRegistry)))
    {
        // Register all signals at the Signal Registry Service.

        // After the registration, an IRunnable object is returned,
        // which is used to send signal values later on.
        pSignalRegistry->RegisterSignalProvider(this,
                                                OIGetInstanceName(),
                                                pDescs,
                                                m_nCount,
                                                &m_pISignalRegistry);
    }

    // clean up, we don't need it anymore
    delete [] pDescs;
    RETURN_NOERROR;
}

/**
 *   Returns the current value of a Signal.
 */
tResult cControllerFilter::GetSignalValue(adtf::tSignalID nSignalID, adtf::tSignalValue * pValue)
{
    if (nSignalID < 0 || nSignalID >= (adtf::tSignalID)m_nCount)
    {
        RETURN_ERROR(ERR_NOT_FOUND);
    }

    tTimeStamp tmStreamTime = _clock->GetStreamTime();
    pValue->nRawValue = 0;
    pValue->f64Value = (tFloat64) sin(2.0 * (adtf_util::cStdMath::MATH_PI * (tmStreamTime / 10000000.0) + (adtf_util::cStdMath::MATH_PI / m_nCount * nSignalID)));
    pValue-> nTimeStamp = tmStreamTime;
    pValue->strTextValue = 0;

    RETURN_NOERROR;
}

/**
 *   Activates a signal.
 *   Activated signals send their values to the Signal Registry Service.
 */
tResult cControllerFilter::ActivateSignalEvents(adtf::tSignalID nSignalID, tTimeStamp nUpdateRate)
{
    if (nSignalID < 0 || nSignalID >= (adtf::tSignalID)m_nCount)
    {
        RETURN_ERROR(ERR_NOT_FOUND);
    }

    __synchronized_kernel(m_oLock);
    m_oActive.insert(nSignalID);
    RETURN_NOERROR;
}

/**
 *   Deactivates a signal.
 */
tResult cControllerFilter::DeactivateSignalEvents(adtf::tSignalID nSignalID)
{
    __synchronized_kernel(m_oLock);
    m_oActive.erase(nSignalID);
    RETURN_NOERROR;
}

tResult cControllerFilter::GetInterface(const tChar* idInterface,
                                         tVoid** ppvObject)
{
    if (idmatch(idInterface, IID_ADTF_SIGNAL_PROVIDER))
    {
        *ppvObject = static_cast<adtf::ISignalProvider*> (this);
    }
    else
    {
        return adtf::cFilter::GetInterface(idInterface, ppvObject);
    }

    Ref();

    RETURN_NOERROR;
}

tUInt cControllerFilter::Ref() {
    return adtf::cFilter::Ref();
}

tUInt cControllerFilter::Unref() {
    return adtf::cFilter::Unref();
}

tVoid cControllerFilter::Destroy() {
 delete this;
}


