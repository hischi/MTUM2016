/**
Copyright (c)
Audi Autonomous Driving Cup. Team MomenTUM. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
3.  All advertising materials mentioning features or use of this software must display the following acknowledgement: "This product includes software developed by the Audi AG and its contributors for Audi Autonomous Driving Cup."
4.  Neither the name of Audi nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY AUDI AG AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL AUDI AG OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


**********************************************************************
* $Author:: MomenTUM#$  $Date:: 2015-10-10 15:10:07#$ $Rev:: 35043   $
**********************************************************************/

#pragma once
#include "mtum_LowLevelController_interface.h"
#include "mtum_LowLevelController.h"
#include "OdometryDataType.h"
#include "DynamicControlValueType.h"
#include "SignalValueType.h"
#include "BoolSignalValueType.h"
#include "ReferencePointsType.h"

//*************************************************************************************************
class cLowLevelController
{

public:
    cLowLevelController(iLLCInterface *parent);
    virtual ~cLowLevelController();

    tResult updateOdometry(tOdometryData const * odometry);
    tResult updateDynamicValue(tDynamicControlValue const * dynval, bool isActive);
    tResult ProcessData();
    void        readCalibration(cFilename filen);

    // MTUM Statusupdate methods called by events on the status input pin
    tBool       Status_IsReady()                {return true;}
    tResult     Status_Reset();
    tResult     Status_ChangeMode(tInt mode)    {RETURN_NOERROR;}
    tResult     Status_SetActive()              {inactive = false;LOG_INFO("low_level controller set active");}
    tResult     Status_SetInactive()            {inactive = true;brakeState=STOP_FWD;LOG_INFO("low_level controller set inactive");return 0;}
    struct LowLevelControllerProperties{
        tUInt distRear, distFront, distLeft, distRight;    // distances from car center to end of map in cm
        tUInt8 threshold;                                // defines the value when a pixel in the map is regarded as occupied
        tFloat deceleration;                             // the minimal possible deceleration the car (and the ground) can handle
        tBool debug;                                     // whether to show debug messages
        tBool gcl_debug, enableEB;                       // draw gcl output?, enable emergency breaking?
        tFloat safetyDist;                               // distance to the obstacle, the vehicle should stand. (meters)
        tFloat safetyMargin;                             // distance around the vehicle to check additionally (meters)
        tInt numIterations;                           // number of iterations for binary search
        tInt numOccupied = 5;                           // number of pixels occupied in rectangle to be regarded as non-free

        tFloat servoForgetRate = 1;
        Mat servoWeights;
        Mat servoR;
        Mat speedw;
        Mat speedR;
        Mat brakeDists;
        tFloat accP = 1.9;
        tFloat accI = 1e-5;
        tFloat accD = 0;
        tFloat speedP = 1;
        tFloat speedI = 1;
        tFloat stopTime = 20;
        tFloat timebetweenSamplesus;

        tBool disableUpdate = true;
        tBool controlAcc;

        cFilename filen;
    };
   enum LightState{
       OFF,
       ON,
       FLASHING,
       UNINITIALIZED
   };
   enum IndicatorState{
       IND_OFF,
       LEFT,
       RIGHT,
       HAZARD,
       IND_UNINITIALIZED
   };

   void setProperties(LowLevelControllerProperties props);
   void saveProperties();
   void DoEmergencyStop(bool doIt);
private:
    tFloat speedVal = 90;
    tFloat accIntegral;
    tFloat speedIntegral;
    tFloat deltaLast;
    tUInt64 lastTimeVelCtrl;
    tUInt64 lastTimeVelValSent;
    tFloat sendSteering;
    tFloat sendMotorVal;
    cMutex sendMutex;
    tFloat maxDist;
    tBool odoValid;
    Point2d ignoreStart;
    bool ForceEB=false;

    bool inactive;
    enum EBrakeState{
        GO_FWD,
        GO_BWD,
        BRAKE_FWD,
        BRAKE_BWD,
        STOP_FWD,
        STOP_BWD,
        IGNORE
    };
    int brakeState;
    bool inStop;
    tUInt64 BeginStop = 0;

    deque<double> oldVels;
    vector<double> smooth;
    tInt m_brakeLightState, m_revLightState, m_headLightState;
    tInt m_IndicatorState;

    void updateRevLight(tFloat vel, bool revLight);
    void updateBrakeLight(tInt brakeLight, bool brake);
    void updateHeadLight(bool light);
    void updateIndicator(tInt indicatorState);



    tFloat controlSteering(tFloat curv, tOdometryData &odo_dyn);




    tUInt checkRotRectangle(const Mat &m, const RotatedRect &r);
    RotatedRect computeRotatedRect(const RotatedRect &r,tFloat curvature,tFloat dist);
    void drawRectangle(IDynamicMemoryBlock *cmds, const Rect &r);
    void drawRotRectangle(IDynamicMemoryBlock *cmds, const RotatedRect &r);

    LowLevelControllerProperties m_props;

    

    tFloat lastX, lastY, lastPhi;

    cMutex odometryMux;
    tOdometryData m_odom;

    iLLCInterface  *m_pFilterReference;



    double interpolateLinear(double val, int searchIndex, int valueIndex) const;

    double getMustBeFreeDist(const tOdometryData &odo_n);


    void CheckNeedBrake(tOdometryData &odo_n, tFloat curv_d, double &distDiffBWD, double &distDiffFWD, double &maxVelBWD,
                        double &maxVelFWD);


    tFloat controlAcceleration(const tDynamicControlValue dynval, tOdometryData odo_dyn, double maxVelBWD, double maxVelFWD,
                               double distDiffBWD, double distDiffFWD, bool velActive);

    tFloat getSpeedValfromVel(tFloat vel);


    void sendSteeringAcceleration();

    void sendSteeringAcceleration(tFloat steering, tFloat speedController);

};
