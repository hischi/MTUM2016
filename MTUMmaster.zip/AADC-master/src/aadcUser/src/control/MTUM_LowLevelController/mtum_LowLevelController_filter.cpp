/**
Copyright (c)
Audi Autonomous Driving Cup. Team MomenTUM. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
3.  All advertising materials mentioning features or use of this software must display the following acknowledgement: "This product includes software developed by the Audi AG and its contributors for Audi Autonomous Driving Cup."
4.  Neither the name of Audi nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY AUDI AG AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL AUDI AG OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


**********************************************************************
* $Author:: MomenTUM#$  $Date:: 2015-10-10 15:10:07#$ $Rev:: 35043   $
**********************************************************************/

#include "stdafx.h"
#include "mtum_LowLevelController_filter.h"


/// Create filter shell
ADTF_FILTER_PLUGIN("MTUM Low Level Controller", OID_ADTF_MTUM_LOWLEVELCONTROLLER, cLLCFilter);


cLLCFilter::cLLCFilter(const tChar* __info):cFilter(__info), m_FilterCore(this)
{
    SetPropertyStr("CalibrationFile","../../../../LowLevelController.yml");
    SetPropertyBool("CalibrationFile" NSSUBPROP_FILENAME, tTrue);
    SetPropertyStr("CalibrationFile" NSSUBPROP_FILENAME NSSUBSUBPROP_EXTENSIONFILTER, "yml Files (*.yml)");
    SetPropertyStr("CalibrationFile" NSSUBPROP_DESCRIPTION, "The Calibrationfile for the reference points");

    SetPropertyFloat("possible deceleration", 2);
    SetPropertyStr("possible deceleration" NSSUBPROP_DESCRIPTION, "Deceleration that is possible in any case");

    SetPropertyBool("debug", false);
    SetPropertyInt("auto enable after", 40*10);
    SetPropertyBool("Disable Update", true);

    SetPropertyBool("control Acc", true);


    SetPropertyInt("Detection theshold", 110);
    SetPropertyInt("Num Occupied", 10);
    SetPropertyFloat("Safety Distance", 0.01 );
    SetPropertyStr("Safety Distance" NSSUBPROP_DESCRIPTION, "Distance to the obstacle the car should stand in meters");
    SetPropertyFloat("Safety Margin", 0.01);
    SetPropertyStr("Safety Margin" NSSUBPROP_DESCRIPTION, "Distance around the vehicle that should be checked additionaly in meters");
    //define Properties globally
    SetPropertyInt("Max front distance", 400);
    SetPropertyStr("Max front distance" NSSUBPROP_GLOBALCONFIGPROPERTYNAME, "Map front distance");
    SetPropertyStr("Max front distance" NSSUBPROP_GLOBALCONFIGPROPERTYNAME NSSUBPROP_DESCRIPTION, "The distance in front of the vehicle in centimeters");

    SetPropertyInt("Max right distance", 300);
    SetPropertyStr("Max right distance" NSSUBPROP_GLOBALCONFIGPROPERTYNAME, "Map right distance");
    SetPropertyStr("Max right distance" NSSUBPROP_GLOBALCONFIGPROPERTYNAME NSSUBPROP_DESCRIPTION, "The distance right of the vehicle in centimeters");

    SetPropertyInt("Max left distance", 200);
    SetPropertyStr("Max left distance" NSSUBPROP_GLOBALCONFIGPROPERTYNAME, "Map left distance");
    SetPropertyStr("Max left distance" NSSUBPROP_GLOBALCONFIGPROPERTYNAME NSSUBPROP_DESCRIPTION, "The distance left of the vehicle in centimeters");

    SetPropertyInt("Max rear distance", 300);
    SetPropertyStr("Max rear distance" NSSUBPROP_GLOBALCONFIGPROPERTYNAME, "Map rear distance");
    SetPropertyStr("Max rear distance" NSSUBPROP_GLOBALCONFIGPROPERTYNAME NSSUBPROP_DESCRIPTION, "The distance behind of the vehicle in centimeters");

    lastImageSample = NULL;
    accActive = false;
    accActiveTime = 0;

}

cLLCFilter::~cLLCFilter()
{

}

tResult cLLCFilter::Init(tInitStage eStage, __exception)
{
    // never miss calling the parent implementation!!
    RETURN_IF_FAILED(cFilter::Init(eStage, __exception_ptr))
    
    // in StageFirst you can create and register your static pins.
    if (eStage == StageFirst)
    {
        RETURN_IF_FAILED(CreatePins(__exception_ptr));
    }
    else if (eStage == StageNormal)
    {
        // In this stage you would do further initialisation and/or create your dynamic pins.
        // Please take a look at the demo_dynamicpin example for further reference.
    }
    else if (eStage == StageGraphReady)
    {
        cLowLevelController::LowLevelControllerProperties props;
        props.filen =GetPropertyStr("CalibrationFile");

        props.distRear =  GetPropertyInt("Max rear distance");
        props.distFront = GetPropertyInt("Max front distance");
        props.distLeft = GetPropertyInt("Max left distance");
        props.distRight = GetPropertyInt("Max right distance");
        props.deceleration =  GetPropertyFloat("possible deceleration");
        props.debug = GetPropertyBool("debug");
        props.enableEB = m_oMapInput.IsConnected();
        props.gcl_debug = m_oGCLOutput.IsConnected();
        props.threshold = GetPropertyInt("Detection theshold");
        props.safetyMargin = GetPropertyFloat("Safety Margin");
        props.safetyDist = GetPropertyFloat("Safety Distance");
        props.disableUpdate = GetPropertyBool("Disable Update");
        props.numOccupied = GetPropertyInt("Num Occupied");
        props.controlAcc = GetPropertyBool("control Acc");

        m_AutoEnableCounter = GetPropertyInt("auto enable after");

        m_FilterCore.setProperties(props);
        m_FilterCore.Status_Reset();
        accActiveTime =0;
        // All pin connections have been established in this stage so you can query your pins
        // about their media types and additional meta data.
        // Please take a look at the demo_imageproc example for further reference.
    }

    RETURN_NOERROR;
}

tResult cLLCFilter::Start(__exception)
{
    return cFilter::Start(__exception_ptr);
}

tResult cLLCFilter::Stop(__exception)
{
    m_FilterCore.saveProperties();
    //cout << "Low Level Controller: saved properties" << endl;
    return cFilter::Stop(__exception_ptr);
}

tResult cLLCFilter::Shutdown(tInitStage eStage, __exception)
{
    // In each stage clean up everything that you initiaized in the corresponding stage during Init.
    // Pins are an exception: 
    // - The base class takes care of static pins that are members of this class.
    // - Dynamic pins have to be cleaned up in the ReleasePins method, please see the demo_dynamicpin
    //   example for further reference.
    
    if (eStage == StageGraphReady)
    {
    }
    else if (eStage == StageNormal)
    {
    }
    else if (eStage == StageFirst)
    {
        SendSteeringAcceleration(90,90);
        if(lastImageSample != NULL)
            lastImageSample->Unlock(m_Map.ptr());
    }

    // call the base class implementation
    return cFilter::Shutdown(eStage, __exception_ptr);
}

tResult cLLCFilter::OnPinEvent(IPin* pSource,
                                           tInt nEventCode,
                                           tInt nParam1,
                                           tInt nParam2,
                                           IMediaSample* pMediaSample)
{
    // first check what kind of event it is
    if (nEventCode == IPinEventSink::PE_MediaSampleReceived)
    {
        // so we received a media sample, so this pointer better be valid.
        RETURN_IF_POINTER_NULL(pMediaSample);

        // by comparing it to our member pin variable we can find out which pin received
        // the sample
        if (pSource == &m_oStatusInput)
        {
            DecodeStatusMessage(pMediaSample);
        }
        else if (pSource == &m_oOdometryInput){
            if(m_AutoEnableCounter > 0)
                m_AutoEnableCounter--;
            if(m_AutoEnableCounter == 0 ) {
                m_FilterCore.Status_SetActive();
                m_AutoEnableCounter = -1;
            }
           __sample_read_lock(pMediaSample, tOdometryData, pData);
           m_FilterCore.updateOdometry(pData);
        }else if (pSource == &m_oDynamicValuesInput ){
            __sample_read_lock(pMediaSample,tDynamicControlValue,pData);
            if((pData->LightFlags & LIGHT_NOMOREPOINTS) > 0)//code for no more points!
            {
                accActive = false;
            }else {
                accActiveTime = getTime();
                m_FilterCore.updateDynamicValue(pData, false);
                accActive = true;
            }
        }else if (pSource == &m_oDynamicValuesInVel ){
            if(!accActive || getTime() > accActiveTime + 0.5 * 1e6) {
                accActive = false;
                __sample_read_lock(pMediaSample, tDynamicControlValue, pData);
                m_FilterCore.updateDynamicValue(pData, true);
            }
        } else if(pSource == &m_oMapInput)
        {


           m_MapMutex.Enter();

           //creating new pointer for input data
           const tVoid* l_pSrcBuffer;

           //receiving data from input sample, and saving to inputFrame
           if (IS_OK(pMediaSample->Lock(&l_pSrcBuffer)))
           {
               if(lastImageSample != NULL)
                   lastImageSample->Unlock(m_Map.ptr());
               //creating the matrix with the data
               m_Map = Mat(m_sMapInputFormat.nHeight,m_sMapInputFormat.nWidth,CV_8UC1,(tVoid*)l_pSrcBuffer,m_sMapInputFormat.nBytesPerLine).clone();

               lastImageSample = pMediaSample;
               //pMediaSample->Unlock(l_pSrcBuffer);
           }
           m_MapMutex.Leave();

        }
    }
    else if(nEventCode == IPinEventSink::PE_MediaTypeChanged)
    {
        if (pSource == &m_oMapInput)
        {
            //the input format was changed, so the imageformat has to changed in this filter also
            cObjectPtr<IMediaType> pType;
            RETURN_IF_FAILED(m_oMapInput.GetMediaType(&pType));

            cObjectPtr<IMediaTypeVideo> pTypeVideo;
            RETURN_IF_FAILED(pType->GetInterface(IID_ADTF_MEDIA_TYPE_VIDEO, (tVoid**)&pTypeVideo));

            const tBitmapFormat *pNewFormat = m_oMapInput.GetFormat();
            if (pNewFormat != NULL)
            {
                m_sMapInputFormat = (*pNewFormat);
                LOG_INFO("Low Level Controller: ObstacleMap format was changed!");
            }
        }
    }
    RETURN_NOERROR;
}
 Mat cLLCFilter::GetMap(){

   m_MapMutex.Enter();
   Mat m = m_Map;
   m_MapMutex.Leave();
   return m;
 }

 tUInt64 cLLCFilter::getTime()
 {
     return _clock->GetStreamTime();
 }

tResult cLLCFilter::SendStatusMessage(mtum_filters destination, mtum_status_messages content)
{
    // now we need a new media sample to forward the data.
    cObjectPtr<IMediaSample> pNewSample;
    if (IS_OK(AllocMediaSample(&pNewSample)))
    {
        // now set its data
        // we reuse the timestamp from the incoming media sample. Please see the api documentation
        // (ADTF Extreme Programmers -> The ADTF Streamtime) for further reference on how sample times are handled in ADTF
        tStatusMessage data;
        data.destination = destination;
        data.source = LOW_LEVEL_CONTROL;
        data.content = content;
        pNewSample->Update(_clock->GetStreamTime(), &data, sizeof(tStatusMessage), 0);

        // and now we can transmit it
        m_oStatusOutput.Transmit(pNewSample);
    }

    RETURN_NOERROR;
}

tResult cLLCFilter::SendSteeringAcceleration(tFloat32 steering, tFloat32 acceleration)
{
    // now we need a new media sample to forward the data.
    cObjectPtr<IMediaSample> pNewSampleSt;
    if (IS_OK(AllocMediaSample(&pNewSampleSt)))
    {

        tSignalValue data;
        data.value = steering;
        data.timestamp =_clock->GetStreamTime();
        pNewSampleSt->Update(_clock->GetStreamTime(), &data, sizeof(tSignalValue), 0);

        // and now we can transmit it
        m_oSteeringOuput.Transmit(pNewSampleSt);
    }
    cObjectPtr<IMediaSample> pNewSampleAcc;
    if (IS_OK(AllocMediaSample(&pNewSampleAcc)))
    {

        tSignalValue data;
        data.value = acceleration;
        data.timestamp =_clock->GetStreamTime();
        pNewSampleAcc->Update(_clock->GetStreamTime(), &data, sizeof(tSignalValue), 0);

        // and now we can transmit it
        m_oAccelerationOutput.Transmit(pNewSampleAcc);
    }
    RETURN_NOERROR;
}
tResult cLLCFilter::SendBrakeLight(tBool light){
    // now we need a new media sample to forward the data.
    cObjectPtr<IMediaSample> pNewSample;
    if (IS_OK(AllocMediaSample(&pNewSample)))
    {

        tBoolSignalValue data;
        data.value= light;
        data.timestamp =0;
        pNewSample->Update(_clock->GetStreamTime(), &data, sizeof(tBoolSignalValue), 0);

        // and now we can transmit it
        m_oBrakeLightOutput.Transmit(pNewSample);
    }
    RETURN_NOERROR;
}

tResult cLLCFilter::SendRevLight(tBool light)
{
    // now we need a new media sample to forward the data.
    cObjectPtr<IMediaSample> pNewSample;
    if (IS_OK(AllocMediaSample(&pNewSample)))
    {

        tBoolSignalValue data;
        data.value= light;
        data.timestamp =0;
        pNewSample->Update(_clock->GetStreamTime(), &data, sizeof(tBoolSignalValue), 0);

        // and now we can transmit it
        m_oReverseLightOutput.Transmit(pNewSample);
    }
    RETURN_NOERROR;
}


tResult cLLCFilter::SendLight(cOutputPin & pin, tBool light)
{
    // now we need a new media sample to forward the data.
    cObjectPtr<IMediaSample> pNewSample;
    if (IS_OK(AllocMediaSample(&pNewSample)))
    {

        tBoolSignalValue data;
        data.value= light;
        data.timestamp =0;
        pNewSample->Update(_clock->GetStreamTime(), &data, sizeof(tBoolSignalValue), 0);

        // and now we can transmit it
        pin.Transmit(pNewSample);
    }
    RETURN_NOERROR;
}

tResult cLLCFilter::DecodeStatusMessage(IMediaSample* pMediaSample)
{
    // this will store the value for our new sample
    tStatusMessage status_message;

    // now lets access the data in the sample,
    // the Lock method gives you access to the buffer of the sample.
    // we use a scoped sample lock to ensure that the lock is released in all circumstances.

    {
        // this will aquire the read lock on the sample and declare and initialize a pointer to the data
        __sample_read_lock(pMediaSample, tStatusMessage, pData);
        // now we can access the sample data through the pointer
        status_message = *pData;
        // the read lock on the sample will be released when leaving this scope
    }

    if(status_message.destination == mtum_filters(LOW_LEVEL_CONTROL) || status_message.destination == mtum_filters(ALL))
    {
        switch(status_message.content)
        {
        case SET_ACTIVE:
            m_FilterCore.Status_SetActive();
            break;
        case SET_INACTIVE:
            m_FilterCore.Status_SetInactive();
            break;
        case RESET:
            m_FilterCore.Status_Reset();
            break;
        case IS_READY:
            SendStatusMessage(mtum_filters(CAR_CONTROL), READY);
            break;
            case LL_EMERGENCY_STOP:
                cout << "Low Level controller: got Emergency stop";
                 m_FilterCore.DoEmergencyStop(true);
                break;
            case LL_EMERGENCY_STOP_FREE:
                cout << "LowLevelController: free";
                m_FilterCore.DoEmergencyStop(false);

        }
    }

    RETURN_NOERROR;
}
tResult cLLCFilter::DrawGCL(IDynamicMemoryBlock* writer)
{
    cObjectPtr<IMediaSample> pSample;
    RETURN_IF_FAILED(AllocMediaSample((tVoid**)&pSample));
    cGCLWriter::StoreCommand(writer, GCL_CMD_END);

    RETURN_IF_FAILED(pSample->Update(_clock->GetStreamTime(), writer->GetPtr(),  // pointer to buffer
                                     (tInt)writer->GetSize(), // size of buffer
                                     IMediaSample::MSF_None));   // copy the buffer

    // we don't need it anymore
    cGCLWriter::FreeDynamicMemoryBlock(writer);

    RETURN_IF_FAILED(m_oGCLOutput.Transmit(pSample));

    RETURN_NOERROR;
}

tResult cLLCFilter::CreatePins(__exception)
{
    // create and register the status-input pin
    RETURN_IF_FAILED(m_oStatusInput.Create("status_input", new cMediaType(0,0,0,STATUSMESSAGE), this));
    RETURN_IF_FAILED(RegisterPin(&m_oStatusInput));

    // create and register the output pin
    RETURN_IF_FAILED(m_oStatusOutput.Create("status_output", new cMediaType(0,0,0,STATUSMESSAGE), this));
    RETURN_IF_FAILED(RegisterPin(&m_oStatusOutput));

    RETURN_IF_FAILED(m_oOdometryInput.Create("odometry",new cMediaType(0,0,0,ODOMETRYDATA),this));
    RETURN_IF_FAILED(RegisterPin(&m_oOdometryInput));

    RETURN_IF_FAILED(m_oDynamicValuesInput.Create("DynamicValuesAcc",new cMediaType(0,0,0,DYNAMICCONTROLVALUE),this));
    RETURN_IF_FAILED(RegisterPin(&m_oDynamicValuesInput));

    RETURN_IF_FAILED(m_oDynamicValuesInVel.Create("DynamicValuesVel",new cMediaType(0,0,0,DYNAMICCONTROLVALUE),this));
    RETURN_IF_FAILED(RegisterPin(&m_oDynamicValuesInVel));

    RETURN_IF_FAILED(m_oSteeringOuput.Create("steering", new cMediaType(0,0,0,SIGNALVALUE),this));
    RETURN_IF_FAILED(RegisterPin(&m_oSteeringOuput));

    RETURN_IF_FAILED(m_oAccelerationOutput.Create("acceleration", new cMediaType(0,0,0,SIGNALVALUE),this));
    RETURN_IF_FAILED(RegisterPin(&m_oAccelerationOutput));

    RETURN_IF_FAILED(m_oBrakeLightOutput.Create("brakeLight", new cMediaType(0,0,0,BOOLSIGNALVALUE),this));
    RETURN_IF_FAILED(RegisterPin(&m_oBrakeLightOutput));

    RETURN_IF_FAILED(m_oReverseLightOutput.Create("reverseLight", new cMediaType(0,0,0,BOOLSIGNALVALUE),this));
    RETURN_IF_FAILED(RegisterPin(&m_oReverseLightOutput));

    RETURN_IF_FAILED(m_oHeadLightOutput.Create("HeadLight", new cMediaType(0,0,0,BOOLSIGNALVALUE),this));
    RETURN_IF_FAILED(RegisterPin(&m_oHeadLightOutput));

    RETURN_IF_FAILED(m_oHazardLightOutput.Create("HazardLight", new cMediaType(0,0,0,BOOLSIGNALVALUE),this));
    RETURN_IF_FAILED(RegisterPin(&m_oHazardLightOutput));

    RETURN_IF_FAILED(m_oIndicatorLeftOutput.Create("Indicator_Left", new cMediaType(0,0,0,BOOLSIGNALVALUE),this));
    RETURN_IF_FAILED(RegisterPin(&m_oIndicatorLeftOutput));

    RETURN_IF_FAILED(m_oIndicatorRightOutput.Create("indicator_Right", new cMediaType(0,0,0,BOOLSIGNALVALUE),this));
    RETURN_IF_FAILED(RegisterPin(&m_oIndicatorRightOutput));
    // BGR Video Input
    RETURN_IF_FAILED(m_oMapInput.Create("Map_Input", IPin::PD_Input, static_cast<IPinEventSink*>(this)));
    RETURN_IF_FAILED(RegisterPin(&m_oMapInput));

    // create GCL Pin for debug purposes
    cObjectPtr<IMediaType> pCmdTypeDyn = NULL;
    RETURN_IF_FAILED(AllocMediaType(&pCmdTypeDyn, MEDIA_TYPE_COMMAND, MEDIA_SUBTYPE_COMMAND_GCL, __exception_ptr));
    RETURN_IF_FAILED(m_oGCLOutput.Create("GCL_output",pCmdTypeDyn, static_cast<IPinEventSink*> (this)));
    RETURN_IF_FAILED(RegisterPin(&m_oGCLOutput));




    RETURN_NOERROR;
}
