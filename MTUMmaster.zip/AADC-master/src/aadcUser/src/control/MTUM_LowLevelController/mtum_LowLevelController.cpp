/**
Copyright (c)
Audi Autonomous Driving Cup. Team MomenTUM. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
3.  All advertising materials mentioning features or use of this software must display the following acknowledgement: "This product includes software developed by the Audi AG and its contributors for Audi Autonomous Driving Cup."
4.  Neither the name of Audi nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY AUDI AG AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL AUDI AG OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


**********************************************************************
* $Author:: MomenTUM#$  $Date:: 2015-10-10 15:10:07#$ $Rev:: 35043   $
**********************************************************************/

#include "stdafx.h"
#include "mtum_LowLevelController.h"
#include <iostream>
#include <iomanip>
#include "car_geometry.h"

cLowLevelController::cLowLevelController(iLLCInterface *parent)
{
    m_pFilterReference = parent;

    inactive = true;

    m_brakeLightState =UNINITIALIZED;
    m_headLightState = UNINITIALIZED;
    m_revLightState = UNINITIALIZED;
    m_IndicatorState = IND_UNINITIALIZED;

    brakeState = GO_FWD;
    lastTimeVelCtrl = 0;
    lastTimeVelValSent =0;

    m_props.servoR= Mat(5,5,CV_32F);
    setIdentity(m_props.servoR, Scalar::all(1e-1));
    cout << "servoR:" << m_props.servoR <<endl;

    smooth.push_back(-0.06293706);
    smooth.push_back(-0.02517483);
    smooth.push_back( 0.01025641);
    smooth.push_back(0.04335664);
    smooth.push_back(0.07412587);
    smooth.push_back( 0.1025641);
    smooth.push_back(0.12867133);
    smooth.push_back(0.15244755);
    smooth.push_back(0.17389277);
    smooth.push_back(0.19300699);
    smooth.push_back(0.20979021);


    Status_Reset();

    speedVal = 90;
    speedIntegral =0;
    sendSteering = 90;
    sendMotorVal =90;
}

tResult cLowLevelController::Status_Reset()
{
    lastX =0;
    lastY = 0;
    lastPhi =0;

    accIntegral = 0;
    speedIntegral =0;
    brakeState = GO_FWD;
    BeginStop = 0;
    lastTimeVelValSent=0;
    lastTimeVelCtrl=0;
    deltaLast = 90;
    inStop = false;

    m_brakeLightState =UNINITIALIZED;
    m_headLightState = UNINITIALIZED;
    m_revLightState = UNINITIALIZED;
    m_IndicatorState = IND_UNINITIALIZED;

    RETURN_NOERROR;
}

cLowLevelController::~cLowLevelController()
{
}

tResult cLowLevelController::updateOdometry(const tOdometryData *odometry)
{
    odometryMux.Enter();
    m_odom = *odometry;
    odoValid = m_odom.valid;
    odometryMux.Leave();
    sendSteeringAcceleration();
    return 0;
}

tResult cLowLevelController::updateDynamicValue(const tDynamicControlValue *dynval, bool velActive)
{
    tDynamicControlValue dcv = *dynval;
    tFloat speed = dcv.setPointSpeed;
    tFloat curv = -dcv.setPointCurvature;
    tFloat acc = dcv.setPointAcceleration;
    tOdometryData odo_dyn;
    odometryMux.Enter();
    odo_dyn = m_odom;
    odometryMux.Leave();


    tInt brakeLight = OFF;
    double maxVelFWD = 4;
    double maxVelBWD = 4;
    double distDiffFWD = 1;
    double distDiffBWD = 1;
    if(m_props.enableEB){
        //pair<tFloat,tFloat> vals =
        CheckNeedBrake(odo_dyn,dcv.setPointCurvature,distDiffBWD, distDiffFWD, maxVelBWD, maxVelFWD);

    }

    tFloat steering = controlSteering(curv,odo_dyn);
    tFloat speedController;

    speedController = controlAcceleration(*dynval, odo_dyn, maxVelBWD, maxVelFWD, distDiffBWD, distDiffFWD,velActive);



    if(m_props.debug) cout << "wanted speed: " <<dcv.setPointSpeed << " wanted steering: " << dcv.setPointCurvature <<" steering: " << steering << "speed: " << speedController << endl;


    sendSteeringAcceleration(steering, speedController);
    bool headlight = !inactive;//(dcv.LightFlags  & LIGHT_HEADLIGHTS) != 0;
    bool revlight = (dcv.LightFlags  & LIGHT_REVERSE) != 0;
    bool hazard = (dcv.LightFlags  & LIGHT_INDICATOR_HAZARD) != 0;
    bool left =  (dcv.LightFlags  & LIGHT_INDICATOR_LEFT) != 0;
    bool right = (dcv.LightFlags  & LIGHT_INDICATOR_RIGHT) != 0;
    bool brake = (dcv.LightFlags  & LIGHT_BRAKELIGHTS) != 0;

    if(!ForceEB) {
        if (brakeState == BRAKE_BWD || brakeState == BRAKE_FWD)
            brakeLight = ON;
        if (brakeState == STOP_BWD || brakeState == STOP_FWD) {
            brakeLight = ON;
            hazard = true;
            if (!inStop) {
                m_pFilterReference->SendStatusMessage(PLANNING, LL_EMERGENCY_STOP);
                cout << "LLC: Emergency stop!" << endl;
                inStop = true;
            }

        } else if (inStop) {
            m_pFilterReference->SendStatusMessage(PLANNING, LL_EMERGENCY_STOP_FREE);
            cout << "LLC: Emergency stop off! " << endl;
            inStop = false;
        }

        if (brakeState == IGNORE) {
            hazard = true;
        }
    }else {
        hazard = true;
    }
    updateBrakeLight(brakeLight,brake);
    updateRevLight(speed,revlight);
    updateHeadLight(headlight);

    int ind;
    if(hazard)
        ind = HAZARD;
    else if(left)
        ind = LEFT;
    else if(right)
        ind = RIGHT;
    else ind = OFF;

    updateIndicator(ind);
    //cout << "speed: " << speed <<endl;


    return 0;
}

void cLowLevelController::sendSteeringAcceleration(tFloat steering, tFloat speedController) {
    sendMutex.Enter();

    sendMotorVal = speedController;
    sendSteering = steering;
    sendMutex.Leave();
    sendSteeringAcceleration();

}
void cLowLevelController::sendSteeringAcceleration(){
    sendMutex.Enter();
    if(inactive || !odoValid || ForceEB){
        sendSteering = 90;
        sendMotorVal = 90;
    }
    if(ForceEB){
        updateIndicator(HAZARD);
    }
    if( m_pFilterReference->getTime() -lastTimeVelValSent >= m_props.timebetweenSamplesus){
        m_pFilterReference->SendSteeringAcceleration(sendSteering, sendMotorVal);
        lastTimeVelValSent = m_pFilterReference->getTime();
    }else if(lastTimeVelValSent > m_pFilterReference->getTime()){
        cout << "Low Level controller: Last time VelValSent was too big: " << lastTimeVelValSent << " time: " <<m_pFilterReference->getTime() << endl;
        lastTimeVelValSent = m_pFilterReference->getTime();
    }
    sendMutex.Leave();
}

void cLowLevelController::CheckNeedBrake( tOdometryData &odo_n,tFloat curv_d,double & distDiffBWD,double & distDiffFWD, double& maxVelBWD, double & maxVelFWD){


    Mat map = m_pFilterReference->GetMap();
    if(map.cols ==0)
    {
        distDiffBWD = 0;
        distDiffFWD = 0;
        maxVelBWD =0;
        maxVelFWD =0;
    }
    int safetydist = (int)(m_props.safetyMargin * 100);
    Rect r(m_props.distRight - CAR_WIDTH / 2 - safetydist, m_props.distRear - CAR_REARAXIS2REAR -safetydist, CAR_WIDTH + 2* safetydist, CAR_LENGTH + 2* safetydist);
    //tFloat32 distance = m_props.safetyDist; //abs(odo_n.vel) * 0.1+ 0.01; //sample all 100 ms
    RotatedRect rr(Point2f(r.x, r.y), Point2f(r.x + r.width, r.y), Point2f(r.x + r.width, r.y + r.height));


    // use a dynamic memory block for drawing gcl
    IDynamicMemoryBlock *pCommandBlock;
    if (m_props.gcl_debug)
        cGCLWriter::GetDynamicMemoryBlock(pCommandBlock);

    tFloat mustBeFreeDistance = getMustBeFreeDist(odo_n); //distance for emergency brake
    tFloat distance = 0.2;
    int maxrectnum = fmax(5.f, ceil(maxDist / distance));
    maxrectnum = min(maxrectnum, 100);
    tFloat32 freeDists[2] = {0.0,0.0};
    for(int i =0; i < 2; i++) {

        tFloat32 dir = (i == 0)?1:-1;

        if ((odo_n.vel * dir) > 1) //if we go more than 1 m/s in the other direction
           continue;
        tFloat32 freeDistance = 0;
        int rectnum;
        for (rectnum = 1; rectnum <= maxrectnum; rectnum++) {


            RotatedRect trr = computeRotatedRect(rr, curv_d, rectnum * distance * dir);

            tUInt value = checkRotRectangle(map, trr);
            if (m_props.gcl_debug) {
                //if(m_props.debug) cout << "found "<< value << " obstacle points" << endl;
                cColor c(0,255,0);
                if(dir < 0)  c = cColor(0, 0, 255);

                if (value > m_props.numOccupied) {
                    c = cColor(255, 0, 0);
                }
                cGCLWriter::StoreCommand(pCommandBlock, GCL_CMD_FGCOL, c.GetRGBA());
                drawRotRectangle(pCommandBlock, trr);
            }
            if (value > m_props.numOccupied) {
                break;
            }
            freeDistance += abs(distance);
        }


        if (rectnum < maxrectnum) // do binary search to get exact position if we just want to reduce the speed
        {
            tFloat min = freeDistance;
            tFloat max = freeDistance + distance;
            for (int i = 0; i < m_props.numIterations; i++) {
                tFloat dist = (max + min) / 2;
                RotatedRect trr = computeRotatedRect(rr, curv_d, dist * dir);
                tUInt value = checkRotRectangle(map, trr);
                if (m_props.gcl_debug) {
                    //if(m_props.debug) cout << "found "<< value << " obstacle points" << endl;
                    cColor c(0, 0, 255);
                    if (value > m_props.numOccupied) {
                        c = cColor(255, 0, 255);
                    }
                    cGCLWriter::StoreCommand(pCommandBlock, GCL_CMD_FGCOL, c.GetRGBA());
                    drawRotRectangle(pCommandBlock, trr);
                }
                if (value > m_props.numOccupied) {
                    max = dist;
                } else {
                    min = dist;
                }

            }
            //cout << "computed free distance: "<< min << endl;
            freeDistance = min;
        }
        freeDists[i] = freeDistance;
    }
    if (m_props.gcl_debug)
        m_pFilterReference->DrawGCL(pCommandBlock);

    //if(m_props.debug) cout << "free distance backwards: " << freeDists[0] << " forwards:" << freeDists[1] <<" mustBeFreeDistance: " << mustBeFreeDistance << endl;


    maxVelBWD = interpolateLinear(freeDists[0],0,1);
    maxVelFWD = interpolateLinear(freeDists[1],0,1);
    distDiffBWD = freeDists[0] - mustBeFreeDistance;
    distDiffFWD = freeDists[1] - mustBeFreeDistance;

    //return make_pair(freeDistance-mustBeFreeDistance,interpolateLinear(freeDistance,1,0));
}

double cLowLevelController::getMustBeFreeDist(const tOdometryData &odo_n) {
    oldVels.push_back(odo_n.vel);
    double svel = odo_n.vel;
    if(oldVels.size() > smooth.size()) {
        oldVels.pop_front();
        svel = 0;
        for (int i = 0; i < smooth.size(); i++) {
            svel += smooth[i] * oldVels[i];
        }
    }




    double d =  m_props.safetyDist;
    if(m_props.brakeDists.cols < 2 || m_props.brakeDists.rows < 2)
    return d + 0.5 * svel * svel / m_props.deceleration ;

    double val = interpolateLinear(abs(svel), 1, 0);

    return val;
}

double cLowLevelController::interpolateLinear(double val, int searchIndex, int valueIndex) const {
    if(val < m_props.brakeDists.at<double>(searchIndex,0)){
        return m_props.brakeDists.at<double>(valueIndex,0);
    }
    int i0;
    for (i0 = 1; i0 < m_props.brakeDists.cols; i0++) {
         if (m_props.brakeDists.at<double>(searchIndex, i0) >= val)
                    break;
    }
    if (i0 >= m_props.brakeDists.cols)
       return m_props.brakeDists.at<double>(valueIndex, m_props.brakeDists.cols - 1);

    double v = val - m_props.brakeDists.at<double>(searchIndex, i0 - 1);
    double v_dist = m_props.brakeDists.at<double>(searchIndex, i0) - m_props.brakeDists.at<double>(searchIndex, i0 - 1);

    return (1 - v / v_dist) * m_props.brakeDists.at<double>(valueIndex, i0 - 1) + v / v_dist * m_props.brakeDists.at<double>(valueIndex, i0);
}


tFloat cLowLevelController::getSpeedValfromVel(tFloat vel){
 tFloat val = 90;
    tFloat absvel = abs(vel);
    if(vel> 0) {
        val= 90 + m_props.speedw.at<double>(0) * absvel + m_props.speedw.at<double>(1) * absvel * absvel;
    }else{
        val = 90 - m_props.speedw.at<double>(0) * absvel - m_props.speedw.at<double>(1) * absvel *absvel;
    }

return val;

}
tFloat cLowLevelController::controlAcceleration(const tDynamicControlValue dynval, tOdometryData odo_dyn, double maxVelBWD,
                                                double maxVelFWD, double distDiffBWD, double distDiffFWD, bool velActive)
{
    if(m_props.debug)cout << "speed:" <<dynval.setPointSpeed << " acceleration: " << dynval.setPointAcceleration <<
            " odo_dyn.acc: " << odo_dyn.acc << " vel active: " << velActive << "inactive: " <<
            inactive << " odo valid:" << odo_dyn.valid << " brake state: " << brakeState << endl;
    if(dynval.setPointSpeed == 0 && (brakeState == STOP_BWD || brakeState == STOP_FWD)){
     brakeState = GO_FWD;
    }
    if(abs(dynval.setPointSpeed) <= 0.01 || inactive || !odo_dyn.valid)
        return 90.0f;
    if((brakeState == STOP_FWD || brakeState == STOP_BWD)){
        if(BeginStop == 0) {
            BeginStop = m_pFilterReference->getTime();
            cout << "LLC Begin Stop: " << BeginStop << endl;

        }
    }else{
        BeginStop = 0;
    }
	if(brakeState != IGNORE) {
        if (distDiffFWD < -0.05 && odo_dyn.vel > 0.7) {
            brakeState = BRAKE_FWD;
            return 0.0;
        }
        if (distDiffBWD < -0.05 && odo_dyn.vel < -0.7) {
            brakeState = BRAKE_BWD;
            return 180.0;
        }

        if (dynval.setPointSpeed > 0 && distDiffFWD < 0) {
            brakeState = BRAKE_FWD;

        }
        if (dynval.setPointSpeed < 0 && distDiffBWD < 0) {
            brakeState = BRAKE_BWD;

        }
    }
    if(brakeState == BRAKE_BWD && abs(odo_dyn.vel) < 0.2){
       brakeState = STOP_BWD;
    }
    if(brakeState == BRAKE_FWD && abs(odo_dyn.vel) < 0.2){
        brakeState = STOP_FWD;
    }
    if((brakeState == BRAKE_BWD) && odo_dyn.vel * 1.2> -maxVelBWD ){
        brakeState = GO_BWD;
    }
    if((brakeState == BRAKE_FWD) && odo_dyn.vel * 1.2 < maxVelFWD ){
        brakeState = GO_FWD;
    }
    if(brakeState == STOP_FWD && maxVelFWD >0.1){
        brakeState= GO_FWD;
    }
    if(brakeState == STOP_BWD && maxVelBWD > 0.1){
        brakeState = GO_BWD;
    }
    if(BeginStop != 0){
        cout << "Stop: time passed: " << (m_pFilterReference->getTime()-BeginStop)*1e-6 << endl;
    }
    if(brakeState != IGNORE && BeginStop != 0 && (m_pFilterReference->getTime()-BeginStop)*1e-6 > m_props.stopTime  ){
        ignoreStart =Point2d(odo_dyn.x,odo_dyn.y);
        brakeState = IGNORE;
        cout << "LowLevelController: ignore obstacle stop; Startpos: " << ignoreStart <<endl;
    }
    if(brakeState == IGNORE){
	    maxVelFWD = 0.3;
        maxVelBWD = 0.3;
        double dist = norm(Point2d(odo_dyn.x,odo_dyn.y)-ignoreStart);
        cout << " dist: " << dist << " distFWD: " << distDiffFWD << " distBWD: " << distDiffBWD << endl;
        if(distDiffBWD > 0.3 && distDiffFWD > 0.3 && dist > 1){
            brakeState = GO_FWD;
        }


    }else{
	    if(brakeState == BRAKE_BWD || brakeState == BRAKE_FWD || (brakeState == STOP_BWD && dynval.setPointSpeed<0) || (brakeState == STOP_FWD && dynval.setPointSpeed > 0)){

            speedIntegral = 0;
            accIntegral = 0;
            return 90;
	    }

    }

    if(!velActive) {


        tFloat delta = dynval.setPointAcceleration - odo_dyn.acc;
        if (!(accIntegral < 20 && accIntegral > -20))
            accIntegral = 0;
        tFloat p = delta * m_props.accP;
        accIntegral += delta * m_props.accI;
        tFloat d = (delta - deltaLast) * m_props.accD;
        deltaLast = delta;

        speedVal += p + accIntegral + d;

    }
    tFloat speed = dynval.setPointSpeed;
    bool lvelActive = velActive;
    if(dynval.setPointSpeed > maxVelFWD || dynval.setPointSpeed < -maxVelBWD ){
        lvelActive = true;
        speed = fmax(-maxVelBWD,fmin(maxVelFWD,dynval.setPointSpeed));
        //cout << "reduced speed to:" << speed <<  " setpointspeed: " << dynval.setPointSpeed << endl;
    }
    if(lvelActive){
        tFloat delta = speed - odo_dyn.vel;
        if(delta < 0.1 && odo_dyn.vel > 0.1){ // we have low error now, value seems to be right
            Mat R = m_props.speedR.clone();
            Mat w = m_props.speedw.clone();
            Mat x = (Mat_<double>(2, 1) <<  abs(speed), speed*speed);

            Mat rx = R * x;
            Mat xt = x.t();
            double v = x.dot(rx);
            //Mat z = (Mat_<float>(1,1) << ServoVal);


            m_props.speedR = (R - rx * 1.0 / (1 + v) * xt * R);

            tFloat val = abs(speedVal -90);
            m_props.speedw += R * x * (val- xt * w);


        }


        tUInt64 timediff = m_pFilterReference->getTime()-lastTimeVelCtrl;
        lastTimeVelCtrl=m_pFilterReference->getTime();
        if(timediff > 1e6 * 0.5){
            speedIntegral=0;
            timediff =0;
        }
        speedIntegral += delta *timediff *1e-6;
        double openLoopVal = getSpeedValfromVel(speed);
        speedVal = openLoopVal + m_props.speedP * delta +  speedIntegral * m_props.speedI;
        if(m_props.debug) cout << "openLoopVal: " << openLoopVal << " p val: " << m_props.speedP *delta << " i val: " << m_props.speedI * speedIntegral << " all: " << speedVal<< setw(3) << setprecision(3) << endl;

    }

    //speedVal += 90.0f;
    if(dynval.setPointSpeed > 0 && speedVal < 90)
        speedVal =90;
    if(dynval.setPointSpeed < 0 && speedVal > 90)
        speedVal =90;

    if(speedVal > 180){
        speedVal = 180;
    }
    if(speedVal < 60){
        speedVal = 60;
    }


    return speedVal;


}

tFloat cLowLevelController::controlSteering(tFloat curv, tOdometryData &odo_dyn)
{
    static tInt ServoVal = 90;
    static tInt counter =0;

    // update steering control -> gradient decent
    if( abs(odo_dyn.vel) > 0.15 && !m_props.disableUpdate && lastX != 0 && lastY !=0) { //


        tFloat dphi= odo_dyn.phi - lastPhi;
        if(dphi > M_PI){
            dphi -= 2*M_PI;
        }
        if(dphi < -M_PI){
            dphi += 2*M_PI;
        }
        tFloat dx = odo_dyn.x-lastX;
        tFloat dy = odo_dyn.y - lastY;

            tFloat dist = sqrt(dx*dx + dy*dy);
        if(dist > 0.1) {
            if (odo_dyn.vel < 0)
                dist *= -1;

            tFloat compCurvature = -dphi / dist;
            tFloat curvS = compCurvature * compCurvature;
            tFloat curvQ = compCurvature * curvS;
            tFloat velCurv = abs(odo_dyn.vel) * compCurvature;
            Mat R = m_props.servoR.clone();
            Mat w = m_props.servoWeights.clone();
            //cout << "R: " << R << " w: " << w << endl;
            Mat x = (Mat_<float>(5, 1) << 1, compCurvature, curvS, curvQ, velCurv);
            Mat xt = x.t();
            Mat rx = R * x;
            Mat in = xt * rx;
            //Mat z = (Mat_<float>(1,1) << ServoVal);
            float v = in.at<float>(0, 0);

            R = (R - rx * 1.0 / (1 + v) * xt * R);


            w += R * x * (ServoVal - xt * w);
            if (m_props.debug) {
                if (m_props.debug && counter++ > 100) {
                    counter = 0;

                    stringstream ss;
                    ss << " weights: " << w;
                    LOG_INFO(ss.str().c_str());

                }
            }
            Mat x1 = (Mat_<float>(1, 5) << 1, -1, 1, -1, 0);
            Mat ms = x1 * w;

            Mat x2 = (Mat_<float>(1, 5) << 1, 1, 1, 1, 0);
            Mat ms2 = x2 * w;

            //if( s1 > 70 || s2 < 110 ){
            //  cout << "LEARNING_PROBLEM: value would limit the avalilable space: s(-1):" << s1 <<" s(1):" << s2 << endl;
            //LOG_WARNING(cString::Format("LEARNING_PROBLEM: value would limit the avalilable space: s(-1): %f, s(1): %f", s1, s2));
            //}else{
            m_props.servoR = R;
            m_props.servoWeights = w;

            lastX = odo_dyn.x;
            lastY = odo_dyn.y;
            lastPhi = odo_dyn.phi;
            //}
        }
        }else{

            lastX = 0;
            lastY = 0;
            lastPhi = 0;

    }
if(abs(odo_dyn.vel) < 0.15){
lastX = odo_dyn.x;
lastY = odo_dyn.y;
lastPhi = odo_dyn.phi;
}
    float c2 = curv*curv;
    float c3 = curv *c2;
    float cv1 = abs(odo_dyn.vel)*curv;
    Mat x = (Mat_<float>(1,5)<< 1, curv,c2, c3, cv1);
    Mat sv = x*m_props.servoWeights;
    ServoVal = sv.at<float>(0,0);
    if(ServoVal > 120)
        ServoVal = 120;
    if(ServoVal < 60)
        ServoVal = 60;
    return ServoVal;

}

void cLowLevelController::setProperties(LowLevelControllerProperties props)
{
    m_props = props;
    // read yml file
    m_props.numIterations = 5;
    m_props.servoR = Mat(5,5,CV_32F);
    setIdentity(m_props.servoR,1e-3);
    m_props.servoWeights = (Mat_<float>(5,1)<< 90, 30, 0,0,0);

    m_props.brakeDists = (Mat_<double>(2,5) << 0.07, 0.20, 0.45, 0.95, 2.3,
                                                  0., 0.40, 1.00, 2.30, 4.5 );
    m_props.speedP = 10;
    m_props.speedI = 1;


    m_props.speedR = Mat(2,2,CV_64F);

    setIdentity(m_props.speedR, 1e-3);

    m_props.speedw = (Mat_<double>(2,1) << 90/3.0,0);

    m_props.timebetweenSamplesus = 20000;

    cFilename filen = props.filen;
    if (filen.IsEmpty())
    {
        LOG_ERROR("LowLevelController: calibration file not found");

        return;
    }
    //create path from path
    ADTF_GET_CONFIG_FILENAME(filen);
    filen = filen.CreateAbsolutePath(".");
    FileStorage fs(filen.GetPtr(), FileStorage::READ);
    Mat R;
    fs["servoR"] >> R;
    if(R.rows == m_props.servoR.rows && R.cols == m_props.servoR.cols)
        m_props.servoR = R;
    Mat w;
    fs["servow"] >> w;
    if(w.rows == m_props.servoWeights.rows && w.cols == m_props.servoWeights.cols)
        m_props.servoWeights=w;
    int numIterations=-1;
    fs["numIterations"] >> numIterations;
    if(numIterations >0 && numIterations < 10)
        m_props.numIterations = numIterations;
    int numOccupied = -1;
    fs["numOccupied"] >> numOccupied;
    if(numOccupied >0 && numOccupied < 1000)
        m_props.numOccupied = numOccupied;
    float sfr = -1;
    fs["servoForgetRate"] >> sfr;
    if(sfr > 0.95 && sfr <= 1)
        m_props.servoForgetRate = sfr;
    tFloat speedP = -1;
    fs["accP"] >> speedP;
    if(speedP > 0)
        m_props.accP = speedP;
    tFloat speedI = -1;
    fs["accI"] >> speedI;
    if(speedI > 0)
        m_props.accI = speedI;
    tFloat speedD = -1;
    fs["accD"] >> speedD;
    if(speedD > 0)
        m_props.accD = speedD;
    fs["speedP"] >> speedP;
    if(speedP > 0)
        m_props.speedP= speedP;

    fs["speedI"] >> m_props.speedI;
    Mat speedw;
    fs["speedw"] >> speedw;
    if(!speedw.empty()){
        m_props.speedw = speedw;
    }
    Mat speedR;
    fs["speedR"] >> speedR;
    if(!speedR.empty()){
        m_props.speedR = speedR;
    }
    Mat brakeDist;
    fs["brakeDists"] >> brakeDist;
    if(!brakeDist.empty())
       m_props.brakeDists =brakeDist;
    fs["stopTime"] >> m_props.stopTime;

    if(m_props.stopTime <= 0)
        m_props.stopTime = 30;
    tFloat time;
    fs["timeBetweenSamples"] >> time;
    if(time > 0)
        m_props.timebetweenSamplesus = time;

    cout << "brake dists: "<<  m_props.brakeDists << endl;
    maxDist= 3;
    if(!m_props.brakeDists.empty()){
        maxDist = m_props.brakeDists.at<double>(0,m_props.brakeDists.cols-1);
    }

    cout << "maxDist: " << maxDist << endl;

    //tBool disableUpdate = false;
    //fs["disableUpdate"] >> disableUpdate;
    //m_props.disableUpdate = disableUpdate;
    fs.release();

    cout << "read properties: servoR:" << m_props.servoR << " servow: " << m_props.servoWeights << "iterations: "<< m_props.numIterations << "disableUpdate: " << m_props.disableUpdate << endl;


}

void cLowLevelController::saveProperties()
{
    cFilename filen = m_props.filen;
    if(filen.IsEmpty() || m_props.disableUpdate){
        cout << "do not save Properties. ";
        if(filen.IsEmpty())
            cout << "Filename invalid";
        else
            cout << "Saving disabled";
        cout << endl;
        return;
    }
    ADTF_GET_CONFIG_FILENAME(filen);
    filen = filen.CreateAbsolutePath(".");
    FileStorage fs(filen.GetPtr(), FileStorage::WRITE);
    fs << "servoR" << m_props.servoR;
    fs << "servow" << m_props.servoWeights;
    fs << "speedw" << m_props.speedw;
    fs << "speedR" << m_props.speedR;
    fs << "numIterations" << m_props.numIterations;
    fs << "numOccupied" << m_props.numOccupied;
    fs << "servoForgetRate" << m_props.servoForgetRate;
    fs << "accP" << m_props.accP;
    fs << "accI" << m_props.accI;
    fs << "accD" << m_props.accD;
    fs << "speedP" << m_props.speedP;
    fs << "speedI" << m_props.speedI;
    fs << "brakeDists" << m_props.brakeDists;
    fs << "stopTime" << m_props.stopTime;
    fs << "timeBetweenSamples" << m_props.timebetweenSamplesus;
    fs.release();
    LOG_INFO("LowLevelController: saved properties");

}


void cLowLevelController::updateRevLight(tFloat vel, bool revLight)
{
    if(m_revLightState == UNINITIALIZED){
        m_pFilterReference->SendRevLight(false);
        m_revLightState = OFF;
    }
    if(m_revLightState == OFF && (vel < -0.2 || revLight)){
        m_pFilterReference->SendRevLight(true);
        m_revLightState = ON;
    }
    if(m_revLightState == ON && (vel> 0.2  && !revLight)){
        m_pFilterReference->SendRevLight(false);
        m_revLightState = OFF;
    }

}

void cLowLevelController::updateBrakeLight(tInt brakeLight, bool brake)
{
    if(m_brakeLightState == UNINITIALIZED){
        m_pFilterReference->SendBrakeLight(false);
        m_brakeLightState = OFF;
    }else if(m_brakeLightState == OFF && (brakeLight == ON || brake) ){
        m_pFilterReference->SendBrakeLight(true);
        m_brakeLightState =ON;
    }else if(m_brakeLightState == ON && (brakeLight == OFF && !brake)){
        m_pFilterReference->SendBrakeLight(false);
        m_brakeLightState = OFF;
    }
}

void cLowLevelController::updateHeadLight(bool light)
{

    if(m_headLightState == UNINITIALIZED){
        m_pFilterReference->SendHeadLight(false);
        m_headLightState = OFF;
    }else if(m_headLightState == OFF && light ){
        m_pFilterReference->SendHeadLight(true);
        m_headLightState =ON;
    }else if(m_headLightState == ON && !light){
        m_pFilterReference->SendHeadLight(false);
        m_headLightState = OFF;
}
}

void cLowLevelController::updateIndicator(tInt indicatorState)
{
   if(m_IndicatorState == IND_UNINITIALIZED){
        m_pFilterReference->SendLeftIndicator(false);
        m_pFilterReference->SendHazardIndicator(false);
        m_pFilterReference->SendRightIndicator(false);
        m_IndicatorState = IND_OFF;
   }
   else if (m_IndicatorState != LEFT && indicatorState == LEFT){
         m_pFilterReference->SendLeftIndicator(true);
         m_IndicatorState = LEFT;
   }
   else if (m_IndicatorState != RIGHT && indicatorState == RIGHT){
         m_pFilterReference->SendRightIndicator(true);
         m_IndicatorState = RIGHT;
   }
   else if (m_IndicatorState != HAZARD && indicatorState == HAZARD){
         m_pFilterReference->SendHazardIndicator(true);
         m_IndicatorState = HAZARD;
   }
   else if (m_IndicatorState != IND_OFF && indicatorState == IND_OFF){
       if(m_IndicatorState == LEFT)
         m_pFilterReference->SendLeftIndicator(false);
       else if (m_IndicatorState== RIGHT)
           m_pFilterReference->SendRightIndicator(false);
       else if (m_IndicatorState == HAZARD)
            m_pFilterReference->SendHazardIndicator(false);
         m_IndicatorState = IND_OFF;
   }

}




void cLowLevelController::drawRectangle(IDynamicMemoryBlock *cmds, const Rect &r) {
    cGCLWriter::StoreCommand(cmds, GCL_CMD_DRAWRECT, r.x, r.y, r.x + r.width, r.x + r.height);
}

void cLowLevelController::drawRotRectangle(IDynamicMemoryBlock *cmds, const RotatedRect &r) {
    Point2f ps[4];
    r.points(ps);
    tUInt32 arrPoints2[] = {8, (tUInt32)ps[0].x, (tUInt32)ps[0].y, (tUInt32)ps[1].x, (tUInt32)ps[1].y,(tUInt32) ps[2].x,(tUInt32) ps[2].y,(tUInt32) ps[3].x, (tUInt32)ps[3].y};
    cGCLWriter::StoreCommand(cmds, GCL_CMD_DRAWPOLYGON,
                             sizeof(arrPoints2) / sizeof(tUInt32),
                             arrPoints2);
}
RotatedRect cLowLevelController::computeRotatedRect(const RotatedRect &r,tFloat curvature,tFloat dist){
    tFloat dphi = curvature* dist; // vel*curvature;
    RotatedRect trr = r;
    if(abs(curvature) > 0.01) {
        Point2f Rotp(m_props.distRight + 100 / curvature, m_props.distRear); // m -> cm
        Point2f newcp = trr.center - Rotp;
        Mat temp(newcp, false);
        tFloat32 sinphi = sin(dphi);
        tFloat32 cosphi = cos(dphi);
        temp = (Mat_<float>(2, 2) << cosphi, -sinphi, sinphi, cosphi) * temp;
        newcp += Rotp;
        trr.center = newcp;
    } else
    {
        trr.center.y -= dist*100; //m -> cm
        dphi =0;
    }

    trr.angle = dphi * 180 / 3.1415;
    return trr;
}

tUInt cLowLevelController::checkRotRectangle(const Mat &m, const RotatedRect &r) {
    Rect boundingR = r.boundingRect();
    RotatedRect rt = r;

    rt.center -= Point2f(boundingR.x, boundingR.y);

    Point2f vs[4];
    rt.points(vs);
    tUInt sum = 0;

    if(boundingR.x < 0 || boundingR.y < 0 || boundingR.x+boundingR.width > m.cols || boundingR.y+boundingR.height > m.rows){
        return 2000;
    }
    //if(m_props.debug) cout << "points: " << vs[0] << ", "<< vs[1] << ", " << vs[2] << ", " << vs[3] << endl;
    try {
        Mat check = Mat(m, boundingR);
        Point2f normals[4];
        tFloat32 distances[4];
        for (int i = 0; i < 4; i++) {
            Point2f temp = vs[(i + 1) % 4] - vs[i];
            normals[i].x = -temp.y;
            normals[i].y = temp.x;

            normals[i] /= norm(normals[i]);
            distances[i] = vs[i].dot(normals[i]);
            //if(m_props.debug) cout << "normals [" << i << "]: " << normals[i] << " distance: " << distances[i] << endl;
        }

        for (int row = 0; row < check.rows; row++) {
            tUInt8 *ptr = check.ptr(row);
            for (int col = 0; col < check.cols; col++) {
                Point2f cp(col, row);
                if (cp.dot(normals[0]) > distances[0] && cp.dot(normals[1]) > distances[1] &&
                        cp.dot(normals[2]) > distances[2] && cp.dot(normals[3]) > distances[3]) {
                    if(ptr[col] < m_props.threshold)sum++;
                }
            }
        }
    } catch (cv::Exception e) {
        if(m_props.debug) cout << "not able to test Rectangle." << e.what() << endl;
        if(m_props.debug) cout << "size of mat: " << m.size() << endl;
        if(m_props.debug) cout << "size of bounding rectangle: " << boundingR << endl;
        sum = 10000;
    }
    return sum;

}

tResult cLowLevelController::ProcessData()
{
    RETURN_NOERROR;
}

void cLowLevelController::DoEmergencyStop(bool doIt) {
    cout << "LowLevelController: Emergency stop: " << doIt << endl;
  ForceEB = doIt;
}
