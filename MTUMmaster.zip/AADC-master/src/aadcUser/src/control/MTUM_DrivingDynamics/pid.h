#ifndef PID_H
#define PID_H

#include <adtf_plugin_sdk.h>
#include <iostream>

#define SCALING_FACTOR 1.0f
#define MAX_I_TERM 100.0f
#define MAX_VALUE 100.0f

class pid
{

public:
    typedef struct PID_DATA
    {
        // Last process value, used to find derivative of process value.
        tFloat32 lastProcessValue;

        // The Proportional tuning constant, multiplied with SCALING_FACTOR
        tFloat32 P_Factor;
        // The Integral tuning constant, multiplied with SCALING_FACTOR
        tFloat32 I_Factor;
        // The Derivative tuning constant, multiplied with SCALING_FACTOR
        tFloat32 D_Factor;

        // Maximum allowed error, avoid overflow
        tFloat32 maxError;
        // Summation of errors, used for integrate calculations
        tFloat32 sumError;
        // Maximum allowed sumerror, avoid overflow
        tFloat32 maxSumError;
    } tPIDData;

    /**
     * @brief pid::pid_SetParameter Initialisation of PID controller parameters.
     *
     * Initialise the variables used by the PID algorithm
     *
     * @param p_factor Proportional term.
     * @param i_factor Integral term.
     * @param d_factor Derivate term.
     * @param pid
     */
    static void pid_SetParameter(tFloat32 p_factor, tFloat32 i_factor, tFloat32 d_factor, struct PID_DATA *pid)
    {
        // Start values for PID controller
        pid->sumError = 0.0f;
        pid->lastProcessValue = 0.0f;
        // Tuning constants for PID loop
        pid->P_Factor = p_factor;
        pid->I_Factor = i_factor;
        pid->D_Factor = d_factor;
        // Limits to avoid overflow
        pid->maxError = 355.0f;         //2.0 m/s
        pid->maxSumError = 10000000.0f;
    }

    /**
     * @brief pid::pid_Controller PID control algorithm
     *
     * Calculates output from setpoint, process value and PID status.
     *
     * @param setPoint Desired value.
     * @param processValue Measured value.
     * @param pid_st PID status struct.
     * @return
     */
    static tFloat32 pid_Controller(tFloat32 setPoint, tFloat32 processValue, struct PID_DATA *pid_st)
    {
        tFloat32 error, p_term, d_term;
        tFloat32 i_term, ret, tmp;

        error = setPoint - processValue;

        //Step 1: Calculate Pterm and limit error overflow
        if (error > pid_st->maxError)
            p_term = MAX_VALUE;
        else if (error < -pid_st->maxError)
            p_term = -MAX_VALUE;
        else
            p_term = pid_st->P_Factor * error;


        //Step 2: Calculate Iterm and limit integral runaway
        tmp = pid_st->sumError + error;
        if (tmp > pid_st->maxSumError)
        {
            i_term = MAX_I_TERM;
            pid_st->sumError = pid_st->maxSumError;
        } else if (tmp < -pid_st->maxSumError)
        {
            i_term = -MAX_I_TERM;
            pid_st->sumError = -pid_st->maxSumError;
        } else {
            pid_st->sumError = tmp;
            i_term = pid_st->I_Factor * pid_st->sumError;
        }

        //Step 3: Calculate Dterm
        d_term = pid_st->D_Factor * (pid_st->lastProcessValue - processValue);
        //cout << "d-term: " << d_term << endl;
        //cout << "p-term: " << p_term << endl;
        //cout << "i-term: " << i_term << endl;

        pid_st->lastProcessValue = processValue;

        //Step 4: Calculate Return Value
        ret = (p_term + i_term + d_term) / SCALING_FACTOR;

        if (ret > MAX_VALUE)
            ret = MAX_VALUE;
        else if (ret < -MAX_VALUE)
            ret = -MAX_VALUE;

        return ret;
    }

    /**
     * @brief pid::pid_Reset_Integrator Resets the integrator.
     *
     * Calling this function will reset the integrator in the PID regulator.
     *
     * @param pid_st
     */
    static void pid_Reset_Integrator(tPIDData *pid_st)
    {
        pid_st->sumError = 0.0f;
    }
};

#endif // PID_H
