
/**
Copyright (c)
Audi Autonomous Driving Cup. Team MomenTUM. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
3.  All advertising materials mentioning features or use of this software must display the following acknowledgement: "This product includes software developed by the Audi AG and its contributors for Audi Autonomous Driving Cup."
4.  Neither the name of Audi nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY AUDI AG AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL AUDI AG OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


**********************************************************************
* $Author:: MomenTUM#$  $Date:: 2015-10-10 15:10:07#$ $Rev:: 35043   $
**********************************************************************/

#include "stdafx.h"
#include "mtum_driving_dynamics_core.h"
#include <iostream>


cDrivingDynamicsCore::cDrivingDynamicsCore(iDrivingDynamicsInterface *parent)
{
    m_pFilterReference = parent;

    m_WheelStateHistory_Index = 0;

    m_SetPointSpeed = 0.0f;
    m_SetPointCurvature = 0.0f;

    m_VehicleState.WheelSpeed = 0.0f;

    logDiv = 0;
}

cDrivingDynamicsCore::~cDrivingDynamicsCore()
{
}


void cDrivingDynamicsCore::UpdateSetPointValue(tFloat32 setPointSpeed, tFloat32 setPointCurvature)
{
    m_SetPointSpeed = setPointSpeed;
    m_SetPointCurvature = setPointCurvature;
}


void cDrivingDynamicsCore::SetLongRegulatorProperty(tFloat32 p_factor, tFloat32 i_factor, tFloat32 d_factor)
{
    pid::pid_SetParameter(p_factor, i_factor, d_factor, &m_oLong_PID_ST);
}

tResult cDrivingDynamicsCore::ProcessWheelData(tUInt32 tach, tInt8 dir, tBool leftWheel, tTimeStamp timestamp)
{
    //Step 1: Save Wheel-Data to calculate vehicle-state afterwards
    if(leftWheel)
    {
        m_WheelStateHistory_Left[m_WheelStateHistory_Index].dir = dir;
        m_WheelStateHistory_Left[m_WheelStateHistory_Index].tach = tach;
        m_WheelStateHistory_Left[m_WheelStateHistory_Index].timestamp = timestamp;
    } else {
        m_WheelStateHistory_Right[m_WheelStateHistory_Index].dir = dir;
        m_WheelStateHistory_Right[m_WheelStateHistory_Index].tach = tach;
        m_WheelStateHistory_Right[m_WheelStateHistory_Index].timestamp = timestamp;
    }
    //Wait for both values (left & right) before going to the next step in history
    if(m_WheelStateHistory_Right[m_WheelStateHistory_Index].tach != 0 &&
            m_WheelStateHistory_Left[m_WheelStateHistory_Index].tach != 0) m_WheelStateHistory_Index++;

    //Step 2: If the history-cycle is completed, calculate vehicle state
    if(m_WheelStateHistory_Index == WHEEL_STATE_HISTORY_MAX) {
        tFloat32 leftWheel_ticks = 0.0f;
        tFloat32 rightWheel_ticks = 0.0f;

        tUInt32 timeStart = 0;
        tUInt32 timeEnd = 0;

        //Step 2.1: Calculate the amount of ticks peer wheel
        //Left-Wheel ticks whithin history
        leftWheel_ticks = m_WheelStateHistory_Left[WHEEL_STATE_HISTORY_MAX - 1].tach - m_WheelStateHistory_Left[0].tach;
        leftWheel_ticks *= (m_WheelStateHistory_Left[WHEEL_STATE_HISTORY_MAX - 1].dir == 1) ? -1: 1;

        //Right-Wheel ticks within history
        rightWheel_ticks += m_WheelStateHistory_Right[WHEEL_STATE_HISTORY_MAX - 1].tach - m_WheelStateHistory_Right[0].tach;
        rightWheel_ticks *= (m_WheelStateHistory_Right[WHEEL_STATE_HISTORY_MAX - 1].dir == 1) ? -1: 1;

        //Step 2.2: Calculate amount of time passed within history
        //take timestamp from earliest sample as start-timestamp
        timeStart = m_WheelStateHistory_Left[0].timestamp < m_WheelStateHistory_Right[0].timestamp ?
                    m_WheelStateHistory_Left[0].timestamp : m_WheelStateHistory_Right[0].timestamp;
        //take timestamp from latest sample as end-timestamp
        timeEnd = m_WheelStateHistory_Left[WHEEL_STATE_HISTORY_MAX - 1].timestamp < m_WheelStateHistory_Right[WHEEL_STATE_HISTORY_MAX - 1].timestamp ?
                    m_WheelStateHistory_Left[WHEEL_STATE_HISTORY_MAX - 1].timestamp : m_WheelStateHistory_Right[WHEEL_STATE_HISTORY_MAX - 1].timestamp;

        //Step 2.3: Calculate vehicle-speed
        tFloat32 axleTicks = (leftWheel_ticks + rightWheel_ticks) / 2;
        tFloat32 timeSpan = ((timeEnd - timeStart) / 1000000.0f);
        tFloat32 multiplier = 1.0f / timeSpan;
        m_VehicleState.WheelSpeed = axleTicks * multiplier;

        //Reset history
        for(tUInt8 x = 0; x < WHEEL_STATE_HISTORY_MAX; x++)
            m_WheelStateHistory_Left[x].tach = m_WheelStateHistory_Right[x].tach = 0;
        m_WheelStateHistory_Index = 0;

        //Step 3: Start the regulation of the speed
        tFloat32 driveValue = 0.0f;

        //Step 3.1: get the pid-value (between 0 and 100) based on the current speed and the set-point-speed
        driveValue = pid::pid_Controller(m_SetPointSpeed / METER_PER_WHEELTICK, m_VehicleState.WheelSpeed, &m_oLong_PID_ST);
        //Step 3.2: scale the pid-value to the actuator-range (100 -> 90, 50 -> 45)
        driveValue = (90.0f * (driveValue / 100.0f));
        //Step 3.3: distinguish direction of setPoint-speed
        if(m_SetPointSpeed < 0)
            driveValue = 90 - driveValue;
        else
            driveValue = 90 + driveValue;

        //Step 4: set linear regulation if setPointSpeet is <= 0.4f
        if(m_SetPointSpeed <= 0.4f && m_SetPointSpeed >= -0.4f)
        {
            driveValue = m_SetPointSpeed * 10 + 90;
            //Reset the PIDs integrator
            pid::pid_Reset_Integrator(&m_oLong_PID_ST);
        }


        if(logDiv > 5)
        {
            //cout << "Speed: " << m_VehicleState.WheelSpeed << "\\" << m_SetPointSpeed / METER_PER_WHEELTICK << endl;
            //cout << "actuator: " << driveValue << endl;
            logDiv = 0;
        } else {
            logDiv++;
        }

        //Step 4: calculate steering
        tFloat32 steering = atan(m_SetPointCurvature * (CAR_AXIS2AXIS / 100.0f));
        steering = -steering*180/3.141592654 + 90;

        //Limit the value
        if(steering <= 60)
            steering = 60;
        if(steering > 120)
            steering = 120;

        //Final: Set actuator-value
        m_pFilterReference->SendActuatorValues(driveValue, steering);
    }

    RETURN_ERROR(ERR_CANCELLED);
}
