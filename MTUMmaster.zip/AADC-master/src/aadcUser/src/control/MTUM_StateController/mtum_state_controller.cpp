/**
Copyright (c) 
Audi Autonomous Driving Cup. All rights reserved.
 
Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 
1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
3.  All advertising materials mentioning features or use of this software must display the following acknowledgement: �This product includes software developed by the Audi AG and its contributors for Audi Autonomous Driving Cup.�
4.  Neither the name of Audi nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 
THIS SOFTWARE IS PROVIDED BY AUDI AG AND CONTRIBUTORS �AS IS� AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL AUDI AG OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


**********************************************************************
* $Author:: spiesra $  $Date:: 2015-05-13 08:29:07#$ $Rev:: 35003   $
**********************************************************************/

#include "stdafx.h"
#include "mtum_state_controller.h"
#include "StatusMessage.h"
#include <BoolSignalValueType.h>
#include <iostream>


ADTF_FILTER_PLUGIN("MTUM State Controller", __guid, cStateController);

#define SC_PROP_FILENAME "Maneuver File"


cStateController::cStateController(const tChar* __info) : cFilter(__info), m_bDebugModeEnabled(tFalse), m_hTimer(NULL), m_FilterCore(this)
{
    SetPropertyBool("Debug Output to Console",false);    
    SetPropertyStr("Debug Output to Console" NSSUBPROP_DESCRIPTION, "If enabled additional debug information is printed to the console (Warning: decreases performance)"); 

    SetPropertyBool("Ignore Ready Check",false);
    SetPropertyStr("Ignore Ready Check" NSSUBPROP_DESCRIPTION, "If enabled the state is directly set to READY.");

    SetPropertyBool("Auto Start",false);
    SetPropertyStr("Auto Start" NSSUBPROP_DESCRIPTION, "If enabled the state is directly set to START.");

    SetPropertyStr("default maneuverlist", "");
    SetPropertyBool("default maneuverlist" NSSUBPROP_FILENAME, tTrue);
    SetPropertyStr("default maneuverlist" NSSUBPROP_FILENAME NSSUBSUBPROP_EXTENSIONFILTER, "xml Files (*.xml)");
    SetPropertyStr("default maneuverlist" NSSUBPROP_DESCRIPTION, "The default maneuver list");
}

cStateController::~cStateController()
{
}

tResult cStateController::Init(tInitStage eStage, __exception)
{
    RETURN_IF_FAILED(cFilter::Init(eStage, __exception_ptr));

    // pins need to be created at StageFirst
    if (eStage == StageFirst)    
    {
        RETURN_IF_FAILED(CreatePins(__exception_ptr));
    }
    else if(eStage == StageGraphReady)
    {
        m_bDebugModeEnabled = GetPropertyBool("Debug Output to Console");
        bool ignoreReadyChecks = GetPropertyBool("Ignore Ready Check");
        bool autoStart = GetPropertyBool("Auto Start");



        // no ids were set yet
        m_bIDsDriverStructSet = tFalse;
        m_bIDsJuryStructSet = tFalse;

        cFilename filen = GetPropertyStr("default maneuverlist");
        m_FilterCore.LoadManeuverListFromFile(filen);

        m_FilterCore.Init(m_bDebugModeEnabled, ignoreReadyChecks, autoStart);

    }
    RETURN_NOERROR;
}

tResult cStateController::Start(__exception)
{
    __synchronized_obj(m_oCriticalSectionTimerSetup);
    createTimer();

    return cFilter::Start(__exception_ptr);
}

tResult cStateController::Run(tInt nActivationCode, const tVoid* pvUserData, tInt szUserDataSize, ucom::IException** __exception_ptr/* =NULL */)
{
    if (nActivationCode == IRunnable::RUN_TIMER)
    {
        SendState(m_FilterCore.GetState(),m_FilterCore.GetCurrentManeuverID());
        SendStatusMessage(ALL, m_FilterCore.GetManeuver());
    }
    
    return cFilter::Run(nActivationCode, pvUserData, szUserDataSize, __exception_ptr);
}

tResult cStateController::Stop(__exception)
{
    __synchronized_obj(m_oCriticalSectionTimerSetup);    
    destroyTimer(__exception_ptr);

    return cFilter::Stop(__exception_ptr);
}

tResult cStateController::Shutdown(tInitStage eStage, __exception)
{     
    return cFilter::Shutdown(eStage, __exception_ptr);
}

tResult cStateController::OnPinEvent(IPin* pSource, tInt nEventCode, tInt nParam1, tInt nParam2, IMediaSample* pMediaSample)
{

    RETURN_IF_POINTER_NULL(pMediaSample);
    RETURN_IF_POINTER_NULL(pSource);

    if (nEventCode == IPinEventSink::PE_MediaSampleReceived  )
    {      
        if (pSource == &m_oStatusInput)
        {
            DecodeStatusMessage(pMediaSample);
        }
        else if (pSource == &m_JuryStructInputPin)
        {
            DecodeJuryMessage(pMediaSample);

        }
        else if (pSource == &m_ManeuverListInputPin && m_pDescManeuverList != NULL)
        {
            DecodeManeuverList(pMediaSample);
        }
    }
    RETURN_NOERROR;

}

tResult cStateController::DecodeJuryMessage(IMediaSample* pMediaSample)
{
    tInt8 i8ActionID = -2;
    tInt16 i16entry = -1;

    {   // focus for sample read lock
        __adtf_sample_read_lock_mediadescription(m_pDescriptionJuryStruct,pMediaSample,pCoder);

        // get the IDs for the items in the media sample
        if(!m_bIDsJuryStructSet)
        {
            pCoder->GetID("i8ActionID", m_szIDJuryStructI8ActionID);
            pCoder->GetID("i16ManeuverEntry", m_szIDJuryStructI16ManeuverEntry);
            m_bIDsJuryStructSet = tTrue;
        }

        pCoder->Get(m_szIDJuryStructI8ActionID, (tVoid*)&i8ActionID);
        pCoder->Get(m_szIDJuryStructI16ManeuverEntry, (tVoid*)&i16entry);
    }

    return m_FilterCore.ProcessJuryUpdate(juryActions(i8ActionID), i16entry);
}

tResult cStateController::DecodeStatusMessage(IMediaSample* pMediaSample)
{
    // this will store the value for our new sample
    tStatusMessage status_message;

    // now lets access the data in the sample,
    // the Lock method gives you access to the buffer of the sample.
    // we use a scoped sample lock to ensure that the lock is released in all circumstances.

    {
        // this will aquire the read lock on the sample and declare and initialize a pointer to the data
        __sample_read_lock(pMediaSample, tStatusMessage, pData);
        // now we can access the sample data through the pointer
        status_message = *pData;
        // the read lock on the sample will be released when leaving this scope
    }

    if(status_message.destination == mtum_filters(CAR_CONTROL) || status_message.destination == mtum_filters(ALL))
        m_FilterCore.ProcessStatusUpdate(mtum_filters(status_message.source), mtum_status_messages(status_message.content));
    else
        SendStatusMessage(mtum_filters(status_message.destination), mtum_status_messages(status_message.content));

    RETURN_NOERROR;
}

tResult cStateController::DecodeManeuverList(IMediaSample* pMediaSample)
{

    {   // focus for sample read lock
        __adtf_sample_read_lock_mediadescription(m_pDescManeuverList,pMediaSample,pCoder);

        std::vector<tSize> vecDynamicIDs;

        // retrieve number of elements by providing NULL as first paramter
        tSize szBufferSize = 0;
        if(IS_OK(pCoder->GetDynamicBufferIDs(NULL, szBufferSize)))
        {
            // create a buffer depending on the size element
            tChar* pcBuffer = new tChar[szBufferSize];
            vecDynamicIDs.resize(szBufferSize);
            // get the dynamic ids (we already got the first "static" size element)
            if (IS_OK(pCoder->GetDynamicBufferIDs(&(vecDynamicIDs.front()), szBufferSize)))
            {
                // iterate over all elements
                for (tUInt32 nIdx = 0; nIdx < vecDynamicIDs.size(); ++nIdx)
                {
                    // get the value and put it into the buffer
                    pCoder->Get(vecDynamicIDs[nIdx], (tVoid*)&pcBuffer[nIdx]);
                }

                // set the resulting char buffer to the string object
                RETURN_IF_FAILED(m_FilterCore.LoadManeuverList((const tChar*) pcBuffer));
            }

            // cleanup the buffer
            delete pcBuffer;
        }
    }
    RETURN_NOERROR;
}

tResult cStateController::SendStatusMessage(mtum_filters destination, mtum_status_messages content)
{
    // now we need a new media sample to forward the data.
    cObjectPtr<IMediaSample> pNewSample;
    if (IS_OK(AllocMediaSample(&pNewSample)))
    {
        // now set its data
        // we reuse the timestamp from the incoming media sample. Please see the api documentation
        // (ADTF Extreme Programmers -> The ADTF Streamtime) for further reference on how sample times are handled in ADTF
        tStatusMessage message;
        message.source = mtum_filters(CAR_CONTROL);
        message.destination = mtum_filters(destination);
        message.content = mtum_status_messages(content);
        pNewSample->Update(_clock->GetStreamTime(), &message, sizeof(tStatusMessage), 0);

        // and now we can transmit it
        m_oStatusOutput.Transmit(pNewSample);
    }

    RETURN_NOERROR;
}


tResult cStateController::SendState(stateCar state, tInt16 i16ManeuverEntry)
{            
    __synchronized_obj(m_oCriticalSectionTransmit);
    
    cObjectPtr<IMediaSample> pMediaSample;
    RETURN_IF_FAILED(AllocMediaSample((tVoid**)&pMediaSample));

    cObjectPtr<IMediaSerializer> pSerializer;
    m_pDescriptionDriverStruct->GetMediaSampleSerializer(&pSerializer);
    tInt nSize = pSerializer->GetDeserializedSize();

    tInt8 bValue = tInt8(state);

    RETURN_IF_FAILED(pMediaSample->AllocBuffer(nSize));
    {   // focus for sample write lock
        __adtf_sample_write_lock_mediadescription(m_pDescriptionDriverStruct,pMediaSample,pCoder);

        // get the IDs for the items in the media sample 
        if(!m_bIDsDriverStructSet)
        {
            pCoder->GetID("i8StateID", m_szIDDriverStructI8StateID);
            pCoder->GetID("i16ManeuverEntry", m_szIDDriverStructI16ManeuverEntry);
            m_bIDsDriverStructSet = tTrue;
        }  

        pCoder->Set(m_szIDDriverStructI8StateID, (tVoid*)&bValue);
        pCoder->Set(m_szIDDriverStructI16ManeuverEntry, (tVoid*)&i16ManeuverEntry);
    }      
        
    pMediaSample->SetTime(_clock->GetStreamTime());
    m_DriverStructOutputPin.Transmit(pMediaSample);
        
    //debug output to console
    if(m_bDebugModeEnabled)  
    {
        switch (state)
            {
            case stateCar_ERROR:
                if(m_bDebugModeEnabled) LOG_INFO(cString::Format("State Controller Module: Send state: ERROR, Maneuver ID %d",i16ManeuverEntry));
                break;
            case stateCar_READY:
                if(m_bDebugModeEnabled) LOG_INFO(cString::Format("State Controller Module: Send state: READY, Maneuver ID %d",i16ManeuverEntry));
                break;
            case stateCar_RUNNING:
                if(m_bDebugModeEnabled) LOG_INFO(cString::Format("State Controller Module: Send state: RUNNING, Maneuver ID %d",i16ManeuverEntry));
                break;
            case stateCar_COMPLETE:
                if(m_bDebugModeEnabled) LOG_INFO(cString::Format("State Controller Module: Send state: COMPLETE, Maneuver ID %d",i16ManeuverEntry));                   
                break;
            case stateCar_STARTUP:
                break;
            }
    }
        
    RETURN_NOERROR;
}


tResult cStateController::createTimer()
{
     // creates timer with 0.5 sec
     __synchronized_obj(m_oCriticalSectionTimerSetup);
     // additional check necessary because input jury structs can be mixed up because every signal is sent three times
     if (m_hTimer == NULL)
     {
            m_hTimer = _kernel->TimerCreate(tTimeStamp(0.5*1e6), 0, static_cast<IRunnable*>(this),
                                        NULL, NULL, 0, 0, adtf_util::cString::Format("%s.timer", OIGetInstanceName()));
     }
     else
     {
        LOG_ERROR("Timer is already running. Unable to create a new one.");
     }
     RETURN_NOERROR;
}

tResult cStateController::destroyTimer(__exception)
{
    __synchronized_obj(m_oCriticalSectionTimerSetup);
    //destroy timer
    if (m_hTimer != NULL) 
    {        
        tResult nResult = _kernel->TimerDestroy(m_hTimer);
        if (IS_FAILED(nResult))
        {
            LOG_ERROR("Unable to destroy the timer.");
            THROW_ERROR(nResult);
        }
        m_hTimer = NULL;
    }
    //check if handle for some unknown reason still exists
    else       
    {
        LOG_WARNING("Timer handle not set, but I should destroy the timer. Try to find a timer with my name.");
        tHandle hFoundHandle = _kernel->FindHandle(adtf_util::cString::Format("%s.timer", OIGetInstanceName()));
        if (hFoundHandle)
        {
            tResult nResult = _kernel->TimerDestroy(hFoundHandle);
            if (IS_FAILED(nResult))
            {
                LOG_ERROR("Unable to destroy the found timer.");
                THROW_ERROR(nResult);
            }
        }
    }

    RETURN_NOERROR;
}


tResult cStateController::CreatePins(__exception)
{
    cObjectPtr<IMediaDescriptionManager> pDescManager;
    RETURN_IF_FAILED(_runtime->GetObject(OID_ADTF_MEDIA_DESCRIPTION_MANAGER,
                                         IID_ADTF_MEDIA_DESCRIPTION_MANAGER,
                                         (tVoid**)&pDescManager,
                                         __exception_ptr));
    /*
    * the MediaDescription for <struct name="tJuryNotAusFlag" .../> has to exist in a description file (e.g. in $ADTF_DIR\description\ or $ADTF_DIR\src\examples\src\description
    * before (!) you start adtf_devenv !! if not: the Filter-Plugin will not loaded because cPin.Create() and so ::Init() failes !
    */

    // create and register the status-input pin
    RETURN_IF_FAILED(m_oStatusInput.Create("status_input", new cMediaType(0,0,0,STATUSMESSAGE), this));
    RETURN_IF_FAILED(RegisterPin(&m_oStatusInput));

    // create and register the output pin
    RETURN_IF_FAILED(m_oStatusOutput.Create("status_output", new cMediaType(0,0,0,STATUSMESSAGE), this));
    RETURN_IF_FAILED(RegisterPin(&m_oStatusOutput));

    // input jury struct
    tChar const * strDesc1 = pDescManager->GetMediaDescription("tJuryStruct");
    RETURN_IF_POINTER_NULL(strDesc1);
    cObjectPtr<IMediaType> pType1 = new cMediaType(0, 0, 0, "tJuryStruct", strDesc1, IMediaDescription::MDF_DDL_DEFAULT_VERSION);
    RETURN_IF_FAILED(m_JuryStructInputPin.Create("Jury_Struct", pType1, this));
    RETURN_IF_FAILED(RegisterPin(&m_JuryStructInputPin));
    RETURN_IF_FAILED(pType1->GetInterface(IID_ADTF_MEDIA_TYPE_DESCRIPTION, (tVoid**)&m_pDescriptionJuryStruct));

    // output driver struct
    tChar const * strDesc2 = pDescManager->GetMediaDescription("tDriverStruct");
    RETURN_IF_POINTER_NULL(strDesc2);
    cObjectPtr<IMediaType> pType2 = new cMediaType(0, 0, 0, "tDriverStruct", strDesc2, IMediaDescription::MDF_DDL_DEFAULT_VERSION);
    RETURN_IF_FAILED(m_DriverStructOutputPin.Create("Driver_Struct", pType2, this));
    RETURN_IF_FAILED(RegisterPin(&m_DriverStructOutputPin));
    RETURN_IF_FAILED(pType2->GetInterface(IID_ADTF_MEDIA_TYPE_DESCRIPTION, (tVoid**)&m_pDescriptionDriverStruct));

    // input maneuver list
    tChar const * strDesc3 = pDescManager->GetMediaDescription("tManeuverList");
    RETURN_IF_POINTER_NULL(strDesc3);
    cObjectPtr<IMediaType> pType3 = new cMediaType(0, 0, 0, "tManeuverList", strDesc3, IMediaDescription::MDF_DDL_DEFAULT_VERSION);
    RETURN_IF_FAILED(m_ManeuverListInputPin.Create("Maneuver_List", pType3, this));
    RETURN_IF_FAILED(RegisterPin(&m_ManeuverListInputPin));
    RETURN_IF_FAILED(pType3->GetInterface(IID_ADTF_MEDIA_TYPE_DESCRIPTION, (tVoid**)&m_pDescManeuverList));

    RETURN_NOERROR;
}



