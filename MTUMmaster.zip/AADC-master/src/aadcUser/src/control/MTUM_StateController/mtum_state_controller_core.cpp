/**
Copyright (c)
Audi Autonomous Driving Cup. Team MomenTUM. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
3.  All advertising materials mentioning features or use of this software must display the following acknowledgement: "This product includes software developed by the Audi AG and its contributors for Audi Autonomous Driving Cup."
4.  Neither the name of Audi nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY AUDI AG AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL AUDI AG OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


**********************************************************************
* $Author:: MomenTUM#$  $Date:: 2015-10-10 15:10:07#$ $Rev:: 35043   $
**********************************************************************/

#include "stdafx.h"
#include "mtum_state_controller_core.h"
#include <iostream>


cStateControllerCore::cStateControllerCore(iStateControllerInterface *parent)
{
    m_pFilterReference = parent;

}

cStateControllerCore::~cStateControllerCore()
{
}

tResult cStateControllerCore::ProcessJuryUpdate(juryActions action, tInt16 maneuverID)
{
    //change the state depending on the input
    // action_GETREADY --> stateCar_READY
    // action_START --> stateCar_RUNNING
    // action_STOP --> stateCar_STARTUP
    switch (juryActions(action))
    {
        case action_GETREADY:
            if(m_bDebugModeEnabled)  LOG_INFO(cString::Format("State Controller: Received: Request Ready with maneuver ID %d",maneuverID));

            m_pFilterReference->SendStatusMessage(ALL, RESET);
            for(int i = 1; i < FILTER_COUNT; i++)
                m_FilterReady[i] = false;

            m_pFilterReference->SendStatusMessage(ALL, IS_READY);

            break;
        case action_START:
            if(m_bDebugModeEnabled)  LOG_INFO(cString::Format("State Controller: Received: Run with maneuver ID %d",maneuverID));

            if (m_State == stateCar_STARTUP || m_State == stateCar_COMPLETE) {
                ChangeState(stateCar_ERROR);
            }
            else {
                if (maneuverID == m_CurrentManeuverID)
                    ChangeState(stateCar_RUNNING);
                else {
                    LOG_WARNING(
                            "StateController: The id of the action_START corresponds not with the id of the last action_GETREADY");
                    SetManeuverID(maneuverID);
                    ChangeState(stateCar_RUNNING);
                }
            }
            break;
        case action_STOP:
            if(m_bDebugModeEnabled)  LOG_INFO(cString::Format("State Controller: Received: Stop with maneuver ID %d",maneuverID));

            ChangeState(stateCar_ERROR);

            break;
    }

    RETURN_NOERROR;
}

tResult cStateControllerCore::ProcessStatusUpdate(mtum_filters source, mtum_status_messages content)
{
    switch(mtum_status_messages(content))
    {
    case NOT_READY:
        m_FilterReady[source-1] = false;
        break;

    case READY:
        m_FilterReady[source-1] = true;

        if(CheckIfAllReady())
        {
            ChangeState(stateCar_READY);
        }
        break;

    case ERROR:
        m_FilterReady[source-1] = false;
        LOG_ERROR("CarControl: One or more filters reported a problem. Stopping car and trying reset!");
        ChangeState(stateCar_ERROR);
        break;

    case MANEUVER_DONE:
        LOG_INFO("Done received");
        IncrementManeuverID();
        break;

    case PARKING_LOTS_FOUND:
        m_pFilterReference->SendStatusMessage(PLANNING, SET_INACTIVE);

    default:
        LOG_INFO("CarControl: A filter send a status update with unknown meaning!");
    }

    RETURN_NOERROR;
}

tResult cStateControllerCore::ChangeState(stateCar newState)
{
    // if state is the same do nothing
    if (m_State == newState) RETURN_NOERROR;

    //handle the timer depending on the state
    switch (newState)
    {
    case stateCar_ERROR:
        LOG_INFO("State ERROR reached");

        m_pFilterReference->SendStatusMessage(LOW_LEVEL_CONTROL, SET_INACTIVE);
        m_pFilterReference->SendStatusMessage(PARKING, SET_INACTIVE);

        break;
    case stateCar_STARTUP:
        LOG_INFO("State STARTUP reached");

        m_pFilterReference->SendStatusMessage(LOW_LEVEL_CONTROL, SET_INACTIVE);
        m_pFilterReference->SendStatusMessage(PARKING, SET_INACTIVE);
        break;
    case stateCar_READY:
        LOG_INFO(adtf_util::cString::Format("State READY reached (ID %d)",m_CurrentManeuverID));

        m_pFilterReference->SendStatusMessage(LOW_LEVEL_CONTROL, SET_INACTIVE);
        m_pFilterReference->SendStatusMessage(PARKING, SET_INACTIVE);
        break;
    case stateCar_RUNNING:
        m_pFilterReference->SendStatusMessage(LOW_LEVEL_CONTROL, SET_ACTIVE);
        m_pFilterReference->SendStatusMessage(PARKING, SET_ACTIVE);
        LOG_INFO("State RUNNING reached");
        break;
    case stateCar_COMPLETE:
        LOG_INFO("State COMPLETE reached");

        m_pFilterReference->SendStatusMessage(LOW_LEVEL_CONTROL, SET_INACTIVE);
        m_pFilterReference->SendStatusMessage(PARKING, SET_INACTIVE);
        break;
    }

    m_State = newState;


    RETURN_NOERROR;
}

tResult cStateControllerCore::IncrementManeuverID()
{
    //check if list was sucessfully loaded in init
    if (m_ManeuverListIndex!=-1 && m_SectionListIndex!=-1)
    {
        //check if end of section is reached
        if (m_SectorList[m_SectionListIndex].maneuverList.size()>tUInt(m_ManeuverListIndex+1))
        {
            //increment only maneuver index
            m_ManeuverListIndex++;
            m_CurrentManeuverID++;
        }
        else
        {
            //end of section was reached and another section is in list
            if (m_SectorList.size() >tUInt(m_SectionListIndex+1))
            {
                //reset maneuver index to zero and increment section list index
                m_SectionListIndex++;
                m_ManeuverListIndex=0;
                m_CurrentManeuverID++;

                if (m_SectorList[m_SectionListIndex].maneuverList[m_ManeuverListIndex].id !=m_CurrentManeuverID)
                {
                    LOG_ERROR("State Controller: inconsistancy in maneuverfile detected. Please check the file ");
                }
            }
            else
            {
                ChangeState(stateCar_COMPLETE);
                LOG_ERROR("State Controller: end of maneuverlist reached, cannot increment any more");
            }
        }
    }
    else
    {
        LOG_ERROR("State Controller: could not set new maneuver id because no maneuver list was loaded");
    }

    if(m_bDebugModeEnabled) LOG_INFO(adtf_util::cString::Format("Increment Manevuer ID: Sectionindex is %d, Maneuverindex is %d, ID is %d",m_SectionListIndex,m_ManeuverListIndex,m_CurrentManeuverID));

    m_pFilterReference->SendStatusMessage(ALL, GetManeuver());

    RETURN_NOERROR;
}

tResult cStateControllerCore::ResetSection()
{
    //maneuver list index to zero, and current maneuver id to first element in list
    m_ManeuverListIndex=0;
    m_CurrentManeuverID = m_SectorList[m_SectionListIndex].maneuverList[m_ManeuverListIndex].id;

    if(m_bDebugModeEnabled) LOG_INFO(adtf_util::cString::Format("Reset section: Sectionindex is %d, Maneuverindex is %d, ID is %d",m_SectionListIndex,m_ManeuverListIndex,m_CurrentManeuverID));

    m_pFilterReference->SendStatusMessage(ALL, GetManeuver());

    RETURN_NOERROR;
}

tResult cStateControllerCore::SetManeuverID(tInt maneuverId)
{
    //look for the right section id and write it to section combobox
    for(unsigned int i = 0; i < m_SectorList.size(); i++)
    {
        for(unsigned int j = 0; j < m_SectorList[i].maneuverList.size(); j++)
        {
            if(maneuverId == m_SectorList[i].maneuverList[j].id)
            {
                m_SectionListIndex = i;
                m_ManeuverListIndex = j;
                m_CurrentManeuverID = maneuverId;
                if(m_bDebugModeEnabled) LOG_INFO(adtf_util::cString::Format("Sectionindex is %d, Maneuverindex is %d, ID is %d",m_SectionListIndex,m_ManeuverListIndex,m_CurrentManeuverID));
                break;
            }
        }
    }

    m_pFilterReference->SendStatusMessage(ALL, GetManeuver());

    RETURN_NOERROR;
}

tInt16 cStateControllerCore::GetCurrentManeuverID()
{
    return m_CurrentManeuverID;
}

stateCar cStateControllerCore::GetState()
{
    if(m_State == stateCar_STARTUP)
        return stateCar_ERROR;
    return m_State;
}

bool cStateControllerCore::IsActive()
{
    return (m_State == stateCar_RUNNING);
}

mtum_status_messages cStateControllerCore::GetManeuver()
{
    mtum_status_messages content;
    if(m_SectionListIndex >= m_SectorList.size() || m_SectionListIndex < 0)
    {
        LOG_ERROR(cString::Format("this sector is not in maneuver list! maximal sector: %d. chosen sector: %d",m_SectorList.size(), m_SectionListIndex));
        return mtum_status_messages(ERROR);
    }
    if(m_ManeuverListIndex >= m_SectorList[m_SectionListIndex].maneuverList.size() || m_ManeuverListIndex < 0)
    {
        LOG_ERROR(cString::Format("this maneuver is not in maneuver list! maneuver id: %d, maximum: %d ", m_ManeuverListIndex,m_SectorList[m_SectionListIndex].maneuverList.size()));
        return mtum_status_messages(ERROR);
    }

    cString action = m_SectorList[m_SectionListIndex].maneuverList[m_ManeuverListIndex].action;
    if(action == "left")
        content = mtum_status_messages(MANEUVER_TURN_LEFT);
    else if(action == "right")
        content = mtum_status_messages(MANEUVER_TURN_RIGHT);
    else if(action == "straight")
        content = mtum_status_messages(MANEUVER_GO_STRAIGHT);
    else if(action == "pull_out_left")
        content = mtum_status_messages(MANEUVER_PULL_OUT_LEFT);
    else if(action == "pull_out_right")
        content = mtum_status_messages(MANEUVER_PULL_OUT_RIGHT);
    else if(action == "parallel_parking")
        content = mtum_status_messages(MANEUVER_PARK_PARALLEL);
    else if(action == "cross_parking")
        content = mtum_status_messages(MANEUVER_PARK_CROSS);

    return content;
}

tResult cStateControllerCore::Init(bool debugEnabled, bool ignoreReadyCheck, bool autoStart)
{
    m_SectionListIndex = -1;
    m_ManeuverListIndex =-1;

    m_State = stateCar_ERROR;
    ChangeState(stateCar_STARTUP);

    m_bDebugModeEnabled = debugEnabled;

    for(int i = 0; i < FILTER_COUNT; i++)
        m_FilterReady[i] = false;

    m_FilterReady[0] = true; // Thats this filter :)

    m_IgnoreReadyCheck = ignoreReadyCheck;

    if(autoStart)
    {
        m_CurrentManeuverID = 0;
        SetManeuverID(0);
        m_State = stateCar_READY;
        ChangeState(stateCar_RUNNING);
    }
    else
    {
        m_CurrentManeuverID = -1;
    }
}

tResult cStateControllerCore::LoadManeuverList(cString maneuverString)
{
    m_SectorList.clear();
    cDOM oDOM;
    oDOM.FromString(maneuverString);
    cDOMElementRefList oSectorElems;
    cDOMElementRefList oManeuverElems;

    //read first Sector Elem
    if(IS_OK(oDOM.FindNodes("AADC-Maneuver-List/AADC-Sector", oSectorElems)))
    {
        //iterate through sectors
        for (cDOMElementRefList::iterator itSectorElem = oSectorElems.begin(); itSectorElem != oSectorElems.end(); ++itSectorElem)
        {
            //if sector found
            tAADC_Sector sector;
            sector.id = (*itSectorElem)->GetAttributeUInt32("id");

            if(IS_OK((*itSectorElem)->FindNodes("AADC-Maneuver", oManeuverElems)))
            {
                //iterate through maneuvers
                for(cDOMElementRefList::iterator itManeuverElem = oManeuverElems.begin(); itManeuverElem != oManeuverElems.end(); ++itManeuverElem)
                {
                    tAADC_Maneuver man;
                    man.id = (*itManeuverElem)->GetAttributeUInt32("id");
                    man.action = (*itManeuverElem)->GetAttribute("action");
                    sector.maneuverList.push_back(man);
                }
            }

            m_SectorList.push_back(sector);
        }
    }
    if (oSectorElems.size() > 0)
    {
        LOG_INFO("CarControl: Loaded Maneuver file successfully.");
        m_SectionListIndex = 0;
        m_ManeuverListIndex = 0;
    }
    else
    {
        LOG_ERROR("CarControl: no valid Maneuver Data found!");
        m_SectionListIndex = -1;
        m_ManeuverListIndex = -1;
        RETURN_ERROR(ERR_INVALID_FILE);
    }


    RETURN_NOERROR;
}

tResult cStateControllerCore::LoadManeuverListFromFile(cFilename fileConfig)
{
    // check if given property is not empty
    if (fileConfig.IsEmpty())
    {
        LOG_WARNING("StateController: initial Maneuever List file not found");
        RETURN_ERROR(ERR_INVALID_FILE);
    }
    //create path from path
    ADTF_GET_CONFIG_FILENAME(fileConfig);
    fileConfig = fileConfig.CreateAbsolutePath(".");

    //Load file, parse configuration
    if (cFileSystem::Exists(fileConfig))
    {
        cString str;
        if(cFileSystem::ReadTextFile(fileConfig, str ))
            return LoadManeuverList(str);
    }

    RETURN_ERROR(ERR_FILE_NOT_FOUND);
}



bool cStateControllerCore::CheckIfAllReady()
{
    if(m_IgnoreReadyCheck)
        return true;

    bool result = true;

    for(int i = 0; i < FILTER_COUNT; i++) {
        if((READY_MASK & (1 << i)) != 0)
        {
            result &= m_FilterReady[i];
            cout << "Filter " << (i+1) << " is " << m_FilterReady[i] << ", ";
        }
        else
            cout << "Filter " << (i+1) << " will be ignored, ";
    }

    return result;
}
