/**
Copyright (c)
Audi Autonomous Driving Cup. Team MomenTUM. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
3.  All advertising materials mentioning features or use of this software must display the following acknowledgement: "This product includes software developed by the Audi AG and its contributors for Audi Autonomous Driving Cup."
4.  Neither the name of Audi nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY AUDI AG AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL AUDI AG OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


**********************************************************************
* $Author:: MomenTUM#$  $Date:: 2015-10-10 15:10:07#$ $Rev:: 35043   $
**********************************************************************/

#include "stdafx.h"
#include "mtum_car_control_core.h"
#include "StatusEnum.h"


cCarControlCore::cCarControlCore(iCarControlInterface *parent)
{
    m_pFilterReference = parent;
    m_FilterCount = 0;

    m_ManeuverIdx = -1;
    m_SectorIdx = -1;
    m_ReadyCallbacks = 0;

    m_State = MTUM_STATE_IDLE;
}

cCarControlCore::~cCarControlCore()
{
}

tResult cCarControlCore::ProcessStatusFeedback(tInt feedback)
{
    switch(mtum_status_messages(feedback))
    {
    case NOT_READY:
        break;

    case READY:
        if(m_ReadyCallbacks >= 0)
            m_ReadyCallbacks++;

        if(m_ReadyCallbacks >= m_FilterCount && m_State == MTUM_STATE_GETTING_READY)
            m_State = MTUM_STATE_READY;

        break;

    case ERROR:
        m_ReadyCallbacks = -1;
        LOG_ERROR("CarControl: One or more filters reported a problem. Stopping car and trying reset!");

        Reset();
        break;

    default:
        LOG_INFO("CarControl: A filter send a status update with unknown meaning!");
    }

    RETURN_NOERROR;
}

tResult cCarControlCore::ProcessJuryUpdate(tInt8 actionID, tInt16 maneuverEntry)
{
    switch(juryActions(actionID))
    {
    case action_GETREADY:

        switch(m_State)
        {
        case MTUM_STATE_IDLE:
            Reset();
            break;

        default:
            LOG_WARNING("CarControl: Jury requested GET_READY, but we are not in a state which allows us to get ready!");
        }

        break;

    case action_START:

        switch(m_State)
        {
        case MTUM_STATE_READY:
            Start(maneuverEntry);
            break;

        default:
            LOG_WARNING("CarControl: Jury requested START, but we are not in a state which allows us to start!");
        }

        break;

    case action_STOP:
    default:

        Stop();
        LOG_WARNING("CarControl: Jury requested STOP. Something seems to be not ok!");

    }


    RETURN_NOERROR;
}

tResult cCarControlCore::Reset()
{
    m_ManeuverIdx = -1;
    m_SectorIdx = -1;
    m_ReadyCallbacks = 0;

    m_State = MTUM_STATE_GETTING_READY;
    m_pFilterReference->SendStatusFeedback(RESET);

    RETURN_NOERROR;
}

tResult cCarControlCore::Start(tInt16 maneuver)
{
    RETURN_NOERROR;
}

tResult cCarControlCore::Stop()
{
    RETURN_NOERROR;
}

tResult cCarControlCore::LoadManeuverList(cString maneuverString)
{
    m_SectorList.clear();
    cDOM oDOM;
    oDOM.FromString(maneuverString);
    cDOMElementRefList oSectorElems;
    cDOMElementRefList oManeuverElems;

    //read first Sector Elem
    if(IS_OK(oDOM.FindNodes("AADC-Maneuver-List/AADC-Sector", oSectorElems)))
    {
        //iterate through sectors
        for (cDOMElementRefList::iterator itSectorElem = oSectorElems.begin(); itSectorElem != oSectorElems.end(); ++itSectorElem)
        {
            //if sector found
            tAADC_Sector sector;
            sector.id = (*itSectorElem)->GetAttributeUInt32("id");

            if(IS_OK((*itSectorElem)->FindNodes("AADC-Maneuver", oManeuverElems)))
            {
                //iterate through maneuvers
                for(cDOMElementRefList::iterator itManeuverElem = oManeuverElems.begin(); itManeuverElem != oManeuverElems.end(); ++itManeuverElem)
                {
                    tAADC_Maneuver man;
                    man.id = (*itManeuverElem)->GetAttributeUInt32("id");
                    man.action = (*itManeuverElem)->GetAttribute("action");
                    sector.maneuverList.push_back(man);
                }
            }

            m_SectorList.push_back(sector);
        }
    }
    if (oSectorElems.size() > 0)
    {
        LOG_INFO("CarControl: Loaded Maneuver file successfully.");
        m_SectorIdx = 0;
        m_ManeuverIdx = 0;
    }
    else
    {
        LOG_ERROR("CarControl: no valid Maneuver Data found!");
        m_SectorIdx = -1;
        m_ManeuverIdx = -1;
        RETURN_ERROR(ERR_INVALID_FILE);
    }


    RETURN_NOERROR;
}

tResult cCarControlCore::SetProperties(tInt filter_count)
{
    m_FilterCount = filter_count;
    m_State = MTUM_STATE_IDLE;

    RETURN_NOERROR;
}
