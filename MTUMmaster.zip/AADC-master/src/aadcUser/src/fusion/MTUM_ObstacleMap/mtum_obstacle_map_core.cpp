/**
Copyright (c)
Audi Autonomous Driving Cup. Team MomenTUM. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
3.  All advertising materials mentioning features or use of this software must display the following acknowledgement: "This product includes software developed by the Audi AG and its contributors for Audi Autonomous Driving Cup."
4.  Neither the name of Audi nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY AUDI AG AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL AUDI AG OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


**********************************************************************
* $Author:: MomenTUM#$  $Date:: 2015-10-10 15:10:07#$ $Rev:: 35043   $
**********************************************************************/

#include "stdafx.h"
#include "mtum_obstacle_map_core.h"
#include "mtum_obstacle_map.h"
#include "car_geometry.h"
#include "UltrasonicStructType.h"

#include <stdlib.h>
#include <cmath>
#include <iostream>

#ifndef M_PI
#define M_PI (3.14159265358979323846f)
#endif

cObstacleMapCore::cObstacleMapCore(iObstacleMapInterface *pFilter)
{
    UCOM_REGISTER_TIMING_SPOT("OM:StartUS", prof_startUS);
    UCOM_REGISTER_TIMING_SPOT("OM:EndUS", prof_endUS);
    UCOM_REGISTER_TIMING_SPOT("OM:StartDepth", prof_startDepth);
    UCOM_REGISTER_TIMING_SPOT("OM:EndRotate", prof_endRotate);
    UCOM_REGISTER_TIMING_SPOT("OM:EndDepth", prof_endDepth);


    m_pFilterReferenz = pFilter;
    m_Rotation = cv::Matx33f(1,0,0,0,1,0,0,0,1);

    m_LastPhi=0;
    m_LastX =0;
    m_LastY=0;
    usWarned = 0;
}

cObstacleMapCore::~cObstacleMapCore()
{
}

tResult cObstacleMapCore::ProcessData(tUltrasonicStruct usData)
{
    UCOM_TIMING_SPOT(prof_startUS);

    if(m_ObstacleMap.empty())
        RETURN_ERROR(ERR_NOT_INITIALISED);

    //std::vector<cv::Point> polygon;
    //cv::ellipse2Poly(cv::Point((tInt) m_Sensors[sensor_id].x + m_LeftDistance, (tInt) m_Sensors[sensor_id].y + m_RearDistance), cv::Size((tInt) value, (tInt) value/2),
    //                 m_Sensors[sensor_id].phi + 90, -1 * m_Sensors[sensor_id].alpha, m_Sensors[sensor_id].alpha, 5, polygon);
    tFloat32 value = 0;
    cv::Mat free_update = cv::Mat::zeros(m_ObstacleMap.rows, m_ObstacleMap.cols, CV_8UC1); //  m_ObstacleMap.clone();
    cv::Mat occupied_update = cv::Mat::zeros(m_ObstacleMap.rows, m_ObstacleMap.cols, CV_8UC1);

    for(tInt sensor_id = 0; sensor_id < 10; sensor_id++)
    {
        switch(sensor_id){
        case 0:
            value = usData.front_left.value;
            break;
        case 1:
            value = usData.front_center_left.value;
            break;
        case 2:
            value = usData.front_center.value;
            break;
        case 3:
            value = usData.front_center_right.value;
            break;
        case 4:
            value = usData.front_right.value;
            break;
        case 5:
            value = usData.side_left.value;
            break;
        case 6:
            value = usData.side_right.value;
            break;
        case 7:
            value = usData.rear_left.value;
            break;
        case 8:
            value = usData.rear_center.value;
            break;
        case 9:
            value = usData.rear_right.value;
        }

        value = value * 100;

        if(value > 100)
        {
            value = 100;
        }
        else if(isnan(value))
        {
            if((usWarned & 1 << sensor_id) == 0) {
                LOG_WARNING(cString::Format("us-value of sensor # %d was NaN", sensor_id));
                usWarned |= 1 << sensor_id;
            }
            continue;
        }

        if(value < 3)
        {
            cv::ellipse(occupied_update, cv::Point((tInt) m_Sensors[sensor_id].x + m_RightDistance, (tInt) m_Sensors[sensor_id].y + m_RearDistance), cv::Size((tInt) value+2,
                                                      (tInt) value/2+2), m_Sensors[sensor_id].phi + 90, -1 * m_Sensors[sensor_id].alpha, m_Sensors[sensor_id].alpha, 120, 3 );
        }
        else
        {
            /*
             * if(sensor_id == 6)
            {
                double phi = (-m_Sensors[sensor_id].alpha*2/3.0 + m_Sensors[sensor_id].phi+90) * M_PI / 180;
                cv::Point2d v(cos(phi), sin(phi));

                cv::Point2d S(m_Sensors[sensor_id].x + m_RightDistance, m_Sensors[sensor_id].y + m_RearDistance);
                cv::Point2d P = S + v * (value+3);
                cv::circle(occupied_update, P, 3, 150-value, -1);
                cv::ellipse(free_update, cv::Point((tInt) m_Sensors[sensor_id].x + m_RightDistance, (tInt) m_Sensors[sensor_id].y + m_RearDistance), cv::Size((tInt) value, (tInt) value), m_Sensors[sensor_id].phi + 90, -1 * (m_Sensors[sensor_id].alpha+1), m_Sensors[sensor_id].alpha+1, 20, -1 );

            }
            else
             */
            {
                cv::ellipse(free_update, cv::Point((tInt) m_Sensors[sensor_id].x + m_RightDistance, (tInt) m_Sensors[sensor_id].y + m_RearDistance), cv::Size((tInt) value, (tInt) value), m_Sensors[sensor_id].phi + 90, -1 * (m_Sensors[sensor_id].alpha+1), m_Sensors[sensor_id].alpha+1, 20, -1 );
                if(value < 100)
                {
                    cv::ellipse(occupied_update, cv::Point((tInt) m_Sensors[sensor_id].x + m_RightDistance, (tInt) m_Sensors[sensor_id].y + m_RearDistance), cv::Size((tInt) value+1, (tInt) value+1), m_Sensors[sensor_id].phi + 90, -1 * m_Sensors[sensor_id].alpha*2/3.0, m_Sensors[sensor_id].alpha*2/3.0, 150-value, 2 );
                }
            }
        }
    }

    m_ObstacleMap = m_ObstacleMap + free_update;
    m_ObstacleMap = m_ObstacleMap - occupied_update;

    UCOM_TIMING_SPOT(prof_endUS);

    RETURN_NOERROR;
}

tResult cObstacleMapCore::ProcessDepthData(cv::Mat depthImage, tFloat32 a, tFloat32 b, tFloat32 c, tFloat32 d)
{
    UCOM_TIMING_SPOT(prof_startDepth);

    if(m_ObstacleMap.empty())
        RETURN_ERROR(ERR_NOT_INITIALISED);

    //cv::Mat debug = cv::Mat(depthImage.rows, depthImage.cols, CV_8UC3, cv::Vec3b(0,0,0));


    cv::warpAffine(m_ObstacleMap, m_ObstacleMap, m_Rotation.get_minor<2,3>(0,0), cv::Size(m_ObstacleMap.cols, m_ObstacleMap.rows), cv::INTER_LINEAR, cv::BORDER_CONSTANT, 127);
    m_Rotation = cv::Matx33f(1,0,0,0,1,0,0,0,1);

    UCOM_TIMING_SPOT(prof_endRotate);

    cv::Mat free_update = cv::Mat::zeros(m_ObstacleMap.rows, m_ObstacleMap.cols, CV_8UC1); //444 us
    cv::Mat occupied_update = cv::Mat::zeros(m_ObstacleMap.rows, m_ObstacleMap.cols, CV_8UC1); //444 us


    for(int x = 10; x < depthImage.cols-10; x++)
    {

        cv::Point3d nearest = ToWorld(cv::Point(x,0), 3000);
        cv::Point3d firstFloor = ToWorld(cv::Point(x,0), 50);
        bool firstFloorFound = false;

        tInt overFloorCnt = 0;

        for(int y = depthImage.rows-1; y >= 0; y--)
        {

            tUInt16 z = depthImage.at<tUInt16>(y, x);

            if(z == 0)
                continue;

            if(!firstFloorFound)
            {
                firstFloor = ToWorld(cv::Point(x,y), (double) z);
                firstFloorFound = true;
            }

            cv::Point3d p = ToWorld(cv::Point(x,y), (double) z);

            tFloat32 distToFloor = a*p.x + b*p.y + c*p.z - d;

            if(-distToFloor > 10)
            {
                overFloorCnt++;
                //debug.at<cv::Vec3b>(y,x) = cv::Vec3b(0, 255, 0);
            }
            else
            {
                overFloorCnt = 0;
                //debug.at<cv::Vec3b>(y,x) = cv::Vec3b(255, 0, 0);
            }

            if(overFloorCnt > 10)
            {
                if(p.z < nearest.z)
                    nearest = p;
            }

        }

        nearest.x *= -1;
        firstFloor.x *= -1;
        cv::Point2f cam = cv::Point2f(m_RightDistance,m_RearDistance+CAR_REARAXIS2CAM);
        cv::Point2f obj = cv::Point2f(nearest.x/10+m_RightDistance, nearest.z/10+m_RearDistance+CAR_REARAXIS2CAM);
        cv::Point2f vec;

        if(firstFloorFound) {
            vec = cv::Point2f(firstFloor.x / 10 + m_RightDistance,
                              firstFloor.z / 10 + m_RearDistance + CAR_REARAXIS2CAM);
        }
        else
        {
            vec = obj - cam;
            vec = vec / sqrt(vec.dot(vec)) * 50;
            vec = vec + cam;
        }

        cv::line(free_update, cv::Point(vec), cv::Point(nearest.x/10+m_RightDistance, nearest.z/10+m_RearDistance+CAR_REARAXIS2CAM), 200, 2 );

        if(nearest.z < 3000)
        {
            cv::circle(occupied_update, cv::Point(nearest.x/10+m_RightDistance, nearest.z/10+m_RearDistance+CAR_REARAXIS2CAM), 1, 255,-1);
        }

    }

    m_ObstacleMap = m_ObstacleMap + free_update;
    m_ObstacleMap = m_ObstacleMap - occupied_update;

    PublishMap();
    //m_pFilterReferenz->SendDebug(debug);

    m_ObstacleMap = m_ObstacleMap + m_Mask;

    UCOM_TIMING_SPOT(prof_endDepth);

    RETURN_NOERROR;
}

tResult cObstacleMapCore::ProcessOdometryData(tFloat32 x, tFloat32 y, tFloat32 phi, tFloat32 vel)
{
    cv::Point2f origin = cv::Point2f(m_RightDistance, m_RearDistance);

    tFloat32 dphi = phi - m_LastPhi;
    tFloat32 dx = x -m_LastX;
    tFloat32 dy = y -m_LastY;
    tFloat32 l = sqrt(dx*dx+dy*dy)*100;
    if(vel < 0){
        l *= -1;
    }
    m_LastPhi = phi;
    m_LastX = x;
    m_LastY = y;

    tFloat32 c = cos(dphi);
    tFloat32 s = sin(dphi);
    tFloat32 tx = origin.x - c * origin.x + s * origin.y;
    tFloat32 ty = origin.x - s * origin.x - c * origin.y - l;


    m_Rotation = cv::Matx33f(c, -s, tx, s, c, ty, 0, 0, 1) * m_Rotation;


    RETURN_NOERROR;
}

tResult cObstacleMapCore::PublishMap()
{
    if(m_ObstacleMap.empty())
        RETURN_ERROR(ERR_NOT_INITIALISED);

    cv::rectangle(m_ObstacleMap, cv::Rect(m_RightDistance-CAR_WIDTH/2, m_RearDistance-CAR_REARAXIS2REAR, CAR_WIDTH, CAR_LENGTH), 255, -1);

//    cv::line(m_ObstacleMap, cv::Point(0, m_RearDistance-CAR_REARAXIS2REAR+CAR_LENGTH), cv::Point(m_ObstacleMap.cols, m_RearDistance-CAR_REARAXIS2REAR+CAR_LENGTH), cv::Scalar(0));
//    cv::line(m_ObstacleMap, cv::Point(0, m_RearDistance-CAR_REARAXIS2REAR+CAR_LENGTH+10), cv::Point(m_ObstacleMap.cols, m_RearDistance-CAR_REARAXIS2REAR+CAR_LENGTH+10), cv::Scalar(0));
//    cv::line(m_ObstacleMap, cv::Point(0, m_RearDistance-CAR_REARAXIS2REAR+CAR_LENGTH+25), cv::Point(m_ObstacleMap.cols, m_RearDistance-CAR_REARAXIS2REAR+CAR_LENGTH+25), cv::Scalar(0));
//    cv::line(m_ObstacleMap, cv::Point(0, m_RearDistance-CAR_REARAXIS2REAR+CAR_LENGTH+50), cv::Point(m_ObstacleMap.cols, m_RearDistance-CAR_REARAXIS2REAR+CAR_LENGTH+50), cv::Scalar(0));
//    cv::line(m_ObstacleMap, cv::Point(0, m_RearDistance-CAR_REARAXIS2REAR+CAR_LENGTH+75), cv::Point(m_ObstacleMap.cols, m_RearDistance-CAR_REARAXIS2REAR+CAR_LENGTH+75), cv::Scalar(0));

    return m_pFilterReferenz->PublishMap(m_ObstacleMap);
}

tResult cObstacleMapCore::SetProperties(tUInt front_distance, tUInt right_distance, tUInt left_distance, tUInt rear_distance, cFilename fileConfig,cv::Mat cameraMatrix, cv::Mat distortions)
{
    m_FrontDistance = front_distance;
    m_RightDistance = right_distance;
    m_LeftDistance = left_distance;
    m_RearDistance = rear_distance;

    m_ObstacleMap = cv::Mat(front_distance+rear_distance, left_distance+right_distance, CV_8UC1, 127);
    m_Mask = cv::Mat(m_ObstacleMap.rows, m_ObstacleMap.cols, CV_8UC1, 1);
    GenerateDirections(320, 240);

    setCameraMatrix(cameraMatrix,distortions);

    // check if given property is not empty
    if (fileConfig.IsEmpty())
    {
        LOG_WARNING("ObstacleMap: Configuration file not found");
        RETURN_ERROR(ERR_INVALID_FILE);
    }
    //create path from path
    ADTF_GET_CONFIG_FILENAME(fileConfig);
    fileConfig = fileConfig.CreateAbsolutePath(".");

    //Load file, parse configuration
    if (cFileSystem::Exists(fileConfig))
    {
        cDOM oDOM;
        oDOM.Load(fileConfig);
        cDOMElementRefList oElems;
        // load settings for the us sensors

        for(int i = 0; i < 10; i++)
        {
            if(IS_OK(oDOM.FindNodes(cString::Format("sensors/us%d",i), oElems)))
            {
                for (cDOMElementRefList::iterator itElem = oElems.begin(); itElem != oElems.end(); ++itElem)
                {
                    cDOMElement* pConfigElement;
                    if (IS_OK((*itElem)->FindNode("x", pConfigElement)))
                    {
                        m_Sensors[i].x = (tFloat32) (pConfigElement->GetData()).AsFloat64();
                    }
                    if (IS_OK((*itElem)->FindNode("y", pConfigElement)))
                    {
                        m_Sensors[i].y = (tFloat32) (pConfigElement->GetData()).AsFloat64();
                    }
                    if (IS_OK((*itElem)->FindNode("phi", pConfigElement)))
                    {
                        m_Sensors[i].phi = (tFloat32) (pConfigElement->GetData()).AsFloat64();
                    }
                    if (IS_OK((*itElem)->FindNode("alpha", pConfigElement)))
                    {
                        m_Sensors[i].alpha = (tFloat32) (pConfigElement->GetData()).AsFloat64();
                    }
                }

                LOG_INFO(cString::Format("x=%f y=%f phi=%f alpha=%f", m_Sensors[i].x, m_Sensors[i].y, m_Sensors[i].phi, m_Sensors[i].alpha));
                cv::ellipse(m_Mask, cv::Point((tInt) m_Sensors[i].x + m_RightDistance, (tInt) m_Sensors[i].y + m_RearDistance), cv::Size(1000, 1000), m_Sensors[i].phi + 90, -1 * (m_Sensors[i].alpha+1), m_Sensors[i].alpha+1, 0, -1 );
            }
    }

        LOG_INFO("ObstacleMap: Loaded configuration files successfully");


    }
    else
    {
        LOG_ERROR("ObstacleMap: Configured configuration file not found or could not be read");
        RETURN_ERROR(ERR_INVALID_FILE);
    }



    RETURN_NOERROR;
}
    void cObstacleMapCore::setCameraMatrix(cv::Mat cameraMatrix, cv::Mat distortion) {
        depthFX = cameraMatrix.at<double>(0,0)/2.0;
        depthFY = cameraMatrix.at<double>(1,1)/2.0;

        depthCX = cameraMatrix.at<double>(0,2)/2.0;
        depthCY = cameraMatrix.at<double>(1,2)/2.0;

        cout << "Floor Detection Set Camera Params: " << depthFX << ", " << depthFY << ", " << depthCX << ", " << depthCY << endl;
    }

void cObstacleMapCore::GenerateDirections(int cols, int rows)
{
    // Calculate virtual sensor size
    double sensorWidth = tan((CAM_ANGLE_H/2.0)*(M_PI/180.0));
    double sensorHeight = tan((CAM_ANGLE_V/2.0)*(M_PI/180.0));

    m_Directions = cv::Mat(rows, cols, CV_64FC2);
    for(int r = 0; r < rows; r++) {
        double rowVec = ((r-rows/2.0)/(rows/2.0)) * (sensorHeight);
        for(int c = 0; c < cols; c++) {
            m_Directions.at<cv::Vec2d>(r,c) = cv::Vec2d(((c - cols/2.0)/(cols/2.0)) * (sensorWidth), rowVec);
        }
    }
}

cv::Point3d cObstacleMapCore::ToWorld(cv::Point pt, double z)
{
    return cv::Point3d((pt.x - depthCX)*z / depthFX, (pt.y - depthCY)*z / depthFY, z);

}
