/**
Copyright (c)
Audi Autonomous Driving Cup. Team MomenTUM. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
3.  All advertising materials mentioning features or use of this software must display the following acknowledgement: "This product includes software developed by the Audi AG and its contributors for Audi Autonomous Driving Cup."
4.  Neither the name of Audi nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY AUDI AG AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL AUDI AG OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


**********************************************************************
* $Author:: MomenTUM#$  $Date:: 2015-10-10 15:10:07#$ $Rev:: 35043   $
**********************************************************************/

#include "stdafx.h"
#include "mtum_obstacle_map.h"
#include "StatusEnum.h"
#include "SignalValueType.h"
#include "OdometryDataType.h"
#include "UltrasonicStructType.h"
#include "FloorStruct.h"
#include <iostream>


/// Create filter shell
ADTF_FILTER_PLUGIN("MTUM Template Filter", OID_ADTF_MTUM_OBSTACLE_MAP_FILTER, cObstacleMapFilter);


cObstacleMapFilter::cObstacleMapFilter(const tChar* __info):cFilter(__info), m_FilterCore(this)
{
    cout << "set property camera calib file: " << endl;

    SetPropertyStr("Camera Calibration File","/home/aadc/calibs/xtion_intrinsic_calib_Auto2.yml");
    SetPropertyBool("Camera Calibration File" NSSUBPROP_FILENAME, tTrue);
    SetPropertyStr("Camera Calibration File" NSSUBPROP_FILENAME NSSUBSUBPROP_EXTENSIONFILTER, "YML Files (*.yml)");
    cout << "..done" << endl;
    SetPropertyInt("Map front distance", 400);
    SetPropertyStr("Map front distance" NSSUBPROP_GLOBALCONFIGPROPERTYNAME, "Map front distance" );
    SetPropertyStr("Map front distance" NSSUBPROP_GLOBALCONFIGPROPERTYNAME NSSUBPROP_DESCRIPTION, "The distance in front of the rear axis in centimeter." );

    SetPropertyInt("Map right distance", 300);
    SetPropertyStr("Map right distance" NSSUBPROP_GLOBALCONFIGPROPERTYNAME, "Map right distance" );
    SetPropertyStr("Map right distance" NSSUBPROP_GLOBALCONFIGPROPERTYNAME NSSUBPROP_DESCRIPTION, "The distance right of the vehicle center (left in map) in centimeter." );

    SetPropertyInt("Map left distance", 200);
    SetPropertyStr("Map left distance" NSSUBPROP_GLOBALCONFIGPROPERTYNAME, "Map left distance" );
    SetPropertyStr("Map left distance" NSSUBPROP_GLOBALCONFIGPROPERTYNAME NSSUBPROP_DESCRIPTION, "The distance left of the vehicle center (left in map) in centimeter." );

    SetPropertyInt("Map rear distance", 300);
    SetPropertyStr("Map rear distance" NSSUBPROP_GLOBALCONFIGPROPERTYNAME, "Map rear distance" );
    SetPropertyStr("Map rear distance" NSSUBPROP_GLOBALCONFIGPROPERTYNAME NSSUBPROP_DESCRIPTION, "The distance behind the rear axis in centimeter." );

    SetPropertyInt("Update Frequency [Hz]", 20);

    SetPropertyStr("Configuration File","../../../configuration_files/SensorSettings.xml");
    SetPropertyBool("Configuration File" NSSUBPROP_FILENAME, tTrue);
    SetPropertyStr("Configuration File" NSSUBPROP_FILENAME NSSUBSUBPROP_EXTENSIONFILTER, "XML Files (*.xml)");
    SetPropertyStr("Configuration File" NSSUBPROP_DESCRIPTION, "The configuration file for the ultrasonic sensors");

    m_hTimer = NULL;
    m_bRunning = tFalse;


    floor.a = 0;
    floor.b = 1;
    floor.c = 0;
    floor.d = 210;
    floor.angle = 18;
}

cObstacleMapFilter::~cObstacleMapFilter()
{

}

tResult cObstacleMapFilter::Init(tInitStage eStage, __exception)
{
    // never miss calling the parent implementation!!
    RETURN_IF_FAILED(cFilter::Init(eStage, __exception_ptr))
    
    // in StageFirst you can create and register your static pins.
    if (eStage == StageFirst)
    {
        RETURN_IF_FAILED(CreatePins(__exception_ptr));
    }
    else if (eStage == StageNormal)
    {
        tUInt front_distance = (tUInt) GetPropertyInt("Map front distance");
        tUInt right_distance = (tUInt) GetPropertyInt("Map right distance");
        tUInt left_distance = (tUInt) GetPropertyInt("Map left distance");
        tUInt rear_distance = (tUInt) GetPropertyInt("Map rear distance");
        cFilename file = GetPropertyStr("Configuration File");

        cFilename filen = GetPropertyStr("Camera Calibration File");

        if (filen.IsEmpty()) {
            LOG_ERROR("Lane Detection: calibration file not found");

            filen ="../../../configuration_files/xtionIntrinsicCalib.yml";
        }
        //create path from path
        ADTF_GET_CONFIG_FILENAME(filen);
        filen = filen.CreateAbsolutePath(".");

        cv::FileStorage fs(filen.GetPtr(), cv::FileStorage::READ);
        cv::Mat cameraMatrix, distortionMatrix;
        fs["camera_matrix"] >> cameraMatrix;
        fs["distortion_coefficients"] >> distortionMatrix;


        fs.release();

        RETURN_IF_FAILED(m_FilterCore.SetProperties(front_distance, right_distance, left_distance, rear_distance, file,
                                                    cameraMatrix, distortionMatrix));

        //set the videoformat of the rgb video pin
        m_sOutputFormat.nWidth = right_distance + left_distance;
        m_sOutputFormat.nHeight = front_distance + rear_distance;
        m_sOutputFormat.nBitsPerPixel = 8;
        m_sOutputFormat.nPixelFormat = cImage::PF_GREYSCALE_8;
        m_sOutputFormat.nBytesPerLine = m_sOutputFormat.nWidth * 1;
        m_sOutputFormat.nSize = m_sOutputFormat.nBytesPerLine * m_sOutputFormat.nHeight;
        m_sOutputFormat.nPaletteSize = 0;
        m_oMapOutput.SetFormat(&m_sOutputFormat, NULL);

        //set the videoformat of the rgb video pin
        m_sDepthFormat.nWidth = 320;
        m_sDepthFormat.nHeight = 240;
        m_sDepthFormat.nBitsPerPixel = 16;
        m_sDepthFormat.nPixelFormat = cImage::PF_GREYSCALE_16;
        m_sDepthFormat.nBytesPerLine = m_sDepthFormat.nWidth * 2;
        m_sDepthFormat.nSize = m_sDepthFormat.nBytesPerLine * m_sDepthFormat.nHeight;
        m_sDepthFormat.nPaletteSize = 0;
        m_oDepthImage.SetFormat(&m_sDepthFormat, NULL);

        // set the videoformat of the debug video pin
        m_sDebugFormat.nWidth = m_sDepthFormat.nWidth;
        m_sDebugFormat.nHeight = m_sDepthFormat.nHeight;
        m_sDebugFormat.nBitsPerPixel = 24;
        m_sDebugFormat.nPixelFormat = cImage::PF_BGR_888;
        m_sDebugFormat.nBytesPerLine = m_sDebugFormat.nWidth * 3;
        m_sDebugFormat.nSize = m_sDebugFormat.nBytesPerLine * m_sDebugFormat.nHeight;
        m_sDebugFormat.nPaletteSize = 0;
        //m_oDebugOutput.SetFormat(&m_sDebugFormat, NULL);

    }
    else if (eStage == StageGraphReady)
    {
        tUInt32 nFlags = 0;

        // Create our cyclic timer.
        // we do this here and not in Start() to prevent the impact of
        // the thread creation during RL_Running
        cString strTimerName = OIGetInstanceName();
        strTimerName += ".rttimerObstacleMap";
        m_hTimer = _kernel->TimerCreate(1000000 / GetPropertyInt("Update Frequency [Hz]"),
                                        0,
                                        static_cast<IRunnable*>(this),
                                        NULL,
                                        NULL,
                                        0,
                                        nFlags,
                                        strTimerName);
        if (!m_hTimer)
        {
            THROW_ERROR_DESC(ERR_UNEXPECTED, "Unable to create timer");
        }
    }

    RETURN_NOERROR;
}

tResult cObstacleMapFilter::Start(__exception)
{
    m_LastOdometryUpdate = 0;
    RETURN_IF_FAILED(m_pOdometryQueue->Clear());
    RETURN_IF_FAILED(m_pUltrasonicQueue->Clear());
    RETURN_IF_FAILED(m_pFloorQueue->Clear());

    // tell the timer handler to start working
    m_bRunning = tTrue;

    return cFilter::Start(__exception_ptr);
}

tResult cObstacleMapFilter::Stop(__exception)
{
    // tell the timer handler to stop working
    m_bRunning = tFalse;

    return cFilter::Stop(__exception_ptr);
}

tResult cObstacleMapFilter::Shutdown(tInitStage eStage, __exception)
{
    // In each stage clean up everything that you initiaized in the corresponding stage during Init.
    // Pins are an exception: 
    // - The base class takes care of static pins that are members of this class.
    // - Dynamic pins have to be cleaned up in the ReleasePins method, please see the demo_dynamicpin
    //   example for further reference.
    
    if (eStage == StageGraphReady)
    {
        RETURN_IF_FAILED(m_pOdometryQueue->Clear());
        RETURN_IF_FAILED(m_pUltrasonicQueue->Clear());
        RETURN_IF_FAILED(m_pFloorQueue->Clear());

        if (m_hTimer)
        {
            // Destroy the timer
            _kernel->TimerDestroy(m_hTimer);
            m_hTimer = NULL;
        }
    }
    else if (eStage == StageNormal)
    {

    }
    else if (eStage == StageFirst)
    {
        m_pOdometryQueue = NULL;
        m_pUltrasonicQueue = NULL;
        m_pFloorQueue = NULL;
    }

    // call the base class implementation
    return cFilter::Shutdown(eStage, __exception_ptr);
}

tResult cObstacleMapFilter::OnPinEvent(IPin* pSource,
                                           tInt nEventCode,
                                           tInt nParam1,
                                           tInt nParam2,
                                           IMediaSample* pMediaSample)
{
    // first check what kind of event it is
    if (nEventCode == IPinEventSink::PE_MediaSampleReceived)
    {
        // so we received a media sample, so this pointer better be valid.
        RETURN_IF_POINTER_NULL(pMediaSample);

        // by comparing it to our member pin variable we can find out which pin received
        // the sample
        if (pSource == &m_oStatusInput)
        {
            DecodeStatusMessage(pMediaSample);
        }
        else if(pSource == &m_oOdometry)
        {
        }
        else if(pSource == &m_oDepthImage)
        {
            if (IS_FAILED(m_pDepthQueue.Push(pMediaSample)))
            {
                IMediaSample* so;
                RETURN_IF_FAILED(m_pDepthQueue.Pop(&so));
                so->Unref();
                RETURN_IF_FAILED(m_pDepthQueue.Push(pMediaSample));
                pMediaSample->Ref();
                //LOG_ERROR("Queue overflow");
                //RETURN_ERROR(ERR_MEMORY);
            }else
                pMediaSample->Ref();

        }
        else
        {
        }
    }
    else if(nEventCode == IPinEventSink::PE_MediaTypeChanged)
    {
        if (pSource == &m_oDepthImage)
        {
            //the input format was changed, so the imageformat has to changed in this filter also
            cObjectPtr<IMediaType> pType;
            RETURN_IF_FAILED(m_oDepthImage.GetMediaType(&pType));

            cObjectPtr<IMediaTypeVideo> pTypeVideo;
            RETURN_IF_FAILED(pType->GetInterface(IID_ADTF_MEDIA_TYPE_VIDEO, (tVoid**)&pTypeVideo));

            const tBitmapFormat *pNewFormat = m_oDepthImage.GetFormat();
            if (pNewFormat != NULL)
            {
                m_sDepthFormat = (*pNewFormat);
                m_sDebugFormat.nWidth = m_sDepthFormat.nWidth;
                m_sDebugFormat.nHeight = m_sDepthFormat.nHeight;
                //m_oDebugOutput.SetFormat(&m_sDebugFormat, NULL);
                LOG_INFO("ObstacleMap: Format for depth input was changed!");
            }
        }
    }

    RETURN_NOERROR;
}

tResult cObstacleMapFilter::Run(tInt nActivationType, const tVoid* pvUserData, tInt szUserDataSize, __exception)
{
    RETURN_IF_POINTER_NULL(m_pOdometryQueue);
    RETURN_IF_POINTER_NULL(m_pUltrasonicQueue);
    RETURN_IF_POINTER_NULL(m_pFloorQueue);

    while(!m_pOdometryQueue->Empty())
    {
         cObjectPtr<IMediaSample> pOdometrySample = NULL;
         if (IS_OK(m_pOdometryQueue->Pop(&pOdometrySample)))
         {
             tOdometryData data;
             tTimeStamp timestamp = pOdometrySample->GetTime();
             {
                 // this will aquire the read lock on the sample and declare and initialize a pointer to the data
                 __sample_read_lock(pOdometrySample, tOdometryData, pData);
                 // now we can access the sample data through the pointer
                 data = *pData;
                 // the read lock on the sample will be released when leaving this scope
             }

             if(timestamp == 0)
             {
                 m_LastOdometryUpdate = timestamp;
                 RETURN_NOERROR;
             }

             m_FilterCore.ProcessOdometryData(data.x, data.y, data.phi, data.vel);
             m_LastOdometryUpdate = timestamp;
         }
    }

    cObjectPtr<IMediaSample> pUltrasonicSample = NULL;
    if (IS_OK(m_pUltrasonicQueue->Get(&pUltrasonicSample, _clock->GetStreamTime(), 10000, ISampleQueue::SQG_GetNewest)))
    {
        tUltrasonicStruct data;
        {
         // this will aquire the read lock on the sample and declare and initialize a pointer to the data
         __sample_read_lock(pUltrasonicSample, tUltrasonicStruct, pData);
         // now we can access the sample data through the pointer
         data = *pData;
         // the read lock on the sample will be released when leaving this scope
        }

        m_FilterCore.ProcessData(data);
    }

    IMediaSample* pDepthSample = NULL;
    IMediaSample* pNextDepthSample = NULL;

    // get only the last rgb sample
    while (IS_OK(m_pDepthQueue.Pop(&pNextDepthSample)))
    {
        if(pDepthSample != NULL)
            pDepthSample->Unref();

         pDepthSample = pNextDepthSample;
    }

    if(pDepthSample != NULL)
    {
        //creating new pointer for input data
        const tVoid* l_pSrcBuffer;
        cv::Mat depthImage;

        //receiving data from input sample, and saving to inputFrame
        if (IS_OK(pDepthSample->Lock(&l_pSrcBuffer)))
        {
            //creating the matrix with the data

            depthImage = cv::Mat(m_sDepthFormat.nHeight,m_sDepthFormat.nWidth,CV_16UC1,(tVoid*)l_pSrcBuffer,m_sDepthFormat.nBytesPerLine);
            pDepthSample->Unlock(l_pSrcBuffer);
        }




        cObjectPtr<IMediaSample> pFloorSample = NULL;
        if (IS_OK(m_pFloorQueue->Get(&pFloorSample, _clock->GetStreamTime(), 10000, ISampleQueue::SQG_GetNewest)))
        {
            __sample_read_lock(pFloorSample, tFloorStruct, pData);

             floor = *pData;
        }

        m_FilterCore.ProcessDepthData(depthImage, floor.a, floor.b, floor.c, floor.d);
        pDepthSample->Unref();
    }
    else
        m_FilterCore.PublishMap();



    RETURN_NOERROR;
}

tResult cObstacleMapFilter::PublishMap(cv::Mat &obstaclemap)
{
    cObjectPtr<IMediaSample> pNewSample;
    if (IS_OK(AllocMediaSample(&pNewSample)))
    {
        pNewSample->Update(_clock->GetStreamTime(), obstaclemap.data, m_sOutputFormat.nSize, 0);
        m_oMapOutput.Transmit(pNewSample);
    }
    RETURN_NOERROR;
}

tResult cObstacleMapFilter::SendDebug(cv::Mat &debug)
{
    cObjectPtr<IMediaSample> pNewSample;
    if (IS_OK(AllocMediaSample(&pNewSample)))
    {
        pNewSample->Update(_clock->GetStreamTime(), debug.data, m_sDebugFormat.nSize, 0);
        //m_oDebugOutput.Transmit(pNewSample);
    }
    RETURN_NOERROR;
}

tResult cObstacleMapFilter::SendStatusFeedback(tInt feedback)
{
    // now we need a new media sample to forward the data.
    cObjectPtr<IMediaSample> pNewSample;
    if (IS_OK(AllocMediaSample(&pNewSample)))
    {
        // now set its data
        // we reuse the timestamp from the incoming media sample. Please see the api documentation
        // (ADTF Extreme Programmers -> The ADTF Streamtime) for further reference on how sample times are handled in ADTF
        tSignalValue data;
        data.value = feedback;
        pNewSample->Update(_clock->GetStreamTime(), &data, sizeof(tSignalValue), 0);

        // and now we can transmit it
        m_oStatusOutput.Transmit(pNewSample);
    }

    RETURN_NOERROR;
}

tResult cObstacleMapFilter::DecodeStatusMessage(IMediaSample* pMediaSample)
{
    // this will store the value for our new sample
    tSignalValue status_message;

    // now lets access the data in the sample,
    // the Lock method gives you access to the buffer of the sample.
    // we use a scoped sample lock to ensure that the lock is released in all circumstances.

    {
        // this will aquire the read lock on the sample and declare and initialize a pointer to the data
        __sample_read_lock(pMediaSample, tSignalValue, pData);
        // now we can access the sample data through the pointer
        status_message = *pData;
        // the read lock on the sample will be released when leaving this scope
    }

    switch(mtum_status_requests(status_message.value))
    {
    case SET_INACTIVE: m_FilterCore.Status_SetInactive();
        break;
    case SET_ACTIVE: m_FilterCore.Status_SetActive();
        break;
    case IS_READY: m_FilterCore.Status_IsReady();
        break;
    case RESET: m_FilterCore.Status_Reset();
        break;
    default: m_FilterCore.Status_ChangeMode(tInt(status_message.value));
    }

    RETURN_NOERROR;
}

tResult cObstacleMapFilter::CreatePins(__exception)
{
    // create and register the status-input pin
    RETURN_IF_FAILED(m_oStatusInput.Create("status_input", new cMediaType(0,0,0,SIGNALVALUE), this));
    RETURN_IF_FAILED(RegisterPin(&m_oStatusInput));

    // create and register the us-data pins
    RETURN_IF_FAILED(m_oUltrasonicStruct.Create("ultrasonic_struct", new cMediaType(0,0,0,ULTRASONICSTRUCT), this, static_cast<ISampleQueue*>(new cSampleQueue(100000, 10))));
    RETURN_IF_FAILED(m_oUltrasonicStruct.GetSampleQueue(&m_pUltrasonicQueue));
    RETURN_IF_FAILED(RegisterPin(&m_oUltrasonicStruct));

    // create and register the odometry pin
    RETURN_IF_FAILED(m_oOdometry.Create("odometry", new cMediaType(0,0,0,ODOMETRYDATA), this, static_cast<ISampleQueue*>(new cSampleQueue(100000, 10))));
    RETURN_IF_FAILED(m_oOdometry.GetSampleQueue(&m_pOdometryQueue));
    RETURN_IF_FAILED(RegisterPin(&m_oOdometry));

    // create and register the floor input pin
    RETURN_IF_FAILED(m_oFloorInput.Create("floor_equation", new cMediaType(0,0,0,FLOORSTRUCT), this, static_cast<ISampleQueue*>(new cSampleQueue(100000, 10))));
    RETURN_IF_FAILED(m_oFloorInput.GetSampleQueue(&m_pFloorQueue));
    RETURN_IF_FAILED(RegisterPin(&m_oFloorInput));

    // get a media type for the depth_input pin
    RETURN_IF_FAILED(m_oDepthImage.Create("depth_image", IPin::PD_Input, static_cast<IPinEventSink*>(this)));
    RETURN_IF_FAILED(RegisterPin(&m_oDepthImage));

    // create and register the output pin
   // RETURN_IF_FAILED(m_oStatusOutput.Create("status_output", new cMediaType(0,0,0,SIGNALVALUE), this));
   // RETURN_IF_FAILED(RegisterPin(&m_oStatusOutput));

    // get a media type for the video-output pin
    RETURN_IF_FAILED(m_oMapOutput.Create("obstacle_map", IPin::PD_Output, static_cast<IPinEventSink*>(this)));
    RETURN_IF_FAILED(RegisterPin(&m_oMapOutput));

    // get a media type for the debug-output pin
    //RETURN_IF_FAILED(m_oDebugOutput.Create("debug", IPin::PD_Output, static_cast<IPinEventSink*>(this)));
    //RETURN_IF_FAILED(RegisterPin(&m_oDebugOutput));

    RETURN_NOERROR;
}
