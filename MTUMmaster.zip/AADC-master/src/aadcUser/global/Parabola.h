/*
 * Parabola.h
 *
 *  Created on: Sep 13, 2015
 *      Author: cleme
 */

#ifndef LANEDETECTION_PARABOLA_H_
#define LANEDETECTION_PARABOLA_H_

#include "PolyModel.h"

class Parabola : public PolyModel {
public:
  double a,b,c;
  Parabola(double a, double b, double c);
  ~Parabola(){};

  static int minRequired();
  double distance(cv::Point2d pt);
  double getY(double x);
    double getM(double x);
    double getKappa(double x);
    double getKappaDash(double x);
  void draw(cv::Mat mat, cv::Scalar color);
    int getType();
};

#endif /* LANEDETECTION_PARABOLA_H_ */
