//
// Created by clemens on 21.10.15.
//

#ifndef AADC_USER_MODEL_H
#define AADC_USER_MODEL_H

#undef __USE_SVID
#undef __USE_MISC
#include <opencv/cv.h>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>

using namespace cv;
using namespace std;

class Model {
public:
    double quality;
    vector<Point2d> supporting;
    cv::Point2d nearest;
    virtual double distance(cv::Point2d pt) = 0;
    virtual double getY(double x) = 0;
    virtual void draw(cv::Mat mat, cv::Scalar color) = 0;
    virtual int getType() = 0;
};


#endif //AADC_USER_MODEL_H
