/*
 * Ransac.h
 *
 *  Created on: Sep 18, 2015
 *      Author: cleme
 */

#ifndef LANEDETECTION_RANSAC_H_
#define LANEDETECTION_RANSAC_H_

#include "Parabola.h"
#include "Line.h"
#include "Circle.h"
#include <random>
#include <type_traits>
#include <functional>

using namespace std;
using namespace cv;

class Ransac {
private:
    std::default_random_engine generator;
    vector<Point2d> findDifferentRandom(int count, vector<Point2d> pts);
public:
    Ransac();
    vector<Point2d> fixModel(vector<Point2d> points, Model *pModel, double d, Point2d *origin, Point2d **start,
                             Point2d **end);
    vector<Parabola*> match(vector<Point2d> pts, double maxDistanceToSupport, unsigned int maxIterations, unsigned int minMatches);
    vector<Line*> matchLine(vector<Point2d> pts, double maxDistanceToSupport, unsigned int maxIterations, unsigned int minMatches);
    vector<Circle*> matchCircle(vector<Point2d> pts, double maxDistanceToSupport, unsigned int maxIterations, unsigned int minMatches);
    vector<Circle*> matchCircleWith(vector<Point2d> pts, Point2d point, double maxDistanceToSupport,
                                            unsigned int maxIterations, unsigned int minMatches, double maxOffsetX, double maxOffsetY);
    vector<Model*> matchModel(vector<Point2d> pts, double maxDistanceToSupport, unsigned int maxIterations, unsigned int minMatches);
    void stabilizeLeastSquares(Parabola* model);
    void stabilizeLeastSquares(Line* model);
    void stabilizeLeastSquares(Model* model);
    void getSupportingPoints(Model* pModel, vector<Point2d> pts, double maxDistanceToSupport);
    vector<Point2d> getNonSupportingPoints(Model* pModel, vector<Point2d> pts, double maxDistanceToSupport);
    vector<Point2d> getNonSupportingPoints(Line* p, vector<Point2d> pts, double maxDistanceToSupport);

    double getRandom(double min, double max);

    vector<Line *> matchLineWith(vector<Point2d> pts, Point2d point, double maxDistanceToSupport,
                                 unsigned int maxIterations, unsigned int minMatches, double maxOffsetX, double maxOffsetY);

    vector<Model*> matchModelWith(vector<Point2d> pts, Point2d point, double maxDistanceToSupport, unsigned int maxIterations,
                                          unsigned int minMatches, double maxXOffset, double maxYOffset);

    vector<Model*> matchModelWith2(vector<Point2d> pts, Point2d point, double slope, double maxDistanceToSupport, unsigned int maxIterations,
                                  unsigned int minMatches, double maxXOffset, double maxYOffset);

    vector<Parabola *> matchParabolaWith(vector<Point2d> pts, Point2d point, double maxDistanceToSupport,
                                         unsigned int maxIterations, unsigned int minMatches, double maxOffsetX,
                                         double maxOffsetY);

    vector<Parabola *> matchParabolaWithSlope(vector<Point2d> pts, Point2d point, double Slope, double maxDistanceToSupport,
                                         unsigned int maxIterations, unsigned int minMatches, double maxOffsetX,
                                         double maxOffsetY);

    vector<Point2d> fixModel(vector<Point2d> points, Model *pModel, double d, Point2d *origin, Point2d **start,
                             Point2d **end, Point2d **crossingCenter);
};



#endif /* LANEDETECTION_RANSAC_H_ */
