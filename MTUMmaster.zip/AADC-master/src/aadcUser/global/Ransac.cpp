/*
 * Ransac.cpp
 *
 *  Created on: Sep 18, 2015
 *      Author: cleme
 */
#include <opencv2/core.hpp>
#include <iostream>
#include "Ransac.h"

using namespace std;


struct LengthSort {

    double length2d(Point2d pt) {
        return sqrt(pt.x*pt.x+pt.y*pt.y);
    }

    Point2d center;
    LengthSort(Point2d center) { this->center = center; }
    bool operator () ( Point2d pt1, Point2d pt2) { return length2d(pt1-center) < length2d(pt2-center); }
};


Ransac::Ransac() {
}

double length(Point2d pt) {
    return sqrt(pt.x*pt.x+pt.y*pt.y);
}

vector<Point2d> Ransac::findDifferentRandom(int count, vector<Point2d> pts) {
  vector<Point2d> result;

  if(pts.size() < count)
    return result;
  if(pts.size() == count)
    return result;

  uniform_int_distribution<int> distribution(0, pts.size()-1);

  vector<int> used;
  for(int i = 0; i < count; i++) {

    int nextIndex;
    do {
      nextIndex = distribution(generator);
    } while (find(used.begin(), used.end(), nextIndex) != used.end());
    used.push_back(nextIndex);
    result.push_back(pts[nextIndex]);
  }
  return result;
}

vector<Parabola*> Ransac::match(vector<Point2d> pts, double maxDistanceToSupport,
                    unsigned int maxIterations, unsigned int minMatches) {

  Mat src(Parabola::minRequired(), 3, CV_64F);
  Mat src2(Parabola::minRequired(), 1, CV_64F);
  Mat dst;

  vector<Parabola*> result;
  for(int i = 0; i < maxIterations; i++) {
    // Get random points
    vector<Point2d> points = findDifferentRandom(Parabola::minRequired(), pts);

    // Calculate the resulting parabola
    for(unsigned int i = 0; i < points.size(); i++) {
      Point2d pt = points[i];
      src.at<double>(i,0) = pt.y*pt.y;
      src.at<double>(i,1) = pt.y;
      src.at<double>(i,2) = 1;
      src2.at<double>(i,0) = pt.x;
    }

    solve(src, src2, dst);

    Parabola* model = new Parabola(dst.at<double>(0,0), dst.at<double>(1,0), dst.at<double>(2,0));


    getSupportingPoints(model, pts, maxDistanceToSupport);

    if(model->supporting.size() >= minMatches) {
      model->quality = model->supporting.size();
      result.push_back(model);
    } else {
        delete model;
    }
  }
  return result;
}

vector<Parabola*> Ransac::matchParabolaWith(vector<Point2d> pts, Point2d point, double maxDistanceToSupport,
                    unsigned int maxIterations, unsigned int minMatches, double maxOffsetX, double maxOffsetY) {

  Mat src(Parabola::minRequired(), 3, CV_64F);
  Mat src2(Parabola::minRequired(), 1, CV_64F);
  Mat dst;

  vector<Parabola*> result;
  for(int i = 0; i < maxIterations; i++) {
    // Get random points
    vector<Point2d> points = findDifferentRandom(Parabola::minRequired()-1, pts);
      points.push_back(point + Point2d(getRandom(-maxOffsetX, maxOffsetX), getRandom(-maxOffsetY, maxOffsetY)));
    // Calculate the resulting parabola
    for(unsigned int i = 0; i < points.size(); i++) {
      Point2d pt = points[i];
      src.at<double>(i,0) = pt.y*pt.y;
      src.at<double>(i,1) = pt.y;
      src.at<double>(i,2) = 1;
      src2.at<double>(i,0) = pt.x;
    }

    solve(src, src2, dst);

    Parabola* model = new Parabola(dst.at<double>(0,0), dst.at<double>(1,0), dst.at<double>(2,0));


    getSupportingPoints(model, pts, maxDistanceToSupport);
    int size = model->supporting.size();
    if(model->supporting.size() >= minMatches) {
        sort(model->supporting.begin(), model->supporting.end(), LengthSort(point));
        model->nearest = Point2d(model->supporting[0]);

        model->quality = model->supporting.size();
      result.push_back(model);
    } else {
        delete model;
    }
  }
  return result;
}



vector<Parabola*> Ransac::matchParabolaWithSlope(vector<Point2d> pts, Point2d point, double slope, double maxDistanceToSupport,
                                            unsigned int maxIterations, unsigned int minMatches, double maxOffsetX, double maxOffsetY) {

    Mat src(Parabola::minRequired(), 3, CV_64F);
    Mat src2(Parabola::minRequired(), 1, CV_64F);
    Mat dst;

    vector<Parabola*> result;
    for(int i = 0; i < maxIterations; i++) {
        // Get random points
        vector<Point2d> points = findDifferentRandom(Parabola::minRequired()-2, pts);
        points.push_back(point + Point2d(getRandom(-maxOffsetX, maxOffsetX), getRandom(-maxOffsetY, maxOffsetY)));
        // Calculate the resulting parabola
        for(unsigned int i = 0; i < points.size(); i++) {
            Point2d pt = points[i];
            src.at<double>(i,0) = pt.y*pt.y;
            src.at<double>(i,1) = pt.y;
            src.at<double>(i,2) = 1;
            src2.at<double>(i,0) = pt.x;
        }

        src.at<double>(2,0) = 2 * points.back().y;
        src.at<double>(2,1) = 1;
        src.at<double>(2,2) = 0;

        //double slopeOffset = abs(slope - tan(atan(slope)+1));

        src2.at<double>(2,0) = slope; //  getRandom(-slopeOffset, slopeOffset);


        solve(src, src2, dst);

        Parabola* model = new Parabola(dst.at<double>(0,0), dst.at<double>(1,0), dst.at<double>(2,0));


        getSupportingPoints(model, pts, maxDistanceToSupport);

        if(model->supporting.size() >= minMatches) {
            sort(model->supporting.begin(), model->supporting.end(), LengthSort(point));
            model->nearest = Point2d(model->supporting[0]);

            model->quality = model->supporting.size();
            result.push_back(model);
        } else {
            delete model;
        }
    }
    return result;
}

vector<Line*> Ransac::matchLine(vector<Point2d> pts, double maxDistanceToSupport,
                                unsigned int maxIterations, unsigned int minMatches) {

    vector<Line*> result;
    for(int i = 0; i < maxIterations; i++) {
        // Get random points
        vector<Point2d> points = findDifferentRandom(Line::minRequired(), pts);

        if(points.size() < Line::minRequired())
            continue;

        Line* model = new Line(Point2d(points[0].y, points[0].x), Point2d(points[1].y, points[1].x));

        getSupportingPoints(model, pts, maxDistanceToSupport);
        if(model->supporting.size() >= minMatches) {
            model->quality = model->supporting.size();
            result.push_back(model);
        } else {
            delete model;
        }
    }
    return result;
}

vector<Line*> Ransac::matchLineWith(vector<Point2d> pts, Point2d point, double maxDistanceToSupport,
                                unsigned int maxIterations, unsigned int minMatches, double maxOffsetX, double maxOffsetY) {

    vector<Line*> result;
    for(int i = 0; i < maxIterations; i++) {
        // Get random points
        vector<Point2d> points = findDifferentRandom(Line::minRequired()-1, pts);
        points.push_back(point + Point2d(getRandom(-maxOffsetX, maxOffsetX), getRandom(-maxOffsetY, maxOffsetY)));

        if(points.size() < Line::minRequired())
            continue;

        Line* model = new Line(Point2d(points[0].y, points[0].x), Point2d(points[1].y, points[1].x));


        getSupportingPoints(model, pts, maxDistanceToSupport);
        if(model->supporting.size() >= minMatches) {
            sort(model->supporting.begin(), model->supporting.end(), LengthSort(point));
            model->nearest = Point2d(model->supporting[0]);


            model->quality = model->supporting.size();
            result.push_back(model);
        } else {
            delete model;
        }
    }
    return result;
}


vector<Circle*> Ransac::matchCircle(vector<Point2d> pts, double maxDistanceToSupport,
                                unsigned int maxIterations, unsigned int minMatches) {
    vector<Circle*> result;
    for(int i = 0; i < maxIterations; i++) {
        // Get random points
        vector<Point2d> points = findDifferentRandom(Circle::minRequired(), pts);

        if(points.size() < Circle::minRequired())
            continue;

        // Calculate the radius of the circle
        double a = length(points[1]-points[0]);
        double b = length(points[2]-points[1]);
        double c = length(points[2]-points[0]);
        double s = (a+b+c)/2;
        double A = sqrt(s*(s-a)*(s-b)*(s-c));
        double r = (a*b*c)/(4*A);

        if(r < 200)
            continue;

        // Calculate the center of the circle
        Point2d p1 = (points[0]+points[1])/2;
        Point2d p2 = (points[1]+points[2])/2;

        Point2d n1 = points[1]-points[0];
        Point2d n2 = points[2]-points[1];

        double a1 = n1.x;
        double b1 = n1.y;
        double c1 = p1.x*n1.x+p1.y*n1.y;

        double a2 = n2.x;
        double b2 = n2.y;
        double c2 = p2.x*n2.x+p2.y*n2.y;

        double xs = (c1*b2-c2*b1)/(a1*b2-a2*b1);
        double ys = (a1*c2-a2*c1)/(a1*b2-a2*b1);

        Circle* model = new Circle(xs, ys, r);

        getSupportingPoints(model, pts, maxDistanceToSupport);
        if(model->supporting.size() >= minMatches) {
            model->quality = model->supporting.size();
            result.push_back(model);
        } else {
            delete model;
        }
    }
    return result;
}

vector<Model*> Ransac::matchModel(vector<Point2d> pts, double maxDistanceToSupport, unsigned int maxIterations,
                                  unsigned int minMatches) {
    vector<Model*> result;
    vector<Line*> lines = matchLine(pts, maxDistanceToSupport, maxIterations/2, minMatches);
    //vector<Circle*> circles = matchCircle(pts, maxDistanceToSupport, maxIterations/2, minMatches);
    vector<Parabola*> parabolas = match(pts, maxDistanceToSupport, maxIterations/2, minMatches);

    result.insert(result.end(), lines.begin(), lines.end());
    //result.insert(result.end(), circles.begin(), circles.end());
    result.insert(result.end(), parabolas.begin(), parabolas.end());
    std::shuffle(result.begin(), result.end(), generator);
    return result;
}

vector<Model*> Ransac::matchModelWith(vector<Point2d> pts, Point2d point, double maxDistanceToSupport, unsigned int maxIterations,
                                  unsigned int minMatches, double maxXOffset, double maxYOffset) {
    vector<Model*> result;
    vector<Line*> lines = matchLineWith(pts, point, maxDistanceToSupport, maxIterations/2, minMatches, maxXOffset, maxYOffset);
    //vector<Circle*> circles = matchCircleWith(pts, point, maxDistanceToSupport, maxIterations/2, minMatches, maxXOffset, maxYOffset);
    vector<Parabola*> parabolas = matchParabolaWith(pts, point, maxDistanceToSupport, maxIterations/2, minMatches, maxXOffset, maxYOffset);
    result.insert(result.end(), lines.begin(), lines.end());
    //result.insert(result.end(), circles.begin(), circles.end());
    result.insert(result.end(), parabolas.begin(), parabolas.end());
    std::shuffle(result.begin(), result.end(), generator);
    return result;
}

vector<Model*> Ransac::matchModelWith2(vector<Point2d> pts, Point2d point, double slope, double maxDistanceToSupport, unsigned int maxIterations,
                                      unsigned int minMatches, double maxXOffset, double maxYOffset) {

    vector<Model*> result;
    //vector<Line*> lines = matchLineWith(pts, point, maxDistanceToSupport, maxIterations/2, minMatches, maxXOffset, maxYOffset);
    //vector<Circle*> circles = matchCircleWith(pts, point, maxDistanceToSupport, maxIterations/2, minMatches, maxXOffset, maxYOffset);
    vector<Parabola*> parabolas = matchParabolaWithSlope(pts, point, slope, maxDistanceToSupport, maxIterations/2, minMatches, maxXOffset, maxYOffset);
    //result.insert(result.end(), lines.begin(), lines.end());
    //result.insert(result.end(), circles.begin(), circles.end());
    result.insert(result.end(), parabolas.begin(), parabolas.end());
    //std::shuffle(result.begin(), result.end(), generator);
    return result;
}



vector<Circle*> Ransac::matchCircleWith(vector<Point2d> pts, Point2d point, double maxDistanceToSupport,
                                unsigned int maxIterations, unsigned int minMatches, double maxOffsetX, double maxOffsetY) {
    vector<Circle*> result;
    for(int i = 0; i < maxIterations; i++) {
        // Get random points
        vector<Point2d> points = findDifferentRandom(Circle::minRequired()-1, pts);
        points.push_back(point + Point2d(getRandom(-maxOffsetX, maxOffsetX), getRandom(-maxOffsetY, maxOffsetY)));
        if(points.size() < Circle::minRequired())
            continue;

        // Calculate the radius of the circle
        double a = length(points[1]-points[0]);
        double b = length(points[2]-points[1]);
        double c = length(points[2]-points[0]);
        double s = (a+b+c)/2;
        double A = sqrt(s*(s-a)*(s-b)*(s-c));
        double r = (a*b*c)/(4*A);

        if(r < 200)
            continue;

        // Calculate the center of the circle
        Point2d p1 = (points[0]+points[1])/2;
        Point2d p2 = (points[1]+points[2])/2;

        Point2d n1 = points[1]-points[0];
        Point2d n2 = points[2]-points[1];

        double a1 = n1.x;
        double b1 = n1.y;
        double c1 = p1.x*n1.x+p1.y*n1.y;

        double a2 = n2.x;
        double b2 = n2.y;
        double c2 = p2.x*n2.x+p2.y*n2.y;

        double xs = (c1*b2-c2*b1)/(a1*b2-a2*b1);
        double ys = (a1*c2-a2*c1)/(a1*b2-a2*b1);

        Circle* model = new Circle(xs, ys, r);

        getSupportingPoints(model, pts, maxDistanceToSupport);

        if(model->supporting.size() >= minMatches) {
            sort(model->supporting.begin(), model->supporting.end(), LengthSort(point));
            model->nearest = Point2d(model->supporting[0]);

            model->quality = model->supporting.size();
            result.push_back(model);
        } else {
            delete model;
        }
    }
    return result;
}


void Ransac::stabilizeLeastSquares(Parabola* model) {
    Mat src(model->supporting.size(), 3, CV_64F);
    Mat src2(model->supporting.size(), 1, CV_64F);
    Mat dst;

    for(unsigned int i = 0; i < model->supporting.size(); i++) {
        Point2d pt = model->supporting[i];
        src.at<double>(i,0) = pt.y*pt.y;
        src.at<double>(i,1) = pt.y;
        src.at<double>(i,2) = 1;
        src2.at<double>(i,0) = pt.x;
    }

    solve(src, src2, dst, DECOMP_SVD);


    model->a = dst.at<double>(0,0);
    model->b = dst.at<double>(1,0);
    model->c = dst.at<double>(2,0);

    model->quality = model->supporting.size();

}

void Ransac::stabilizeLeastSquares(Line* model) {

    Mat src(model->supporting.size(), 2, CV_64F);
    Mat src2(model->supporting.size(), 1, CV_64F);
    Mat dst;

    for(unsigned int i = 0; i < model->supporting.size(); i++) {
        Point2d pt = model->supporting[i];
        src.at<double>(i,0) = pt.y;
        src.at<double>(i,1) = -1;
        src2.at<double>(i,0) = -pt.x;
    }

    solve(src, src2, dst, DECOMP_SVD);


    double newN1 = dst.at<double>(0,0);
    double newD = dst.at<double>(1,0);
    double newN2 = 1;

    model->m = -newN1;
    model->t = newD;

    double length = sqrt(newN1*newN1+newN2*newN2);
    newN1 /= length;
    newN2 /= length;
    newD /= length;


    model->n[0] = newN1;
    model->n[1] = newN2;
    model->d = newD;

    model->quality = model->supporting.size();
}

void Ransac::stabilizeLeastSquares(Model* model) {
    if(Line* l = dynamic_cast<Line*>(model)) {
        stabilizeLeastSquares(l);
    } else if(Parabola* p = dynamic_cast<Parabola*>(model)) {
        stabilizeLeastSquares(p);
    }
}

void Ransac::getSupportingPoints(Model*pModel, vector<Point2d> pts,
    double maxDistanceToSupport) {
  pModel->supporting.clear();
  for(unsigned int i = 0; i < pts.size(); i++) {
    if(abs(pModel->distance(pts[i])) <= maxDistanceToSupport) {
        pModel->supporting.push_back(Point2d(pts[i]));
    }
  }
}

double Ransac::getRandom(double min, double max) {
    uniform_real_distribution<double>distribution(min, max);
    return distribution(generator);
}

vector<Point2d> Ransac::getNonSupportingPoints(Line *p, vector<Point2d> pts, double maxDistanceToSupport) {
    vector<Point2d> result;
    for(unsigned int i = 0; i < pts.size(); i++) {
        if(p->distance(pts[i]) > maxDistanceToSupport) {
            result.push_back(Point2d(pts[i]));
        }
    }
    return result;
}

vector<Point2d> Ransac::getNonSupportingPoints(Model *p, vector<Point2d> pts, double maxDistanceToSupport) {
    vector<Point2d> result;
    for(unsigned int i = 0; i < pts.size(); i++) {
        if(p->distance(pts[i]) > maxDistanceToSupport) {
            result.push_back(Point2d(pts[i]));
        }
    }
    return result;
}


// Deletes all points from the vector that are too distant from the start of the line (0,0)
vector<Point2d> Ransac::fixModel(vector<Point2d> points, Model *pModel, double d, Point2d *origin, Point2d **start, Point2d **end) {
    if(points.size() < 2)
        return points;

    Point2d center = Point2d(0,0);

    if(origin != NULL)
        center = *origin;

    sort(points.begin(), points.end(), LengthSort(center));

    vector<Point2d> gapPoints;
    if(origin != NULL && norm(points[0]-center) > 2*d) {
        if(start != NULL) {
            *start = NULL;
        }
        if(end != NULL) {
            *end = NULL;
        }
        return gapPoints;
    }


    bool endValid = false;
    Point2d endPoint;
    for(int i = 1; i < points.size(); i++) {
        double distance = max(norm(points[i] - points[i-1]), norm(points[i]-Point2d(pModel->getY(points[i].y),points[i].y)));
        if(distance <= d) {
            if(distance >= d/3.0)
                gapPoints.push_back(Point2d(points[i]));
            endPoint = points[i];
            endValid = true;
        } else {
            break;
        }
    }
    if(start != NULL) {
        (*start) = new Point2d(points[0]);
    }
    if(end != NULL) {
        if(endValid) {
            (*end) = new Point2d(endPoint);
        } else {
            (*end) = new Point2d(**start);
        }
    }
    return gapPoints;
}