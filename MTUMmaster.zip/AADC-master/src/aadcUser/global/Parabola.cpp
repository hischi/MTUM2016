/*
 * Parabola.cpp
 *
 *  Created on: Sep 13, 2015
 *      Author: cleme
 */
#include <opencv2/core.hpp>
#include <opencv2/imgproc.hpp>
#include <iostream>
#include "Parabola.h"


using namespace std;
using namespace cv;

  Parabola::Parabola(double a, double b, double c) {
    /*Mat src(points.size(), 3, CV_64F);
    Mat result(points.size(), 1, CV_64F);
    for(int i = 0; i < points.size(); i++) {
      Point2d pt = points[i];
      src.at<double>(i,0) = pt.y*pt.y;
      src.at<double>(i,1) = pt.y;
      src.at<double>(i,2) = 1;
      result.at<double>(i,0) = pt.x;
    }
    Mat dst;

    if(points.size() == minRequired()) {
      solve(src, result, dst);
    } else {
      solve(src, result, dst, DECOMP_SVD);
    }

    a = dst.at<double>(0,0);
    b = dst.at<double>(1,0);
    c = dst.at<double>(2,0);*/
    this->a = a;
    this->b = b;
    this->c = c;
  }

  int Parabola::minRequired() {
    return 3;
  }

  double Parabola::distance(Point2d pt) {
    return abs(pt.x - getY(pt.y));
  }

  double Parabola::getY(double x) {
   // cout << "a: " << a << " b: " << b << " c: " << c << endl;

    return a*x*x+b*x+c;
  }

  void Parabola::draw(Mat mat, Scalar color) {
      for(int x = 0; x < 500; x++) {
          circle(mat, .5*Point2d(getY(x),x) + Point2d(250,250), 1, color);
      }
  }

double Parabola::getM(double x) {
  return 2*a*x + b;
}

double Parabola::getKappa(double x) {
double m = getM(x);

return ((2*a) / (pow((1+m*m),1.5)));

}

double Parabola::getKappaDash(double x) {
  double m = getM(x);

  return (12*a*a*m) / (pow((m*m+1),2.5));

}



int Parabola::getType() {
  return 2;
}
