//
// Created by clemens on 21.10.15.
//

#ifndef AADC_USER_POLYMODEL_H
#define AADC_USER_POLYMODEL_H

#include "Model.h"

class PolyModel : public Model {
public:
    virtual double getM(double x) = 0;
    virtual double getKappa(double x) = 0;
    virtual double getKappaDash(double x) = 0;
};


#endif //AADC_USER_POLYMODEL_H
