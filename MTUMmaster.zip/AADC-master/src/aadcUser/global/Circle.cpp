/*
 * Parabola.cpp
 *
 *  Created on: Sep 13, 2015
 *      Author: cleme
 */
#include <opencv2/core.hpp>
#include <opencv2/imgproc.hpp>
#include <iostream>
#include "Circle.h"

using namespace std;
using namespace cv;

  Circle::Circle(double cx, double cy, double r) {
    this->cx = cy;
    this->cy = cx;
    this->r = r;
  }

  int Circle::minRequired() {
    return 3;
  }

  double Circle::distance(Point2d pt) {
    return abs(sqrt((pt.y-cx)*(pt.y-cx)+(pt.x-cy)*(pt.x-cy)) - r);
  }

  void Circle::draw(Mat mat, Scalar color) {
      //circle(mat, Point2d(cy,cx), r, color);
  }


double Circle::getY(double x) {
  // We can "calculate" a y value for points in the circle only
  if(abs(x - cx) > r) {
    return 99999;
  }

  double temp = r*r-(cx-x)*(cx-x);
  if(temp <= 0) {
    cout << "CIRCLE:ERR:CANNOT GET Y!" << endl;
    return 999999;
  }
  return -sqrt(temp) + cy;
}

double Circle::getKappa(double x) {
  return 1/r;
}

int Circle::getType() {
  return 3;
}
