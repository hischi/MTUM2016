/*
 * Parabola.h
 *
 *  Created on: Sep 13, 2015
 *      Author: cleme
 */

#ifndef LANEDETECTION_LINE_H_
#define LANEDETECTION_LINE_H_

#include "PolyModel.h"

class Line : public PolyModel {
public:
    Vec2d n;
    double m, t, d;
    Point2d pt1, pt2;
  Line(Point2d pt1, Point2d pt2);
  ~Line(){};
  static int minRequired();
  double distance(cv::Point2d pt);
  double getY(double x);
  double getX(double y);
  double getM(double x);
    double getKappa(double x);
    double getKappaDash(double x);
  void draw(cv::Mat mat, cv::Scalar color);
    int getType();
};

#endif /* LANEDETECTION_LINE_H_ */
