/*
 * Parabola.cpp
 *
 *  Created on: Sep 13, 2015
 *      Author: cleme
 */
#include <opencv2/core.hpp>
#include <opencv2/imgproc.hpp>
#include <iostream>
#include "Line.h"

using namespace std;
using namespace cv;

  Line::Line(Point2d pt1, Point2d pt2) {
    this->pt1 = pt1;
    this->pt2 = pt2;

    Point2d dir = pt2-pt1;
    Point2d nv(-dir.y, dir.x);
    if(pt1.dot(nv) >= 0) {
      this->n = nv/norm(nv);
    } else {
      this->n = nv/-norm(nv);
    }


    this->d = pt1.dot(this->n);

    if(abs(dir.x) > 0.1) {
      this->m = dir.y/dir.x;
    } else {
      this->m = 10000;
    }
    this->t = pt1.y - m*pt1.x;
  }

  int Line::minRequired() {
    return 2;
  }

  double Line::distance(Point2d pt) {
    return abs(Point2d(pt.y, pt.x).dot(n)-d);
  }

  double Line::getY(double x) {
    return m*x+t;
  }

  double Line::getX(double y) {
    return (y-t)/m;
  }

  void Line::draw(Mat mat, Scalar color) {
      for(int x = 0; x < mat.rows; x++) {
          circle(mat, .5*Point2d(getY(x),x)+Point2d(250,250), 1, color);
      }
  }

double Line::getM(double x) {
  return m;
}

double Line::getKappa(double x) {
  return 0;
}

double Line::getKappaDash(double x) {
  return 0;
}

int Line::getType() {
  return 1;
}
