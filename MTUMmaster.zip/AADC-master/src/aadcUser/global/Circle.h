/*
 * Parabola.h
 *
 *  Created on: Sep 13, 2015
 *      Author: cleme
 */

#ifndef LANEDETECTION_CIRCLE_H_
#define LANEDETECTION_CIRCLE_H_

#include "Model.h"

class Circle : public Model {
public:
  double cx, cy, r;
  Circle(double cx, double cy, double r);
    ~Circle(){};
  static int minRequired();
  double distance(cv::Point2d pt);
  void draw(cv::Mat mat, cv::Scalar color);
    double getY(double x);
    double getKappa(double x);
    int getType();
};

#endif /* LANEDETECTION_LINE_H_ */
