#ifndef _CAR_GEOMETRY_H_
#define _CAR_GEOMETRY_H_


//*************************************************************************************************

#define CAR_AXIS2AXIS 36
#define CAR_R_AXIS2CAMERA 28
#define CAR_WIDTH 30
#define CAR_FRONTAXIS2FRONT 13
#define CAR_REARAXIS2REAR 11
#define CAR_LENGTH (CAR_FRONTAXIS2FRONT + CAR_REARAXIS2REAR + CAR_AXIS2AXIS)

#define CAR_REARAXIS2CAM 28.0
#define CAR_REARAXIS2FRONTBUMPER 48.0

#define CAR_AXIS2AXIS_M 0.36

#define CAM_ANGLE_V 46
#define CAM_ANGLE_H 58

//*************************************************************************************************
#endif // _CAR_GEOMETRY_H_
