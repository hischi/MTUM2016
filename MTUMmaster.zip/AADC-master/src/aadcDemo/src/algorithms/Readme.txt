In diesem Ordner sind die Sourcen enthalten.

Folders:
*AADC_XtionCamera:	Dieser Filter liefert die Videobilder einer angeschlossenen Asus Xtion Kamera. Als Ausgang liefert er das �ber die Eigenschaften eingestellte Videoformat am Ausgang Video_RGB, ein Videobild mit niedriger Aufl�sung (320x180 30 FPS) am Pin Video_RGB_LowRes und das Tiefenbild am Pin Depth_Image mit gleichem Format wie in den Einstellungen definiert.


Files:
* CMakeLists.txt:	Datei der CMake kette
* Readme.txt:		Diese Datei