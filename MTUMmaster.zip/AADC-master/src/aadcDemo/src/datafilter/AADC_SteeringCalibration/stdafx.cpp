/**
 *
 * ADTF Demo Source.
 *
 * @file
 * Copyright &copy; Audi Electronics Venture GmbH. All rights reserved
 *
 * $Author: forchher $
 * $Date: 2015-07-28 11:23:49 +0200 (Di, 28 Jul 2015) $
 * $Revision: 37571 $
 *
 * @remarks
 *
 */
#include "stdafx.h"
