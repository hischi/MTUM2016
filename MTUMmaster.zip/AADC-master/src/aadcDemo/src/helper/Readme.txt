In diesem Ordner sind die Sourcen der helper-Filter enthalten.

Folders:
* AADC_CarVisualization: 	Dieser Filter dient zum Remote Steuern des Fahrzeugs mittels GUI auf einem Notebook. 	


Files:
* CMakeLists.txt:	Datei der CMake kette
* Readme.txt:		Diese Datei