/**
 *
 * Standard includes
 *
 * @file
 * Copyright &copy; Audi Electronics Venture GmbH. All rights reserved
 *
 * $Author: VTW8PSR $
 * $Date: 2012-07-20 11:02:58 +0200 (Fr, 20 Jul 2012) $
 * $Revision: 14107 $
 *
 */

#include "stdafx.h"
 