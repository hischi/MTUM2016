/**
 *
 * Standard includes.
 *
 * @file
 * Copyright &copy; Audi Electronics Venture GmbH. All rights reserved
 *
 * $Author: spiesra $
 * $Date: 2015-05-13 08:29:07 +0200 (Mi, 13 Mai 2015) $
 * $Revision: 35003 $
 *
 * @remarks
 *
 */
#include "stdafx.h"
