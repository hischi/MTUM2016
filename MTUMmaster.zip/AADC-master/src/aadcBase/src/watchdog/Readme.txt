In diesem Ordner sind die Sourcen der WatchDog Filter enthalten.

Folders:
*AADC_WatchdogTrigger: 	Dieser Filter sendet periodisch ein Signal an den Watchdog im Arduino. Kommt diese Signal im Arduino nicht an, wird das Relais f�r die Antriebselektronik ausgeschaltet.


Files:
* CMakeLists.txt:	Datei der CMake kette
* Readme.txt:		Diese Datei