How to install

We use one code base for all aadc arduinos. Please see coding pins to determine arduino nr.

1.Download Arduino SDK Version 1.6.5
https://www.arduino.cc/

2. Copy containing libs folders (AADC_Com, I2Cdev, MPU6050, SpeedCalibration, TimerOne)  to C:\Program Files (x86)\Arduino\libraries\

3. Open aadc.ino file, build and upload binary to arduino micro.