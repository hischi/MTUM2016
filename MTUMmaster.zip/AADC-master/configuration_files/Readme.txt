Hier werden die vom Basissystem ben�tigten xml-files hinterlegt. Diese sind entsprechend ihrer Benennung f�r die Kalibration der Sensoren oder die Konfiguration der Kamera n�tig.

Files:
* xtionSettings.xml: Konfigurationsdatei f�r die XtionCamera