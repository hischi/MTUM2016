This is the entry point of the AADC Software

Folders:
* src: Here are the source of AADC Base, AADC User and AADC Demo with all the filters and the sample code.
* bin: Here are the binaries of all the filters. User filter will also be created here.
* config: Here are the ADTF Configurations including the Example Configuration, the User Configuration and the Base Configuration.
* configuration_files: Here are severel configuration files for the camera, the calibration or the marker detection.
* description: Here are the Description-Files for the Filters saved.
* doc: Here is the source code documentation located.
